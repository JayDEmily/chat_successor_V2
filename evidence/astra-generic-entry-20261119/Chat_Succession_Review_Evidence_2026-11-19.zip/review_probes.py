"""Independent baseline probes, not an implementation or live browser test.

Run from the extracted handoff root:
    python3 -B /path/to/review_probes.py --bundle .

Only temporary local files and mocked browser/provision/process calls are used.
Expected baseline deficiencies are asserted deliberately; PASS means reproduced.
"""
from argparse import ArgumentParser
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import Mock, patch

ap = ArgumentParser()
ap.add_argument("--bundle", type=Path, required=True)
args = ap.parse_args()
BUNDLE = args.bundle.resolve()
sys.path.insert(0, str(BUNDLE / "source/integration"))
import cli
from launch_project import launch_request, read_request
from runner import cycle, initialise
from succession.core import Action, Config, Controller, Response

PROJECT = "g-p-abc123"
URL = "https://chatgpt.com/g/g-p-abc123/project"
REPO = "example-org/ordinary-project"
CHAT = "00000000-0000-0000-0000-000000000001"


class BaselineReviewProbes(unittest.TestCase):
    def config(self, **changes):
        result = dict(project=PROJECT, project_name="Example",
                      project_url=URL, repo=REPO, branch="work/prior",
                      max_unique_chats=5, run_id="review-run",
                      repo_dir_wsl="/not-used", workflow="git-handoff")
        result.update(changes)
        return result

    def held(self, base):
        state = base / "controller.json"
        config = base / "config.json"
        cfg = self.config()
        config.write_text(json.dumps(cfg))
        c = initialise(state, Config(PROJECT, REPO, cfg["branch"], 5), CHAT)
        b, reader = Mock(), Mock()
        b.observe.return_value = Response(CHAT, "held-turn", "CHAT_STATUS: ERROR",
                                         project=PROJECT)
        assert cycle(c, b, reader, cfg["run_id"], state) == Action.HOLD
        return state, config, b, reader

    def resume(self, state, config, b, reader):
        with patch.object(sys, "argv", ["cli.py", "resume", "--state", str(state),
                                       "--config", str(config)]), \
             patch("cli.create_dependencies", return_value=(b, reader)), \
             redirect_stdout(io.StringIO()):
            cli.main()

    def test_01_resume_only_never_produces_a_new_worker_turn(self):
        with TemporaryDirectory() as tmp:
            state, config, b, reader = self.held(Path(tmp))
            self.resume(state, config, b, reader)
            c = Controller.load(state)
            for _ in range(4):
                self.assertEqual(cycle(c, b, reader, "review-run", state), Action.IGNORE)
            self.assertEqual(c.state.consumed_responses, [[CHAT, "held-turn"]])
            self.assertEqual(c.unique_count, 1)
            self.assertIsNone(c.state.pending)
            b.prepare.assert_not_called()
            b.send_once.assert_not_called()

    def test_02_changed_branch_bootstraps_even_if_old_run_is_not_halted(self):
        with TemporaryDirectory() as tmp:
            base = Path(tmp)
            request = base / "request.json"
            browser, reader = Mock(), Mock()
            with patch("launch_project.provision_reader", return_value="/not-used"), \
                 patch("launch_project.resolve_project",
                       return_value=(PROJECT, "Example", URL)), \
                 patch("launch_story.create_dependencies", return_value=(browser, reader)), \
                 patch("launch_story.start_controller", return_value=1234), \
                 patch("launch_story.bootstrap") as bootstrap:
                def fake_bootstrap(cfg, state_path, _b, _r):
                    return initialise(state_path,
                                      Config(PROJECT, REPO, cfg["branch"], 5),
                                      CHAT).state.__dict__
                bootstrap.side_effect = fake_bootstrap
                for branch in ("work/prior", "work/new"):
                    request.write_text(json.dumps(
                        dict(repo=REPO, branch=branch, project_name="Example",
                             project_url=URL)))
                    launch_request(request, base)
                self.assertEqual(bootstrap.call_count, 2)
                self.assertNotEqual(bootstrap.call_args_list[0].args[1],
                                    bootstrap.call_args_list[1].args[1])
                first = Controller.load(bootstrap.call_args_list[0].args[1])
                self.assertIsNone(first.state.halted)

    def test_03_same_project_url_new_display_name_selects_new_run(self):
        with TemporaryDirectory() as tmp:
            base = Path(tmp)
            request = base / "request.json"
            with patch("launch_project.provision_reader", return_value="/not-used"), \
                 patch("launch_project.resolve_project",
                       side_effect=lambda req, state: (PROJECT, req["project_name"], URL)), \
                 patch("launch_project.launch", return_value={}) as launch:
                for name in ("Example", "Renamed Example"):
                    request.write_text(json.dumps(
                        dict(repo=REPO, branch="work/prior", project_name=name,
                             project_url=URL)))
                    launch_request(request, base)
                self.assertNotEqual(launch.call_args_list[0].args[1],
                                    launch.call_args_list[1].args[1])

    def test_04_request_does_not_accept_owner_instruction_context(self):
        with TemporaryDirectory() as tmp:
            path = Path(tmp) / "request.json"
            path.write_text(json.dumps(dict(
                repo=REPO, branch="work/prior", project_name="Example",
                owner_instruction="I approve the previously proposed repair.")))
            with self.assertRaises(ValueError):
                read_request(path)

    def test_05_receipt_is_not_checked_without_fresh_worker_completion(self):
        with TemporaryDirectory() as tmp:
            state, config, b, reader = self.held(Path(tmp))
            self.resume(state, config, b, reader)
            c = Controller.load(state)
            b.observe.return_value = None
            for _ in range(3):
                self.assertEqual(cycle(c, b, reader, "review-run", state), Action.WAIT)
            reader.read.assert_not_called()
            b.send_once.assert_not_called()

    def test_06_cli_resume_does_not_compare_loaded_config_to_saved_run(self):
        with TemporaryDirectory() as tmp:
            base = Path(tmp)
            state, config, b, reader = self.held(base)
            config.write_text(json.dumps(self.config(repo="example-org/different")))
            self.resume(state, config, b, reader)
            c = Controller.load(state)
            self.assertEqual(c.config.repo, REPO)
            self.assertIsNone(c.state.halted)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(BaselineReviewProbes)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(not result.wasSuccessful())
