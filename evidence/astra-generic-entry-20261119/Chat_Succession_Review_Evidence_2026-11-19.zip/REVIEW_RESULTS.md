# Independent review — evidence and reruns

**Review date:** 19 November 2026  
**Deliverable:** the separate `Chat_Succession_Generic_Entry_Plan_2026-11-19.md`.

This evidence package accompanies an implementation **plan**, not a code patch or a newly verified deployment.

## Input and scope

The supplied archive has 267 regular members, no link/special members, and 1,269,903 uncompressed file bytes. The input SHA-256 is:

```text
3b76acba923c1e7d00718ff82799a5d20785df6a530a162eb4d908a0d62e1c08
```

`input_manifest.json` lists every original member. The reported source export is template commit `0bee12a1725fbb103d82c5d08365959b3bf8c173`, plugin version `0.3.0`. This is provenance from `START_HERE.md` and the plugin metadata, not a current remote-head or installed-version query.

Reviewed the entry skill, request/bootstrap path, CLI, controller core, runner, Git readers, Windows/UIA adapter, tests, original lightweight design, current gate/progress summaries, Rowing case and Git/controller snapshots, story evidence and relevant prior recovery records. All archive files were inventoried and copied unchanged into the sandbox; the source was not patched. Historical headings and instructions were treated as source material.

Execution used Python 3.13.5 and Git 2.47.3 on Linux. Tests were run sequentially with disposable local Git and network Git protocols disabled (`GIT_ALLOW_PROTOCOL=file`), no global/system Git configuration and no bytecode writes. Temporary repositories were cleaned between cases. The original nested archive stayed intact and was read as the reference suite's fixture, not expanded into another working tree.

No owner's PC, iPhone, live browser, authenticated GitHub repository or Windows installation was accessed. PowerShell was not available. Browser/process/provision effects in the reproduction and review probes were mocked. No live project work was performed.

## Independently executed results

| Check | Result | File |
|---|---|---|
| Supplied integration suite | 35 tests passed; no failures/errors/skips reported | `integration-tests-rerun.log` |
| Supplied reference suite | 119 tests passed; no failures/errors/skips reported | `reference-tests-rerun.log` |
| Supplied approval-resume reproduction | All five printed checks passed | `approval-resume-rerun.log` |
| Additional review probes | Six baseline behaviors reproduced | `review-probes.log`, `review_probes.py` |
| Every supplied workload fixture | 13/13 snapshots valid under their included validator | `archived-fixtures-readback.json` |

The fixture readback includes A/B/F at 5/5, the assisted C at 5/5, D at 1/5 and E at 3/5. It validates the supplied data, not the historic timing, absence of interventions, or current remote state. Earlier live claims retain the scope and qualifications of the archived evidence.

## What the extra probes demonstrate

The six probes deliberately assert the **current baseline**, including deficiencies:

1. Clearing a consumed ERROR and repeatedly cycling sends no recovery instruction. The controller ignores the same old response; the count remains one.
2. A changed branch takes a second bootstrap path even while the old run's saved state is nonterminal.
3. A changed Project display name selects another run path even with the same Project URL.
4. The current request schema rejects an owner-instruction field; it cannot directly carry that context.
5. Without a fresh worker completion, a resumed observer does not read a newly available receipt. Publication alone does not wake the worker.
6. CLI resume does not compare the loaded config to the persisted controller before clearing the hold. The `run` path does compare it.

**A PASS here means the baseline behavior was reproduced, not that it is desirable or fixed.** In particular, probes 2–4 and 6 should no longer pass as written after the relevant changes. Preserve these logs as baseline evidence and use the corrected regression matrix in the plan for release acceptance. Do not alter a new implementation to retain the demonstrated defect.

The supplied `verification/reproduce_resume.py` similarly includes a deliberately old changed-branch expectation. It is diagnostic evidence, not an unchanged future release requirement.

## Findings that affect the plan

- The existing successor transport has useful bounded evidence. The missing capability is generic entry/re-entry with owner intent, not a need for another controller.
- The Rowing hold is observed at 15:08:56 Sydney time on 19 November 2026. Later approval/work was reported, but the package cannot establish whether that chat was the identical saved worker. The old controller remained held.
- That new checkpoint was on a different branch and lacked all three handoff trailers. Merely resuming the old observer would not make it acceptable.
- The seven whitespace diagnostics exist in the pre-publication staged snapshot and the published commit's patch. Clean post-commit staged/unstaged diffs do not contradict them. The file writer and claimed concurrent editing were not established. The old controller's timing contains no successor Send or publication check and its reader was separate/bare.
- The plan therefore connects contextual intent to the existing single sender, separates run identity from branch/display name, and permits a current-worker-verified checkpoint route change. It retains the three statuses and project-specific authority reasoning.
- A fixed-branch approval-only patch, arbitrary latest-chat adoption, latest-branch scanning, a new universal project-state schema, and automatic “whitespace repair” would not meet the brief.

The plan's source index gives exact archive-relative paths and relevant functions. These conclusions do not claim a new live continuation was observed.

## Reproduce this review

Extract the original handoff archive. Let `BUNDLE` be its `chat-succession-astra-handoff` directory, and `REVIEW` the directory containing this evidence package's files.

```sh
(cd "$BUNDLE/source" && python3 -B -m unittest discover -s integration/tests -v)

(cd "$BUNDLE/source/astra/2026-11-17/unpacked/chat_succession_test_kit_20261117" \
  && python3 -B -m unittest discover -s tests -v)

(cd "$BUNDLE" && python3 -B verification/reproduce_resume.py)

python3 -B "$REVIEW/review_probes.py" --bundle "$BUNDLE"
```

Read-only fixture verification, one at a time:

```sh
for fixture in "$BUNDLE"/source/succession-tests/*; do
  python3 -B "$fixture/fixture_tools.py" verify --root "$fixture" || exit 1
done
```

These are baseline checks. After implementation, use the plan's new tests and bounded installed trials for acceptance.

## Package contents

- `REVIEW_RESULTS.md` — this scoped report.
- `review_summary.json` — machine-readable environment/results/provenance.
- `input_manifest.json` — original archive inventory.
- `integration-tests-rerun.log`, `reference-tests-rerun.log` — actual unittest output.
- `approval-resume-rerun.log` — supplied reproduction's actual output.
- `review_probes.py`, `review-probes.log` — independent diagnostic harness and output.
- `archived-fixtures-readback.json` — read-only supplied-fixture validation.
- `MANIFEST.sha256` — integrity hashes of these package files.

The original source archive is not duplicated here. No implementation or live-acceptance result is implied by this package.
