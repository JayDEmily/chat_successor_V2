import json
from pathlib import Path
import tempfile
from account_routes import require_route, bound_config_fields, verify_saved_binding

with tempfile.TemporaryDirectory(prefix="route-coupling-") as temp:
    root = Path(temp)
    (root/"account-routing-required").touch()
    file = root/"account_routes.json"
    initial = {"install_root":str(root), "profile_path":r"C:\Mock\Chrome\Profile1",
               "chrome_app_id":"Chrome.Mock", "plugin_id":"plugin_mock_0001",
               "backend_commit":"a"*40}
    def route(entry):
        file.write_text(json.dumps({"schema":1,"accounts":{"account-a":entry}}),encoding="utf-8")
        return require_route(root,"account-a")
    original = route(initial)
    saved = bound_config_fields(original)
    changes = []
    for field, new_value in (("backend_commit","b"*40),("plugin_id","plugin_mock_0002")):
        changed = route({**initial,field:new_value})
        try:
            verify_saved_binding(saved,changed)
            outcome = "ACCEPT"
        except ValueError as exc:
            outcome = "HOLD: "+str(exc)
        changes.append({"changed_field":field,
                        "account_profile_root_unchanged":all(original[k] == changed[k]
                            for k in ("account_key","profile_path","install_root","chrome_app_id")),
                        "route_receipt_changed":original["route_receipt"] != changed["route_receipt"],
                        "saved_binding_result":outcome})
    print(json.dumps({"kind":"CHARACTERIZATION_NOT_ACCEPTANCE","changes":changes},indent=2))
