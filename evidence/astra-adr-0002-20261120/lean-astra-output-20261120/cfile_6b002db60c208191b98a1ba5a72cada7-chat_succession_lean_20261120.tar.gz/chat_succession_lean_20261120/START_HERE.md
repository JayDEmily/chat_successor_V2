# Start here

**Review date: 20 November 2026. This is an implementation handoff, not a deployment.**

Read **PROGRAM.md**. It contains the independent assessment, recommended ADR 0002
execution amendment, three gates, 23 small core leaf cards, deferred capability
work and the old-to-new coverage map.

Give the 6.0 implementer one card at a time. Do not turn the cards into a new
task-management application or require a fresh owner approval after each card.

## Contents

- `PROGRAM.md` — the one proposed work programme.
- `01_program_and_tests.patch` — adds the programme at
  `docs/astra-succession/adr-0002/LEAN_PROGRAM.md`, adds two test files and
  clarifies the old management page's stale status/next-work pointer.
  It does not change product runtime behavior.
- `02_reader_hold.patch` — L03 candidate: three added runtime lines.
- `03_pause_before_prepare.patch` — L04 candidate: four added runtime lines.
- `integration/tests/` — readable copies of the two added tests.
- `RESULTS.md` and `results/` — actual local results and source provenance.

This is not a full reconstruction of the original archive. The patches leave
omitted repository/archive members alone. The complete original and its Git
history must remain in the owner's Ubuntu/Windows workspace. No original
archive, private journal, installed backend or account was changed here.

## Apply only in a review workspace

Use the actual repository root, not the installed backend. The supplied base
is reported as `beacfae4790c2ec4f390e90ad0bd214fe6a1ef05`, with a separate
uncommitted `integration/uia_adapter.ps1` edit. Preserve that edit first; these
patches neither overwrite it nor certify it. Do not reset or force-clean it.

With `PACKAGE` set to the extracted delivery's absolute directory:

```sh
git status --short
git diff -- integration/uia_adapter.ps1

git apply --check "$PACKAGE/01_program_and_tests.patch"
git apply "$PACKAGE/01_program_and_tests.patch"
```

The new Python suite on the supplied baseline is expected to fail exactly
the early-pause and explicit-unqualified-reader cases. The native regression
is also not claimed green: it is designed to expose the known reader problem.

Review/apply each candidate as its own leaf, not as a release decision:

```sh
git apply --check "$PACKAGE/02_reader_hold.patch"
git apply "$PACKAGE/02_reader_hold.patch"

git apply --check "$PACKAGE/03_pause_before_prepare.patch"
git apply "$PACKAGE/03_pause_before_prepare.patch"

python3 -B -X utf8 -m unittest discover -s integration/tests -p test_a2_thin_loop.py -v
```

The patches were application-checked on LF files and on a Git working copy
using CRLF with `core.autocrlf=true`. Use the repository's normal line-ending
configuration. A failed patch check means inspect the source/context; do not
force-apply or normalize the whole repository. Do not copy the test files
manually *and* then apply the patch that creates them.

On Windows, from the complete checkout:

```powershell
powershell.exe -NoProfile -File integration/tests/test_a2_transcript_boundary.ps1
```

The native script loads only selected function definitions from the existing
adapter and fixture. It uses synthetic nodes, never invokes an adapter mode,
opens no Chrome window and makes no Send. The full existing native/Python
suites are still required at the relevant gate.

For the optional local characterization of upgrade coupling (not a permanent
acceptance assertion):

```sh
PYTHONPATH=integration python3 -B -X utf8 "$PACKAGE/results/route_coupling_probe.py"
```

## First 6.0 assignment

> Execute only lean L01 from LEAN_PROGRAM.md on a review copy. Run the supplied
> native regression against clean published e33ae7a and separately against
> the preserved interrupted edit. Record the actual failed assertions and
> positive controls. Do not install, Send, resume any old run, change account
> bindings, fix additional code or write another plan. Return the five-line
> result and nominate L02.

If Windows is unavailable, return that environment limitation; do not emulate
UIA and call it a native pass.

**The release remains HOLD.** Local Python success does not fix F1, establish
positive virtualized current-turn identity, or constitute phone/capacity
acceptance. Automatic stale reload is only deferred safely after L09 removes
its automatic invocation; the delivered Python patches do not implement L09.
