"""Lean ADR 0002 regressions against the existing modules; no second controller.

All browser observations/Sends are mocked. One test uses real file-only Git.
Run from the repository root:
  python3 -B -X utf8 -m unittest discover -s integration/tests -p test_a2_thin_loop.py -v

Two tests intentionally fail on the supplied baseline and pass after the
separate small Python patch. Native latest-turn correctness is NOT tested here.
"""
from dataclasses import asdict
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runner import Destination, Submitted, cycle, dispatch_prepared, initialise, inspect_state
from repo_reader import GitHandoffReader, PublishedObservation, PublishedStateError
from windows_backend import WindowsUIA
from succession.core import Action, Config, Controller, RepoView, Response
from succession.composer import ComposerObservation

PROJECT = "g-p-abc123"
REPO = "example-org/disposable"
BRANCH = "work/test"
RUN = "a" * 24
CHAT1 = "00000000-0000-0000-0000-000000000001"
CHAT2 = "00000000-0000-0000-0000-000000000002"


class ThinLoopTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="thin-loop-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.path = self.root / "controller.json"
        self.c = initialise(self.path, Config(PROJECT, REPO, BRANCH, 3), CHAT1)
        self.browser = Mock()
        self.reader = Mock()
        self.reader.read.return_value = self.publication()
        self.browser.prepare.side_effect = lambda kind, chat: Destination(
            PROJECT, chat if kind == Action.CONTINUE_CURRENT.value else None,
            ComposerObservation(editable_text="", attachments_present=False), 17, "doc-17")
        self.browser.send_once.side_effect = lambda target, message: Submitted(
            PROJECT, target.current_chat_id or CHAT2, message, True)

    def response(self, status="TASK_COMPLETE", rid="turn-1", chat=CHAT1):
        return Response(chat, rid, "CHAT_STATUS: " + status, project=PROJECT)

    def publication(self, chat=CHAT1, done=False):
        return PublishedObservation(
            RepoView(REPO, BRANCH, chat, done, None if done else "Second slice"),
            "b" * 40, RUN, "")

    def bridge(self, payload):
        bridge = WindowsUIA(PROJECT, "Disposable", Path("NOT_EXECUTED.ps1"), self.path,
                            project_url=f"https://chatgpt.com/g/{PROJECT}/project")
        bridge._invoke = Mock(return_value=payload)
        return bridge

    def test_two_workers_finish_below_cap_without_extra_dispatch(self):
        self.browser.observe.return_value = self.response()
        self.assertEqual(cycle(self.c, self.browser, self.reader, RUN, self.path), Action.WAIT)
        self.assertEqual(self.c.state.unique_chat_ids, [CHAT1, CHAT2])
        self.browser.observe.return_value = self.response(rid="turn-2", chat=CHAT2)
        self.reader.read.return_value = self.publication(CHAT2, True)
        self.assertEqual(cycle(self.c, self.browser, self.reader, RUN, self.path), Action.STOP_FINISHED)
        before = self.path.read_bytes()
        self.assertEqual(cycle(Controller.load(self.path), self.browser, self.reader, RUN, self.path),
                         Action.HOLD)
        self.browser.send_once.assert_called_once()
        self.assertEqual(self.reader.read.call_count, 2)
        self.assertEqual(self.path.read_bytes(), before)

    def test_identical_continuations_at_cap_are_distinct_events_not_replays(self):
        self.c.config = Config(PROJECT, REPO, BRANCH, 1)
        for rid in ("turn-1", "turn-2"):
            self.browser.observe.return_value = self.response("NEED_MORE_TIME", rid)
            self.assertEqual(cycle(self.c, self.browser, self.reader, RUN, self.path), Action.WAIT)
            self.c = Controller.load(self.path)
            self.assertEqual(cycle(self.c, self.browser, self.reader, RUN, self.path), Action.IGNORE)
        self.assertEqual(self.browser.send_once.call_count, 2)
        self.assertEqual(self.c.unique_count, 1)
        self.assertEqual([call.args[1] for call in self.browser.send_once.call_args_list],
                         ["Okay, continue working."] * 2)
        self.reader.read.assert_not_called()

    def test_finish_and_eligible_work_at_cap_have_different_stops(self):
        for done, expected in ((False, Action.STOP_CAP), (True, Action.STOP_FINISHED)):
            with self.subTest(done=done):
                c = Controller(Config(PROJECT, REPO, BRANCH, 1), CHAT1)
                self.browser.observe.return_value = self.response()
                self.reader.read.return_value = self.publication(done=done)
                self.assertEqual(cycle(c, self.browser, self.reader, RUN, self.path), expected)
                with self.assertRaises(ValueError):
                    Controller.load(self.path).resume_after_owner()
        self.browser.prepare.assert_not_called()
        self.browser.send_once.assert_not_called()

    def test_publication_failure_is_repaired_without_consuming_the_source(self):
        self.browser.observe.return_value = self.response()
        self.reader.read.side_effect = PublishedStateError("Injected unpublished receipt")
        with self.assertLogs(level="WARNING"):
            self.assertEqual(cycle(self.c, self.browser, self.reader, RUN, self.path), Action.HOLD)
        self.assertEqual(Controller.load(self.path).state.consumed_responses, [])
        self.browser.prepare.assert_not_called()
        self.reader.read.side_effect = None
        self.c = Controller.load(self.path)
        self.c.resume_after_owner()
        self.assertEqual(cycle(self.c, self.browser, self.reader, RUN, self.path), Action.WAIT)
        self.browser.send_once.assert_called_once()

    def test_lost_ack_restart_adopts_once_without_resending(self):
        self.browser.observe.return_value = self.response()
        self.browser.send_once.side_effect = RuntimeError("Injected acknowledgement loss")
        self.assertEqual(cycle(self.c, self.browser, self.reader, RUN, self.path), Action.HOLD)
        c = Controller.load(self.path)
        pending = asdict(c.state.pending)
        self.browser.reset_mock()
        self.assertEqual(cycle(c, self.browser, self.reader, RUN, self.path), Action.HOLD)
        self.assertEqual(self.browser.mock_calls, [])
        self.assertEqual(asdict(c.state.pending), pending)
        self.assertEqual(c.confirm(pending["action_id"], CHAT2, PROJECT).action, Action.WAIT)
        c.save(self.path)
        c = Controller.load(self.path)
        self.assertEqual(c.confirm(pending["action_id"], CHAT2, PROJECT).action, Action.IGNORE)
        self.assertEqual(c.state.unique_chat_ids, [CHAT1, CHAT2])

    def test_existing_pause_blocks_preparation_not_only_the_click(self):
        # Baseline RED: direct dispatch prepares/navigates before noticing pause.
        self.c.consume(self.response("NEED_MORE_TIME"))
        self.c.save(self.path)
        action = asdict(self.c.state.pending)
        marker = self.path.with_suffix(".pause")
        marker.write_text("pause-generation-one", encoding="utf-8")
        self.assertEqual(dispatch_prepared(self.c, self.browser, self.path), Action.HOLD)
        self.assertEqual(self.browser.mock_calls, [])
        saved = Controller.load(self.path)
        self.assertEqual(asdict(saved.state.pending), action)
        self.assertEqual(saved.unique_count, 1)
        self.assertEqual(marker.read_text(encoding="utf-8"), "pause-generation-one")
        self.assertTrue(inspect_state(self.path)["pause_acknowledged"])

    def test_pause_during_preparation_still_blocks_click(self):
        self.c.consume(self.response("NEED_MORE_TIME"))
        self.c.save(self.path)
        def prepare(_kind, _chat):
            self.path.with_suffix(".pause").write_text("late-pause", encoding="utf-8")
            return Destination(PROJECT, CHAT1, ComposerObservation(editable_text=""), 17, "doc-17")
        self.browser.prepare.side_effect = prepare
        self.assertEqual(dispatch_prepared(self.c, self.browser, self.path), Action.HOLD)
        self.browser.send_once.assert_not_called()
        self.assertEqual(Controller.load(self.path).state.pending.phase, "prepared")

    def test_explicitly_unqualified_reader_holds_instead_of_polling_forever(self):
        # Baseline RED: no deadline + this payload produces WAIT indefinitely.
        bridge = self.bridge({
            "project": PROJECT, "chat_id": CHAT1, "view_status": "observed",
            "window_handle": 17, "ready": False, "response_id": None, "text": "",
            "stop_control": False, "method": "UIA_VIRTUALIZED_UNQUALIFIED",
            "reason": "Virtualized view lacks verified absolute turn identity",
        })
        self.assertEqual(cycle(self.c, bridge, self.reader, RUN, self.path), Action.HOLD)
        saved = Controller.load(self.path)
        self.assertEqual(saved.state.consumed_responses, [])
        self.assertIsNone(saved.state.pending)
        self.assertEqual(saved.unique_count, 1)
        self.assertIn("unqualified", saved.state.halted.lower())
        self.assertIn(CHAT1, saved.state.halted)
        self.assertEqual(cycle(saved, bridge, self.reader, RUN, self.path), Action.HOLD)
        bridge._invoke.assert_called_once_with("Observe", ChatId=CHAT1)
        self.reader.read.assert_not_called()
        self.assertFalse(bridge.target_path.exists())

    def test_ordinary_streaming_still_waits_without_inventing_completion(self):
        bridge = self.bridge({
            "project": PROJECT, "chat_id": CHAT1, "ready": False, "stop_control": True,
        })
        before = self.path.read_bytes()
        self.assertEqual(cycle(self.c, bridge, self.reader, RUN, self.path), Action.WAIT)
        self.assertEqual(self.path.read_bytes(), before)
        self.reader.read.assert_not_called()
        bridge._invoke.assert_called_once_with("Observe", ChatId=CHAT1)

    def test_supported_stable_read_still_returns_the_same_response(self):
        payload = {
            "project": PROJECT, "chat_id": CHAT1, "ready": True, "role": "assistant",
            "response_id": "uia-turn-1-aaaaaaaaaaaaaaaaaaaa", "text": "CHAT_STATUS: ERROR",
            "stop_control": False, "method": "UIA_ACCESSIBILITY_TEXT",
        }
        bridge = self.bridge(payload)
        before = self.path.read_bytes()
        with patch("windows_backend.time.sleep"):
            self.assertEqual(bridge.observe(CHAT1).response_id, payload["response_id"])
        self.assertEqual(bridge._invoke.call_count, 2)
        self.assertEqual(self.path.read_bytes(), before)

    def test_missing_or_changed_owner_scope_cannot_dispatch_after_restart(self):
        self.c.consume(self.response("ERROR"))
        request_id = "c" * 24
        context = dict(request_id=request_id, instruction="Approve one test line",
                       scope="One line", pointer="README.md", worker_id=CHAT1, response_id="turn-1")
        self.c.continue_after_owner(request_id, "turn-1", "Read the private input.")
        self.c.save(self.path)
        action_id = self.c.state.pending.action_id
        owner = self.path.with_name(f"owner-{request_id}.json")
        body = json.dumps(context).encode("utf-8")
        owner.with_suffix(".sha256").write_text(hashlib.sha256(body).hexdigest(), encoding="ascii")
        for replacement in (None, json.dumps({**context, "scope": "Two lines"}).encode("utf-8")):
            with self.subTest(replacement=replacement is not None):
                if replacement is not None:
                    owner.write_bytes(replacement)
                c = Controller.load(self.path)
                c.resume_after_owner()  # Same positively unsent prepared action.
                c.save(self.path)
                self.assertEqual(dispatch_prepared(c, self.browser, self.path), Action.HOLD)
                saved = Controller.load(self.path)
                self.assertEqual(saved.state.pending.action_id, action_id)
                self.assertEqual(saved.state.pending.phase, "prepared")
                self.assertEqual(self.browser.mock_calls, [])

    def test_status_reads_do_not_mutate_journal_or_acknowledge_new_pause(self):
        from runner import owner_pause_reason
        marker = self.path.with_suffix(".pause")
        marker.write_text("first", encoding="utf-8")
        self.c.pause(owner_pause_reason(self.path))
        self.c.save(self.path)
        self.assertTrue(inspect_state(self.path)["pause_acknowledged"])
        marker.write_text("second", encoding="utf-8")
        before = self.path.read_bytes()
        status = inspect_state(self.path)
        self.assertTrue(status["pause_requested"])
        self.assertFalse(status["pause_acknowledged"])
        self.assertEqual(self.path.read_bytes(), before)
        self.assertEqual(marker.read_text(encoding="utf-8"), "second")

    def test_real_local_git_uses_published_tip_not_an_unpushed_handoff(self):
        self.assertIsNotNone(shutil.which("git"), "Local Git is required for this test")
        env = os.environ.copy()
        env.update(GIT_ALLOW_PROTOCOL="file", GIT_CONFIG_NOSYSTEM="1",
                   GIT_CONFIG_GLOBAL=os.devnull, GIT_CONFIG_SYSTEM=os.devnull,
                   GIT_TERMINAL_PROMPT="0")
        for key in list(env):
            if key in ("GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_CONFIG_PARAMETERS",
                       "GIT_CONFIG_COUNT") or key.startswith(("GIT_CONFIG_KEY_", "GIT_CONFIG_VALUE_")):
                env.pop(key)
        def git(cwd, *args):
            result = subprocess.run(
                ["git", "-c", "core.hooksPath=" + os.devnull, "-c", "commit.gpgsign=false",
                 "-c", "user.name=Offline Test", "-c", "user.email=offline@example.invalid",
                 "-C", str(cwd), *args], env=env, text=True, capture_output=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stderr)
            return result.stdout.strip()
        remote, writer, readback = (self.root / name for name in ("remote.git", "writer", "reader.git"))
        git(self.root, "init", "--bare", "--template=", str(remote))
        git(self.root, "init", "--template=", "-b", BRANCH, str(writer))
        git(writer, "remote", "add", "origin", str(remote))
        git(self.root, "init", "--bare", "--template=", str(readback))
        git(readback, "remote", "add", "origin", str(remote))
        notes = writer / "NOTES.md"
        def commit(text, chat, next_task):
            notes.write_text(text, encoding="utf-8")
            git(writer, "add", "NOTES.md")
            git(writer, "commit", "-m", "Fixture slice", "-m",
                f"Chat-Succession-Run: {RUN}\nChat-ID: {chat}\nChat-Succession-Next: {next_task}")
            return git(writer, "rev-parse", "HEAD")
        first = commit("First test line.\n", CHAT1, "Add second line")
        git(writer, "push", "origin", BRANCH)
        reader = GitHandoffReader(readback, REPO, BRANCH)
        reader._verify_origin = Mock()  # Deliberate local-remote seam, not GitHub identity evidence.
        second = commit("First test line.\nSecond test line.\n", CHAT2, "FINISHED")
        self.assertEqual(git(writer, "rev-parse", f"{second}^"), first)
        with patch.dict(os.environ, env, clear=True):
            self.assertEqual(reader.read(RUN).commit, first)
            self.browser.observe.return_value = self.response()
            self.assertEqual(cycle(self.c, self.browser, reader, RUN, self.path), Action.WAIT)
            git(writer, "push", "origin", BRANCH)
            self.assertEqual(reader.read(RUN).commit, second)
            self.browser.observe.return_value = self.response(chat=CHAT2, rid="turn-2")
            self.assertEqual(cycle(self.c, self.browser, reader, RUN, self.path), Action.STOP_FINISHED)
        self.browser.send_once.assert_called_once()
        self.assertEqual(self.c.unique_count, 2)
        self.assertEqual(git(readback, "show", f"{second}:NOTES.md"),
                         "First test line.\nSecond test line.")


if __name__ == "__main__":
    unittest.main()
