# Chat Succession — Astra review snapshot

Source pin `36b17092aa5fef09b5ac3747c03e5661be23559c` from `JayDEmily/chat_successor` on `codex/chat-succession-finish`.
The bundle uses a dedicated snapshot branch to include only the testable source,
synthetic fixtures and current review evidence. See `START-HERE.md` in the outer
archive for the review request and verified live outcome.

## Test entry points

- `python -B -X utf8 -m unittest discover -s integration/tests` runs the integration tests.
- `integration/tests/test_a2_chrome_readback.ps1` and
  `integration/tests/test_a2_l04_ps_view_helpers.ps1` use Windows PowerShell and
  synthetic UI Automation data.
- Serve the repository root on loopback HTTP and open
  `/integration/tests/test_chrome_user_message.html` in a disposable headless
  Chrome profile for the eight existing DOM checks.
- The reference kit includes the controller, synthetic fixtures and relevant
  reference tests. Its historical archive audit is outside this snapshot.
