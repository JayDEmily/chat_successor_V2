"""Run ONLY the supplied synthetic HTML + reader, in a disposable headless browser.

Normal mode uses loopback HTTP, as in README.md. --mock-route uses about:blank
with explicit location/history doubles if browser policy disallows navigation.
That mode exercises real layout/innerText/MutationObserver, NOT real URL routing,
extension injection, authenticated Chrome, Windows UIA, or a Send.
Requires an already-installed Playwright Python package and Chromium/Chrome.
Never downloads a browser, loads a user profile, or contacts an external service.
"""
from contextlib import ExitStack
import argparse
import hashlib
import http.server
import json
from pathlib import Path
import re
import shutil
import sys
import threading


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    ap.add_argument("--chrome", default=shutil.which("chromium") or shutil.which("google-chrome"))
    ap.add_argument("--reader", type=Path, help="Optional local reader copy for negative-control checks")
    ap.add_argument("--mock-route", action="store_true")
    ap.add_argument("--container-flags", action="store_true",
                    help="In-process/no-sandbox renderer for a restricted disposable Linux test container")
    ap.add_argument("--report", type=Path)
    args = ap.parse_args()
    if not args.chrome:
        ap.error("--chrome must name an installed Chromium/Chrome executable")
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        ap.error("Playwright is not installed; alternatively serve the HTML on loopback per README.md")

    fixture_path = args.root / "integration/tests/test_chrome_user_message.html"
    reader_path = args.reader or args.root / "integration/chrome_reader/readback.js"
    fixture, reader = fixture_path.read_text(encoding="utf-8"), reader_path.read_text(encoding="utf-8")
    fixture_url = "/integration/tests/test_chrome_user_message.html"
    reader_url = "/integration/chrome_reader/readback.js"
    assets = {fixture_url: ("text/html", fixture), reader_url: ("text/javascript", reader)}

    class FixtureHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path not in assets:
                self.send_error(404)
                return
            mime, body = assets[self.path]
            body = body.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", mime + "; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *_args):
            pass

    with ExitStack() as stack:
        origin = None
        if not args.mock_route:
            server = stack.enter_context(http.server.ThreadingHTTPServer(("127.0.0.1", 0), FixtureHandler))
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            stack.callback(thread.join)
            stack.callback(server.shutdown)
            origin = f"http://127.0.0.1:{server.server_port}"
        playwright = stack.enter_context(sync_playwright())
        flags = ["--disable-background-networking", "--disable-component-update",
                 "--disable-dev-shm-usage", "--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1"]
        if args.container_flags:
            flags += ["--no-sandbox", "--no-zygote", "--single-process", "--in-process-gpu"]
        browser = playwright.chromium.launch(executable_path=args.chrome, headless=True, args=flags, timeout=15000)
        stack.callback(browser.close)
        context = browser.new_context(service_workers="block")
        blocked = []

        def route(request):
            if origin and request.request.url in (origin + fixture_url, origin + reader_url):
                request.continue_()
            else:
                blocked.append(request.request.url)
                request.abort()

        context.route("**/*", route)
        page = context.new_page()
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))
        if args.mock_route:
            scripts = re.findall(r"<script>(.*?)</script>", fixture, re.S)
            if len(scripts) != 1:
                raise ValueError("Expected the published fixture's single inline test script")
            markup = re.sub(r"<script\b[^>]*>.*?</script>", "", fixture, flags=re.S)
            page.set_content(markup)
            page.evaluate("window.__fixtureRoute = {pathname: '/integration/tests/test_chrome_user_message.html'}")
            page.add_script_tag(content="((history) => {" + scripts[0] +
                "})({replaceState(_state, _title, path) { window.__fixtureRoute.pathname = path; }});")
            # The production reader bytes are unchanged; only its location input is doubled.
            page.add_script_tag(content="((location) => {" + reader + "})(window.__fixtureRoute);")
            page.evaluate("window.dispatchEvent(new Event('DOMContentLoaded'));")
        else:
            page.goto(origin + fixture_url, timeout=10000)
        page.wait_for_function("document.querySelector('#result').textContent !== 'PENDING'", timeout=10000)
        result = page.locator("#result").inner_text()
        checks = page.evaluate("window.receiptChecks || []")
        passed = bool(re.fullmatch(r"PASS: [0-9]+ Chrome user-message checks", result)) and not errors
        report = {
            "transport": "mock_location_history_no_navigation" if args.mock_route else "loopback_http",
            "browser": browser.version, "result": result, "passed": passed,
            "fixture_sha256": hashlib.sha256(fixture.encode("utf-8")).hexdigest(),
            "reader_sha256": hashlib.sha256(reader.encode("utf-8")).hexdigest(),
            "page_errors": errors, "blocked_requests": blocked, "checks": checks,
        }
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        print("transport:", report["transport"])
        print("browser:", report["browser"])
        print(result)
        print("page_errors:", errors)
        print("blocked_requests:", blocked)
        return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())