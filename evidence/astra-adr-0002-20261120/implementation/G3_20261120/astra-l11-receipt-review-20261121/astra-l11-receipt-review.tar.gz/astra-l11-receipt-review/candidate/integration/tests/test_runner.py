"""Local simulated integration checks; none are live ChatGPT evidence."""
from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runner import (
    Destination, PausedBeforeClick, Submitted, cycle, dispatch_prepared, initialise, inspect_state,
)
from succession.composer import ComposerObservation
from succession.core import Action, Config, Controller, Response, RepoView
from repo_reader import PublishedStateError


CFG = Config(project="g-p-TEST", repo="JayDEmily/chat_successor",
             branch="trial/test-run", max_unique_chats=2)


class SyntheticBrowser:
    def __init__(self, *, draft="", project=None, failure=None):
        self.draft = draft
        self.project = project or CFG.project
        self.failure = failure
        self.calls = []
        self.response = None

    def observe(self, expected_chat_id):
        self.calls.append("observe")
        return self.response

    def prepare(self, kind, current_chat_id):
        self.calls.append("prepare")
        if self.failure == "prepare":
            raise RuntimeError("Injected target failure")
        return Destination(self.project,
                           current_chat_id if kind == Action.CONTINUE_CURRENT.value else None,
                           ComposerObservation(editable_text=self.draft),
                           private_window_handle=100)

    def send_once(self, target, message):
        self.calls.append("send")
        if self.failure == "after_send":
            raise RuntimeError("Injected lost acknowledgement")
        return Submitted(self.project,
                         "chat-next" if target.current_chat_id is None else target.current_chat_id,
                         message, True)


class Reader:
    def __init__(self, *, programme_complete=False, publication=True):
        self.calls = 0
        self.programme_complete = programme_complete
        self.publication = publication

    def read(self, expected_run):
        self.calls += 1
        if not self.publication:
            raise PublishedStateError("Injected remote fetch outage")
        class O: pass
        o = O()
        o.run_id = expected_run
        o.commit = "a" * 40  # Exact synthetic fetched SHA for L05 diagnostics.
        o.view = RepoView(CFG.repo, CFG.branch, "chat-first",
                          self.programme_complete,
                          None if self.programme_complete else "Next fixture slice")
        return o


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "state.json"
        self.controller = initialise(self.path, CFG, "chat-first")

    def tearDown(self):
        self.tmp.cleanup()

    def response(self, text="CHAT_STATUS: TASK_COMPLETE", response_id="turn1", complete=True):
        return Response("chat-first", response_id, text,
                        complete=complete, project=CFG.project)

    def test_first_run_is_counted_and_never_overwritten(self):
        self.assertEqual(inspect_state(self.path)["unique_chat_count"], 1)
        with self.assertRaises(FileExistsError):
            initialise(self.path, CFG, "another")

    def test_published_task_complete_launches_once(self):
        b = SyntheticBrowser()
        b.response = self.response()
        r = Reader()
        self.assertEqual(cycle(self.controller, b, r, "test", self.path), Action.WAIT)
        self.assertEqual(self.controller.unique_count, 2)
        self.assertEqual(self.controller.state.current_chat_id, "chat-next")
        self.assertEqual(b.calls, ["observe", "prepare", "send"])
        self.assertEqual(r.calls, 1)
        self.assertEqual(Controller.load(self.path).unique_count, 2)

    def test_pause_requested_during_prepare_prevents_send(self):
        state_path = self.path

        class PausingBrowser(SyntheticBrowser):
            def prepare(self, kind, current_chat_id):
                target = super().prepare(kind, current_chat_id)
                state_path.with_suffix(".pause").write_text("Operator pause", encoding="utf-8")
                return target

        browser = PausingBrowser()
        browser.response = self.response()
        self.assertEqual(cycle(self.controller, browser, Reader(), "test", self.path), Action.HOLD)
        self.assertEqual(browser.calls, ["observe", "prepare"])
        saved = Controller.load(self.path)
        self.assertEqual(saved.state.pending.phase, "prepared")
        self.assertEqual(saved.unique_count, 1)
        self.assertEqual(state_path.with_suffix(".pause").read_text(encoding="utf-8"),
                         "Operator pause")

    def test_existing_pause_prevents_browser_preparation(self):
        self.controller.consume(self.response("CHAT_STATUS: NEED_MORE_TIME"))
        self.controller.save(self.path)
        pending = asdict(self.controller.state.pending)
        marker = self.path.with_suffix(".pause")
        marker.write_text("Pause generation one", encoding="utf-8")
        browser = SyntheticBrowser()

        self.assertEqual(dispatch_prepared(self.controller, browser, self.path), Action.HOLD)
        self.assertEqual(browser.calls, [])
        saved = Controller.load(self.path)
        self.assertEqual(asdict(saved.state.pending), pending)
        self.assertEqual(saved.unique_count, 1)
        self.assertEqual(marker.read_text(encoding="utf-8"), "Pause generation one")
        self.assertTrue(inspect_state(self.path)["pause_acknowledged"])

    def test_adapter_pause_receipt_preserves_prepared_action(self):
        class PausingBrowser(SyntheticBrowser):
            def send_once(self, target, message):
                raise PausedBeforeClick("Operator pause requested before Send")

        browser = PausingBrowser()
        browser.response = self.response()
        self.assertEqual(cycle(self.controller, browser, Reader(), "test", self.path), Action.HOLD)
        saved = Controller.load(self.path)
        self.assertEqual(saved.state.pending.phase, "prepared")
        self.assertEqual(saved.state.halted, "Operator pause requested before Send")
        self.assertEqual(saved.unique_count, 1)

    def test_l06_prepare_only_persists_unsent_handover_then_dispatches_once(self):
        b = SyntheticBrowser()
        b.response = self.response()
        reader = Reader()
        result = cycle(self.controller, b, reader, "test", self.path,
                       defer_dispatch=True)
        self.assertEqual(result, Action.LAUNCH_SUCCESSOR)
        self.assertEqual(b.calls, ["observe"])
        self.assertEqual(reader.calls, 1)
        self.assertEqual(self.controller.unique_count, 1)
        self.assertEqual(self.controller.state.pending.phase, "prepared")
        pending_id = self.controller.state.pending.action_id

        restarted = Controller.load(self.path)
        self.assertEqual(restarted.state.pending.action_id, pending_id)
        self.assertEqual(cycle(restarted, b, Reader(), "test", self.path,
                               defer_dispatch=True), Action.LAUNCH_SUCCESSOR)
        self.assertEqual(b.calls, ["observe"])
        self.assertEqual(restarted.unique_count, 1)
        self.assertEqual(cycle(restarted, b, Reader(), "test", self.path),
                         Action.WAIT)
        self.assertEqual(b.calls, ["observe", "prepare", "send"])
        self.assertEqual(restarted.unique_count, 2)
        self.assertIsNone(Controller.load(self.path).state.pending)

    def test_continuation_at_cap_does_not_create_new_chat(self):
        self.controller.config = Config(CFG.project, CFG.repo, CFG.branch, 1)
        b = SyntheticBrowser()
        b.response = self.response("CHAT_STATUS: NEED_MORE_TIME")
        self.assertEqual(cycle(self.controller, b, Reader(), "test", self.path), Action.WAIT)
        self.assertEqual(self.controller.unique_count, 1)
        self.assertEqual(b.calls.count("send"), 1)

    def test_draft_is_preserved_and_no_send(self):
        b = SyntheticBrowser(draft="New chat in Chat succession folder")
        b.response = self.response()
        self.assertEqual(cycle(self.controller, b, Reader(), "test", self.path), Action.HOLD)
        self.assertEqual(b.calls.count("send"), 0)
        self.assertEqual(self.controller.state.pending.phase, "prepared")
        self.assertIsNotNone(self.controller.state.halted)

    def test_value_only_never_proves_empty(self):
        class ValueOnlyBrowser(SyntheticBrowser):
            def prepare(self, kind, current_chat_id):
                self.calls.append("prepare")
                return Destination(CFG.project, None,
                                   ComposerObservation(uia_value="New chat",
                                                       placeholder="New chat"),
                                   100)
        b = ValueOnlyBrowser()
        b.response = self.response()
        self.assertEqual(cycle(self.controller, b, Reader(), "test", self.path), Action.HOLD)
        self.assertEqual(b.calls.count("send"), 0)

    def test_wrong_project_no_send(self):
        b = SyntheticBrowser(project="other-project")
        b.response = self.response()
        self.assertEqual(cycle(self.controller, b, Reader(), "test", self.path), Action.HOLD)
        self.assertNotIn("send", b.calls)

    def test_lost_ack_persists_uncertain_and_restart_hold(self):
        b = SyntheticBrowser(failure="after_send")
        b.response = self.response()
        self.assertEqual(cycle(self.controller, b, Reader(), "test", self.path), Action.HOLD)
        self.assertEqual(b.calls.count("send"), 1)
        restarted = Controller.load(self.path)
        self.assertEqual(restarted.state.pending.phase, "uncertain")
        self.assertIsNotNone(restarted.state.halted)
        self.assertEqual(cycle(restarted, b, Reader(), "test", self.path), Action.HOLD)
        self.assertEqual(b.calls.count("send"), 1)

    def test_publication_outage_does_not_consume_turn_before_repair(self):
        b = SyntheticBrowser()
        b.response = self.response()
        self.assertEqual(cycle(self.controller, b, Reader(publication=False),
                               "test", self.path), Action.HOLD)
        self.assertEqual(self.controller.state.consumed_responses, [])
        self.assertNotIn("send", b.calls)
        self.controller.resume_after_owner()
        self.controller.save(self.path)
        self.assertEqual(cycle(self.controller, b, Reader(), "test", self.path),
                         Action.WAIT)
        self.assertEqual(self.controller.unique_count, 2)
        self.assertEqual(b.calls.count("send"), 1)

    def test_preparation_failures_do_not_begin_send(self):
        b = SyntheticBrowser(failure="prepare")
        b.response = self.response()
        self.assertEqual(cycle(self.controller, b, Reader(), "test", self.path), Action.HOLD)
        self.assertEqual(self.controller.state.pending.phase, "prepared")

    def test_streaming_never_dispatches(self):
        b = SyntheticBrowser()
        b.response = self.response(complete=False)
        self.assertEqual(cycle(self.controller, b, Reader(), "test", self.path), Action.WAIT)
        self.assertEqual(b.calls, ["observe"])

    def test_finished_programme_stops_without_composer(self):
        b = SyntheticBrowser()
        b.response = self.response()
        self.assertEqual(cycle(self.controller, b, Reader(programme_complete=True),
                               "test", self.path), Action.STOP_FINISHED)
        self.assertEqual(b.calls, ["observe"])

    def test_duplicate_completed_response_has_no_second_send(self):
        b = SyntheticBrowser()
        b.response = self.response()
        self.assertEqual(cycle(self.controller, b, Reader(), "test", self.path), Action.WAIT)
        b.response = Response("chat-next", "turn1", "CHAT_STATUS: NEED_MORE_TIME",
                              project=CFG.project)
        self.assertEqual(cycle(self.controller, b, Reader(), "test", self.path), Action.WAIT)
        self.assertEqual(self.controller.unique_count, 2)


if __name__ == "__main__":
    unittest.main()
