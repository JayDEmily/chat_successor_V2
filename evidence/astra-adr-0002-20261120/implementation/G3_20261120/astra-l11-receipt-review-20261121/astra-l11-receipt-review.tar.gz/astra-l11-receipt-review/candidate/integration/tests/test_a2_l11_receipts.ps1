# L11 native regression: ONLY supplied synthetic UIA/receipt patterns.
# Extract functions/mode AST; never execute the adapter entry point or acquire Chrome.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName UIAutomationClient

$tokens=$null
$errors=$null
$adapter=Join-Path $PSScriptRoot '..\uia_adapter.ps1'
$tree=[Management.Automation.Language.Parser]::ParseFile($adapter,[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Windows adapter did not parse'}
foreach($name in @('Check-Project','Chat-FromUrl','Read-ChromeTurnSnapshot',
                   'Get-ChromeResponseId','Find-PostedMessage','Assert-PrivateDispatchReceipt')){
 $nodes=@($tree.FindAll({
  param($node)
  $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq $name
 },$false))
 if($nodes.Count -ne 1){throw "Missing or ambiguous function $name"}
 . ([scriptblock]::Create($nodes[0].Extent.Text))
}
$block=$tree.Find({
 param($node)
 $node -is [Management.Automation.Language.IfStatementAst] -and
   $node.Clauses[0].Item1.Extent.Text -ceq '$Mode -eq ''Reconcile'''
},$false)
if($null -eq $block){throw 'Missing Reconcile mode'}
$reconcile=[scriptblock]::Create($block.Extent.Text.Replace('exit 0','return'))

# IDs/strings and the mock readonly Edit come from test_a2_chrome_readback.ps1.
# Bound target receipt/AST technique comes from test_a2_l03_ps_action_gate.ps1.
$ProjectId='g-p-11111111111111111111111111111111'
$ChromeAppId='Chrome.UserData.Test'
$ChatId='11111111-1111-1111-1111-111111111111'
$SourceResponse='chrome-turn-22222222-2222-2222-2222-222222222222-33333333-3333-3333-3333-333333333333'
$PendingResponseId=$SourceResponse
$ProjectUrl="https://chatgpt.com/g/$ProjectId/project"
$savedUrl="https://chatgpt.com/g/$ProjectId/c/$ChatId"
$WindowHandle=[long]222
$DocumentId='42.222'
$PrepareAction='a2-action-id-1'
$RouteReceipt=''
$OwnerInputPath=''
$Mode='Reconcile'
$Kind='CONTINUE_CURRENT'
$Message='Exact submitted text'
$window=[pscustomobject]@{Current=@{NativeWindowHandle=$WindowHandle}}
$element=[pscustomobject]@{
 Current=@{Name='Chat Succession Chrome readback';ClassName='chat-succession-readback'
           ControlType=[System.Windows.Automation.ControlType]::Edit}
 Payload=''
}
$element | Add-Member ScriptMethod GetCurrentPattern {
 param($pattern)
 if($pattern -ne [System.Windows.Automation.ValuePattern]::Pattern){throw 'Only readonly Value access allowed'}
 return @{Current=@{Value=$this.Payload;IsReadOnly=$true}}
}
function Check([bool]$condition,[string]$description){
 if(-not $condition){throw "FAIL: $description"}
 Write-Output "PASS: $description"
}
function New-Snapshot {
 return @{
  project=$ProjectId;chat=$ChatId;phase='observed'
  key='44444444-4444-4444-4444-444444444444';user=$Message;userAfterAssistant=$true;reply=$null
  previous=@{key='22222222-2222-2222-2222-222222222222'
             reply=@{id='33333333-3333-3333-3333-333333333333'}}
 }
}
function Hold-Snapshot([string]$reason,[string]$phase='unqualified'){
 return @{project=$ProjectId;chat=$ChatId;phase=$phase;reason=$reason}
}
function Frame($snapshot,[long]$age=0){return @{snapshot=$snapshot;age=$age}}
function Use-Frames([object[]]$values){
 $script:frames=$values
 $script:reads=0
 $script:sleeps=0
 $script:effects=0
 $script:profileMatches=$true
 $script:address=$savedUrl
 $script:mutation=''
}
function Desc($item){
 if($item -ne $window){throw 'Only the nominated synthetic window may be read'}
 $frame=$script:frames[[Math]::Min($script:reads,$script:frames.Count-1)]
 $script:reads++
 $sample=$frame.snapshot.Clone()
 $sample.observedAt=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()-[long]$frame.age
 $element.Payload=$sample | ConvertTo-Json -Depth 6 -Compress
 return $element
}
function Get-Address($item){return $script:address}
function Test-WindowProfile($item){return $script:profileMatches}
function Get-TargetWindow([string]$expectedChat,[long]$handle){
 if($expectedChat -cne $ChatId -or $handle -ne $WindowHandle){throw 'Target identity changed'}
 return @{window=$window;chat=$ChatId;url=$script:address}
}
function Start-Sleep([int]$Milliseconds){
 if($Milliseconds -ne 400){throw 'Unexpected poll duration'}
 $script:sleeps++
 if($script:mutation -ceq 'url'){$script:address=$savedUrl+'?changed'}
 if($script:mutation -ceq 'action'){
  $changed=$record.Clone()
  $changed.action_id='stale-other-action'
  [IO.File]::WriteAllText($PrepareTargetPath,($changed | ConvertTo-Json -Compress))
 }
}
function Forbidden-Effect {$script:effects++;throw 'Read-only reconciliation attempted a browser effect'}
function Find-Composer {Forbidden-Effect}
function Find-EnabledSendButtons {Forbidden-Effect}
function Open-ChromeWindow {Forbidden-Effect}
function Recover-SavedWorkerView {Forbidden-Effect}
function Maximize-ChromeWorkerWindow {Forbidden-Effect}
$window | Add-Member ScriptMethod GetCurrentPattern {Forbidden-Effect}

$folder=Join-Path ([IO.Path]::GetTempPath()) ('l11-native-'+[guid]::NewGuid().ToString('N'))
$null=[IO.Directory]::CreateDirectory($folder)
$PrepareTargetPath=Join-Path $folder 'target.json'
$hash=[Security.Cryptography.SHA256]::Create()
try{$digest=[BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($Message))).Replace('-','').ToLowerInvariant()}
finally{$hash.Dispose()}
$record=@{action_id=$PrepareAction;project=$ProjectId;kind=$Kind;source=$ChatId
          handle=$WindowHandle;document_id=$DocumentId;message_sha256=$digest
          source_response=$PendingResponseId;route_receipt=$RouteReceipt}
[IO.File]::WriteAllText($PrepareTargetPath,($record | ConvertTo-Json -Compress))
$before=[Convert]::ToBase64String([IO.File]::ReadAllBytes($PrepareTargetPath))
try{
 Use-Frames @((Frame (New-Snapshot)))
 $positive=& $reconcile | ConvertFrom-Json
 Check ($positive.posted_message_observed -and $positive.submitted_text -ceq $Message -and
        $positive.chat_id -ceq $ChatId -and $positive.receipt_reason -ceq 'verified' -and
        $positive.receipt_attempts -eq 1 -and $script:sleeps -eq 0) 'exact anchored positive receipt'

 $missing=New-Snapshot
 $missing.previous=$null
 $missing.previousReason='turn_missing'
 foreach($frame in @(
   (Frame (Hold-Snapshot 'user_conversation_provisional')),
   (Frame (Hold-Snapshot 'assistant_conversation_provisional')),
   (Frame (Hold-Snapshot 'transcript_loading' 'loading')),
   (Frame (New-Snapshot) 6000),
   (Frame $missing)
 )){
  Use-Frames @($frame,(Frame (New-Snapshot)))
  $later=& $reconcile | ConvertFrom-Json
  Check ($later.posted_message_observed -and $later.receipt_reason -ceq 'verified' -and
         $later.receipt_attempts -eq 2 -and $script:reads -eq 2 -and $script:sleeps -eq 1 -and
         $script:effects -eq 0) 'transient becomes exact by rereading only'
 }

 foreach($case in @(
  @{frame=(Frame $missing);reason='previous_turn_missing'},
  @{frame=(Frame (New-Snapshot) 6000);reason='sample_expired'},
  @{frame=(Frame (Hold-Snapshot 'user_conversation_provisional'));reason='user_conversation_provisional'}
 )){
  Use-Frames @($case.frame)
  $held=& $reconcile | ConvertFrom-Json
  Check (-not $held.posted_message_observed -and $null -eq $held.submitted_text -and
         $held.receipt_reason -ceq $case.reason -and $held.receipt_attempts -eq 25 -and
         $script:reads -eq 25 -and $script:sleeps -eq 24 -and $script:effects -eq 0) ('bounded hold: '+$case.reason)
  Check ([Convert]::ToBase64String([IO.File]::ReadAllBytes($PrepareTargetPath)) -ceq $before) 'private target receipt is byte-identical after timeout'
 }

 $wrongAnchor=New-Snapshot
 $wrongAnchor.previous.reply.id='55555555-5555-5555-5555-555555555555'
 $wrongChat=New-Snapshot
 $wrongChat.chat='99999999-9999-9999-9999-999999999999'
 $wrongProject=New-Snapshot
 $wrongProject.project='g-p-00000000000000000000000000000000'
 $wrongText=New-Snapshot
 $wrongText.user='Exact submitted'
 $ambiguousPrevious=New-Snapshot
 $ambiguousPrevious.previous=$null
 $ambiguousPrevious.previousReason='assistant_selection_ambiguous'
 $oldMissing=New-Snapshot
 $oldMissing.previous=$null
 foreach($case in @(
  @{frame=(Frame $wrongAnchor);reason='preceding_reply_mismatch'},
  @{frame=(Frame $wrongChat);reason='snapshot_destination_mismatch'},
  @{frame=(Frame $wrongProject);reason='snapshot_destination_mismatch'},
  @{frame=(Frame $wrongText);reason='text_mismatch'},
  @{frame=(Frame $ambiguousPrevious);reason='previous_assistant_selection_ambiguous'},
  @{frame=(Frame $oldMissing);reason='preceding_reply_unverified'},
  @{frame=(Frame (New-Snapshot) -6000);reason='snapshot_time_invalid'},
  @{frame=(Frame (Hold-Snapshot 'assistant_selection_ambiguous'));reason='assistant_selection_ambiguous'},
  @{frame=(Frame (Hold-Snapshot 'transcript_offscreen' 'offscreen'));reason='transcript_offscreen'},
  @{frame=(Frame (Hold-Snapshot 'user_route_rebound'));reason='user_route_rebound'},
  @{frame=(Frame (Hold-Snapshot 'verified'));reason='verified'}
 )){
  Use-Frames @($case.frame,(Frame (New-Snapshot)))
  $held=& $reconcile | ConvertFrom-Json
  Check (-not $held.posted_message_observed -and $null -eq $held.submitted_text -and
         $held.receipt_reason -ceq $case.reason -and $held.receipt_attempts -eq 1 -and
         $script:reads -eq 1 -and $script:sleeps -eq 0 -and $script:effects -eq 0) ('no authority from a reason; immediate hold: '+$case.reason)
 }

 Use-Frames @((Frame (New-Snapshot)))
 $script:profileMatches=$false
 $held=& $reconcile | ConvertFrom-Json
 Check (-not $held.posted_message_observed -and $held.receipt_reason -ceq 'destination_changed') 'late profile mismatch cannot acknowledge'

 Use-Frames @((Frame $missing),(Frame (New-Snapshot)))
 $script:mutation='url'
 $held=& $reconcile | ConvertFrom-Json
 Check (-not $held.posted_message_observed -and $held.receipt_reason -ceq 'destination_changed' -and
        $held.receipt_attempts -eq 2 -and $script:reads -eq 1 -and $script:effects -eq 0) 'changed route cannot be adopted on a later poll'

 Use-Frames @((Frame $missing),(Frame (New-Snapshot)))
 $script:mutation='action'
 $errorMessage=''
 try{$null=& $reconcile}catch{$errorMessage=$_.Exception.Message}
 Check ($errorMessage -like '*Prepared action identity or route changed*' -and $script:reads -eq 1 -and
        $script:sleeps -eq 1 -and $script:effects -eq 0) 'private dispatch gate reruns before every read'
}finally{
 Remove-Item -LiteralPath $folder -Recurse -Force
}