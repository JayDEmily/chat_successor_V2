"""L11 receipt regressions. Synthetic fixtures only; no PowerShell/Chrome/remote IO.

Uses the runner/L09 lost-ack pattern, IDs from test_a2_chrome_readback.ps1,
and the mock CHROME_DOM sampling pattern from test_worker_view.py.
A mocked adapter receipt is not proof that the native DOM/UIA gates ran.
"""
from contextlib import redirect_stdout
from dataclasses import asdict
import hashlib
import io
import json
from pathlib import Path
import os
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cli
from runner import Destination, cycle, dispatch_prepared, initialise
from succession.composer import ComposerObservation
from succession.core import Action, Config, Controller, Response
from windows_backend import BrowserObservationError, WindowsUIA

PROJECT = "g-p-11111111111111111111111111111111"
CHAT = "11111111-1111-1111-1111-111111111111"
USER = "22222222-2222-2222-2222-222222222222"
REPLY = "33333333-3333-3333-3333-333333333333"
OTHER = "44444444-4444-4444-4444-444444444444"
ANCHOR = f"chrome-turn-{USER}-{REPLY}"


class ReceiptSafetyTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.path = Path(tmp.name) / "controller.json"
        self.cfg = Config(PROJECT, "JayDEmily/chat_successor", "trial/l01", 3)
        self.controller = initialise(self.path, self.cfg, CHAT)
        self.bridge = WindowsUIA(PROJECT, "Shoko fixture", Path("adapter.ps1"), self.path)
        self.source = Response(CHAT, ANCHOR, "CHAT_STATUS: NEED_MORE_TIME", project=PROJECT)
        self.calls = []
        fault = patch.dict(os.environ, {"ASTRA_L09_FAULT": ""})
        fault.start()
        self.addCleanup(fault.stop)

    def stage(self, *, uncertain=False):
        self.decision = self.controller.consume(self.source)
        self.controller.save(self.path)
        self.target = Destination(PROJECT, CHAT, ComposerObservation(editable_text=""), 222, "42.222")
        self.bridge._atomic_target_write({
            "kind": "CONTINUE_CURRENT", "source": CHAT, "handle": 222,
            "document_id": "42.222", "project": PROJECT,
            "action_id": self.decision.action_id, "source_response": ANCHOR,
            "message_sha256": hashlib.sha256(self.decision.message.encode("utf-8")).hexdigest(),
            "route_receipt": None,
        })
        if uncertain:
            self.controller.begin_send(self.decision.action_id)
            self.controller.save(self.path)
            self.controller.uncertain(self.decision.action_id, "Synthetic lost acknowledgement")
            self.controller.save(self.path)

    def result(self, **changes):
        payload = {
            "project": PROJECT, "chat_id": CHAT, "submitted_text": self.decision.message,
            "posted_message_observed": True, "receipt_reason": "verified", "receipt_attempts": 1,
        }
        return {**payload, **changes}

    def adapter(self, outcomes):
        outcomes = iter(outcomes)

        def run(argv, **_kwargs):
            mode = argv[argv.index("-Mode") + 1]
            self.calls.append(mode)
            # Both paths remain bound to the same durable action and predecessor.
            for flag, expected in (
                ("-WindowHandle", "222"), ("-DocumentId", "42.222"),
                ("-PrepareAction", self.decision.action_id), ("-SourceResponse", ANCHOR),
                ("-PendingResponseId", ANCHOR), ("-Message", self.decision.message),
            ):
                self.assertEqual(argv[argv.index(flag) + 1], expected)
            pending = json.loads(self.path.read_text(encoding="utf-8"))["state"]["pending"]
            self.assertEqual(pending["action_id"], self.decision.action_id)
            if mode == "Send":
                self.assertEqual(pending["phase"], "sending")  # persisted before possible click
            else:
                self.assertEqual(mode, "Reconcile")
            outcome = next(outcomes)
            if isinstance(outcome, BaseException):
                raise outcome
            if isinstance(outcome, dict):
                return Mock(returncode=0, stdout=json.dumps(outcome), stderr="")
            return outcome
        return run

    def cli_reconcile(self):
        config = {**asdict(self.cfg), "run_id": "l01", "project_name": "Shoko fixture"}
        out = io.StringIO()
        argv = ["cli.py", "reconcile", "--state", str(self.path),
                "--config", str(self.path.with_name("fixture-config.json"))]
        with patch.object(cli, "load_config", return_value=config), \
             patch.object(cli, "create_dependencies", return_value=(self.bridge, Mock())), \
             patch.object(sys, "argv", argv), redirect_stdout(out):
            cli.main()
        return json.loads(out.getvalue())

    def assert_still_pending(self, before, target_before):
        self.assertEqual(self.path.read_bytes(), before)
        self.assertEqual(self.bridge.target_path.read_bytes(), target_before)
        saved = Controller.load(self.path)
        self.assertEqual(saved.state.pending.action_id, self.decision.action_id)
        self.assertEqual(saved.state.pending.response_id, ANCHOR)
        self.assertEqual(saved.state.pending.message, self.decision.message)
        self.assertEqual(saved.state.pending.phase, "uncertain")
        self.assertEqual(saved.unique_count, 1)
        self.assertEqual(cycle(saved, self.bridge, Mock(), "l01", self.path), Action.HOLD)
        self.assertEqual(dispatch_prepared(saved, self.bridge, self.path), Action.HOLD)
        self.assertEqual(self.path.read_bytes(), before)

    def test_positive_exact_receipt_confirms_one_continuation(self):
        self.stage()
        with patch.object(self.bridge, "prepare", return_value=self.target), \
             patch("windows_backend.subprocess.run", side_effect=self.adapter([self.result()])):
            self.assertEqual(dispatch_prepared(self.controller, self.bridge, self.path), Action.WAIT)
        saved = Controller.load(self.path)
        self.assertIsNone(saved.state.pending)
        self.assertEqual(saved.unique_count, 1)
        self.assertEqual(saved.consume(self.source).action, Action.IGNORE)
        self.assertEqual(self.calls, ["Send"])

    def test_lost_ack_holds_through_readonly_failures_then_confirms_without_second_send(self):
        self.stage()
        lost_ack = Mock(returncode=1, stdout="", stderr=(
            "Send attempted but exact posted message + saved ID not both observed; "
            "receipt_reason=previous_turn_missing"))
        holds = [
            self.result(posted_message_observed=False, submitted_text=None,
                        receipt_reason=reason, receipt_attempts=attempts)
            for reason, attempts in (
                ("previous_turn_missing", 25), ("assistant_selection_ambiguous", 1),
                ("sample_expired", 25),
            )
        ]
        with patch.object(self.bridge, "prepare", return_value=self.target) as prepare, \
             patch("windows_backend.subprocess.run",
                   side_effect=self.adapter([lost_ack, *holds, self.result(receipt_attempts=2)])), \
             self.assertLogs("windows_backend", level="INFO") as logs:
            self.assertEqual(dispatch_prepared(self.controller, self.bridge, self.path), Action.HOLD)
            before, target_before = self.path.read_bytes(), self.bridge.target_path.read_bytes()
            for _ in holds:
                self.assertEqual(self.cli_reconcile()["event"], "unresolved_no_resend")
                self.assert_still_pending(before, target_before)
            self.assertEqual(prepare.call_count, 1)
            self.assertEqual(self.cli_reconcile()["action"], "WAIT")
            with self.assertRaisesRegex(BrowserObservationError, "No possibly sent"):
                self.bridge.reconcile_readonly()
        saved = Controller.load(self.path)
        self.assertIsNone(saved.state.pending)
        self.assertEqual(saved.unique_count, 1)
        self.assertEqual(self.calls, ["Send", "Reconcile", "Reconcile", "Reconcile", "Reconcile"])
        self.assertEqual(self.bridge.target_path.read_bytes(), target_before)
        output = "\n".join(logs.output)
        self.assertIn("reason=previous_turn_missing attempts=25", output)
        self.assertIn("reason=assistant_selection_ambiguous attempts=1", output)
        self.assertNotIn(self.decision.message, output)

    def test_provisional_destination_cannot_be_rescued_by_a_positive_flag(self):
        self.stage(uncertain=True)
        before, target_before = self.path.read_bytes(), self.bridge.target_path.read_bytes()
        with patch("windows_backend.subprocess.run", side_effect=self.adapter([
            self.result(chat_id="local-chatgpt:" + CHAT),
        ])):
            self.assertEqual(self.cli_reconcile()["event"], "unresolved_no_resend")
        self.assert_still_pending(before, target_before)
        self.assertEqual(self.calls, ["Reconcile"])

    def test_false_flag_or_inexact_text_cannot_be_rescued_by_diagnostic_metadata(self):
        self.stage(uncertain=True)
        before, target_before = self.path.read_bytes(), self.bridge.target_path.read_bytes()
        outcomes = [
            self.result(posted_message_observed=False, receipt_reason="verified"),
            self.result(submitted_text=self.decision.message + " unexpected text"),
            self.result(posted_message_observed=False, receipt_reason="bad\nreason",
                        receipt_attempts=True),
        ]
        with patch("windows_backend.subprocess.run", side_effect=self.adapter(outcomes)), \
             self.assertLogs("windows_backend", level="INFO") as logs:
            for _ in outcomes:
                self.assertEqual(self.cli_reconcile()["event"], "unresolved_no_resend")
                self.assert_still_pending(before, target_before)
        self.assertIn("reason=unspecified attempts=None", "\n".join(logs.output))
        self.assertNotIn("bad\nreason", "\n".join(logs.output))
        self.assertEqual(self.calls, ["Reconcile"] * 3)

    def test_wrong_saved_chat_or_project_preserves_the_same_pending_action(self):
        self.stage(uncertain=True)
        pending = asdict(Controller.load(self.path).state.pending)
        target_before = self.bridge.target_path.read_bytes()
        outcomes = [self.result(chat_id=OTHER), self.result(project="other-project")]
        with patch("windows_backend.subprocess.run", side_effect=self.adapter(outcomes)):
            for _ in outcomes:
                self.assertEqual(self.cli_reconcile()["action"], "HOLD")
                saved = Controller.load(self.path)
                self.assertEqual(asdict(saved.state.pending), pending)
                self.assertEqual(saved.unique_count, 1)
                self.assertEqual(self.bridge.target_path.read_bytes(), target_before)
        self.assertEqual(self.calls, ["Reconcile", "Reconcile"])

    def test_reconcile_transport_failures_do_not_retry_or_rearm(self):
        self.stage(uncertain=True)
        before, target_before = self.path.read_bytes(), self.bridge.target_path.read_bytes()
        failures = [
            Mock(returncode=0, stdout="{", stderr=""),
            Mock(returncode=1, stdout="", stderr="Chrome readback sample has expired"),
            subprocess.TimeoutExpired("powershell.exe", 90),
        ]
        for failure in failures:
            with self.subTest(failure=type(failure).__name__), \
                 patch("windows_backend.subprocess.run", side_effect=self.adapter([failure])) as run:
                with self.assertRaises((BrowserObservationError, subprocess.TimeoutExpired)):
                    self.bridge.reconcile_readonly()
                self.assertEqual(run.call_count, 1)
                self.assert_still_pending(before, target_before)
        self.assertEqual(self.calls, ["Reconcile"] * 3)

    def test_generic_get_filehash_error_is_not_an_automatic_no_click_receipt(self):
        self.stage()
        error = Mock(returncode=1, stdout="", stderr="Get-FileHash is not recognized")
        with patch.object(self.bridge, "prepare", return_value=self.target), \
             patch("windows_backend.subprocess.run", side_effect=self.adapter([error])), \
             patch.object(self.controller, "confirm_not_sent") as rearm:
            self.assertEqual(dispatch_prepared(self.controller, self.bridge, self.path), Action.HOLD)
            rearm.assert_not_called()
        self.assert_still_pending(self.path.read_bytes(), self.bridge.target_path.read_bytes())
        self.assertEqual(self.calls, ["Send"])

    def test_stale_chrome_sample_does_not_consume_or_prepare(self):
        # Same timestamp is not independent fresh readback. Existing fixture fields.
        sample = {"project": PROJECT, "chat_id": CHAT, "view_status": "observed",
                  "window_handle": 222, "method": "CHROME_DOM", "chrome_read_at": 1000,
                  "ready": True, "stop_control": False, "role": "assistant",
                  "response_id": ANCHOR, "text": "CHAT_STATUS: NEED_MORE_TIME"}
        before = self.path.read_bytes()
        with patch.object(self.bridge, "_invoke", return_value=sample) as invoke, \
             patch("windows_backend.time.sleep"), patch.object(self.bridge, "prepare") as prepare:
            self.assertEqual(cycle(self.controller, self.bridge, Mock(), "l01", self.path), Action.WAIT)
            self.assertEqual([call.args[0] for call in invoke.call_args_list], ["Observe", "Observe"])
            prepare.assert_not_called()
        self.assertEqual(self.path.read_bytes(), before)
        self.assertIsNone(self.controller.state.pending)
        self.assertEqual(self.controller.state.consumed_responses, [])


if __name__ == "__main__":
    unittest.main()