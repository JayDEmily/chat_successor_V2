# Request for Astra — Chat Succession L11

Please review this bounded Windows/Chrome chat handoff prototype and suggest the
smallest changes and regression tests that would make the observed receipt failures
easier to diagnose and recover. You have the source and synthetic fixtures. Assume
you have no Windows desktop, Chrome session, account access or private run state.

## What actually happened

The installed Shoko run finished with assistance on source `36b1709`. Two distinct
saved workers published exactly the required Cat/Dog lines in two consecutive
commits (`e3d2aa4`, `66b80b5`). The controller verified the opening commit before
one successor Send and logged `STOP_FINISHED` at 2 of 3 with an empty pending slot.

- **Saved address while the page still had a provisional ID.** The posted prompt
  matched exactly, but the app exposed `local-chatgpt:<uuid>` on the rendered message.
  An explicit refresh of the completed saved view restored the saved ID. The normal,
  unattended provisional-to-saved transition remains unverified on live Chrome.
- **Exact continuation receipts were intermittently unavailable.** The live view
  could be offscreen, omit the preceding reply through virtualization, or expose
  multiple assistant selection markers. One live reply exposed four. A scoped
  scroll and explicit refresh of a completed view recovered exact text and the
  preceding reply. Long prompt expansion controls were already handled separately.
- **Owner re-entry and startup.** A comparison window reached the saved address
  before its transcript mounted. `36b1709` moved transcript reading into the
  existing bounded poll. A separate PowerShell module-path mismatch prevented
  `Get-FileHash` before typing or clicking. The default Windows module path worked.
  The same recorded action was rearmed only after positive pre-click evidence.

Windows UI Automation maximization was verified in a no-Send preflight. It helped
standardize layout. Exact receipt holds still occurred. The reviewed run used
manual, read-only reconciliation and made no repeat click for possibly posted
messages. L12 Bird/Pig has yet to start.

## What to return

1. Prioritize at most two small changes and explain which observed failures they cover.
2. Write focused, runnable tests or a small patch suitable for adapting here. Prefer
   synthetic DOM fixtures, mocked PowerShell UIA snapshots or Python tests. Cover
   a positive receipt, a provisional or stale mismatch, and a plausible failure
   that must preserve the pending action and avoid a second Send.
3. List the exact Windows observations still needed for any claim that cannot be
   established offline.

Keep the existing controller, saved identity checks, durable pending-action journal,
and bounded waits. Use the published test patterns. Treat a possibly submitted
action as read-only until its exact text and destination are verified. Keep a
continuation tied to its verified preceding reply. Use only the supplied synthetic
fixtures for proposed tests.

## Open the bundle

    git clone -b astra/l11-test-review chat-successor.bundle chat-successor-review

The bundle is a self-contained, focused snapshot of the source at
`36b17092aa5fef09b5ac3747c03e5661be23559c`. Start with `README.md`, then
`integration/chrome_reader/readback.js`, `integration/uia_adapter.ps1`,
`integration/windows_backend.py` and their existing tests. The `review/` folder
contains the two independent reports and the targeted source diff.
