"""Minimal helper for custom GPT action calls to `/turn`.

Features:
    * Tracks turn numbers and emits a write-status marker (e.g., turn=0003 write=true).
    * Carries forward the last unpersisted turn after failures and retries it on the next call.
    * Enforces paired last_* fields (both null or both populated).
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from typing import Any, Callable, Dict, Optional, Tuple


HttpClient = Callable[[str, Dict[str, Any]], Dict[str, Any]]


class CustomGPTTurnClient:
    def __init__(
        self,
        *,
        function_url: str,
        root_session_id: str,
        session_id: str,
        http_post: Optional[HttpClient] = None,
        timeout_seconds: int = 30,
    ):
        self.function_url = function_url.rstrip("/")
        self.root_session_id = root_session_id
        self.session_id = session_id
        self.http_post = http_post or self._default_post
        self.timeout_seconds = timeout_seconds
        self.turn_number = 1
        self._pending_last: Optional[Tuple[str, str]] = None

    def _default_post(self, path: str, body: Dict[str, Any]) -> Dict[str, Any]:
        url = self.function_url + path
        req = urllib.request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
            status = resp.getcode()
            payload = json.loads(resp.read().decode("utf-8"))
            return {"status": status, "body": payload}

    def _validate_last_fields(self, last_user: Optional[str], last_assistant: Optional[str]) -> None:
        if (last_user is None) != (last_assistant is None):
            raise ValueError("last_user_message and last_assistant_message must both be null or both populated")

    def send_turn(
        self,
        *,
        current_user_message: str,
        last_user_message: Optional[str],
        last_assistant_message: Optional[str],
    ) -> Tuple[Dict[str, Any], str]:
        """Call /turn, retrying the previous turn if a prior attempt failed.

        Returns (response_body, marker). Marker is a short string to append to the assistant reply.
        """
        self._validate_last_fields(last_user_message, last_assistant_message)

        send_last_user, send_last_assistant = (
            self._pending_last if self._pending_last is not None else (last_user_message, last_assistant_message)
        )

        payload = {
            "root_session_id": self.root_session_id,
            "session_id": self.session_id,
            "last_user_message": send_last_user,
            "last_assistant_message": send_last_assistant,
            "current_user_message": current_user_message,
        }

        try:
            resp = self.http_post("/turn", payload)
        except Exception:
            # Preserve the last_* pair for the next attempt if present.
            if send_last_user is not None and send_last_assistant is not None:
                self._pending_last = (send_last_user, send_last_assistant)
            raise

        status = resp.get("status")
        body = resp.get("body", {})
        if status != 200:
            if send_last_user is not None and send_last_assistant is not None:
                self._pending_last = (send_last_user, send_last_assistant)
            raise AssertionError(f"/turn returned HTTP {status}: {body}")

        persisted = body.get("persisted_last_turn")
        if persisted is None:
            raise AssertionError("persisted_last_turn missing from /turn response")

        # If we had a pending last_* pair, require it to be persisted on success.
        if send_last_user is not None and send_last_assistant is not None and persisted is not True:
            self._pending_last = (send_last_user, send_last_assistant)
            raise AssertionError("Expected persisted_last_turn=True when last_* was provided")

        # Success: clear pending if any and advance turn counter.
        self._pending_last = None
        marker = self._make_marker(persisted)
        self.turn_number += 1
        return body, marker

    def _make_marker(self, persisted: bool) -> str:
        return f"turn={self.turn_number:04d} write={'true' if persisted else 'false'}"
