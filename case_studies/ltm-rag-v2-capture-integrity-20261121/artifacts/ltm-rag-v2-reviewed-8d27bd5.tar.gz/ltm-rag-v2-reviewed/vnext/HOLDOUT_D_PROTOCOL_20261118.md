# Holdout D — independent source-ranking test registered before evaluation

**Registration:** 18 November 2026 AEDT. All D cases are new fictional records that did not appear in the earlier six-message live archive or 26-message Holdout C.

## Fixed data

- `fixtures/synthetic_holdout_d.json`: 40 fictional messages across 12 distinct narratives: 12 original reports, 12 assistant caveats, 12 same-branch user corrections, and 4 assistant-only alternative-branch inferences. Every correction explicitly supersedes its original and is distinct from assistant inference.
- `HOLDOUT_D_PROBES_20261118.json`: 32 immutable questions, each with one registered expected original-source message ID and candidate limit 8.
- 12 explicit references to a corrected detail, 12 implicit/paraphrased references to a corrected detail, **4 questions explicitly requesting the superseded original** and **4 requesting the alternative branch**. The latter two categories detect unwanted promotion of a correction over the precise requested version/branch.
- The corpus, questions, expected message IDs, ordering and scoring were created **after inspecting C results but before ever running D**. A separate new D set is more informative than retesting C, but this handcrafted 32-case sample is still not a representative population reliability estimate.

## Locked retrieval alternatives

Use the same pinned local CPU model `BAAI/bge-small-en-v1.5` through FastEmbed 0.9.1 / ONNXRuntime 1.32.0 and the same **previously fixed** algorithms from `SHADOW_EMBEDDING_EXPERIMENT_20261118.md`:

- **FTS5 baseline** (existing SQLite `Archive.lookup`, OR tokens and BM25).
- **DENSE_RAW**: cosine ranking of one embedding per unaltered source message.
- **DENSE_CHAIN**: for each correction candidate append only its referenced, exact original text with fixed labels; all message identities remain distinct.
- **HYBRID_RRF**: fixed unweighted RRF of DENSE_CHAIN and FTS5 ranks with k=60.

Report registered-message recall@8, rank1 and individual ranks for all 32 cases; do not omit regressions in original/alternative categories. No task-specific synonyms, source identifiers, registered answers, prompt-type labels or other hidden information may enter the ranker. The expected IDs are used for scoring **only**.

## Execution boundary

Create an isolated **temporary** SQLite catalogue loaded exclusively from D. The six-message live MCP and tunnel are not changed or restarted. Embedding weights stay in the ignored local model cache; no source conversation data is sent to an external inference API. Only these 40 invented messages and 32 invented prompts are processed.

A method must not be promoted to the native MCP search merely because its D score is higher: inspect whether it preserves version, correction and alternative branch identities and obtain a separate integration contract and end-to-end native test. The full exact source stays in the authoritative SQLite archive, not in model vectors.
