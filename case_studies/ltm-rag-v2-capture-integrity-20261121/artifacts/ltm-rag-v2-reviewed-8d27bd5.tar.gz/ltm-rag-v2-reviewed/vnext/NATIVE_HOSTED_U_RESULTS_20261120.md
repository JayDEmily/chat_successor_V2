# Stage U — hosted vector search → original SQLite, private read-only MCP

**20 November 2026 | Engineering result: BACKEND_READY_NATIVE_EXPLICIT_TOOL_REJECTED_SOURCE_SCOPE.**

## Implementation and isolated transport

The two frozen native questions were independently registered at commit `23286c98bff035cadc93873d4d0d8542485c638b` (parent `cbf3982d3aab6bab7d4c853fe7118a132524623a`) and exact remote GitHub blobs read back before the native test. Stage U introduced `ltm_vnext/hosted_mcp_u.py` with precisely one read-only MCP tool, `lookup_synthetic_memory_u(query, limit=3)`. The tool invokes an OpenAI hosted Stage T Vector Store search and resolves candidate file mappings to the **original** exact 10-record fictional SQLite archive. The fixed synthetic-source checks include message roles, IDs, branch/conversation, exact UTF-8 and hashes, and author/capture chronology. No real chat history or external generative model API call is used.

An independent dedicated loopback listener `127.0.0.1:8792/mcp` was brought up. A new private OpenAI tunnel was created with name `LTM-RAG-vNext-Hosted-U-20261120` only after a zero-match remote name check; remote tunnel identity and organisation readbacks then found **exactly one**. The U tunnel doctor returned **PASS** for local listener and MCP route; its ephemeral `/readyz` endpoint returned **HTTP 200**. The installed MCP SDK's `tools/list` readback returned exactly **one** tool with `read_only_hint=True`; this test consumed no search calls.

The plugin archive `ltm-rag-vnext-hosted-memory-u`, version 0.1.0, was created privately and exact four registry manifests read back, with the expected tunnel ID and no plugin-packaged credentials. This plugin package alone did not expose a normal-chat **Try in chat** action; Stage V subsequently registered a **distinct native custom MCP connector** using the same U tunnel, without altering other connectors.

## Offline tests and native boundary

- U adapter's 10/10 focused tests and full **231/231** core regression passed. The source identity, malformed query/limit, durable call quota (five maximum), restart/replay, duplicate file identity, rejected real-history sources, and no-source abstention were all exercised through fake provider responses. These do not constitute a native hosted lookup success.
- The U server audit `vnext/.local/trial-u-hosted-mcp-audit.jsonl` recorded **one** native invocation from Stage V-N02: `CALL_STARTED`, followed by `CALL_COMPLETED: DENIED_SCOPE, candidate_count=0`. Its SHA-256 after the two V native tests was `e2b7188cbbdbb1668fa6ec00678c6fb780a7308defc0d31097a7ae84ff5c4e66`. The model-formed query's SHA-256 differed from the frozen V-N02 prompt, so the model did generate its own tool input. The audit deliberately did not log that input or the specific validation predicate; therefore **the exact rejection cause is unknown**.
- Code inspection establishes potential overrestriction: U's literal keyword whitelist and hard maximum `limit=3` are not semantically equivalent to isolated source validation and can reject legitimate natural-language queries. This is a defect candidate, not proof of which particular predicate failed in V.
- All five historical original/G/I/K/M/P services, Stage S original contaminated five-file store, and Stage T corrected five-file store remain separate and unmodified. No real-history ingestion, persistent capture daemon, OS reboot hook, production endpoint, ChatGPT Work, credential creation or generated ChatGPT API Responses call was made.

**Verdict:** U private one-tool backend, tunnel, and connection are operational; native ChatGPT really invoked the tool once, **but did not obtain a verified original SQL source packet** in this registered test. Do not infer source retrieval from a correct model answer. This result is frozen and is not retrospectively promoted if a later query-normalisation repair succeeds.

See [Stage V native evidence](NATIVE_HOSTED_V_RESULTS_20261120.md) for the two distinct chat conditions.
