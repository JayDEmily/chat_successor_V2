# Trial G — separate outbound tunnel implementation boundary

**Scope:** isolated read-only MCP access to the **20 newly preregistered fictional G records**, to support the clean-context Project. The existing original six-message service and its connected tunnel remain unchanged and operational.

## Why a distinct tunnel

The original private connector points to `127.0.0.1:8787` and a six-record SQLite fixture. Replacing that database or pointing its tunnel to G would invalidate the previous B/F evidence and risk interfering with unrelated use. Trial G therefore requires its own SQLite file, **127.0.0.1:8788** listener, audit log, control-plane tunnel ID and separate ChatGPT connector identity.

## Authorised credential path and fixed scope

- Reuse **only existing Ubuntu credentials** in `/home/jds/.env`: `OPENAI_API_KEY` for runtime authentication and `OPENAI_ADMIN_KEY` solely if control-plane tunnel creation requires an administrative key. Both were verified present and unique without displaying their contents.
- Never create a new API key or weaken the original tunnel's permissions. Do not put raw keys on shell command lines, Git, test fixtures, log output or new key files.
- Any new tunnel is scoped to the same previously established organization `org-BTw54pQ0XEDOzp89gClJhtJs`, with a distinct name `LTM-RAG-vNext-clean-G-20261119` and an explicitly synthetic/read-only description. Do **not** create an organization, workspace or new API project.
- Keep endpoint private to the OpenAI outbound tunnel mechanism: local MCP binds `127.0.0.1:8788`; no publicly listening port. Separate Git-ignored profile and runtime files.
- The created tunnel ID and create/readback outcome must be recorded, but source contents remain fictional and no real conversation data is imported.
- Original tunnel ID `tunnel_6afd0f1439e88191862ade433921b3f9` and port **8787** are forbidden mutation targets.

## Implement / verify in order

1. Run isolated exact-source temporary HTTP smoke against the preregistered G fixture; check both tool annotations readonly, g03 source bytes and SHA-256, same-branch correction, no alternative-branch neighbours and minimised audit events.
2. Start a **separate** loopback G server and prove that the live original six-record server continues to answer its original fixture. No persistent Windows startup service requested.
3. Use admin CLI in **read-only list mode** first to inspect whether the exact intended tunnel name already exists. Do not duplicate an existing tunnel.
4. Create at most one organization-scoped tunnel if absent using the existing admin key in process environment only. Verify its control-plane metadata by ID. Persist only tunnel ID/receipt under ignored `.local` plus a redacted summary in Git.
5. Generate a distinct G tunnel-client profile that points to `http://127.0.0.1:8788/mcp`; start it manually using the existing runtime project key, not a new key. Verify local MCP lookup/fetch, tunnel doctor, health readiness and last successful control-plane poll.
6. Independently confirm a **new ChatGPT connector** is configured for this distinct tunnel, without uninstalling/changing the original. Do not claim native tool access before an actual connected G lookup and local audit event.
7. Do not submit G01 in the new Project until its saved **Project-only** memory setting is independently read back and the documented propagation caveat is addressed.

## Failure boundary

If administrative listing/creation returns a permission error or the platform refuses a second connector, do not borrow the original tunnel, repoint its profile, reconfigure its MCP database, create additional keys or claim a native test. Preserve the exact non-secret failure output and complete all permitted local/offline evidence.

No new general-purpose inference, autonomous history capture, genuine user data or Windows reboot task is authorised by this stage.
