# Native ChatGPT Trial F — initial, separately verified checkpoint

**Status:** PARTIAL. Four of sixteen registered questions were actually sent. Cases C01–C04, A01–A04 and U01–U04 are **not yet executed**. Their outcomes are unknown.

Registered exact inputs and review criteria at Git commit `98a7017`, before any sends. Every completed source is fictional, not genuine personal history.

| Case | Test | Successful local lookup | Separate fetch | Trace criterion | Observed answer quality |
|---|---|---:|---:|---|---|
| M01 | Bicycle serial number absent | 1 | 1 | PASS | Reported serial number unavailable; quoted real fictional m5 source, not an invented serial number |
| M02 | Notebook strap colour absent | 1 | 0 | PASS | Reported strap colour unavailable; cited corrected library source m3, whose initial lookup contains full text |
| M03 | Misleading purple-gate quotation | 1 | 1 | PASS | Rejected purple gate, reproduced exact yellow-gate m5 sentence and distinguished authored statement from physical proof |
| M04 | Authenticated Mira audio recording | 0 | 0 | **FAIL** | Saved response states no authenticated recording, cites m3 and m2, but no successful MCP call. Source quotation typography differs from the canonical exact m3 sentence |

For M01–M03, local event IDs and response excerpts were saved automatically in the ignored `vnext/.local/native-trial-f-results.jsonl`. The corresponding saved Project conversations are available through the ledger's exact chat URLs.

## M04 UI stall, recovery and evidential separation

The test runner sent M04 **once** into a verified isolated ChatGPT Project conversation:
https://example.invalid/private-chatgpt-evidence

ChatGPT's window remained in the `Thinking` state with no visible final assistant marker for several minutes. The terminal runner was **terminated** while retaining its pending-send guard. The UI was independently checked to identify exactly this saved conversation; its single `Stop` control was invoked only in that window. Afterwards, the saved assistant reply became visible. The exact saved response was read independently via Windows UI Automation, captured locally, then reconciled into the ledger as M04 **without re-sending**.

The independent MCP audit event count stayed exactly at the pre-send value **51**, demonstrating **zero successful local tool calls** for M04. Therefore, despite the answer's plausible and evidence-consistent conclusion, its **expected native lookup trace failed**. This does not prove the model never attempted a failed remote call; none reached the local MCP handler.

The assistant's wording distinguishes the fictional user's report from authenticated speech, which is correct per m2 and m3. However, M04's embedded correction quotation is not byte-identical to m3's original Unicode-quoted text; do not score that text as exact archival reproduction.

Recovery was performed by `scripts/reconcile_native_f_m04.py`, which required exact prior ledger sequence, pending-send identity, no intervening audited MCP events, and a real saved response with expected fictional source locators. The script appended M04 and then removed its pending marker. Direct analyser readback verified **4 ledger entries, no pending marker, 3/4 expected lookups met**.

The native F runner has since been patched with a **120-second wall-clock safety stop** that preserves the pending marker and halts without navigating or attempting a duplicate send when ChatGPT does not finish. Parser validation passed; this safeguard does not guarantee that the model will finish within that period.

## Scope and next step

Only the registered remaining cases may be attempted, starting at exact index 4 and only after verifying an isolated empty synthetic-Project composer. If the next case stalls, stop safely and publish the partial evidence; never relabel an unavailable or unexecuted case as passed. There is no population reliability verdict from this partial sample.

No changes were made to the live six-message SQLite MCP, tunnel, API credentials, historical data import or Windows startup settings.
