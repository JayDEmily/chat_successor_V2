# Astra retrieval repairs: source-deduplication and file pagination

**21 November 2026**
**Applicable review:** `vnext/reviews/20261121_complementary_memory/ARCHITECTURE_AND_EVIDENCE.md`, Section 5, issues 3 and 6.
**Scope:** existing synthetic-only hosted retrieval and file-list reconciliation; no schema, original source, plugin or remote index alteration.

## Repairs

1. `ltm_vnext/native_dialogue_s.py` deduplicates overlapping hosted vector-search hits by their canonical hosted file ID before handing source pairs to the U/W strict gateway. Malformed result envelopes and invalid file IDs fail closed. The existing gateway continues to reject genuinely duplicate or invalid turns in a caller-supplied candidate list.
2. `ltm_vnext/hosted_memory_r.py` now reads the OpenAI Files list page by page using its documented `after` cursor, validating `has_more`, unique IDs and progression, rather than silently limiting reconciliation to the first 100 files. It explicitly errors if the 100-page bound is exhausted. No new provider requests were made during the tests.

API reference: https://developers.openai.com/api/reference/resources/files/methods/list

## Verification

- Existing S fake-provider tests extended for repeated chunks and malformed search envelope.
- Existing T fake-provider tests extended for repeated chunks and a whole T-pipeline-to-U-gateway `FOUND` call with exactly one canonical user/assistant pair.
- New `tests/test_astra_file_pagination.py` checks two-page retrieval, encoded cursor, single page, duplicate IDs, missing `has_more`, empty unfinished page and bounded pagination.
- Full Ubuntu core test suite and Astra review-tool suite rerun before publication; see final checkpoint output for exact counts.
- No live API/ChatGPT request or semantic benchmark was performed. This is deterministic code-path repair; model-assisted retrieval usefulness remains an unexecuted native evaluation.

The unchanged Astra import remains `269bf99504244301fb790b49dc908beb9a545603`, with implementation on a separate descendant branch.
