# LTM-RAG vNext — shadow semantic retrieval decision

**Status:** EVALUATED_OFFLINE_ONLY. No native MCP tool, source database or original ChatGPT retrieval record has been modified.

## Verifiable experiment boundaries

- Holdout C: 26 new fictional records, 16 frozen probes. The initial FTS5 baseline was inspected before proposing dense embeddings. Thus the C embedding result is **exploratory**, not independently validated.
- Model/method preregistration: `SHADOW_EMBEDDING_EXPERIMENT_20261118.md`, Git commit `53c9208`. Three fixed shadow methods: raw dense (one embedding per original text), correction-chain dense (only same-branch superseded text appended), and unweighted RRF k=60 with existing FTS5, all compared against unchanged FTS5.
- Holdout D: **40 distinct invented messages** and **32 registered prompts** across 12 narratives, with 12 each explicit and implicit correction questions, four superseded-original questions and four alternative-branch questions. Fixture, prompts, expected source IDs and test protocol committed at `27c697c` **before any D model invocation**. Although unseen by earlier tests, D was handcrafted after observing C's lexical weakness.
- Model weights: `BAAI/bge-small-en-v1.5` run through local FastEmbed 0.9.1, ONNXRuntime 1.32.0, NumPy 2.5.5, CPU provider (2 threads); separate ignored environment/cache. Model snapshot `Qdrant/bge-small-en-v1.5-onnx-Q` revision `aa8f8b060edb00e03bfdd08813a2949946c8ba55`. Exact 66,465,124-byte `model_optimized.onnx` SHA-256: `51f1bd0addd6e859e42c2c8021a5e5461385bb676a649f4b269aa445449f2431`. Other tokenizer/config SHA-256 values in `SHADOW_EMBEDDING_RESULTS.md`; model weights **not committed** to Git.
- Upstream implementation: Qdrant FastEmbed, https://github.com/qdrant/fastembed ; supported CPU/ONNX models and installation, https://pypi.org/project/fastembed/ .

## Measured outcomes

### Holdout C — corrected-source rankings (8 explicit, 8 implicit)

| Candidate method | Explicit recall@8 | Implicit recall@8 | Implicit first rank |
|---|---:|---:|---:|
| Existing FTS5 | 8/8 | 6/8 | 1/8 |
| Raw dense | **8/8** | **8/8** | 4/8 |
| Correction-chain dense | **8/8** | **8/8** | 4/8 |
| Hybrid RRF | 8/8 | 7/8 | 4/8 |

### Fresh Holdout D — 12 explicit, 12 implicit, 4 originals, 4 alternatives

| Candidate | Explicit recall@8 | Implicit recall@8 | Original rank 1 | Alternative rank 1 |
|---|---:|---:|---:|---:|
| Existing FTS5 | 12/12 | 5/12 | 2/4 | 4/4 |
| Raw dense | **12/12** | **12/12** | **2/4** | **4/4** |
| Correction-chain dense | **12/12** | **12/12** | **0/4** | 4/4 |
| Hybrid RRF | 12/12 | 8/12 | 1/4 | 4/4 |

**Important:** every candidate recovered all four original sources and four alternative-branch sources within the **top eight**, but correction-chain ranking demoted all four original-source targets to rank 2 when the user explicitly asked for the earlier version. Corrected-source ranking first on D: raw dense **10/12 explicit, 8/12 implicit**; correction chain **11/12 explicit, 12/12 implicit**; FTS5 **7/12 explicit, 1/12 implicit**. Rank-1 comparisons matter because the model could cite a plausible but wrong historical version if it follows only the first retrieved item.

## Recommended next engineering boundary

**Select RAW_DENSE as the leading candidate for a subsequent isolated trial**, **not** as the authorised live retrieval replacement. It materially improves implicit corrected-source recall on both synthetic sets without the observed rank-1 regression for requests about the original version. Retain FTS5 as a transparent diagnostic baseline, not automatically fused by the current fixed RRF (which degraded some implicit results). Preserve all branch/correction metadata and original source text in SQLite.

Before deploying any semantic layer to native ChatGPT:

1. Establish a larger, separately preregistered set including **ambiguous, negative/no-relevant-source, superseded-original, competing-correction, and cross-branch** probes, not only corrected-source queries. Define abstention/false-promotion scoring; a dense top-k method always returns candidates even for an unrelated query.
2. Define a read-only retrieval API that resolves candidates by stable source ID and exposes the exact SQLite source packet, separately from embedding vectors. Recheck source integrity, attribution and Unicode quotation fidelity end-to-end.
3. Only on sufficient evidence, explicitly version the live tool contract and test unprompted native ChatGPT invocation and irrelevance selectivity. Do **not** modify the current live MCP or import real history on this result alone.

## Cost and operation

A repeat local CPU run of all D embeddings (40 raw messages, 40 chain messages, 32 questions) on the owner's Ubuntu machine returned exit status 0 in **2.16 seconds elapsed** using approximately **291,000 KiB peak resident memory** and 175% aggregate CPU utilisation during the run. This is **one measured warm-cache run**, not an uptime or throughput promise. Model setup downloaded files once; all subsequent computations were local, with no paid OpenAI model inference.

Separate testing: **55/55 original Python unit tests** remain passing and **11/11 shadow ranking unit tests** pass in the isolated embedding virtual environment. Live synthetic services were left running and never reconfigured in this evaluation.

## Non-claims

These invented and manually authored cases do not measure production population accuracy, user-level memory usefulness, source authenticity or genuine historical ingestion. A good recall@8 does not establish a faithful final answer; the existing Trial B still has two independently demonstrated Unicode quote-mark deviations (H03/H10) and the strict H10 fetch-call failure. Those evidence items remain preserved.
