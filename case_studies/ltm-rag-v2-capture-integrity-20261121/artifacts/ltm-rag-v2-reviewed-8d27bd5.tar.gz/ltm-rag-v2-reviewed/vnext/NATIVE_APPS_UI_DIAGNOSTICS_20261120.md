# Post–Stage O native UI diagnostic hardening — 20 November 2026

**Disposition: READ_ONLY_DIAGNOSTICS_VERIFIED; ROOT_CAUSE_OF_MISSING_STAGE_O_CALLBACK_UNKNOWN.**

## Source and bounded investigation

- Repository branch `work/ltm-rag-vnext-synthetic-20261118`, last previously accepted evidence commit `27d7e908a1899d697d81f6b695ad9850b850fe5f`. No Stage O replay, further native prompt or automated widget click in this work.
- The Windows host reported its last boot as **03:03:54 AEDT on 20 November 2026**, so the missing former Stage O Chrome window cannot be explained by a Windows reboot in the 14:24–15:50 AEDT interval.
- The former Win32 window handle was absent from the later top-level Chrome inventory. This proves **only that the handle was no longer available**. It does not identify who closed the window, whether it navigated or was replaced, or the reason the native controller ceased.
- Remote Desktop Commander local call history confirms a `start_process` launch of the original Stage O controller at **14:24:48 AEDT**. No corresponding read of that process's native exit status was preserved in the relevant history. Its process output can no longer be retrieved reliably; later OS process IDs can be reused by unrelated work.
- Independent Stage O [audit](MCP_APPS_O_NATIVE_RESULTS_20261120.md) confirms one send marker, one native `open_topic_selector_m` event at **14:25:02.425 AEDT**, no `confirm_topic_m` event, no click marker and no source packets. The original script could throw on foreground changes, unexpected UIA control state or COM error without durable post-send checkpoints. Which, if any, caused the failure **cannot be determined**.
- The host Application/System Event Log sweep over the interval did not yield a grounded Chrome/PowerShell crash or reboot record; absence of a relevant event is not proof that a process did not terminate.

## Concrete correction (no native side effects)

[NativeAppsUiDiagnostics.ps1](scripts/NativeAppsUiDiagnostics.ps1) is a **new read-only / pure-evaluation** diagnostics module. It is not the Stage O runner and does not open Chrome, send a message, click, alter focus, navigate, scroll, install plugins or touch the MCP server.

- `SelfTest` exercises **16 deterministic checks**: first/second stable sample, minimum 250 ms interval, out-of-bounds scroll eligibility, one-scroll exhaustion, wrong URL, lost foreground, five-option/status preconditions, 38 s local deadline, UIA offscreen flag, moving geometry, malformed observation rejection, allowlisted trace fields, private JSONL flush, and refusal to write outside ignored/private directories. **16/16 PASS on Windows PowerShell.**
- `Inspect` requires an explicit target Chrome handle and exact saved ChatGPT conversation URL. It records a sanitised observation with `WINDOW_ABSENT`, `URL_MISMATCH`, `FOREGROUND_MISMATCH`, `WIDGET_NOT_VERIFIED`, `SCROLL_INTO_VIEW_ONCE_ALLOWED`, or `WAIT_FOR_STABLE_SECOND_SAMPLE`, depending on observed properties. It never triggers an actual scroll or click. On the former Stage O window handle, it correctly returned `WINDOW_ABSENT` and wrote a flushed JSONL record under ignored `vnext/.local` (**no native action**).
- `Library` exposes the pure `Evaluate-MerrowObservation` state transition and `Append-PrivateTrace` helper for a separately preregistered future native controller. The trace format permits only coarse boolean/geometry/elapsed state; raw user prompts, session/subject values, challenges and access credentials are not accepted trace fields. Private local traces remain ignored and are not committed.
- A future native runner must actually **call** these helpers at each significant post-send step and in a fail-closed `catch/finally`; the existence of this library alone does **not** demonstrate that the former Stage O failure has been repaired. Before any further live one-send/one-click attempt, require distinct preregistration, a dedicated verified browser target and explicit start/exit/status capture.

## Preserved boundaries

No new native MCP call, app-only confirmation, real history import, external inference, token, service/profile/plugin change, source packet access or OS autostart occurred during this diagnostic patch. Original/G/I/K/M services and their existing synthetic verdicts remain unchanged. Stage I remains 14/16; Stage K's historical four-call deviation remains documented.
