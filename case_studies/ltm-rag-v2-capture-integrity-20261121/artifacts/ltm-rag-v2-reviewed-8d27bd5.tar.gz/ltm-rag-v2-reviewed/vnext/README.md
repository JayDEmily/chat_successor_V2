# LTM-RAG vNext — synthetic integration proof

This independent implementation begins with Astra's 18 November 2026 recommendation: demonstrate that the familiar ChatGPT conversation can retrieve relevant historical evidence without a user-issued search instruction. The legacy AWS/Lambda implementation remains untouched outside this directory.

## Source and status

- Design source: https://example.invalid/private-drive-evidence
- Source commission: 18 November 2026, held in the Ubuntu Astra Gateway local run inputs, not copied into this repository because it includes personal examples.
- The report links to an Astra sandbox ZIP, but the three Drive files and the Ubuntu API response directory do not contain that ZIP. Its individual contracts/code have not been inspected.
- Evidence catalogue, local CLI and read-only MCP adapter: implemented against **synthetic fixtures only**.
- **Native ChatGPT functional compatibility: PASS on a small synthetic pilot.** The private plugin `LTM-RAG vNext Synthetic Recall` was created and connected to the dedicated Platform tunnel, which authenticates using the owner-approved existing project key (no new credential). Native evidence: 1 explicitly requested retrieval, **3 unprompted history-needed retrievals** (including one in a new dedicated ChatGPT Project), **2 unrelated non-search controls**, one bounded outage with truthful unavailable response, and a successful recovered lookup. See [NATIVE_LIVE_EVIDENCE_20261118.md](NATIVE_LIVE_EVIDENCE_20261118.md) and [NATIVE_TRIAL.md](NATIVE_TRIAL.md). Aggregate reliability, personal archive import and background research are not yet verified.
- For future OpenAI Responses research, the existing production API Access gateway is the preferred usage-accounting and inference boundary. Its role and exact inspected release are recorded in [MODEL_API_BOUNDARY.md](MODEL_API_BOUNDARY.md). No gateway model job is authorised or triggered by the synthetic retrieval tests.

## Reproduce the local test

From the repository root:

    python3 -m venv vnext/.venv
    vnext/.venv/bin/pip install -r vnext/requirements-mcp.txt
    export PYTHONPATH=vnext
    vnext/.venv/bin/python -m unittest discover -s vnext/tests -v

Create and query an explicitly synthetic database:

    python3 -m ltm_vnext.cli --db /tmp/ltm-vnext-synthetic.sqlite init
    python3 -m ltm_vnext.cli --db /tmp/ltm-vnext-synthetic.sqlite seed vnext/fixtures/synthetic_conversations.json
    python3 -m ltm_vnext.cli --db /tmp/ltm-vnext-synthetic.sqlite lookup 'blue notebook'

Serve locally over Streamable HTTP MCP v2 (127.0.0.1 only):

    vnext/.venv/bin/python -m ltm_vnext.mcp_server --db /tmp/ltm-vnext-synthetic.sqlite --port 8787

Endpoint: http://127.0.0.1:8787/mcp

Run the owner-approved tunnel client with the existing Ubuntu project key (in a separate terminal, **after** starting the local synthetic MCP server):

    python3 vnext/scripts/tunnel_using_existing_key.py doctor
    python3 vnext/scripts/tunnel_using_existing_key.py run

The launcher reads `/home/jds/.env` at execution and maps `OPENAI_API_KEY` into the tunnel process as `CONTROL_PLANE_API_KEY` while removing the admin key from its environment. No third credential is created. The tunnel client runs in the foreground; its readiness and polling require independent checking before claiming connectivity.

Run a one-shot loopback HTTP smoke test, which terminates its own server:

    vnext/.venv/bin/python vnext/scripts/smoke_http.py

Two annotated read-only tools are exposed: lookup_evidence and fetch_source. No tool performs writes, and only the manual synthetic seed command ingests data.

## Evidence contract implemented

Records preserve exact Unicode text, its SHA-256, source ID and locator, stable distinct message/version identity, authored role, separately reported speaker, attribution class, source/branch/position, unknown date precision, fidelity label and correction relationship. Neighbouring text is limited to the same source, conversation and branch. Indexing uses parameterised FTS5 searches.

Original recollections remain user-authored reports: an apparent quotation is not independently authenticated as the other person's original speech. A later correction is linked, not substituted into the earlier source text.

## Completed synthetic evidence and outstanding acceptance gates

Initial connection, spontaneous retrieval, native **ChatGPT Project** compatibility and one controlled service outage/recovery cycle were demonstrated in [the first live evidence report](NATIVE_LIVE_EVIDENCE_20261118.md). A 20-case [pre-registered reliability trial](RELIABILITY_TRIAL_B_PROTOCOL.md) is now **20/20 complete**, following post-restart recovery in a separately opened Chrome window: **10/10 necessary lookups, 9/10 strict source-fetch/content checks, 0/10 unnecessary lookups**. See the [complete outcome and Wilson intervals](RELIABILITY_TRIAL_B_RESULTS.md) and the [H10 source-fetch diagnosis](H10_SOURCE_FETCH_DIAGNOSIS_20261118.md). The [19-case partial checkpoint](RELIABILITY_TRIAL_B_PARTIAL_20261118.md) remains preserved as an accurate historical stopping record. A separate [bounded supervision trial](SUPERVISION_TRIAL.md) demonstrated independent MCP and tunnel child restarts with exact synthetic source retrieval and successful control-plane polling; it is not a reboot/WSL shutdown persistence guarantee. No private conversation archive is present and no reliability population threshold is accepted. **New evidence:** a [retrospective Unicode quote-fidelity audit](TRIAL_B_QUOTE_FIDELITY_AUDIT.md) found 11/13 source-quoted spans exact and two quote-mark-only differences (H03/H10). An entirely separate [26-message offline holdout](HOLDOUT_C_PROTOCOL.md) found 8/8 explicit but 6/8 implicit recall@8 for the existing lexical search, with only 1/8 implicit targets ranked first. See [Holdout C baseline](HOLDOUT_C_BASELINE_RESULTS.md); it does not exercise live ChatGPT.

To inspect the currently running bounded synthetic supervisor without modifying it:

    python3 vnext/scripts/supervise_synthetic_services.py status

When both dedicated services are stopped, the supervised synthetic-only launch is:

    python3 vnext/scripts/supervise_synthetic_services.py preflight
    python3 vnext/scripts/supervise_synthetic_services.py run

The second command stays in the foreground and manages only its own two child processes. It refuses to duplicate an existing instance. No OS startup service is installed, and a live user-space session is not a reboot persistence guarantee.

Secure MCP Tunnel documentation: https://developers.openai.com/api/docs/guides/secure-mcp-tunnels
Custom plugin documentation: https://developers.openai.com/api/docs/guides/custom-mcp-server
Official MCP Python SDK v2: https://py.sdk.modelcontextprotocol.io/

Do not misinterpret unit or local MCP tests as evidence that ChatGPT automatically activates the plugin.

## Local embedding shadow experiments (not a live MCP dependency)

The read-only synthetic vNext MCP continues to use the original SQLite FTS5 search. The separate, optional CPU shadow experiments are documented in:

- [Pre-registered method comparison](SHADOW_EMBEDDING_EXPERIMENT_20261118.md)
- [Previously seen Holdout C results](SHADOW_EMBEDDING_RESULTS.md)
- [Newly registered Holdout D protocol](HOLDOUT_D_PROTOCOL_20261118.md)
- [Fresh 32-case Holdout D results](SHADOW_HOLDOUT_D_RESULTS.md)
- [Evidence-backed next-stage decision](SHADOW_RETRIEVAL_DECISION_20261118.md)

No shadow dependencies are installed into the live MCP virtual environment. The optional FastEmbed 0.9.1 + ONNXRuntime 1.32.0 environment is under ignored `vnext/.local/shadow-embedding-venv`, with downloaded model files under `vnext/.local/shadow-models`. The pinned model weights and tokenizer hashes are in the C report, but not in Git.

Run the two deterministic test suites independently:

    PYTHONPATH=vnext vnext/.venv/bin/python -m unittest discover -s vnext/tests -q
    PYTHONPATH=vnext vnext/.local/shadow-embedding-venv/bin/python -m unittest discover -s vnext/tests_shadow -q

The semantic experiments are offline candidate-ranking analysis on fictional fixtures only. They do not establish real-world memory quality, arbitrary-case source fidelity or permission to import user history.

## Synthetic relevance and exact source-packet results

The 58-case [relevance/no-source Holdout E protocol](HOLDOUT_E_ABSTENTION_PROTOCOL.md) and frozen [C/D-only cosine calibration](RELEVANCE_GATE_CALIBRATION_20261118.md) demonstrate that the local embedding model's **source-ranking** ability does not provide a sufficient **relevance decision**. The strict cosine-only gate accepted the correct source for just 13/30 relevant questions and wrongly promoted one irrelevant case; see [the full E test](HOLDOUT_E_RELEVANCE_RESULTS.md) and [the rejection decision](ABSTENTION_GATE_DECISION_20261118.md). **That gate is not deployed.**

The separate [shadow source-packet experiment](SHADOW_PACKET_INTEGRITY_E_RESULTS.md) verified 464/464 read-only SQLite packets across the E benchmark, with 40 passing isolated corruption/integrity tests. The [packet-boundary decision](SOURCE_PACKET_BOUNDARY_DECISION_20261118.md) accepts only exact synthetic source resolution; all retrieved records remain marked `unverified_candidate` until a separate relevance/answer decision. The connected native MCP continues to serve only its original six synthetic records through FTS5.

## Native source-grounding and recovery checkpoint

The completed [Trial F tool trace](NATIVE_TRIAL_F_TRACE_RESULTS.md) and separate [semantic source review](NATIVE_TRIAL_F_SEMANTIC_RESULTS.md) test missing facts, historical corrections, ambiguous references and unrelated questions in 16 new native ChatGPT Project conversations. **Five of eight source-needed cases performed an audited MCP lookup**, despite all eight main conclusions agreeing with the original synthetic fixture. All four ambiguous questions selected an unjustified unique referent. [Project-memory context](PROJECT_MEMORY_CONFOUND_20261118.md) means these are within-Project functional observations, not independent retrieval causality claims.

After an Ubuntu restart, the six-source MCP and tunnel were [manually restored and verified](UBUNTU_RESTART_RECOVERY_20261118.md), without enabling automatic startup. The [clean-context Trial G design](NATIVE_TRIAL_G_CLEAN_CONTEXT_DESIGN_20261118.md) was subsequently executed on 19 November 2026; see [complete trace](NATIVE_TRIAL_G_TRACE_RESULTS.md) and [separate semantic review](NATIVE_TRIAL_G_SEMANTIC_RESULTS.md).

The [post-restart direct connected-plugin verification](POST_RESTART_CONNECTED_PLUGIN_SMOKE_20261118.md) additionally confirms an explicit ChatGPT lookup and source fetch through the restored tunnel, with matching local MCP audit events. This proves full read-only connectivity, not unprompted source relevance or autonomous memory selection.

## Current native Trial G and offline referent Gate H — 19 November 2026

The separate 20-source fictional G MCP and private tunnel on localhost 8788 were connected in a new project-only ChatGPT Project, preserving the original six-source MCP on 8787. G01 was the first chat-empty Project turn and invoked the new source tool. The complete 16-case [native trace](NATIVE_TRIAL_G_TRACE_RESULTS.md) recorded 15 successful lookups, no separate fetches, 14/14 specified invocation/selectivity checks and two ambiguity cases whose lookup was optional. The separate [original-source review](NATIVE_TRIAL_G_SEMANTIC_RESULTS.md) found 14/16 acceptable answers; the two failures, G13 and G14, confidently selected Merrow despite missing referent identity. G02–G16 may use prior same-Project chats. No population reliability claim follows.

A distinct, non-deployed [Referent Gate H](REFERENT_GATE_H_PROTOCOL_20261119.md) addresses only current-question **unique narrative selection**. Its [38 preregistered synthetic cases](REFERENT_GATE_H_CASES_20261119.json) and evidence-backed manifest were published before code at Git commit 2e1535e. The [independently reconciled offline results](REFERENT_GATE_H_RESULTS_20261119.md) passed 38/38: 16 uniquely anchored, 16 unanchored, four explicitly multi-topic and two mismatching retrieved candidates. [Decision](REFERENT_GATE_H_DECISION_20261119.md): ACCEPT_SHADOW_REFERENT_SELECTION_ONLY. This does not verify native ChatGPT following the gate, semantic retrieval relevance, history intent classification or authenticated conversational follow-up context.

Core Python regression is 101/101 and separate shadow regression 40/40; live MCP code, original plugin, both archives/tunnels, real data and operating-system boot settings were unchanged in H. The next task is an independently registered native decision-support contract and tests, not silent activation of the shadow gate.

## Stage I: isolated native decision-support connector and qualified result

The [Stage I pre-registered protocol](NATIVE_DECISION_SUPPORT_I_PROTOCOL_20261119.md), containing 20 offline and 16 native fictional cases, was pushed before implementation at Git commit bdc5dc7. The new [read-only synthetic MCP source resolver](ltm_vnext/decision_support_i.py) remained separate from the original six-message service and Trial G. Its [offline evidence](NATIVE_DECISION_SUPPORT_I_OFFLINE_RESULTS_20261119.md) was **20/20 PASS**, with a one-shot private HTTP MCP tool smoke test. Core regressions passed 118/118 and separate shadow tests 40/40.

Stage I was subsequently connected through a **third** private loopback MCP listener on 127.0.0.1:8789, a separate private tunnel and custom ChatGPT plugin named **LTM-RAG vNext Decision I**. A newly created ChatGPT Project, **LTM-RAG vNext Decision I Clean Context**, had Project-only memory selected at creation and independently verified in reopened settings. It was initially chat-empty, with I01 the first native question. See [connection verification](TRIAL_I_CONNECTION_VERIFICATION_20261119.md).

All **16/16 native cases** were sent exactly once to distinct saved chats, with exact prompt SHA-256, pending-send protection and independent tool audit. The [native trace report](NATIVE_DECISION_SUPPORT_I_TRACE_RESULTS_20261119.md) confirms 14 successful I resolver calls, **12/12 specified invocation/selectivity checks** and **14/16 correct source-packet scope**. The separate [semantic original-source review](NATIVE_DECISION_SUPPORT_I_SEMANTIC_RESULTS_20261119.md) found **14/16 acceptable** and **two unsupported referent failures, I05/I15**. Both ambiguous questions selected unrelated historical context, despite the local H/I gate correctly rejecting the original user prompts in offline testing.

[Decision](NATIVE_DECISION_SUPPORT_I_DECISION_20261119.md): **RETURN_NATIVE_REFERENT_SELECTION; ACCEPT_ISOLATED_SOURCE_FIDELITY_AND_TOOL_INVOCATION_ONLY**. The MCP tool receives assistant-authored argument text, not a proven host-authenticated copy of the user's question. Adding factual evidence or a separate fetch call cannot solve that trust-boundary problem. A trusted user-message input mechanism must be established and separately tested before any real-history or production integration. Neither older service/tunnel, genuine archive data, external inference, key creation nor OS automatic startup were changed.


## Stage J: trusted current-turn ingress feasibility (offline shadow only)

The [Stage J preregistered protocol](TRUSTED_TURN_J_PROTOCOL_20261119.md) and [26 frozen synthetic cases](TRUSTED_TURN_J_CASES_20261119.json) were committed **before** implementation at `0628a23`. Official OpenAI documentation describes MCP arguments as model-supplied. `openai/session` identifies an anonymised conversation for correlation, not an independently authenticated copy of the user's current message. The inspected ChatGPT custom-MCP contract does not document such a user-message binding.

A separate in-process [conditional turn-binding proof](ltm_vnext/trusted_turn_j.py) was independently audited at **26/26 PASS**, including both prior Stage I ambiguous prompts, injected story identities, wrong/missing turn contexts, replay, and valid original single/multi-source packets. **134/134** core and **40/40** shadow tests pass. [Full original-evidence audit](TRUSTED_TURN_J_OFFLINE_RESULTS_20261119.md); [source-backed decision and architecture trade-offs](TRUSTED_TURN_J_DECISION_20261119.md).

**Stage J does not modify the connected MCP, send native ChatGPT questions, verify host-provided current-user text, or admit genuine conversation data.** Its outcome is `PASS_SHADOW_TRUSTED_INGRESS_CONDITIONAL_ONLY`; a hard guaranteed native ambiguity gate remains unverified. The I05/I15 native failures are preserved.


## Stage K: native MCP metadata presence and session correlation — 20 November 2026

Frozen before implementation at `8b6ae97`: [protocol](MCP_METADATA_K_PROTOCOL_20261119.md) and [10 offline + 3 native observations](MCP_METADATA_K_CASES_20261119.json). The [read-only K adapter](ltm_vnext/metadata_probe_k.py) passes **10/10 frozen** cases, **146/146** core and **40/40** shadow tests. The [earlier K connection record](MCP_METADATA_K_CONNECTION_20261119.md) accurately documents the *then-unverified* plugin; a distinct **private K ChatGPT plugin has since been created and independently verified**.

[Reconciled native Stage K evidence](MCP_METADATA_K_NATIVE_RESULTS_20261120.md) confirms four actual native K tool events, not the planned maximum three. K-N01/K-N02 share a saved conversation and process-fingerprint session/subject; an **extra K-N01-style invocation** occurred in another saved chat at 09:49:50; the separate K-N03 prompt/send and fourth event at 09:58:06 are temporally corroborated. All four events contain session and subject metadata; different conversations have different observed session fingerprints, the same subject fingerprint, **no advertised elicitation capability**, and **no original user-message attestation**. The fourth conversation's assistant response said *Unknown* despite the tool audit's positive presence flags. **Decision: native metadata delivery and correlation OBSERVED, but the three-call protocol has a documented overrun and is not a clean PASS.** No session field establishes the user's exact current-message text; Stage I's I05/I15 native failures remain unresolved. No real data, other connector change, external inference or OS autostart.


## Stage L: conditional explicit-topic confirmation shadow — 20 November 2026

The [Stage L protocol](CLARIFICATION_L_PROTOCOL_20261120.md) and [20 frozen cases](CLARIFICATION_L_CASES_20261120.json) were published **before implementation** at `d5e7649333153d8ba5e0b7e91cb33fa480945974`. An independent [offline audit](CLARIFICATION_L_OFFLINE_RESULTS_20261120.md) passed **20/20**: a separate simulated user-UI confirmation can conditionally constrain source release to exactly one or two user-selected *fictional topics*. No source packet is returned for an unconfirmed or forged model request, guessed challenge, wrong user/session/flow, invalid choice, expiry or replay. Original packets are revalidated through existing I source integrity before a one-shot release.

**Boundary:** This is a conditional *source scope* gate, **not** a verified real ChatGPT user click, original question attestation, or native repair of I05/I15. The model-facing status contains neither private confirmation challenge nor source packets. A future native UI flow would require its own independently registered and authenticated experiment. No new MCP server/plugin/tool, live service change, real-data ingestion, external model API or OS autostart in L. [Full decision](CLARIFICATION_L_DECISION_20261120.md). Core regression: **154/154**, shadow: **40/40**.


## Stage M — isolated MCP Apps selector (offline transport complete, native not yet claimed)

Frozen Stage M [protocol](MCP_APPS_M_PROTOCOL_20261120.md) and [16 cases](MCP_APPS_M_CASES_20261120.json) were independently read back from registration commit `2c24a4ebabb5a8be8ec4d3ecabc5cedc73a69193` before implementation. The disposable [server](ltm_vnext/mcp_apps_m.py) and [HTML widget](ltm_vnext/mcp_apps_m_widget.html) expose two tools: model+app opening, app-only confirmation. The [independent offline audit](MCP_APPS_M_OFFLINE_RESULTS_20261120.md) passes **16/16**, with core **160/160** and shadow **40/40** passing. A separate one-shot local Streamable HTTP SDK client verified tool/resource discovery, widget MIME, tool result UI-only challenge transport, accepted synthetic choice, wrong-session denial, replay denial and zero returned source packets; its temporary 8791 listener was terminated. **No native ChatGPT widget, human choice or host enforcement has been demonstrated** by these offline tests. Session/subject are only correlation hints, and app-only visibility is enforced by the host, not the server. The existing original/G/I/K services remain unchanged.


### Stage M private plugin and tunnel connection checkpoint — 20 November 2026

The distinct M-only tunnel `tunnel_6affa48f70b0819187bbe06449bf2750` was created once, then independently verified by name, ID and organisation. Its ignored profile points exclusively to the new 8791 loopback MCP Apps listener; the M tunnel and the pre-existing original/G/I/K tunnel readiness endpoints all returned `ready`. A new private, user-scoped ChatGPT plugin **LTM-RAG vNext Apps M** (`plugins_6affa5ab43fc81918f735d54ea8e9425`) was created and independently read back, including exact M tunnel binding in its stored package manifests. **No Stage M native call was made:** the isolated fresh ChatGPT test window did not independently expose a selectable M tool, so M-N01 and optional M-N02 remain `NOT_RUN_TOOL_NOT_VERIFIED`. See [connection evidence](MCP_APPS_M_CONNECTION_20261120.md). Registry installation and tunnel health are not evidence of native UI rendering or a human choice; the Stage I and K verdicts remain unchanged.


### Stage M native MCP Apps transport — 20 November 2026

The Stage M private tunnel was independently registered with a **native ChatGPT custom MCP plugin** `plugin_asdk_app_6affaf818f3481919433489e25b52471`, distinct from the earlier portable desktop plugin package. A single one-send-guarded ChatGPT test opened the **actual embedded MCP Apps widget**, displaying all five fictional topic choices. A single explicitly labelled **automated** Merrow click called the native **app-only** `confirm_topic_m` tool, with **zero source packets**. The server returned `EXPIRED` because the frozen **60-second TTL** had passed (**262.618 s** from opening); ChatGPT's widget rendered the expiry. Thus native widget and callback transport are observed, **not** a successfully confirmed selection, human approval or original-user-message attestation. The UI-added plugin mention preceded the exact frozen prompt text and is recorded as a full-message presentation deviation. Frozen Stage M native send/click limits are exhausted: no additional native M sends or clicks. [Independent native audit and decision](MCP_APPS_M_NATIVE_RESULTS_20261120.md). Stage I and K verdicts remain unchanged.


### Stage N — guarded native under-TTL confirmation probe (20 November 2026)

[Stage N frozen protocol](MCP_APPS_N_PROTOCOL_20261120.md) and [two-case matrix](MCP_APPS_N_CASES_20261120.json) were independently GitHub-verified at preregistration commit `75f4d64b5616cacbbb648069be60320f0d88c4e7`. One new native ChatGPT prompt called `open_topic_selector_m`, returning `AWAITING_CONFIRMATION` and zero source packets; a saved browser readback confirmed the exact frozen prompt suffix, separate native plugin mention, and all five fictional topic buttons. **N-N02 did not perform a click**: the one-send controller aborted with a safe-viewport guard error before invoking `confirm_topic_m`. Later, after the 60-second TTL, the button was inside the viewport, so the transient geometry difference is not explained and must not be described as a permanent widget defect. The private audit holds the prior two M events unchanged plus exactly one N opening event. [Independent Stage N native result](MCP_APPS_N_NATIVE_RESULTS_20261120.md): `NATIVE_N_UI_NOT_VERIFIED`, no accepted confirmation, no human consent, original user-message attestation or actual source release. No further Stage N resend or click is permitted in this expired flow. Stage M, Stage I and Stage K judgments remain unchanged.


### Stage O — native viewport-recovery test result (20 November 2026)

The [frozen Stage O protocol](MCP_APPS_O_PROTOCOL_20261120.md) and [two-case matrix](MCP_APPS_O_CASES_20261120.json) were committed before execution at `0a82ea6e22528d3494f7095b7112b2ef78f2e515`. Exactly **one** native opening reached the unchanged synthetic-only M service, returning `AWAITING_CONFIRMATION` with zero source packets. **No app-only confirmation callback was observed, and no automated-click marker exists.** The test browser window was unavailable at final readback, so the precise reason for the missing click is unknown; the positive native path has **not** passed. The Stage O challenge has expired and cannot be retried under its frozen budget. See [Stage O independent native evidence](MCP_APPS_O_NATIVE_RESULTS_20261120.md). Prior Stage M/N results, Stage I and K limitations, and all original/G/I/K/M service boundaries are preserved.


### Post–Stage O UI diagnostics (20 November 2026)

A [read-only native UI diagnostic module](scripts/NativeAppsUiDiagnostics.ps1) now provides deterministic verification of the existing fictional Merrow widget, viewport/stability logic and an allowlisted private JSONL trace. **16/16 Windows PowerShell self-tests pass**; an inspection of the old, absent Stage O window returned `WINDOW_ABSENT` without sending, clicking or changing focus. This is **diagnostic instrumentation, not a new native confirmation or proof of Stage O success**. The exact cause of the missing Stage O callback remains unknown because the original post-send process output and per-iteration telemetry are unavailable. See the [diagnostic decision](NATIVE_APPS_UI_DIAGNOSTICS_20261120.md) before commissioning any new time-bounded native trial.


## Stage P — native positive MCP Apps UI callback (20 November 2026)

The [preregistered Stage P protocol](MCP_APPS_P_PROTOCOL_20261120.md) and [two frozen native cases](MCP_APPS_P_CASES_20261120.json) were independently verified on GitHub at `340fe6e27277f9e3295ec0995eb4cb80b5119422` before implementation. In a newly created, dedicated Chrome window, the existing native ChatGPT plugin rendered the five fictional topic controls. One frozen message and **one** Merrow `InvokePattern` activation produced the expected native `open_topic_selector_m / AWAITING_CONFIRMATION` then app-only `confirm_topic_m / CONFIRMED` server events **12.192 seconds apart**, within the unchanged 60-second TTL. Independent UI readback showed all five buttons disabled and the positive synthetic-selection status. **Zero source packets**, no human consent attestation or trusted original user-message ingress. The controller and independently checked audit/trace are in [Stage P evidence](MCP_APPS_P_NATIVE_RESULTS_20261120.md); private markers/chat URL remain ignored. `PASS_P_NATIVE_ACCEPTED_UI_TRANSPORT_ONLY` is a **transport result**, not production authorisation, source relevance or repair of Stage I's unsupported referents. No more Stage P native sends/clicks are permitted.


## Autonomous continuation authority — 20 November 2026

The owner's standing synthetic-only project grant is recorded in [CONTINUOUS_AUTONOMOUS_WORK.md](CONTINUOUS_AUTONOMOUS_WORK.md) and linked from [AGENTS.md](AGENTS.md). Continue within each active ChatGPT turn through routine tests, frozen registrations and independently verified GitHub checkpoints without requesting renewed approval. Do not interpret an expired native probe as permission to resend; preregister a separate finite trial if needed. The ChatGPT conversation itself does not run remote commands between turns without a separate scheduled/agent mechanism.


## Stage Q — native app callback quarantine versus source authorisation (20 November 2026)

[Stage Q preregistered protocol](MCP_APPS_Q_PROTOCOL_20261120.md) and [21-case frozen matrix](MCP_APPS_Q_CASES_20261120.json) enforce the essential distinction left by Stage P: `CONFIRMED` is **native app transport evidence**, not trusted source-scope authorisation. The new isolated [quarantine adapter](ltm_vnext/app_event_quarantine_q.py) does not import the archive or owner gateway and returns **zero source packets** from any client/model-authored app event. An independent offline comparator retains Stage L's separately simulated owner-granted one-shot source scope, with exact original fictional packet validation. [Independent audit and decision](MCP_APPS_Q_OFFLINE_RESULTS_20261120.md): **21/21 frozen Q PASS**, Stage L re-audited **20/20**, core regressions **181/181**, shadow **40/40**; no new native calls, true human-consent attestation or production integration. The owner standing autonomous-continuation grant remains active within the synthetic-only project boundary.


## Owner-authentication and original-message boundary (20 November 2026)

A [primary-document review and explicit admission decision](NATIVE_OWNER_AUTH_BOUNDARY_DECISION_20261120.md) follows the accepted Stage P native transport and Stage Q app-event quarantine results. Current OpenAI plugin contracts require OAuth-based authentication and server-side authorisation for user-specific data; `openai/session`, `openai/subject`, app-only tool visibility and synthetic widget confirmation are **not** equivalent to authenticated exact user-message ingress. The installed M plugin remains unauthenticated and synthetic-only. **No genuine archive connector or source release is authorised or built.** Next material dependency is an independently authorised owner-identity/source-scope contract; the standing continuation policy still applies to all reversible, synthetic-only work that does not cross this boundary.


## Chronology of captured messages — 20 November 2026

The [Stage R SQLite chronology amendment](STAGE_R_CHRONOLOGY_AMENDMENT_20261120.md) preserves three distinct concepts: exact original message send timestamp with timezone (`message_sent_at_source`), its normalised UTC instant (`message_sent_at_utc`), and the first SQLite receipt time (`ingested_at_utc`). The existing `event_time`/`time_precision` describes the event under discussion, **not** necessarily when the message was sent. `source_id`/`conversation_id`/`branch_id`/`position` preserve immutable sequence. New records get a UTC ingestion timestamp, idempotent replays do not refresh it, and legacy/frozen records without a reliable send timestamp retain NULL. No frozen R case/fixture or existing live connector was changed.


## Stage R — hosted Vector Store incremental conversation-memory pilot — 20 November 2026

The separately preregistered [12-turn fictional Stage R trial](HOSTED_MEMORY_R_PROTOCOL_20261120.md) has now indexed a single scripted conversation incrementally into **one isolated OpenAI Platform Vector Store** with a 30-day last-activity expiry. Its canonical [SQLite database](STAGE_R_CHRONOLOGY_AMENDMENT_20261120.md) retains 24 exact original messages (12 user, 12 scripted assistant), per-branch order, immutable correction and authorship provenance, and **24 UTC ingestion timestamps**; original send timestamps remain explicitly NULL because they were not supplied in the frozen script. Each hosted file ID resolves to the exact two corresponding SQLite source records; search output never replaces original text. The [six frozen hosted query cases](HOSTED_MEMORY_R_CASES_20261120.json) recovered the expected fictional source on **rank 1 in all 6/6 cases** (8-turn and 12-turn milestones). [Pilot report and independent readback](HOSTED_MEMORY_R_RESULTS_20261120.md). This validates the hosted indexing/retrieval plumbing, **not** automatic native ChatGPT conversation capture, responses generated by ChatGPT, personal memory, identity/consent or general semantic accuracy. Core regression 207/207 and shadow 40/40. Original/G/I/K/M/P connectors unchanged.

## Stage R — real hosted Vector Store, fictional two-sided transcript (20 November 2026)

The owner-authorised [Stage R frozen protocol](HOSTED_MEMORY_R_PROTOCOL_20261120.md) and [12-turn fictional diary fixture](fixtures/synthetic_diary_r_20261120.json) are now indexed in an isolated OpenAI-hosted Vector Store in the new **LTM-RAG vNext — Conversation Memory** API project. The **user and assistant sides remain separate immutable SQLite source records**, with 12 per-exchange hosted text files and private file-ID→two-local-message-ID mappings. The exact original messages, correction links, source roles and hashes are verified on retrieval, independently of the hosted search snippet.

[Stage R indexed-source and search report](HOSTED_MEMORY_R_RESULTS_20261120.md): 24/24 original fictional records, 12/12 completed files, **six frozen hosted semantic-search tests all ranked the intended original turn first** (2 after eight exchanges, 4 after twelve). The implementation is `ltm_vnext/hosted_memory_r.py` with [runner](scripts/run_hosted_memory_r.py) and [independent read-only audit](scripts/audit_hosted_memory_r.py). Local private store metadata, full result ledger and SQLite test archive remain under ignored owner-only `.local/hosted-memory-r`. The new key is read from `/home/jds/.env` as `OPENAI_LTM_RAG_VNEXT_API_KEY`, not copied to Git.

**These were scripted fictional replies, not actual GPT responses.** The existing native ChatGPT UI was not sent any messages or attached to this hosted store. There is no automatic capture of ordinary user/assistant turns and no new native MCP provider. The model/embedding dimensionality used internally by OpenAI's hosted index was not individually selectable or verified. **ChatGPT Work is explicitly prohibited here.** Next engineering task is an separately registered, synthetic-only, single-chat ChatGPT turn capture and exact assistant-response readback, followed by incremental SQL/hosted indexing. It must not bypass the original source/provenance or consent boundary.

## Real ChatGPT responses → SQLite → hosted vectors: Stage S/T (20 November 2026)

A [finite native conversation trial](NATIVE_DIALOGUE_S_PROTOCOL_20261120.md) sent five **fictional simulated-user messages** through a dedicated signed-in normal ChatGPT browser window and observed **five actual model-generated replies**. The first capture's assistant source contained an 80-character Chrome UI footer; consequently Stage S is **PARTIAL**, and its original receipts/store were preserved ([Stage S report](NATIVE_DIALOGUE_S_RESULTS_20261120.md)). An independently registered **zero-extra-send**, read-only [Stage T recovery](NATIVE_DIALOGUE_T_PROTOCOL_20261120.md) verified every original native ChatGPT response body, then reconstructed **10 exact SQLite original records**, **10 actual UTC ingestion timestamps**, **five source send-action timestamps** (but no claimed assistant original send times), and **five clean hosted files** in a separate expiring Vector Store. All **3 frozen T semantic searches ranked the intended original SQL turn first**, and the independent source/file/chronology audit passed ([verified Stage T report](NATIVE_DIALOGUE_T_RESULTS_20261120.md)). Core suite 221/221 and shadow 40/40. This **demonstrates the live scripted conversation capture/index/retrieval loop**, not automatic cross-chat retrieval, ordinary ChatGPT background capture or actual owner-authored data. ChatGPT Work remains prohibited.


## Stage S/T — real ChatGPT generated dialogue and verified hosted memory — 20 November 2026

The [Stage S native trial](NATIVE_DIALOGUE_S_PROTOCOL_20261120.md) entered five **entirely fictional** user messages through a separately verified, signed-in normal ChatGPT Chrome window, received **five genuine ChatGPT model responses**, and captured/indexed ten role-separated SQLite messages and five hosted files. An independent UI readback found the first source capture appended **80 characters of browser footer** to each assistant response, so [Stage S's source-fidelity verdict is PARTIAL](NATIVE_DIALOGUE_S_RESULTS_20261120.md), not a clean pass, even though all three frozen hosted search targets ranked first.

The separately preregistered [Stage T source repair](NATIVE_DIALOGUE_T_PROTOCOL_20261120.md) used **no additional native ChatGPT messages**. It reread the original conversation's five user and five assistant message bodies, proved exact Unicode match to raw capture prefixes minus the fixed known browser footer, and rebuilt a **clean 10-message SQLite archive and a distinct 5-file OpenAI Vector Store** without altering the contaminated Stage S evidence. Independent remote index and source readback returned `PASS_T_EXACT_NATIVE_UI_RENDERED_SOURCE_SQL_HOSTED`; **3/3** fixed retrieval queries ranked their target first. [Stage T results](NATIVE_DIALOGUE_T_RESULTS_20261120.md). Core tests **221/221**, shadow **40/40**.

The original dialogue was **fictional and scripted on the user side**, but the **model replies were actually generated by native ChatGPT**. Message timestamps distinguish automation's UI send-action instant, first SQLite receipt and later assistant UI-completion observation. Native model original server-send time remains unknown. This demonstrates bounded sequential capture and hosted retrieval; it does **not** yet automatically capture all unrelated ChatGPT conversations or silently look up this store from another native thread. ChatGPT Work remains prohibited. All five S native send slots are spent; any future distinct cross-chat test must receive its own separately frozen scope and new action budget.

## Live OpenAI Vector Store retrieval in a new ChatGPT conversation

[Stage W](NATIVE_HOSTED_W_RESULTS_20261120.md) verified the selected connector from normal ChatGPT through OpenAI Vector Store search to both exact SQLite originals. [Stage X](NATIVE_HOSTED_X_RESULTS_20261120.md) repeated the live round trip with an ordinary question after connector selection. The fresh unselected chat answered correctly with zero recorded hosted calls, so automatic hosted recall remains unverified. The unrelated control also made zero hosted calls.

## Automatic recall in fresh normal ChatGPT

[The archive-provenance run](NATIVE_RECALL_ARCHIVE_PROVENANCE_RESULTS_20261120.md) verified two automatic OpenAI Vector Store lookups with the connector and skill unselected. Both replies cited the original SQLite record and returned its exact archive-assigned UTC timestamp. The unrelated control made zero hosted calls. The private plugin's [recall skill source](recall_plugin/skills/fictional-diary-recall/SKILL.md) and [hosted test listener](scripts/run_native_recall_routing.py) are in this branch.

## Long-form recall trial

[The 515-word dictation trial](NATIVE_RECALL_LONG_FORM_RESULTS_20261121.md) returned a 441-word recap and exposed a lookup-length rejection. The backend returned zero original records, and the unrelated control made zero attempts. The private plugin uses the prior verified recall skill. The registered trial launcher accepts `--trial long-form` with a separate durable five-attempt budget.
