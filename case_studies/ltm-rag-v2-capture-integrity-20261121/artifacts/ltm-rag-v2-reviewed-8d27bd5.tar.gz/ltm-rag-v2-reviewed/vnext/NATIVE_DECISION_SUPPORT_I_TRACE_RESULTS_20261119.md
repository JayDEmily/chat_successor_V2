# Native Decision-Support I — independently verified ChatGPT tool trace

Separate Stage I test of a single synthetic-only source-resolution
tool, in a newly created Project with Project-only memory selected.

Executed **16/16** registered cases in unique saved chats;
**14** successful read-only I resolver calls.
Specified invocation/selectivity: **12 PASS**,
**0 FAIL**;
optional-invocation ambiguity cases: **4**.

| Case | Class | Registered invocation | Observed calls | Source packets | Source-scope | Trace | Chat |
|---|---|---|---:|---|---|---|---|
| I01 | ambiguous_first_clean | optional | 1 | [0] | PASS | optional | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I02 | history_corrected | required | 1 | [4] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I03 | history_corrected | required | 1 | [4] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I04 | history_alternative | required | 1 | [4] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I05 | ambiguous | optional | 1 | [12] | FAIL | optional | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I06 | multi_history | required | 1 | [8] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I07 | reported_speech | required | 1 | [4] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I08 | missing_fact | required | 1 | [4] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I09 | unrelated | must avoid | 0 | [] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I10 | unrelated | must avoid | 0 | [] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I11 | ambiguous | optional | 1 | [0] | PASS | optional | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I12 | history_original | required | 1 | [4] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I13 | history_alternative | required | 1 | [4] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I14 | history_corrected | required | 1 | [4] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I15 | ambiguous | optional | 1 | [4] | FAIL | optional | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |
| I16 | missing_fact | required | 1 | [4] | PASS | PASS | [Saved native answer](https://example.invalid/private-chatgpt-evidence) |

Source-packet scope: **14 PASS**,
**2 FAIL** against registered original-topic requirement.

The two scope failures are I05 (12 packets for an unanchored question)
and I15 (four packets for another unanchored question).
They are recorded as FAIL; successful tool transport is not semantic compliance.

## Inspection and uncertainty

- The independent auditor checked all 16 SHA-256 prompt hashes
  against the pre-registered questions, exact saved Project ID,
  distinct chat URLs, event-ID ownership, order and timestamps,
  source packet counts implied by explicit narrative anchors and
  handler status. It verified no pending duplicate-risk send.
- A successful resolver call is evidence that the native assistant
  accessed the correct isolated I tool, not itself that its
  answer correctly used original source text. Semantic source
  fidelity, correction/authorship and ambiguity verdicts are
  independently recorded, not manufactured from tool invocation.
- I01 was the very first message in the newly chat-empty Project;
  I02–I16 may use other chats within this Project. Creation as
  Project-only was verified in a reopened settings modal; whether
  memory settings propagated instantaneously cannot be proved.
- All questions and evidence were fictional. Full answer text,
  private local per-case ledger and tool audit stay Git-ignored.
  Historical G outcomes remain unchanged; absence of separate
  fetch_source calls is expected because the versioned I contract
  includes exact original message packets within one resolver call.
- Original 8787 and G 8788 MCP tools were not intentionally
  modified; any independent audit activity on those tools
  must be evaluated separately rather than silently assumed zero.
