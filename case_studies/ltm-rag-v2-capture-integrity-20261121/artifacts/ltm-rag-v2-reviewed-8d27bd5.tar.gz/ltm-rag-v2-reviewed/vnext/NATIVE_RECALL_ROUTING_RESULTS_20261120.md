# Native recall skill trial — 20 November 2026

The existing private hosted-memory app gained the [fictional diary recall skill](recall_plugin/skills/fictional-diary-recall/SKILL.md) in version 1.0.1. The release readback preserved the app ID and connection. Normal ChatGPT showed the skill in the installed plugin. The test listener continued to use the verified Stage T OpenAI Vector Store and original SQLite records.

Both fresh, unselected ChatGPT questions produced the expected exact excerpts. The hosted backend recorded zero calls in either test window. The first requested the rowing-shell review wording, and the second requested the opening description of the friend who designs rowing shells. This leaves automatic use of the hosted archive unverified. The unrelated case was set aside after the two positive cases failed the tool-call requirement.

Use the separate [source-only tests](NATIVE_RECALL_ARCHIVE_PROVENANCE_CASES_20261120.json) for the next live attempt. They require a timestamp assigned during SQLite ingestion, which was outside the question text and original dialogue.
