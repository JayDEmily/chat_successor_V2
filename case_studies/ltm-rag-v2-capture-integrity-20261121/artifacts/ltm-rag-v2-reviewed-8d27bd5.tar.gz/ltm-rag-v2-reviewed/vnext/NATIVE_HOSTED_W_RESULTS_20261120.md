# Stage W live ChatGPT retrieval — 20 November 2026

**PASS.** One fresh normal ChatGPT conversation, with the existing private hosted-memory connector selected, returned the correct original user correction and the paired ChatGPT reply.

The native W-N01 prompt was sent once at 10:47:00 UTC. The Ubuntu MCP audit recorded a call at 10:47:11 UTC and `FOUND` at 10:47:13 UTC with three candidate pairs. OpenAI Vector Store search ranked turn 3 first. The server returned the corresponding SQLite originals `t03u` (simulated user, position 5) and `t03a` (ChatGPT assistant, position 6), followed by turns 5 and 2. The saved ChatGPT answer separately attributed both records, identified Casey as the Saturday feeder and Sunday morning for watering, and quoted both originals. The rendered quotations matched the exact SQLite text and content hashes.

This run used the clean ten-record, five-file Stage T source. The independent source audit verified the five hosted file mappings and preserved the Stage S and earlier audit evidence. The prior U/V audit hash matched its frozen value. One W user send and one W backend call were used. The W test is closed. The private send marker, saved-chat capture, and call audit are under `vnext/.local`; the capture links the rendered answer to the observed call window.

The W protocol and case matrix at `f02460d7f935fdb1d447ccdd4b688d0e7613aa0e` matched the GitHub files. The live server used the implementation from `bf8cc9d6eb3b501a25ce996838234bb6dccba7f6`. Ubuntu regressions passed 244 core and 40 shadow tests. The original tunnel and native connector carried the live request.

W verifies retrieval with the connector selected. [Stage X](NATIVE_HOSTED_X_PROTOCOL_20261120.md) tests ordinary question wording and automatic routing in a fresh chat.
