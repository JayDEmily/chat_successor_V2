# Stage N — single guarded native under-TTL confirmation probe

**Verdict: `NATIVE_N_UI_NOT_VERIFIED` (the frozen click was withheld after a transient viewport guard failure); positive confirmation NOT established.**

## Preregistration and invariants

- Frozen N registration Git commit `75f4d64b5616cacbbb648069be60320f0d88c4e7`, direct parent `ec90ed9188b7090140ae20a0be83fe7b31e19241`, byte-for-byte verified before result classification.
- Frozen protocol SHA-256 `677311dab616622f7137b7d33490055b8d296ee820ef18ae270871e31f154331`; matrix SHA-256 `a9450310cdac39ce9cdc8a705c0b1f67ad13225c0e28319f4a491114d46f4f28`; exactly two cases N-N01 and N-N02.
- Original Stage M Python server and widget byte-identical to pinned offline implementation; existing M tunnel/native plugin reused, without new key, plugin or listener change.
- First two Stage M audit event bytes preserved with original SHA-256 `3697904ca3f7b744cb87e0b9f6a23628716d2375ee72a6396978972b16c0c19b`; Stage N added exactly **one** new event, not a replacement.

## Actual Stage N observations

- **N-N01: one frozen native prompt sent.** Windows one-send receipt verifies exact frozen request SHA-256 and plugin selection; the saved ChatGPT conversation independently displays the frozen text with a separate UI-added plugin mention.
- Third native MCP audit event: one `open_topic_selector_m`, `AWAITING_CONFIRMATION`, session and subject presence flags true, original text un-attested and **0 source packets**.
- Native embedded widget rendered all five fictional topic buttons and the initial unselected status.
- **N-N02: no click.** The one-send/one-click controller stopped after reporting `Widget button outside safe viewport` rather than clicking unverified coordinates. The automated click marker is absent; the audit contains **no new `confirm_topic_m` event**.
- A separate later UI readback found the Merrow button in the expected viewport (centre x=804, y=594), but that later readback was **after** the frozen 60-second TTL. It does **not** prove the button was in the viewport when the controller aborted. The temporal viewport discrepancy is unresolved.
- No authenticated click, no successful positive confirmation, no human consent, no original-user-question provenance, and no source-data release.

## Decision and stop rule

Do not re-send N-N01 and do not click the expired N widget. The N native test did **not** satisfy the positive-confirmation acceptance predicate. It demonstrated correct fail-closed automation on uncertain UI geometry; that is not proof of successful UI selection.

The same synthetic-only trust boundary applies: host-side app-only tool filtering and client-supplied session/subject correlation are **not** server-side authorisation or exact original user-message attestation. Stage I remains 14/16; Stage K's earlier four-call discrepancy remains.

If a new positive native test is warranted, pre-register it separately and improve the controller's deterministic viewport recovery/settling before the next single send. Do not alter frozen N expectations or reuse its send marker.
