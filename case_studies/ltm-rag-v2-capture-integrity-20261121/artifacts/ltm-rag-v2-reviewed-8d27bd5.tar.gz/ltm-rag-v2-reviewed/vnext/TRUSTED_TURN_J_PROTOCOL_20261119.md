# Stage J — trusted-current-turn ingress feasibility and shadow contract

**Registered 19 November 2026, before implementation. Synthetic-only; no native ChatGPT invocation in Stage J.** This is a new research hypothesis, not a rescore of Stage I. Existing fixtures, services, tunnels, and connected plugins are out of scope for modification.

## Primary evidence consulted (official, 19 Nov 2026)

1. OpenAI Plugins MCP server: https://developers.openai.com/plugins/concepts/mcp-server — the **model** selects the tool and supplies arguments conforming to input schema; server validates the received request.
2. OpenAI Plugins reference: https://developers.openai.com/plugins/reference — `_meta["openai/session"]` is an anonymised conversation identifier for **correlating** tool calls; `_meta["openai/subject"]` an anonymised user identifier for rate limiting/identification. The enumerated client metadata does **not** include an original user-message text or authenticated turn content. Absence from this documented list is not a proof of nonexistence in every private integration.
3. OpenAI Plugins build guide: https://developers.openai.com/plugins/build/mcp-server — enforce authorization server-side; `readOnlyHint` is not authentication. User elicitation is an input-gathering feature, not a retrospective attestation of previous user message text.
4. OpenAI Realtime MCP guide: https://developers.openai.com/api/docs/guides/realtime-mcp — remote MCP does not automatically receive full conversation context; it sees data sent through tool calls.
5. OpenAI Responses API migration: https://developers.openai.com/api/docs/guides/migrate-to-responses — an **application that controls its own input** creates the `role=user` input item. OpenAI Agents SDK guardrails: https://developers.openai.com/api/docs/guides/agents/guardrails-approvals — app-owned guardrails can inspect user input and tool arguments.
6. OpenAI Plugins security and privacy: https://developers.openai.com/plugins/guides/security-privacy — do not request full transcripts as a workaround, and validate model-provided inputs server-side.

## Current finding and scope

**Native ChatGPT custom MCP:** No documented server-side path to a **host-attested copy of the current user's exact message** was established in the official sources inspected. `openai/session` is useful for correlating calls **within one ChatGPT conversation** where provided, but is neither a message body, a per-turn token, nor an authorisation credential. It must not be confused with the cross-chat Project identity or with source authorship. OpenAI SDK tracing events, API-side response items, message IDs supplied by the model, and any hash calculated only from the model's own arguments do not cure this.

**Potential path with an owned front end or agent controller:** the application itself receives the user message, authenticates its session/turn and binds that immutable message to an exact turn before the model executes. Its history resolver then selects topics based **only on the owner-provided message**, never a model-authored `question`. This requires control of message ingress; Stage J does not claim native ChatGPT exposes that control. A user-elicitation prompt can ask a user to supply an identifier, but cannot silently authenticate the original earlier question.

## Frozen shadow experiment

The preregistered `TRUSTED_TURN_J_CASES_20261119.json` contains **26** deterministic synthetic input cases; all expected outcomes and full original packet identities must be frozen in Git **before implementation**. Only an in-process **owner-controlled synthetic fixture** can register a user message. The simulated model may supply an arbitrary different tool question. The resolver's trusted caller context is supplied out-of-band, **never taken from tool arguments**; input `user_id/session_id/turn_id` are test identities only, not a claim that ChatGPT verifies them.

Locked outcome rules:

- No registered, current, matching owner context: `NO_BOUND_TURN`, zero source packets.
- A different model-supplied `question` (even if it adds an identifying record name, differs by Unicode/spacing or supplies fake context): `MODEL_ARGUMENT_MISMATCH`, zero source packets. Consume the registered turn to avoid replay/reuse.
- Exact original message with no grounded explicit anchor: `UNANCHORED`, zero source packets.
- Exact original with one/multiple grounded anchors: `UNIQUE`/`MULTIPLE`; original I resolver returns all four/eight/twelve source packets, original exact bytes and provenance untouched. `UNIQUE` does not guarantee the answer is true outside fictional source evidence.
- No user message text, private credentials, original text, or raw prompt bodies are written into the audit. Frozen case prompts are wholly fictional.
- A successful bound turn is one-shot; no replay, cross-principal, cross-session, cross-turn substitution, stale-turn leakage, duplicate active binding or assistant-controlled registration route.

**Pass criteria:** 26/26 frozen expected statuses and exact ordered original packet IDs; direct mutation/replay/cross-session tests pass; existing core and shadow regressions pass unchanged. No HTTP listener, MCP tool registration, tunnel, plugin refresh, live native send, API inference, new key or source archive import. Documentation must identify whether the new approach is implementable in *native ChatGPT* separately from its offline correctness; a simulated trusted ingress does not prove a real one exists.

**Acceptance:** `PASS_SHADOW_TRUSTED_INGRESS_CONDITIONAL_ONLY` if frozen tests pass. The live native remedy remains `UNVERIFIED_NO_HOST_MESSAGE_BINDING` pending primary platform evidence of a trusted user-message binding. Do not claim I05/I15 repaired natively.
