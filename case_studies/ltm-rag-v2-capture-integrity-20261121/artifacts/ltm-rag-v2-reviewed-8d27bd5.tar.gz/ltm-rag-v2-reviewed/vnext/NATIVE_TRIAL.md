# Native ChatGPT-to-Ubuntu MCP trial (synthetic only)

**Source:** Astra Max independent design, 18 November 2026. The numbered steps below are an execution checklist derived from its proposed acceptance stages, **not** a claim that Astra supplied numbered gates/leaves.

## Verified prerequisites (Ubuntu)

- GitHub branch `work/ltm-rag-vnext-synthetic-20261118` contains a local SQLite/FTS5 synthetic archive and two read-only MCP tools: `lookup_evidence` and `fetch_source`.
- The MCP server responds over local Streamable HTTP at `http://127.0.0.1:8787/mcp` when launched; a loopback HTTP smoke test passed.
- With `--audit-log`, every tool call produces a timestamp, tool name, synthetic marker and result count, **not** the query or recovered words.
- OpenAI's official `tunnel-client` v0.0.21 Linux amd64 ZIP was downloaded from the project's public release page; its SHA-256 was checked against the release's published digest. The verified binary is local and Git-ignored.
- The dedicated Platform tunnel **`tunnel_6afd0f1439e88191862ade433921b3f9`** (`LTM-RAG-vNext-synthetic-20261118`) was created and verified by a separate read-only API list. Its org attachment is known; **actual ChatGPT connectivity is now independently verified** by the plugin connection toast and eight successful native MCP calls (see `NATIVE_LIVE_EVIDENCE_20261118.md`).
- Local profile `ltm-vnext-synthetic` was created under `vnext/.local/profiles`, pointing at the loopback HTTP MCP endpoint. The local service launched and loaded 6 synthetic records.
- The owner authorised **reuse of the existing project key** rather than new runtime credentials. `scripts/tunnel_using_existing_key.py` maps `OPENAI_API_KEY` to the process-only `CONTROL_PLANE_API_KEY`; no stored credential is changed. `OPENAI_ADMIN_KEY` is excluded from the daemon environment.
- With the local server running, `doctor --json --explain` returned `result=ok`. The tunnel successfully fetched its metadata from OpenAI and reached `200 ready` and `200 live`. At 2026-11-18T02:43:17Z the health JSON reported active polling with a successful OpenAI control-plane poll and zero consecutive failures. **The subsequent ChatGPT plugin connection and actual native recall were verified separately** in `NATIVE_LIVE_EVIDENCE_20261118.md`.
- The separate API Access gateway was inspected as the **future inference/usage boundary**, not as a substitute for the native MCP tunnel. No Responses generation or usage API query was needed for this synthetic retrieval stage.

## Completed native compatibility trial

The user authorised UI access to their existing Chrome ChatGPT session. The private plugin **LTM-RAG vNext Synthetic Recall** was created with the existing tunnel ID and connected successfully, without adding credentials. An explicitly requested synthetic search succeeded; **three** history-needed requests in fresh chats (including one inside a dedicated ChatGPT Project) made relevant tool calls **without naming or selecting the plugin**, and **two** unrelated requests made no memory calls. A controlled MCP service outage caused ChatGPT to report source unavailability; recovery was demonstrated by another successful source lookup. See [native test evidence](NATIVE_LIVE_EVIDENCE_20261118.md) for exact inputs, outputs, event IDs, and limitations. **This is a functional compatibility PASS, not acceptance of the aggregate initiation/selectivity targets.**

## Remaining steps

1. **Operator recovery only, if the synthetic services stop:** In one Ubuntu terminal run `bash vnext/scripts/run_synthetic_mcp.sh`. In another run `python3 vnext/scripts/tunnel_using_existing_key.py doctor`; on `result=ok`, run `python3 vnext/scripts/tunnel_using_existing_key.py run`. This reuses the existing Ubuntu project key without placing credentials in Git or the CLI argument vector.
2. **Completed:** a normal ChatGPT Project context in a separately created `LTM-RAG vNext Synthetic Trial`, with one unprompted history-needed request and one unrelated turn.
3. **Completed:** a bounded local MCP outage, truthful ChatGPT source-unavailability and a verified recovered lookup after restarting the synthetic service.
4. **Completed pre-registered trial:** following a verified Windows/WSL recovery, the remaining N10 was sent once from an isolated new Chrome window, without disturbing the unrelated draft. Final figures: **10/10 required lookup initiation**, **9/10 stricter source-fetch/content checks** (H10 still fails the fetch requirement), and **0/10 unnecessary lookups**. See [complete results](RELIABILITY_TRIAL_B_RESULTS.md), [historical 19-case stop](RELIABILITY_TRIAL_B_PARTIAL_20261118.md), and [H10 mechanism](H10_SOURCE_FETCH_DIAGNOSIS_20261118.md). The two-sided 95% Wilson intervals do not establish Astra's population reliability thresholds.
5. **Bounded supervision verified:** the dedicated MCP and tunnel child processes restarted independently, with live MCP lookup/fetch and control-plane polling restored. See [supervision evidence](SUPERVISION_TRIAL.md). Durability after Windows restart, WSL shutdown, user sign-out and the supervisor's own unexpected exit is untested. Personal conversation capture/import and secondary API research remain deferred.

No private ChatGPT conversations should be sent through the synthetic trial. The local CLI imports only fixtures explicitly marked `synthetic=true`.

## Local test commands

From the repository root:

```bash
export PYTHONPATH=vnext
vnext/.venv/bin/python -m unittest discover -s vnext/tests -v
vnext/.venv/bin/python vnext/scripts/smoke_http.py
```

The tunnel client can be inspected locally with:

```bash
vnext/.local/tooling/tunnel-client help quickstart
```

The script `run_synthetic_mcp.sh` runs in the foreground. Do not claim a connection is live until OpenAI tunnel health and an actual ChatGPT tool call have both succeeded.

## Evidence recording

For each normal conversational turn, record **turn ordinal, whether history was needed, whether a tool call occurred, whether it was relevant, and the matching timestamp/event ID**. Do not copy personal dialogue into the issue or Git history. Compare call events from the local JSONL audit log. The provided fictional fixture must not be presented as the user's historical memory.

Astra's proposed later-stage population thresholds were at least 90% initiation on history-needed turns and at most 10% unnecessary searches. The 20-case synthetic sample now has measured point estimates, but their Wilson 95% intervals (**72.2%–100%** initiation and **0%–27.8%** unnecessary lookup) do not establish these population targets. Additional representative testing and human value evaluation remain separate gates.

## Official references

- [Secure MCP Tunnel](https://developers.openai.com/api/docs/guides/secure-mcp-tunnels)
- [Add custom MCP server](https://developers.openai.com/api/docs/guides/custom-mcp-server)
- [Astra report in Drive](https://example.invalid/private-drive-evidence)
