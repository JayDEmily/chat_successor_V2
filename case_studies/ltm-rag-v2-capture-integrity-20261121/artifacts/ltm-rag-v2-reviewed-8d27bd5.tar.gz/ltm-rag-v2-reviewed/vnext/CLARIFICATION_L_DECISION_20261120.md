# Stage L decision — conditional UI-approved source scope only

**20 November 2026 | Synthetic offline; native ChatGPT unverified.**

**Decision: PASS_L_CONDITIONAL_OWNER_UI_SHADOW_ONLY.** The [frozen Stage L protocol](CLARIFICATION_L_PROTOCOL_20261120.md) and [20-case matrix](CLARIFICATION_L_CASES_20261120.json) were committed and independently GitHub-read-back **before** implementation at `d5e7649333153d8ba5e0b7e91cb33fa480945974` (parent `9227a20562c157876e1966ef9527a76e4edcca4d`).

## Established in this limited scope

- [Independent 20/20 audit](CLARIFICATION_L_OFFLINE_RESULTS_20261120.md) checks frozen registration bytes, exact original 20 synthetic source records, SHA-256, authorship, branch, source locators, reported speaker and correction relationships.
- A model-authored current question or model-supplied topic hint cannot by itself release a source. The mock server creates an **unpredictable private UI challenge** and exposes a model-visible `AWAITING_CONFIRMATION` result with no source packets or secret.
- Only a separate *simulated owner-UI callback*, with the correct private challenge, current synthetic owner context and one or two distinct allowed fictional topics, can grant one-time source scope. Missing, forged, wrong-session, wrong-principal, expired or replayed confirmation produces zero source packets. The model's question is ignored for source selection even after confirmation.
- When the simulated owner choice is valid, the existing I resolver rechecks the exact original synthetic archive before releasing only those source packets. The offline trial covers both prior ambiguous I05/I15 question strings: a separate confirmed topic can determine **topic scope**, but does not authenticate what the original question said or what it *meant*.

## What is not established

The owner-UI callback was a **test harness assumption**, not a verified native ChatGPT human interaction. ChatGPT has not yet been shown to deliver an authenticated click or exact original turn to the server. The [official Plugins reference](https://developers.openai.com/plugins/reference) documents `_meta.ui.visibility` and widget-only `_meta` data, while the [official MCP Apps UI quickstart](https://developers.openai.com/plugins/build/app-quickstart) documents embedded widgets and app-initiated `tools/call`. Those are *implementation candidates*, not evidence of a native authenticated approval channel. The [MCP build guide](https://developers.openai.com/plugins/build/mcp-server) documents elicitation, while Stage K's four native events advertised no elicitation capability; this one observation does not exclude all alternative client modes.

The [official MCP Events feature](https://developers.openai.com/plugins/build/mcp-events) is server-to-ChatGPT update delivery and cannot independently attest the currently typed user question. In Stage K, the [documented session/subject metadata](https://developers.openai.com/plugins/reference) were present for observed tool calls but cannot grant source access or prove the original question. No new project token, authenticated user principal, production message ingress or source relevance classifier has been demonstrated by L.

## Handover / next bounded engineering gate

1. **Do not connect the Stage L shadow class directly as a model-callable approval tool.** A model-controlled confirmation function would invalidate the trust boundary immediately. Preserve I/J/K verdicts and source integrity checks.
2. A later **separately preregistered** native experiment could build a disposable synthetic-only MCP Apps widget whose model-facing tool never leaks its UI-only challenge and whose app-only confirmation tool is not available to the model. Verify actual visibility, tool provenance, server-side authorisation and replay/context isolation before any source release. A synthetic UI automation click would prove only functional transport, **not** that a human consented.
3. If the product requires a *hard guarantee for the user's exact words*, use an **owned application/controller ingress**, as demonstrated conditionally in Stage J. A direct topic choice is a different requirement and is not interchangeable with exact-message binding.

No original/G/I/K service or connector edit, genuine-history import, external inference, new credentials, OS autostart, or native ChatGPT message occurred during Stage L.
