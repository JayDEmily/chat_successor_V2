# Trial G — separate native connector and tunnel verification

**Date:** 19 November 2026 (Australia/Melbourne). **Starting checkpoint:** bae9480 on branch work/ltm-rag-vnext-synthetic-20261118.

## Independently checked boundaries

- Original six-message MCP remains on private loopback 127.0.0.1:8787, original tunnel client remains running and reports ready=true, control-plane status=ok, with successful polling. Original plugin LTM-RAG vNext Synthetic Recall remained listed as connected in ChatGPT.
- Distinct synthetic Trial G MCP is on private loopback 127.0.0.1:8788, with isolated 20-record SQLite archive and separate .local/trial-g-mcp-audit.jsonl. The source HTTP smoke checks g03 exact bytes, source SHA-256, original branch correction and explicit readonly tool annotations.
- New OpenAI tunnel ID: tunnel_6afe1991fb2c8191850673165b90cce5. Read-only administrative lookup independently confirmed its name, organisation and identity; no additional tunnel or API key was created in this continuation.
- Local, Git-ignored profile: .local/profiles/ltm-vnext-clean-g.yaml; its MCP target is http://127.0.0.1:8788/mcp. New dedicated runner scripts/tunnel_g_using_existing_key.py reads the existing authorised Ubuntu API key into process-only CONTROL_PLANE_API_KEY, explicitly excludes the admin credential, and preserves the original runner and original tunnel profile.
- G tunnel client startup identified the intended G tunnel and G profile, established the streamable HTTP MCP session, completed successful control-plane polling and dispatcher delivery. At 11:03 AEDT the G health endpoint reported ready=true, control-plane ok and 17 completed dispatches; the original tunnel also reported ready=true and control-plane ok.
- A second **private ChatGPT plugin** named **LTM-RAG vNext Clean G** was created, configured for the new tunnel, then independently shown in the connected plugin list alongside the original. Plugin ID: plugin_asdk_app_6afe3844404081919e64e60152aef9d2.
- The dedicated Project LTM-RAG vNext Trial G Clean Context, ID g-p-6afd806ca9348191accae58eea37c74c, had its **Project-only** memory setting reopened and read back. Its chat list was visibly **No chats** before the first Send. Project settings propagation remains a platform caveat.
- G01 was sent once as the first Project turn with no explicit tool-selection chip, and the separate local G MCP audit recorded successful lookup event 0026303e-7508-4049-9260-da35c4e45a01. Native G connector access is thereby established; the independent answer/fidelity results are in the separate Trial G reports.

## Runner and evidence protection

The scripts/Run-NativeTrialG.ps1 runner guards the dedicated Chrome window using the pre-recorded window handle and exact Project URL; checks the unique composer and frozen prompt; rejects unexpected drafts and any existing pending-send marker; persists a pending marker **before** invoking Send; saves unique ChatGPT conversation URLs, full answer text, successful local MCP audit IDs and lookup/fetch counts; and clears pending only after an observed completed answer. It has a bounded timeout that holds uncertain cases for manual reconciliation rather than resending. Later cases include a SHA-256 prompt marker.

G01's saved result predates the strengthened prompt hash; that missing marker is explicitly retained. The first Project turn's empty-state UI and prompt were independently checked before Send. No external GPT API inference, real conversation history import, public MCP port, automatic OS startup change, original connector modification or previous audit rewrite occurred.
