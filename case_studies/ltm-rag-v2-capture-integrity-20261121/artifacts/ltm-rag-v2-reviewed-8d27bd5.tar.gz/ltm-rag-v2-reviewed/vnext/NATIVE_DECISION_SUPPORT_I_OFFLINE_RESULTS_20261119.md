# Native Decision-Support I — independently audited OFFLINE result

**Verdict: PASS_OFFLINE_I_ONLY.** All **20/20** preregistered
synthetic decision/source cases passed. This is **not** a native
ChatGPT trial, not a deployed connector and not a model-behaviour fix.

## Frozen evidence and source identity

- Both preregistered files were checked byte-for-byte against
  Git SHA bdc5dc7b6862531c5c0f29d56503e3fb5ee9876d; parent d05bae31ded0ce17eb55c0b7b3cfdb2b5c1055e3.
- Unmodified original G 20-message fictional fixture SHA-256:
  e3531da9538eb40dc41bec43f29c089f7aed7525ee574e84d21e469fabf9dcbf.
- Every source packet from all 20 cases independently matched
  the fixture's exact Unicode source bytes, SHA-256, author, branch,
  attributed speaker, locator and neighbouring-branch boundary.
- UNANCHORED questions returned **zero source packets**, including
  both previously failing G13/G14 queries.

## Case classifications

- MULTIPLE: 2
- UNANCHORED: 7
- UNIQUE: 11

| Case | Type | Status | Full source message IDs |
|---|---|---|---|
| I-O01 | exact_G13 | UNANCHORED | none |
| I-O02 | exact_G14 | UNANCHORED | none |
| I-O03 | name | UNIQUE | g01, g02, g03, g04 |
| I-O04 | id | UNIQUE | g01, g02, g03, g04 |
| I-O05 | id | UNIQUE | g09, g10, g11, g12 |
| I-O06 | reported_speaker | UNIQUE | g05, g06, g07, g08 |
| I-O07 | id | UNIQUE | g13, g14, g15, g16 |
| I-O08 | id | UNIQUE | g17, g18, g19, g20 |
| I-O09 | comparison | MULTIPLE | g01, g02, g03, g04, g17, g18, g19, g20 |
| I-O10 | comparison | MULTIPLE | g09, g10, g11, g12, g13, g14, g15, g16 |
| I-O11 | ambiguous | UNANCHORED | none |
| I-O12 | authenticity | UNIQUE | g05, g06, g07, g08 |
| I-O13 | missing_fact | UNIQUE | g17, g18, g19, g20 |
| I-O14 | alternative_branch | UNIQUE | g09, g10, g11, g12 |
| I-O15 | id | UNIQUE | g05, g06, g07, g08 |
| I-O16 | substring_collision | UNANCHORED | none |
| I-O17 | substring_collision | UNANCHORED | none |
| I-O18 | unrelated_no_intent | UNANCHORED | none |
| I-O19 | alias | UNIQUE | g09, g10, g11, g12 |
| I-O20 | ambiguous | UNANCHORED | none |

## Transport and regression verification

One-shot separate localhost MCP smoke must be recorded
independently: exactly one read-only resolve_history_reference
tool; ambiguous -> no packets; corrected source, two-narrative
comparison and reported-speech packet values exact. A separate
private audit contains successful tool events without prompt
or source text. This report does not inspect a native browser.

New 17-unit tests included intentional corruption of SQLite
record count, original text/hash/locator, author, branch,
reported speaker and correction relationships. The complete
vNext regression is 118/118 core plus 40/40 shadow (command
results observed separately). The pre-existing Archive seed
helper's sqlite context-manager connections may emit ResourceWarning
on forced garbage collection; I's own read-only connections
are explicitly closed, without modifying the existing MCP.

The existing six-source and G MCP interfaces were not changed.
A **separate** native I connector and clean Project must first
be operationally verified before any of the 16 registered
native questions can be sent or counted.
