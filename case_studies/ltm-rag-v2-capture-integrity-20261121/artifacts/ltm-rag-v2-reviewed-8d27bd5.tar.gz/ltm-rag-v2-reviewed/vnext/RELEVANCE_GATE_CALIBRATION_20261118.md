# Raw dense relevance gate: calibration only

The fixed protocol and new Holdout E were committed BEFORE calibration.
This script reads only Holdouts C/D and the registered negative calibration queries.
The resulting threshold is now frozen before any test on E.

Model: BAAI/bge-small-en-v1.5 (local CPU ONNX inference)
Gate rule: nextafter(max negative top1 across 24 C/D questions,+infinity) float32
Threshold float32: 0.721659660
Maximum negative top1 float32: 0.721659601
Calibration config SHA-256: 99162793107342e568dc023e3c1bebef1b73c2e37753643adb1ed1c8bc991012
Negative accepted: 0/24 (zero by construction)
Positive accepted: 27/48
Positive accepted and target in top8: 27/48

| Calibration negative | Corpus | Top source | Top cosine | Outcome |
|---|---|---|---:|---|
| C01 | C | c16 | 0.549737 | REJECT |
| C02 | C | c10 | 0.565861 | REJECT |
| C03 | C | c10 | 0.569189 | REJECT |
| C04 | C | c14 | 0.627110 | REJECT |
| C05 | C | c17 | 0.675563 | REJECT |
| C06 | C | c20 | 0.659042 | REJECT |
| C07 | C | c23 | 0.581982 | REJECT |
| C08 | C | c14 | 0.587176 | REJECT |
| C09 | C | c06 | 0.647496 | REJECT |
| C10 | C | c10 | 0.598087 | REJECT |
| C11 | C | c20 | 0.568185 | REJECT |
| C12 | C | c16 | 0.529156 | REJECT |
| D01 | D | d03 | 0.605048 | REJECT |
| D02 | D | d05 | 0.659468 | REJECT |
| D03 | D | d09 | 0.650648 | REJECT |
| D04 | D | d10 | 0.605738 | REJECT |
| D05 | D | d15 | 0.642400 | REJECT |
| D06 | D | d18 | 0.692968 | REJECT |
| D07 | D | d19 | 0.695335 | REJECT |
| D08 | D | d23 | 0.628100 | REJECT |
| D09 | D | d27 | 0.641120 | REJECT |
| D10 | D | d28 | 0.548002 | REJECT |
| D11 | D | d33 | 0.721660 | REJECT |
| D12 | D | d36 | 0.665307 | REJECT |

## Evidential limit

This threshold has ZERO independent validation yet. Its zero false-positive
rate on the 24 calibration negatives is mechanically guaranteed.
It may reject genuine source questions. Holdout E must now be scored
without modifying or recalibrating the threshold.
