# Trial G — clean-Project synthetic source-grounding protocol

**Pre-registration:** 19 November 2026, before any new fictional source is exposed to a native ChatGPT Project conversation. Original Trial B/F metrics remain unchanged.

## Context and Project control

The new ChatGPT Project is **LTM-RAG vNext Trial G Clean Context**, ID `g-p-6afd806ca9348191accae58eea37c74c`. It is separate from the original `LTM-RAG vNext Synthetic Trial` Project, and initially showed **No chats** in its Project actions menu.

Project settings were changed from **Default** to **Project-only** and the Save control invoked. The settings modal closed. A later **independent reopened settings readback** displayed the project-only description (the Project can access only its own memory, hidden from outside chats). OpenAI's [official Project documentation](https://help.openai.com/en/articles/10169521-projects-in-chatgpt) says changes may take a few hours to propagate, and prior chats within the *same* project can still be referenced.

**Critical limitation:** Only the **first native test** can be described as a newly created, previously chat-empty Project context. Subsequent case results are **within-Project** observations; their answers may be influenced by earlier G conversations. A saved Project-only setting is not by itself proof that propagation has completed or that all other possible sources of model context are excluded.

## Frozen and withheld synthetic evidence

- `fixtures/synthetic_clean_g.json`: **20 completely invented source records** in five distinct narratives with unusual identifiers `ULN-4827`, `TERN-91`, `QEV-73`, `ORA-62`, and `SOVA-88`. Five original user statements, five assistant context/caveat turns, five same-branch user corrections, and five assistant-only alternative-branch inferences.
- Vela's purported spoken words are stored as a **user-reported recollection**, not an authenticated audio recording. Correction messages explicitly supersede the original user's message on the same source, conversation and branch.
- All exact UTF-8 source text, author role, reported speaker, `source_locator`, branch, supersession and SHA-256 identity remain in the canonical SQLite source-packet format. A matching quoted fact is not evidence that a real named speaker personally said it.
- These G source facts have **never been sent in a native G chat or installed in the original six-message MCP**. The new file is pre-registered in Git but no native Project file will be uploaded.
- `NATIVE_TRIAL_G_20261119.json` freezes **16** exact questions/expected source message identities. G01 is the first, priority clean-context probe; G02–G16 are recorded as potentially exposed to prior G chats. Classes: four corrected history lookups, two original-version requests, two alternative-branch requests, two recollection/authenticated-speech questions, two missing-source questions, two vague/ambiguous references and two unrelated technical controls.

## Independent service boundary

Do not modify the existing six-message MCP database, its `127.0.0.1:8787` server, the original tunnel `tunnel_6afd0f1439e88191862ade433921b3f9` or any previous audit. A **separate** local synthetic G SQLite database, audit and loopback MCP listener are required, with a distinct tunnel and connector if native ChatGPT can access them.

The existing `OPENAI_API_KEY` in the Ubuntu private `.env` may be reused only as previously authorised through process-only key mapping; no new API key. Administrative creation of a new tunnel, if used, must have its own Git-tracked setup/receipt without exposing credentials. No public HTTP listener; all source data remain deliberately fictional.

Until the new connector is demonstrably available in the new Project and the memory-mode change has had sufficient propagation/verification, **do not send G01 or another G question**.

## Frozen checks, not just answer markers

- **G01 clean-context first turn:** an independently audited native `lookup_evidence` call from the new G source service, correct amended user record `g03`, stable source locator and original Unicode content, no equivalent G source in earlier new Project turns.
- **G02–G10:** trace of successful handler events, correct source ID, original/corrected distinction, branch, source authorship, attribution of allegedly spoken words, and exact source quotation when explicitly quoted. A correct answer with no MCP event is a **failed invocation trace**, even if plausible through Project memory.
- **G11–G12 missing:** source may be consulted, but answer must not fabricate a serial number or audio recording.
- **G13–G14 ambiguous:** no uniquely supported source identity; clarification or explicit insufficient information is acceptable, arbitrary confident selection of one record is **not**.
- **G15–G16 unrelated:** an ordinary technical answer without a G or original-project memory lookup.
- Every case must have a durable single-send pending marker; the runner must check exact dedicated Project URL, empty composer, relevant app availability, saved chat ID and local audit before recording. A timeout is not a pass, and a possibly-sent case must never be silently resent.
- Record source-fidelity verdict separately from tool-call trace. Compute all denominators from executed, saved cases; preserve missing, failed and unexecuted cases.

## Advance only on observed evidence

The first new test can establish whether a clean Project context invokes the separate archive; **one case cannot establish population reliability**. The remaining 15 cases give additional functional coverage with an explicit cross-chat confound. If a separate private tunnel/connector cannot be established, retain this as a **design and offline source-integrity result**, not a completed native gate.

No real conversation archive is imported, no supplementary model inference is requested, and Windows/Ubuntu auto-start remains outside this tranche.
