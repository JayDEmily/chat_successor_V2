# Shadow dense candidate IDs to exact SQLite source packets — Holdout E

This is **offline synthetic-only** evidence. The live MCP plugin, original
six-message archive and active tunnel were not modified.

- Frozen Holdout E fixture SHA-256: 85c46d6a2e9f558257285dbf92f6444ce0c835d48b814976a6ca4a9459246ded
- Frozen Holdout E probes SHA-256: 13665770ab10c2c4070d82d0a77ee0b09e7e048e1e65fb787ed51231dc6befea
- Local model: BAAI/bge-small-en-v1.5 (FastEmbed ONNX CPU two threads).
- Exact source packet reads and hash/integrity checks: 464/464.
- Ranked relevant targets appearing in top 8: 30/30.
- No-unique-source questions: 28; each produces 8 **unverified** ranked candidates; none is marked relevant.
- Time for this local embedding + SQLite audit (one observation): 0.981 seconds.

| Case | Class | Expected exact message | Rank in 8 | Source packets | Relevance status |
|---|---|---|---:|---:|---|
| E01 | explicit | e03 | 1 | 8 | unverified candidate |
| I01 | implicit | e03 | 2 | 8 | unverified candidate |
| O01 | original | e01 | 1 | 8 | unverified candidate |
| E02 | explicit | e06 | 1 | 8 | unverified candidate |
| I02 | implicit | e06 | 1 | 8 | unverified candidate |
| O02 | original | e04 | 1 | 8 | unverified candidate |
| E03 | explicit | e09 | 1 | 8 | unverified candidate |
| I03 | implicit | e09 | 1 | 8 | unverified candidate |
| O03 | original | e07 | 3 | 8 | unverified candidate |
| E04 | explicit | e12 | 1 | 8 | unverified candidate |
| I04 | implicit | e12 | 1 | 8 | unverified candidate |
| O04 | original | e10 | 1 | 8 | unverified candidate |
| E05 | explicit | e15 | 1 | 8 | unverified candidate |
| I05 | implicit | e15 | 3 | 8 | unverified candidate |
| O05 | original | e13 | 3 | 8 | unverified candidate |
| E06 | explicit | e18 | 1 | 8 | unverified candidate |
| I06 | implicit | e18 | 1 | 8 | unverified candidate |
| O06 | original | e16 | 2 | 8 | unverified candidate |
| E07 | explicit | e21 | 1 | 8 | unverified candidate |
| I07 | implicit | e21 | 1 | 8 | unverified candidate |
| E08 | explicit | e24 | 1 | 8 | unverified candidate |
| I08 | implicit | e24 | 1 | 8 | unverified candidate |
| E09 | explicit | e27 | 1 | 8 | unverified candidate |
| I09 | implicit | e27 | 1 | 8 | unverified candidate |
| E10 | explicit | e30 | 1 | 8 | unverified candidate |
| I10 | implicit | e30 | 1 | 8 | unverified candidate |
| A01 | alternative | e31 | 1 | 8 | unverified candidate |
| A02 | alternative | e32 | 2 | 8 | unverified candidate |
| A03 | alternative | e33 | 1 | 8 | unverified candidate |
| A04 | alternative | e34 | 2 | 8 | unverified candidate |
| H01 | hard_negative | no unique source | no registered target | 8 | unverified candidate |
| H02 | hard_negative | no unique source | no registered target | 8 | unverified candidate |
| H03 | hard_negative | no unique source | no registered target | 8 | unverified candidate |
| H04 | hard_negative | no unique source | no registered target | 8 | unverified candidate |
| H05 | hard_negative | no unique source | no registered target | 8 | unverified candidate |
| H06 | hard_negative | no unique source | no registered target | 8 | unverified candidate |
| H07 | hard_negative | no unique source | no registered target | 8 | unverified candidate |
| H08 | hard_negative | no unique source | no registered target | 8 | unverified candidate |
| H09 | hard_negative | no unique source | no registered target | 8 | unverified candidate |
| H10 | hard_negative | no unique source | no registered target | 8 | unverified candidate |
| N01 | unrelated_negative | no unique source | no registered target | 8 | unverified candidate |
| N02 | unrelated_negative | no unique source | no registered target | 8 | unverified candidate |
| N03 | unrelated_negative | no unique source | no registered target | 8 | unverified candidate |
| N04 | unrelated_negative | no unique source | no registered target | 8 | unverified candidate |
| N05 | unrelated_negative | no unique source | no registered target | 8 | unverified candidate |
| N06 | unrelated_negative | no unique source | no registered target | 8 | unverified candidate |
| N07 | unrelated_negative | no unique source | no registered target | 8 | unverified candidate |
| N08 | unrelated_negative | no unique source | no registered target | 8 | unverified candidate |
| N09 | unrelated_negative | no unique source | no registered target | 8 | unverified candidate |
| N10 | unrelated_negative | no unique source | no registered target | 8 | unverified candidate |
| B01 | ambiguous | no unique source | no registered target | 8 | unverified candidate |
| B02 | ambiguous | no unique source | no registered target | 8 | unverified candidate |
| B03 | ambiguous | no unique source | no registered target | 8 | unverified candidate |
| B04 | ambiguous | no unique source | no registered target | 8 | unverified candidate |
| B05 | ambiguous | no unique source | no registered target | 8 | unverified candidate |
| B06 | ambiguous | no unique source | no registered target | 8 | unverified candidate |
| B07 | ambiguous | no unique source | no registered target | 8 | unverified candidate |
| B08 | ambiguous | no unique source | no registered target | 8 | unverified candidate |

## Exact-source integrity checks performed per packet

For each dense-ranked message ID, the resolver reads the record through
the existing read-only Archive.fetch API using its stable source/message/version
identity. It checks: local ID, author role, reported speaker, attribution,
source locator, conversation, branch, correction predecessor, corrected_by
descendants, UTF-8 exact_text and SHA-256, and adjacent same-branch source
text, position and SHA-256. Any mismatch raises PacketIntegrityError.

This proves match to these synthetic fixture originals, not independent
authentication of a real human utterance. The cosine similarity score
does not classify relevance. In particular, the 28 non-unique-source
questions produce 224 technically valid source packets that are **not**
evidence supporting an answer to their generic or ambiguous question.
A separate ChatGPT invocation/answer-grounding mechanism is required.
No packet was advertised as an authenticated external source or a verified
answer. No real personal conversation import or model inference API occurred.
