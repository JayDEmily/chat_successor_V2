"""Isolated native-facing synthetic I source resolver; never imported by live G MCP.

No history-intent classifier, context-token authentication or production ingestion.
The whole 20-record synthetic archive is revalidated on every tool invocation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone
from contextlib import closing
from pathlib import Path
from typing import Any

from .archive import Archive
from .referent_gate import ReferentGate


SCHEMA_VERSION = 1
TOOL_NAME = "resolve_history_reference"
ACTIONS = {
    "UNANCHORED": "CLARIFY_IF_HISTORY_REQUEST",
    "UNIQUE": "REVIEW_ORIGINAL_SOURCES",
    "MULTIPLE": "REVIEW_ORIGINAL_SOURCES",
}
PROVENANCE_NOTE = (
    "Wholly fictional source messages, NOT independent real-world verification. "
    "An assistant's alternative-branch inference is not a user correction. "
    "A user-reported recollection attributed to a third party is not "
    "authenticated speech or an audio recording."
)


class SourceIntegrityError(ValueError):
    """Exact original source archive does not match the pinned synthetic fixture."""


def _parse_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise SourceIntegrityError("Expected JSON mapping")
    return data


class SyntheticHistoryResolver:
    """Require explicit source referent before returning any original packets."""

    def __init__(self, db_path: str | Path, fixture_path: str | Path,
                 manifest_path: str | Path):
        self.db_path = Path(db_path)
        self.fixture_path = Path(fixture_path)
        self.manifest_path = Path(manifest_path)
        self.gate = ReferentGate(self.manifest_path, self.fixture_path)
        self.archive = Archive(self.db_path)
        original = _parse_json(self.fixture_path)
        if original.get("synthetic") is not True or len(original.get("messages", [])) != 20:
            raise SourceIntegrityError("I requires the exact 20-message fictional G archive")
        self._by_topic: dict[str, list[dict[str, Any]]] = {}
        self._expected: dict[str, dict[str, Any]] = {}
        for msg in original["messages"]:
            row = Archive._validate(msg)
            local_id = row["local_id"]
            if local_id in self._expected:
                raise SourceIntegrityError("Duplicate source identity")
            self._expected[local_id] = row
            self._by_topic.setdefault(msg["conversation_id"], []).append(row)
        if len(self._by_topic) != 5:
            raise SourceIntegrityError("I expects all five independent fictional narratives")
        self.validate_originals()

    def validate_originals(self) -> None:
        """Full byte/provenance comparison; no SQLite mutation or partial repairs."""
        with closing(self.archive._read_db()) as db:
            rows = db.execute("SELECT * FROM messages ORDER BY row_id").fetchall()
            if len(rows) != len(self._expected):
                raise SourceIntegrityError("Source record count differs from original fixture")
            present = set()
            for stored in rows:
                lid = stored["local_id"]
                expected = self._expected.get(lid)
                if expected is None or lid in present:
                    raise SourceIntegrityError("Unexpected/duplicate source identity")
                present.add(lid)
                for key,value in expected.items():
                    if stored[key] != value:
                        raise SourceIntegrityError(
                            f"Original source integrity failed for {lid}: {key}")
            if present != set(self._expected):
                raise SourceIntegrityError("Missing source records")
            for lid,row in self._expected.items():
                expected_children = sorted(k for k,v in self._expected.items()
                                           if v["supersedes_local_id"] == lid)
                packet = Archive._packet(
                    db,
                    db.execute("SELECT * FROM messages WHERE local_id=?",(lid,)).fetchone(),
                    1,
                )
                if sorted(packet["corrected_by"]) != expected_children:
                    raise SourceIntegrityError("Changed correction descendants")
                for neighbour in packet["neighbouring_dialogue"]:
                    original = self._expected.get(neighbour["local_id"])
                    if original is None:
                        raise SourceIntegrityError("Unknown source neighbour")
                    if (original["source_id"] != row["source_id"]
                            or original["conversation_id"] != row["conversation_id"]
                            or original["branch_id"] != row["branch_id"]):
                        raise SourceIntegrityError("Cross-branch/source neighbour")
                    for key in ("position","author_role","exact_text","content_sha256"):
                        if neighbour[key] != original[key]:
                            raise SourceIntegrityError("Altered source neighbour")

    def resolve(self, question: str) -> dict[str, Any]:
        decision = self.gate.decide(question)
        # Even an ambiguous request must not succeed with a corrupted archive.
        self.validate_originals()
        action = ACTIONS[decision.status]
        packets = []
        if action == "REVIEW_ORIGINAL_SOURCES":
            for topic in decision.conversation_ids:
                for record in self._by_topic[topic]:
                    with closing(self.archive._read_db()) as db:
                        source_row = db.execute(
                            "SELECT * FROM messages WHERE local_id=?",
                            (record["local_id"],)).fetchone()
                        packet = (Archive._packet(db, source_row, 1)
                                  if source_row is not None else None)
                    if packet is None:
                        raise SourceIntegrityError("Source vanished during read")
                    for key,value in record.items():
                        if packet[key] != value:
                            raise SourceIntegrityError("Source changed between validation and read")
                    packets.append(packet)
        return {
            "schema_version": SCHEMA_VERSION,
            "synthetic_only": True,
            "status": decision.status,
            "action": action,
            "conversation_ids": list(decision.conversation_ids),
            "explicit_anchor_evidence": [
                {"conversation_id":a.conversation_id,"anchor":a.text,
                 "source_message_id":a.source_message_id,
                 "source_locator":a.source_locator,"content_sha256":a.content_sha256}
                for a in decision.anchors
            ],
            "source_packets": packets,
            "source_count": len(packets),
            "evidence_limitations": PROVENANCE_NOTE,
            "consumer_guidance": (
                "If the user is asking about history, clarify which fictional record; "
                "no unique topic was established. Do not invent a record or a fact. "
                "If the question is unrelated to history, answer it normally; "
                "this tool does not classify intent."
                if decision.status == "UNANCHORED" else
                "Read exact packet text, branch, author and correction identity "
                "before answering. The returned records are source evidence only, "
                "not authenticated truth. Do not assume the user's desired version."
            ),
        }


class DecisionAudit:
    """Separate private call-event ledger with no question or source text."""

    def __init__(self, path: str | Path | None):
        self.path = Path(path) if path else None

    def record(self, *, outcome: str, source_count: int = 0) -> None:
        if self.path is None:
            return
        if outcome not in ("ok","error") or type(source_count) is not int:
            raise ValueError("Invalid I audit marker")
        event = {
            "event_id":str(uuid.uuid4()),
            "timestamp_utc":datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "tool":TOOL_NAME,
            "outcome":outcome,
            "result_count":source_count,
            "synthetic_only":True,
        }
        flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND
        descriptor=os.open(self.path,flags,0o600)
        try:
            os.write(descriptor, (json.dumps(event,sort_keys=True)+"\n").encode("utf-8"))
        finally:
            os.close(descriptor)


def create_server(db_path: str | Path, fixture_path: str | Path,
                  manifest_path: str | Path, audit_path: str | Path | None = None):
    """Create a standalone tool server; never register on ports 8787/8788."""
    from mcp.server import MCPServer
    from mcp.types import CallToolResult, TextContent, ToolAnnotations

    resolver=SyntheticHistoryResolver(db_path,fixture_path,manifest_path)
    audit=DecisionAudit(audit_path)
    server=MCPServer(
        "LTM-RAG-vNext-Decision-I-Synthetic",
        version="1.0.0",
        instructions=(
            "Single read-only tool over wholly fictional history. "
            "For a request about past fictional conversations call "
            "resolve_history_reference with the complete current user question "
            "verbatim; do not expand it with an inferred name or memory from "
            "another chat. A result UNANCHORED has no source packets: "
            "ask which record was intended if the question is about history. "
            "Do not call this tool for general unrelated technical questions. "
            "Exact original messages are fictional user reports, corrections "
            "and assistant speculation, not authenticated real-world facts "
            "or genuine third-party audio."
        ),
    )
    readonly=ToolAnnotations(read_only_hint=True,open_world_hint=False)

    @server.tool(annotations=readonly)
    def resolve_history_reference(question: str):
        """For historical recall only, verify current-question referent and return original fictional evidence; never infer missing record identities."""
        try:
            packet=resolver.resolve(question)
        except Exception:
            audit.record(outcome="error")
            raise
        audit.record(outcome="ok",source_count=packet["source_count"])
        return CallToolResult(
            content=[TextContent(type="text",text=json.dumps(packet,ensure_ascii=False))],
            structured_content=packet,
        )
    return server


def main() -> None:
    p=argparse.ArgumentParser()
    p.add_argument("--db",type=Path,required=True)
    p.add_argument("--fixture",type=Path,required=True)
    p.add_argument("--manifest",type=Path,required=True)
    p.add_argument("--port",type=int,default=8789)
    p.add_argument("--audit-log",type=Path,default=None)
    args=p.parse_args()
    if args.port in (8787,8788) or not 1024 <= args.port <= 65535:
        p.error("I listener must not bind 8787 or 8788")
    create_server(args.db,args.fixture,args.manifest,args.audit_log).run(
        transport="streamable-http",host="127.0.0.1",port=args.port,
        json_response=True,stateless_http=True,
    )


if __name__ == "__main__":
    main()
