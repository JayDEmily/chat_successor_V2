"""Stage L conditional user-choice source boundary; synthetic and OFFLINE ONLY.

The simulated owner UI callback is an **assumed** trusted origin in this
in-process experiment. No native ChatGPT UI, login, message attestation,
MCP endpoint, external model API or real archive is implemented.
"""
from __future__ import annotations

import hmac
import secrets
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any

from .decision_support_i import SyntheticHistoryResolver

TRUST_BOUNDARY = "OWNER_UI_CONFIRMATION_SIMULATED_NOT_NATIVE_CHATGPT"


class ClarificationLContractError(ValueError):
    """Malformed owner-only test context or a duplicate active flow."""


def _key(value: Mapping[str, Any] | None) -> tuple[str, str, str] | None:
    if not isinstance(value, Mapping):
        return None
    if set(value) != {"user_id", "session_id", "turn_id"}:
        return None
    vals = (value["user_id"], value["session_id"], value["turn_id"])
    if any(type(v) is not str or not v or len(v) > 128 or v.strip() != v
           for v in vals):
        return None
    return vals


@dataclass
class _Pending:
    # UI-only ticket is NEVER exposed in the model_public part of begin().
    challenge: str
    deadline: float
    selected: tuple[str, ...] | None = None


class ClarificationGatewayL:
    """Two-phase source-scope proof. The model never chooses source topics.

    begin: simulated owner turn registration, with model-safe/public and
      UI-private output separated. Native _meta delivery is not implemented.
    confirm_from_owner_ui: caller MUST be independent owner-authorised UI;
      deliberately NOT registered as an MCP tool for model invocation.
    resolve_tool_call: may accept any model-authored words, but cannot
      promote them into source scope, and may release once after confirmation.
    """

    def __init__(self, resolver: SyntheticHistoryResolver, *,
                 clock: Callable[[], float] = time.monotonic,
                 challenge_factory: Callable[[], str] | None = None,
                 ttl_seconds: float = 60):
        if not callable(clock) or type(ttl_seconds) not in (int, float) or not 0 < ttl_seconds <= 300:
            raise ClarificationLContractError("Invalid in-process clock/TTL")
        self._resolver = resolver
        self._clock = clock
        self._challenge_factory = challenge_factory or (lambda: secrets.token_urlsafe(32))
        self._ttl = ttl_seconds
        self._pending: dict[tuple[str, str, str], _Pending] = {}
        self._spent: set[tuple[str, str, str]] = set()
        # The existing H gate validates that these aliases are present in
        # exact original main-branch user text from the pinned fixture.
        self._order = tuple(resolver.gate._topic_ids)
        aliases: dict[str, str] = {}
        for _pattern, evidence in resolver.gate._anchors:
            aliases.setdefault(evidence.conversation_id, evidence.text)
        if set(aliases) != set(self._order) or len(self._order) != 5:
            raise ClarificationLContractError("Wrong fictional source manifest")
        self._alias = aliases

    @staticmethod
    def _empty(status: str) -> dict[str, Any]:
        return {
            "schema_version": 1, "synthetic_only": True,
            "trust_boundary": TRUST_BOUNDARY, "status": status,
            "conversation_ids": [], "source_packets": [], "source_count": 0,
            "original_user_text_attested": False,
        }

    def begin(self, owner_context: Mapping[str, Any]) -> tuple[dict, dict]:
        key = _key(owner_context)
        if key is None:
            raise ClarificationLContractError("Invalid owner context")
        if key in self._pending or key in self._spent:
            raise ClarificationLContractError("Flow is active or spent")
        if any(other[:2] == key[:2] for other in self._pending):
            raise ClarificationLContractError("Overlapping owner session flow")
        challenge = self._challenge_factory()
        if type(challenge) is not str or len(challenge) < 32:
            raise ClarificationLContractError("Invalid UI-only challenge")
        if any(hmac.compare_digest(challenge, p.challenge)
               for p in self._pending.values()):
            raise ClarificationLContractError("Duplicate UI-only challenge")
        self._pending[key] = _Pending(
            challenge=challenge, deadline=self._clock() + self._ttl)
        public = self._empty("AWAITING_CONFIRMATION")
        public["guidance"] = ("Ask for an explicit fictional topic selection; "
                              "do not infer a unique record or return original source.")
        # A future native integration MUST deliver this only to a trusted
        # widget private channel; the test does not implement that transport.
        private_ui = {"widget_challenge": challenge,
                      "topic_ids": list(self._order),
                      "synthetic_only": True}
        return public, private_ui

    def confirm_from_owner_ui(self, owner_context: Mapping[str, Any] | None,
                              challenge: object, selected: object) -> bool:
        key = _key(owner_context)
        if key is None:
            return False
        entry = self._pending.get(key)
        if entry is None or self._clock() >= entry.deadline or entry.selected is not None:
            return False
        if (type(challenge) is not str or
                not hmac.compare_digest(challenge, entry.challenge)):
            return False
        if (type(selected) is not list or
                not 1 <= len(selected) <= 2 or
                any(type(topic) is not str or topic not in self._order
                    for topic in selected) or len(set(selected)) != len(selected)):
            return False
        # Deterministic canonical original-manifest order, never model order.
        entry.selected = tuple(topic for topic in self._order if topic in selected)
        return True

    def resolve_tool_call(self, model_question: object,
                          owner_context: Mapping[str, Any] | None,
                          model_claimed_topics: object = None) -> dict[str, Any]:
        """Ignore untrusted question and claimed topics for scope selection."""
        key = _key(owner_context)
        if key is None:
            return self._empty("NO_CONFIRMED_SCOPE")
        entry = self._pending.get(key)
        if entry is None:
            return self._empty("NO_CONFIRMED_SCOPE")
        if self._clock() >= entry.deadline:
            self._pending.pop(key)
            self._spent.add(key)
            return self._empty("EXPIRED")
        if entry.selected is None:
            return self._empty("AWAITING_CONFIRMATION")

        # One-shot consumption precedes downstream source resolution, so an
        # exception cannot permit a second release with the same approval.
        self._pending.pop(key)
        self._spent.add(key)
        canonical = " ".join(self._alias[topic] for topic in entry.selected)
        response = self._resolver.resolve(canonical)
        if (tuple(response["conversation_ids"]) != entry.selected or
                response["status"] not in ("UNIQUE", "MULTIPLE")):
            raise ClarificationLContractError("Pinned source selection mismatch")
        return {
            "schema_version": 1, "synthetic_only": True,
            "trust_boundary": TRUST_BOUNDARY,
            "status": "CONFIRMED_SOURCE_SCOPE",
            "conversation_ids": list(entry.selected),
            "source_packets": response["source_packets"],
            "source_count": response["source_count"],
            "original_user_text_attested": False,
            "source_scope_choice_only": True,
            "evidence_limitations": (
                "Simulated independent UI selection only. This does not attest "
                "the prior original message, the user's actual intent, "
                "human click provenance, or the truth of fictional records."),
        }

    @property
    def active_flow_count(self) -> int:
        return len(self._pending)
