"""Stage K isolated MCP metadata-presence probe.

Synthetic-only. No database access, source retrieval, external inference or
original user-message access. Metadata is *client supplied*, not proof of
identity or prompt authenticity. Never print/store raw IDs or headers.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import secrets
import uuid
from datetime import datetime, timezone
from pathlib import Path
from collections.abc import Mapping
from typing import Any
from mcp.server.mcpserver import Context


SCHEMA_VERSION = 1
TOOL_NAME = "inspect_metadata_presence_k"
BOUNDARY = "CLIENT_SUPPLIED_META_NOT_TRUSTED_USER_MESSAGE"


def _valid_id(value: object) -> str | None:
    if not isinstance(value, str) or not value or len(value) > 512:
        return None
    if not value.strip() or value != value.strip():
        return None
    return value


class MetadataProbeK:
    """Privacy-minimised process-local observer; not an auth primitive."""

    def __init__(self, *, audit_path: str | Path | None = None,
                 ephemeral_key: bytes | None = None):
        self._key = ephemeral_key if ephemeral_key is not None else secrets.token_bytes(32)
        if not isinstance(self._key, bytes) or len(self._key) < 16:
            raise ValueError("At least 128 bits of process-local key required")
        self.audit_path = Path(audit_path) if audit_path is not None else None

    def fingerprint(self, value: object) -> str | None:
        checked = _valid_id(value)
        if checked is None:
            return None
        return hmac.new(self._key, checked.encode("utf-8"), hashlib.sha256).hexdigest()

    def inspect(self, request_meta: object, *,
                capabilities: object = None,
                tool_arguments: object = None) -> tuple[dict[str, Any], dict[str, Any]]:
        # tool_arguments is explicitly *ignored*, including any spoofed meta keys.
        _ = tool_arguments
        meta: Mapping = request_meta if isinstance(request_meta, Mapping) else {}
        session = _valid_id(meta.get("openai/session"))
        subject = _valid_id(meta.get("openai/subject"))
        # The advertised capability is neither a proof of UI support nor
        # evidence of a direct human decision.
        if isinstance(capabilities, Mapping):
            elicit = capabilities.get("elicitation")
        else:
            elicit = getattr(capabilities, "elicitation", None)
        flags = {
            "schema_version": SCHEMA_VERSION,
            "synthetic_only": True,
            "trust_boundary": BOUNDARY,
            "session_present": session is not None,
            "subject_present": subject is not None,
            "usable_session_and_subject": session is not None and subject is not None,
            "elicitation_capability_advertised": elicit is not None,
            "native_user_text_attested": False,
            "raw_metadata_disclosed": False,
            "guidance": (
                "These flags only prove what client-provided MCP request metadata "
                "contained. Presence of an anonymised session or subject is not "
                "authentication of the user's original message or a per-turn "
                "authorisation token. Elicitation capabilities do not prove "
                "that a human saw or accepted a clarification."
            ),
        }
        private = {
            "session_fingerprint":self.fingerprint(session),
            "subject_fingerprint":self.fingerprint(subject),
        }
        return flags,private

    def record(self, flags: dict[str, Any], private: dict[str, Any]) -> str:
        event_id=str(uuid.uuid4())
        if self.audit_path is None:
            return event_id
        event = {
            "event_id":event_id,
            "timestamp_utc":datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "tool":TOOL_NAME,
            "session_present":flags["session_present"],
            "subject_present":flags["subject_present"],
            "elicitation_capability_advertised":flags["elicitation_capability_advertised"],
            "session_fingerprint":private["session_fingerprint"],
            "subject_fingerprint":private["subject_fingerprint"],
            "native_user_text_attested":False,
            "synthetic_only":True,
        }
        self.audit_path.parent.mkdir(parents=True,exist_ok=True)
        # Require the existing directory to be private (for disposable audit).
        fd=os.open(self.audit_path,os.O_CREAT|os.O_WRONLY|os.O_APPEND,0o600)
        try:
            os.write(fd,(json.dumps(event,sort_keys=True)+"\n").encode("utf8"))
        finally:
            os.close(fd)
        return event_id


def create_server(audit_path: str | Path | None = None):
    from mcp.server import MCPServer
    from mcp.types import CallToolResult, TextContent, ToolAnnotations
    server=MCPServer(
        "LTM-RAG-vNext-Metadata-K-Synthetic",
        version="1.0.0",
        instructions=(
            "Disposable synthetic-only read-only MCP metadata probe. "
            "Use only when explicitly asked to inspect tool-call metadata. "
            "The server never reads messages, original history, user IDs "
            "or source databases. Its boolean flags are not authentication "
            "of the original user question. No personal data is required."
        ),
    )
    probe=MetadataProbeK(audit_path=audit_path)

    @server.tool(annotations=ToolAnnotations(read_only_hint=True,open_world_hint=False))
    def inspect_metadata_presence_k(ctx: Context):
        """Inspect only boolean availability of current MCP call metadata; do not supply user text or identifiers."""
        # In this pinned SDK v2, ctx._input_params stores CallToolRequestParams.
        # Private SDK surface: adapter tests MUST catch future changes.
        params=getattr(ctx,"_input_params",None)
        meta=getattr(params,"meta",None)
        flags,private=probe.inspect(meta,capabilities=ctx.client_capabilities)
        probe.record(flags,private)
        return CallToolResult(
            content=[TextContent(type="text",text=json.dumps(flags,sort_keys=True))],
            structured_content=flags,
        )
    return server


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--port",type=int,default=8790)
    parser.add_argument("--audit-log",type=Path)
    args=parser.parse_args()
    if args.port in (8787,8788,8789) or not 1024<=args.port<=65535:
        parser.error("Stage K must not bind previous experimental ports")
    create_server(args.audit_log).run(
        transport="streamable-http",host="127.0.0.1",port=args.port,
        json_response=True,stateless_http=True,
    )


if __name__=="__main__":
    main()
