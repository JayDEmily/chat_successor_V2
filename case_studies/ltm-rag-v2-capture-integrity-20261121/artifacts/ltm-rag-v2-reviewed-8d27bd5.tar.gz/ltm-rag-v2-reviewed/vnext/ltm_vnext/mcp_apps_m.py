"""Disposable synthetic-only MCP Apps experiment M. No archive or real messages.

App-only tool visibility is a host UI filter, not server authentication.
Client-supplied session/subject metadata are correlation hints, not identities.
"""
from __future__ import annotations
import argparse
import hashlib
import hmac
import json
import os
import secrets
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from collections.abc import Mapping

from mcp.server import MCPServer
from mcp.server.apps import Apps
from mcp.server.mcpserver import Context
from mcp.types import CallToolResult, TextContent, ToolAnnotations

TOOL_OPEN = "open_topic_selector_m"
TOOL_CONFIRM = "confirm_topic_m"
RESOURCE = "ui://ltm-rag-vnext-m/selector.html"
TOPICS = ("merrow_prism","vela_case","qev_tensile","ora_pier","sova_container")
LABELS = ("Merrow calibration log","Vela reported recollection","QEV-73 tensile record",
          "ORA-62 pier correction","SOVA-88 container correction")
WIDGET = Path(__file__).with_name("mcp_apps_m_widget.html")


def valid(meta, name):
    value = meta.get(name) if isinstance(meta, Mapping) else None
    return value if type(value) is str and 1 <= len(value) <= 512 and value.strip()==value else None


@dataclass
class Flow:
    token: str
    started: float
    consumed: bool = False


class SelectorM:
    def __init__(self, *, clock=None, token_factory=None, audit_path=None):
        self.clock = clock or time.monotonic
        self.token_factory = token_factory or (lambda: secrets.token_urlsafe(32))
        self.salt = secrets.token_bytes(32)
        self.flows = {}
        self.used_tokens = set()
        self.audit_path = Path(audit_path) if audit_path else None

    def context(self, meta):
        pair = (valid(meta,"openai/session"),valid(meta,"openai/subject"))
        if not all(pair):
            return None
        return tuple(hmac.new(self.salt,s.encode(),hashlib.sha256).digest() for s in pair)

    def record(self, tool, status, meta):
        if self.audit_path is None:
            return
        event = dict(event_id=str(uuid.uuid4()),
                     timestamp_utc=datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
                     tool=tool,status=status,session_present=valid(meta,"openai/session") is not None,
                     subject_present=valid(meta,"openai/subject") is not None,
                     synthetic_only=True,source_count=0,original_user_text_attested=False)
        self.audit_path.parent.mkdir(parents=True,exist_ok=True)
        fd = os.open(self.audit_path,os.O_CREAT|os.O_WRONLY|os.O_APPEND,0o600)
        try:
            os.write(fd,(json.dumps(event,sort_keys=True)+"\n").encode())
        finally:
            os.close(fd)

    @staticmethod
    def public(status, topic=None):
        out = dict(schema_version=1,synthetic_only=True,status=status,source_packets=[],
                   source_count=0,original_user_text_attested=False,
                   human_consent_attested=False,client_metadata_not_authorisation=True)
        if status=="CONFIRMED":
            out["selected_topic"]=topic
        return out

    def begin(self, meta):
        key=self.context(meta)
        if key is None:
            result=self.public("NO_SESSION_CONTEXT")
            self.record(TOOL_OPEN,result["status"],meta)
            return result,{}
        prior=self.flows.get(key)
        if prior and not prior.consumed and self.clock()-prior.started<60:
            result=self.public("ACTIVE_FLOW_ALREADY_EXISTS")
            self.record(TOOL_OPEN,result["status"],meta)
            return result,{}
        token=self.token_factory()
        if type(token) is not str or len(token)<32 or token in self.used_tokens:
            raise ValueError("Invalid/duplicate UI-only token")
        self.used_tokens.add(token)
        self.flows[key]=Flow(token,self.clock())
        result=self.public("AWAITING_CONFIRMATION")
        result["message"]="Select one invented topic using the optional synthetic UI."
        private=dict(stage_m=dict(challenge=token,synthetic_only=True,
                    topics=[dict(id=t,label=LABELS[i]) for i,t in enumerate(TOPICS)]))
        self.record(TOOL_OPEN,result["status"],meta)
        return result,private

    def confirm(self, meta, challenge, topic_id):
        key=self.context(meta)
        flow=self.flows.get(key) if key is not None else None
        if flow is None or flow.consumed:
            status="DENIED"
        elif self.clock()-flow.started>=60:
            flow.consumed=True
            status="EXPIRED"
        elif (type(challenge) is not str or
              not hmac.compare_digest(challenge,flow.token) or
              type(topic_id) is not str or topic_id not in TOPICS):
            status="DENIED"
        else:
            status="CONFIRMED"
            flow.consumed=True
        result=self.public(status,topic_id if status=="CONFIRMED" else None)
        self.record(TOOL_CONFIRM,status,meta)
        return result


def _meta(ctx: Context):
    return getattr(getattr(ctx,"_input_params",None),"meta",None)


def create_server(audit_path=None):
    selector=SelectorM(audit_path=audit_path)
    apps=Apps()

    @apps.tool(resource_uri=RESOURCE,visibility=["model","app"],
               name=TOOL_OPEN,annotations=ToolAnnotations(
                   read_only_hint=True,open_world_hint=False))
    def open_topic_selector_m(ctx: Context):
        """Display a synthetic fictional topic selector only when explicitly requested."""
        result,private=selector.begin(_meta(ctx))
        return CallToolResult(content=[TextContent(type="text",text=(
            "Fictional selector: "+result["status"]+"; no historical sources available."))],
            structured_content=result,meta=private or None)

    @apps.tool(resource_uri=RESOURCE,visibility=["app"],name=TOOL_CONFIRM,
               description="UI-only synthetic confirmation. Not human consent.")
    def confirm_topic_m(ctx: Context,challenge: str,topic_id: str):
        """Receive one simulated UI choice. Never release source packets."""
        result=selector.confirm(_meta(ctx),challenge,topic_id)
        return CallToolResult(content=[TextContent(type="text",
            text="Synthetic choice: "+result["status"])],structured_content=result)

    apps.add_html_resource(RESOURCE,WIDGET.read_text(encoding="utf-8"),
                           title="Stage M fictional topic selector")
    return MCPServer("LTM-RAG-vNext-Apps-M-Synthetic",version="1.0.0",
         instructions="Disposable fictional-only UI test. Call open_topic_selector_m only if asked. Do not call app-only confirmation yourself. No archives, user messages or real data.",
         extensions=[apps])


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--port",type=int,default=8791)
    p.add_argument("--audit-log",type=Path)
    args=p.parse_args()
    if args.port!=8791:
        p.error("Stage M only on dedicated loopback port 8791")
    create_server(args.audit_log).run(transport="streamable-http",
        host="127.0.0.1",port=8791,json_response=True,stateless_http=True)


if __name__=="__main__":
    main()
