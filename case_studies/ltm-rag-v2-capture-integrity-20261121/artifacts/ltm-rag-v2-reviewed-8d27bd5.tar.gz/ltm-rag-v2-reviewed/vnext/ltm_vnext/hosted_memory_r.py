"""Synthetic-only SQL-authoritative OpenAI hosted Vector Store memory pilot.

Hosted search only returns candidates. Original message bytes, roles, corrections
and exact attribution are independently verified in local SQLite. No real
history, ChatGPT UI scrape, Responses inference, production MCP or new key.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import closing
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

from .archive import Archive, InvalidFixture, RecordConflict

STORE_NAME = "LTM-RAG vNext — Synthetic Conversation Memory R"
KEY_NAME = "OPENAI_LTM_RAG_VNEXT_API_KEY"


class HostedRFailure(RuntimeError):
    """An unavailable, corrupted or unauthorised synthetic source boundary."""


class OpenAIHttpR:
    """Small standard-library client, intentionally limited to Files/Vector Stores."""

    def __init__(self, key: str, *, base_url: str = "https://api.openai.com/v1"):
        if not key.startswith("sk-") or not base_url.startswith("https://"):
            raise HostedRFailure("Missing project-scoped key or invalid API base")
        self._key = key
        self._base = base_url.rstrip("/")

    def _request(self, method: str, endpoint: str, *, data: bytes | None = None,
                 content_type: str | None = None) -> dict:
        if method not in ("GET", "POST") or not endpoint.startswith("/"):
            raise HostedRFailure("Unsupported vector-store API operation")
        headers = {"Authorization": "Bearer " + self._key,
                   "Accept": "application/json"}
        if data is not None:
            headers["Content-Type"] = content_type or "application/json"
        request = Request(self._base + endpoint, method=method, headers=headers,
                          data=data)
        try:
            with urlopen(request, timeout=30) as response:
                body = response.read(4_000_001)
                if len(body) > 4_000_000:
                    raise HostedRFailure("Unexpectedly large API response")
                result = json.loads(body)
                if not isinstance(result, dict):
                    raise HostedRFailure("Invalid vector-store JSON response")
                return result
        except HTTPError as exc:
            # Never print the server response or Authorization header.
            raise HostedRFailure(f"OpenAI Files/Vector Stores API HTTP {exc.code}") from None
        except (URLError, TimeoutError) as exc:
            raise HostedRFailure("OpenAI Vector Stores connection error: " +
                                 type(exc).__name__) from None

    def json(self, method: str, endpoint: str, payload: dict | None = None):
        return self._request(method, endpoint,
             data=(json.dumps(payload,sort_keys=True).encode("utf-8")
                   if payload is not None else None))

    def stores(self):
        return self.json("GET", "/vector_stores?limit=100").get("data", [])

    def create_store(self):
        return self.json("POST","/vector_stores",{
            "name": STORE_NAME,
            "expires_after":{"anchor":"last_active_at","days":30},
            "metadata":{"synthetic_only":"true","scope":"ltm-rag-vnext-r"},
        })

    def retrieve_store(self, store_id: str):
        return self.json("GET","/vector_stores/"+quote(store_id,safe=""))

    def files(self):
        # A single 100-object page is insufficient for long-lived upload
        # reconciliation. Follow the provider cursor and fail closed on an
        # incomplete/ambiguous listing rather than uploading a duplicate.
        all_files = []
        seen_ids = set()
        cursor = None
        for _ in range(100):  # 10,000 files maximum; explicit bound.
            endpoint = "/files?purpose=assistants&limit=100"
            if cursor is not None:
                endpoint += "&after=" + quote(cursor, safe="")
            page = self.json("GET", endpoint)
            if (not isinstance(page, dict) or not isinstance(page.get("data"), list)
                or type(page.get("has_more")) is not bool):
                raise HostedRFailure("Malformed provider file listing")
            items = page["data"]
            for item in items:
                if (not isinstance(item, dict) or
                    type(item.get("id")) is not str or not item["id"] or
                    item["id"] in seen_ids):
                    raise HostedRFailure("Duplicate or invalid provider file ID")
                seen_ids.add(item["id"])
                all_files.append(item)
            if not page["has_more"]:
                return all_files
            if not items or items[-1]["id"] == cursor:
                raise HostedRFailure("Provider file pagination did not progress")
            cursor = items[-1]["id"]
        raise HostedRFailure("Provider file listing exceeded bounded pages")

    def upload_file(self, filename: str, content: bytes):
        boundary="ltm_r_"+uuid.uuid4().hex
        part=(
            "--"+boundary+"\r\n"
            "Content-Disposition: form-data; name=\"purpose\"\r\n\r\n"
            "assistants\r\n"
            "--"+boundary+"\r\n"
            "Content-Disposition: form-data; name=\"file\"; filename=\""+
               filename+"\"\r\n"
            "Content-Type: text/plain; charset=utf-8\r\n\r\n"
        ).encode("utf-8")
        body=part+content+("\r\n--"+boundary+"--\r\n").encode("utf-8")
        return self._request("POST","/files",data=body,
                            content_type="multipart/form-data; boundary="+boundary)

    def attachment(self, store_id: str, file_id: str):
        endpoint="/vector_stores/"+quote(store_id,safe="")+"/files/"+quote(file_id,safe="")
        try:
            return self.json("GET",endpoint)
        except HostedRFailure as err:
            if str(err)=="OpenAI Files/Vector Stores API HTTP 404":
                return None
            raise

    def attach(self, store_id: str, file_id: str, attrs: dict):
        return self.json("POST","/vector_stores/"+quote(store_id,safe="")+"/files",
                         {"file_id":file_id,"attributes":attrs})

    def search(self, store_id: str, query: str, *, max_results: int = 10):
        return self.json("POST",
            "/vector_stores/"+quote(store_id,safe="")+"/search",
            {"query":query,"max_num_results":max_results,"rewrite_query":False,
             "filters":{"type":"eq","key":"synthetic_only","value":True}})


def project_key(path: Path = Path("/home/jds/.env")) -> str:
    """Read only the project-specific key; never echo the value."""
    rows = [x.partition("=")[2].strip().strip('"').strip("'")
            for x in path.read_text(encoding="utf-8").splitlines()
            if x.startswith(KEY_NAME+"=")]
    if len(rows)!=1 or not rows[0].startswith("sk-svcacct-"):
        raise HostedRFailure("Project credential missing or duplicated")
    return rows[0]


class SyntheticConversationR:
    """Incremental immutable synthetic user+scripted-assistant turn indexing."""

    def __init__(self, db_path: Path, fixture_path: Path, api,
                 store_id: str):
        self.db_path=Path(db_path)
        self.fixture_path=Path(fixture_path)
        self.api=api
        if not isinstance(store_id,str) or not store_id.startswith("vs_"):
            raise HostedRFailure("Invalid isolated hosted vector store identifier")
        self.store_id=store_id
        data=json.loads(self.fixture_path.read_text(encoding="utf-8"))
        if (data.get("synthetic") is not True or data.get("turn_count")!=12
                or len(data.get("messages",[]))!=24):
            raise HostedRFailure("Wrong frozen synthetic pilot fixture")
        self.by_turn={}
        self.expected={}
        for turn in range(1,13):
            pair=data["messages"][(turn-1)*2:turn*2]
            if ([m["author_role"] for m in pair]!=["user","assistant"]
                    or [m["position"] for m in pair]!=[2*turn-1,2*turn]
                    or [m["message_id"] for m in pair]
                        !=[f"r{turn:02d}u",f"r{turn:02d}a"]
                    or any(m["conversation_id"]!="fictional_diary_r"
                           or m["branch_id"]!="main" or
                           m["capture_method"]!="synthetic_fixture"
                           for m in pair)):
                raise HostedRFailure("Turn authorship/identity mismatch")
            self.by_turn[turn]=pair
            for row in pair:
                exact=Archive._validate(row)
                self.expected[exact["local_id"]]=exact
        if len(self.expected)!=24:
            raise HostedRFailure("Duplicate frozen message identities")
        self.archive=Archive.initialise(self.db_path)
        with sqlite3.connect(self.db_path) as db:
            db.execute("""CREATE TABLE IF NOT EXISTS hosted_r_files(
                turn_index INTEGER PRIMARY KEY,
                file_id TEXT NOT NULL UNIQUE,
                filename TEXT NOT NULL UNIQUE,
                payload_sha256 TEXT NOT NULL,
                user_local_id TEXT NOT NULL,
                assistant_local_id TEXT NOT NULL,
                completed INTEGER NOT NULL DEFAULT 0
            )""")

    def payload(self, turn: int) -> tuple[str,bytes,dict]:
        if turn not in self.by_turn:
            raise HostedRFailure("Out-of-range synthetic turn")
        user,assistant=self.by_turn[turn]
        body=("\n".join([
            "WHOLLY FICTIONAL TEST CONVERSATION. NOT A REAL PERSON'S CHAT.",
            "Conversation: fictional_diary_r",
            f"Turn: {turn:02d}",
            f"USER original message ID [{user['message_id']}]: {user['exact_text']}",
            f"ASSISTANT scripted response ID [{assistant['message_id']}]: {assistant['exact_text']}",
            "",
        ])).encode("utf-8")
        digest=hashlib.sha256(body).hexdigest()
        filename=f"fictional_diary_r_turn_{turn:02d}_{digest[:16]}.txt"
        attrs={"synthetic_only":True,"conversation_id":"fictional_diary_r",
               "turn_index":turn,"payload_sha256":digest}
        return filename,body,attrs

    def _get_mapping(self,turn: int):
        with sqlite3.connect(self.db_path) as db:
            db.row_factory=sqlite3.Row
            row=db.execute("SELECT * FROM hosted_r_files WHERE turn_index=?",
                           (turn,)).fetchone()
            return dict(row) if row else None

    def index_turn(self,turn: int) -> dict:
        filename,body,attrs=self.payload(turn)
        pair=self.by_turn[turn]
        # Persist both original source messages BEFORE any network index write.
        with tempfile.TemporaryDirectory(prefix="ltm-r-fixture-") as temporary:
            fixture=Path(temporary)/"turn.json"
            fixture.write_text(json.dumps({"synthetic":True,"messages":pair}),
                               encoding="utf-8")
            try:
                self.archive.ingest_synthetic(fixture)
            except (InvalidFixture,RecordConflict) as error:
                raise HostedRFailure("Changed turn payload or immutable original record") from None
        originals=[Archive._validate(m) for m in pair]
        mapping=self._get_mapping(turn)
        if mapping is not None:
            if (mapping["filename"]!=filename or
                mapping["payload_sha256"]!=attrs["payload_sha256"] or
                [mapping["user_local_id"],mapping["assistant_local_id"]]
                    !=[m["local_id"] for m in originals]):
                raise HostedRFailure("Changed turn payload after upload")
            file_id=mapping["file_id"]
        else:
            # Crash reconciliation: an uploaded but unrecorded file is
            # recognised by its deterministic content-addressed filename.
            found=[f for f in self.api.files() if f.get("filename")==filename]
            if len(found)>1:
                raise HostedRFailure("Ambiguous duplicate remote uploaded files")
            uploaded=found[0] if found else self.api.upload_file(filename,body)
            file_id=uploaded.get("id")
            if not isinstance(file_id,str) or not file_id.startswith("file-"):
                raise HostedRFailure("Unexpected uploaded file identity")
            with sqlite3.connect(self.db_path) as db:
                db.execute("""INSERT INTO hosted_r_files(
                    turn_index,file_id,filename,payload_sha256,
                    user_local_id,assistant_local_id,completed)
                    VALUES(?,?,?,?,?,?,0)""",
                    (turn,file_id,filename,attrs["payload_sha256"],
                     originals[0]["local_id"],originals[1]["local_id"]))
        attachment=self.api.attachment(self.store_id,file_id)
        if attachment is None:
            attachment=self.api.attach(self.store_id,file_id,attrs)
        if attachment.get("file_id") not in (file_id,None) or attachment.get("status")=="failed":
            raise HostedRFailure("Remote file attachment failed or changed")
        for _ in range(40):
            state=self.api.attachment(self.store_id,file_id)
            if state is None:
                raise HostedRFailure("Uploaded file attachment disappeared")
            if state.get("status")=="completed":
                with sqlite3.connect(self.db_path) as db:
                    db.execute("UPDATE hosted_r_files SET completed=1 WHERE turn_index=?",
                               (turn,))
                return {"turn":turn,"indexed":True,"file_id":file_id,
                        "new_local_messages":2}
            if state.get("status") in ("failed","cancelled"):
                raise HostedRFailure("Hosted indexing returned non-complete status")
            time.sleep(1.5)
        raise HostedRFailure("Hosted indexing exceeded bounded polling window")

    def _evidence(self,local_id: str):
        original=self.expected.get(local_id)
        if original is None:
            raise HostedRFailure("Hosted candidate refers to unknown original source")
        with closing(self.archive._read_db()) as db:
            row=db.execute("SELECT * FROM messages WHERE local_id=?",
                           (local_id,)).fetchone()
            packet=Archive._packet(db,row,1) if row else None
            present_ids={x[0] for x in db.execute("SELECT local_id FROM messages")}
        if packet is None or any(packet.get(k)!=v for k,v in original.items()):
            raise HostedRFailure("Canonical SQLite packet integrity failure")
        if packet["fidelity"]!="synthetic_only":
            raise HostedRFailure("Non-synthetic packet leakage")
        expected_children=sorted(row["local_id"] for row in self.expected.values()
                                 if row["supersedes_local_id"]==local_id
                                 and row["local_id"] in present_ids)
        if sorted(packet["corrected_by"])!=expected_children:
            raise HostedRFailure("Correction relationship integrity failure")
        for neighbour in packet["neighbouring_dialogue"]:
            original_neighbour=self.expected.get(neighbour["local_id"])
            if (original_neighbour is None or
                original_neighbour["source_id"]!=packet["source_id"] or
                original_neighbour["conversation_id"]!=packet["conversation_id"] or
                original_neighbour["branch_id"]!=packet["branch_id"] or
                any(neighbour.get(field)!=original_neighbour[field] for field in
                    ("exact_text","content_sha256","author_role","position"))):
                raise HostedRFailure("Neighbouring original source integrity failure")
        return packet

    def search_candidates(self,query: str,*,top: int = 10) -> list[dict[str,Any]]:
        if not isinstance(query,str) or not query.strip() or not 1<=top<=10:
            raise HostedRFailure("Invalid bounded synthetic search request")
        provider=self.api.search(self.store_id,query,max_results=top)
        data=provider.get("data")
        if not isinstance(data,list):
            raise HostedRFailure("Malformed search result envelope")
        with sqlite3.connect(self.db_path) as db:
            db.row_factory=sqlite3.Row
            records={row["file_id"]:dict(row) for row in
                     db.execute("SELECT * FROM hosted_r_files WHERE completed=1")}
        candidates=[]
        seen=set()
        for hit in data:
            if not isinstance(hit,dict) or type(hit.get("file_id")) is not str:
                raise HostedRFailure("Malformed hosted file candidate")
            file_id=hit["file_id"]
            if file_id in seen:
                continue
            seen.add(file_id)
            record=records.get(file_id)
            if record is None:
                raise HostedRFailure("Unrecognised hosted file; deny source release")
            fn,body,attrs=self.payload(record["turn_index"])
            if (record["filename"]!=fn or
                    record["payload_sha256"]!=hashlib.sha256(body).hexdigest()):
                raise HostedRFailure("Original source/index mapping changed")
            packets=[self._evidence(record["user_local_id"]),
                     self._evidence(record["assistant_local_id"])]
            if ([p["author_role"] for p in packets]!=["user","assistant"]
                    or [p["message_id"] for p in packets]!=
                       [f"r{record['turn_index']:02d}u",f"r{record['turn_index']:02d}a"]):
                raise HostedRFailure("Candidate source role/position mismatch")
            candidates.append({"rank":len(candidates)+1,
                               "turn_index":record["turn_index"],
                               "file_id":file_id,
                               "score":hit.get("score"),
                               "source_packets":packets,
                               "candidate_only":True})
        return candidates

    def validate_all_local(self) -> dict:
        with closing(self.archive._read_db()) as db:
            rows=db.execute("SELECT local_id FROM messages ORDER BY position").fetchall()
        if any(row["local_id"] not in self.expected for row in rows):
            raise HostedRFailure("Unexpected source outside fictional fixture")
        for row in rows:
            self._evidence(row["local_id"])
        with sqlite3.connect(self.db_path) as db:
            mapped=db.execute("SELECT turn_index FROM hosted_r_files WHERE completed=1 ORDER BY turn_index").fetchall()
        return {"original_messages":len(rows),"indexed_turns":[x[0] for x in mapped]}
