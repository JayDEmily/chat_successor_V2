"""Conditional Stage J shadow: independently bound current-turn synthetic message.

NO network listener, MCP registration, ChatGPT-origin attestation, authentication
integration, data import, or model API. An owned controller must supply the
original user message and host_context separately from model-authored args.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from .decision_support_i import SyntheticHistoryResolver


class TrustedIngressError(ValueError):
    """Invalid or conflicting simulated owner-controlled message ingress."""


@dataclass(frozen=True)
class BoundTurn:
    principal: str
    session: str
    turn: str
    actual_user_text: str


def _context_key(value: Mapping | None) -> tuple[str, str, str] | None:
    """Transport context MUST be supplied out-of-band by an owned controller."""
    if not isinstance(value, Mapping):
        return None
    if set(value) != {"user_id", "session_id", "turn_id"}:
        return None
    ids = (value["user_id"], value["session_id"], value["turn_id"])
    if any(not isinstance(item, str) or not item or
           len(item) > 128 or item.strip() != item for item in ids):
        return None
    return ids


class BoundTurnGateway:
    """Strictly conditional proof, not an MCP-callable native ChatGPT gateway.

    register_trusted_turn is an application-internal **owner ingress** operation.
    Exposing it as an MCP tool, or accepting its values from assistant arguments,
    would destroy the sole trust assumption tested here.
    """

    def __init__(self, original_resolver: SyntheticHistoryResolver):
        self._resolver = original_resolver
        self._pending: dict[tuple[str, str, str], BoundTurn] = {}
        self._spent: set[tuple[str, str, str]] = set()

    def register_trusted_turn(self, host_context: Mapping,
                              actual_user_text: str) -> None:
        key = _context_key(host_context)
        if key is None:
            raise TrustedIngressError("Owner-supplied context missing or invalid")
        if (not isinstance(actual_user_text, str) or
                not actual_user_text.strip() or len(actual_user_text) > 8192):
            raise TrustedIngressError("Owner-supplied actual user question invalid")
        if key in self._spent or key in self._pending:
            raise TrustedIngressError("Turn identity may never be reused")
        if any(old_key[:2] == key[:2] for old_key in self._pending):
            raise TrustedIngressError(
                "A session may not have overlapping unconsumed trusted turns")
        self._pending[key] = BoundTurn(
            principal=key[0], session=key[1], turn=key[2],
            actual_user_text=actual_user_text)

    @staticmethod
    def _denied(status: str, bound: bool) -> dict:
        return {
            "schema_version": 1, "synthetic_only": True,
            "trust_boundary": "OWNER_INGRESS_SIMULATED_NOT_NATIVE_CHATGPT",
            "status": status,
            "conversation_ids": [], "source_packets": [],
            "source_count": 0,
            "bound_to_owner_input": bound,
            "evidence_limitations": (
                "No original source packets can be returned without an "
                "independently supplied exact current-turn user message. "
                "Model-supplied identifiers, hashes and question strings "
                "are not equivalent to authenticated owner ingress."),
        }

    def resolve_tool_call(self, model_question: object,
                          host_context: Mapping | None) -> dict:
        """The model controls only model_question; host_context is out-of-band.

        Never pass host_context from a model argument. A failed authenticated
        call consumes the matching turn to block same-turn replay.
        """
        key = _context_key(host_context)
        if key is None or key not in self._pending:
            return self._denied("NO_BOUND_TURN", bound=False)
        bound = self._pending.pop(key)
        self._spent.add(key)
        if (not isinstance(model_question, str) or
                model_question != bound.actual_user_text):
            return self._denied("MODEL_ARGUMENT_MISMATCH", bound=True)
        response = self._resolver.resolve(bound.actual_user_text)
        if response["status"] not in ("UNIQUE", "MULTIPLE", "UNANCHORED"):
            raise TrustedIngressError("Unexpected original referent status")
        # The old resolver preserves original UTF-8 text, correction and
        # authorship; importantly its question now comes from owner ingress.
        response["trust_boundary"] = "OWNER_INGRESS_SIMULATED_NOT_NATIVE_CHATGPT"
        response["bound_to_owner_input"] = True
        return response

    @property
    def active_turn_count(self) -> int:
        return len(self._pending)
