"""Stage U private read-only hosted-vector -> exact SQLite synthetic MCP.

No real conversation archive, no new embeddings, no user-authentication claim,
no external model inference, no mutating tools. A strict finite source and
hosted-search budget limits accidental use outside the trial.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import threading
from datetime import datetime, timezone
from typing import Any
import uuid

from .verified_dialogue_t import NativeVerifiedT, PRIVATE_T
from .native_dialogue_s import StageSFailure

ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / ".local" / "trial-u-hosted-mcp-audit.jsonl"
TOOL = "lookup_synthetic_memory_u"
MAX_CALLS = 5
SOURCE_ANCHORS = (
    "nimbus","ryan","emily","casey","yoga","garden","watering","courtyard",
    "rowing","shell","boat","m6","bolts","friend","diary","pet sitter",
)
DISCLAIMER = "FICTIONAL_STAGE_T_ONLY_NO_OWNER_IDENTITY_OR_ORIGINAL_MESSAGE_ATTESTATION"


class StageUScopeError(RuntimeError):
    query_characters: int | None = None
    retry_hint: str | None = None


def validate_query(query: object, limit: object) -> tuple[str,int]:
    if type(query) is not str or not 8 <= len(query) <= 360 or query.strip() != query:
        raise StageUScopeError("Query must be a single bounded nonempty fictional diary question")
    if ("\r" in query or "\n" in query or "\x00" in query or
        any(ord(c) < 32 for c in query)):
        raise StageUScopeError("No multiline/control query allowed")
    if type(limit) is not int or not 1 <= limit <= 3:
        raise StageUScopeError("At most three synthetic conversation pairs per call")
    if not any(anchor in query.lower() for anchor in SOURCE_ANCHORS):
        raise StageUScopeError("Source scope is only the known fictional Stage T diary")
    return query,limit


class CallQuotaU:
    """Durable finite budget; count a call attempt BEFORE hosted network work."""

    def __init__(self, audit_path:Path=AUDIT,*,limit:int=MAX_CALLS,stage:str="U"):
        self.path=Path(audit_path)
        self.limit=limit
        if stage not in ("U", "W", "X", "Y", "long-form", "long-form-retry", "long-history"):
            raise StageUScopeError("Unknown bounded synthetic audit stage")
        self.stage=stage
        self.lock=threading.Lock()
        if not 1<=limit<=MAX_CALLS:
            raise StageUScopeError("Trial call budget exceeds frozen cap")
        self.path.parent.mkdir(parents=True,exist_ok=True)
        os.chmod(self.path.parent,0o700)

    def _read(self):
        if not self.path.exists():return []
        rows=[json.loads(line) for line in self.path.read_text(encoding="utf-8").splitlines()
              if line.strip()]
        if any(rec.get("stage")!=self.stage for rec in rows):
            raise StageUScopeError("Unknown records in private scoped audit")
        return rows

    def _append(self, event:dict):
        record={"stage":self.stage,"synthetic_only":True,
                "timestamp_utc":datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
                **event}
        fd=os.open(self.path,os.O_CREAT|os.O_WRONLY|os.O_APPEND,0o600)
        try:
            encoded=(json.dumps(record,sort_keys=True,ensure_ascii=True)+"\n").encode("utf-8")
            os.write(fd,encoded)
            os.fsync(fd)
        finally:
            os.close(fd)

    def begin(self,query:object) -> str | None:
        with self.lock:
            rows=self._read()
            attempts=[row for row in rows if row.get("event")=="CALL_STARTED"]
            if len(attempts)>=self.limit:
                self._append({"event":"CALL_DENIED_QUOTA","calls_spent":len(attempts)})
                return None
            event_id=str(uuid.uuid4())
            digest=(hashlib.sha256(query.encode("utf-8")).hexdigest()
                    if type(query) is str else None)
            self._append({"event":"CALL_STARTED","event_id":event_id,
                          "query_sha256":digest,"calls_spent":len(attempts)+1})
            return event_id

    def finish(self,event_id:str,status:str,candidates:int,*,
               reason:str|None=None,source_message_ids:list[str]|None=None,
               query_characters:int|None=None):
        if status not in ("FOUND","NO_MATCH","DENIED_SCOPE","ERROR"):
            raise StageUScopeError("Invalid audit completion")
        if reason is not None and reason not in (
                "BAD_TYPE","BAD_LENGTH","UNSAFE_CONTROL",
                "REAL_HISTORY_REQUEST","INVALID_LIMIT"):
            raise StageUScopeError("Invalid sanitised rejection reason")
        ids=source_message_ids or []
        if any(type(x) is not str or re.fullmatch(r"t0[1-5][ua]",x) is None
               for x in ids):
            raise StageUScopeError("Non-fictional source ID in private audit")
        event={"event":"CALL_COMPLETED","event_id":event_id,
               "status":status,"candidate_count":candidates}
        if reason is not None:
            event["rejection_reason"]=reason
        if query_characters is not None:
            event["normalized_query_characters"] = query_characters
        if ids:
            event["verified_source_message_ids"]=ids
        with self.lock:
            self._append(event)


class HostedMemoryGatewayU:
    def __init__(self,*,pipeline=None,quota=None,validator=None):
        self.pipeline=pipeline
        self.quota=quota or CallQuotaU()
        self.validator=validator or validate_query

    @staticmethod
    def public(status:str, candidates:list[dict]|None=None) -> dict[str,Any]:
        items=candidates or []
        return dict(schema_version=1,synthetic_only=True,
                    status=status,source_scope=DISCLAIMER,
                    trust_boundary="untrusted_model_query_only_fictional_sources",
                    candidate_only=True,source_packets_count=sum(
                        len(c["original_source_packets"]) for c in items),
                    results=items,
                    human_consent_attested=False,
                    original_user_text_attested=False)

    def lookup(self,query:object,limit:object=3):
        event_id=self.quota.begin(query)
        if event_id is None:
            return self.public("QUOTA_EXHAUSTED")
        try:
            query,limit=self.validator(query,limit)
        except StageUScopeError as exc:
            self.quota.finish(event_id, "DENIED_SCOPE", 0,
                              reason=getattr(exc, "reason", None),
                              query_characters=exc.query_characters)
            packet = self.public("DENIED_SCOPE")
            if exc.retry_hint is not None:
                packet.update(rejection_reason=exc.reason, retry_hint=exc.retry_hint)
            return packet
        try:
            pipeline=self.pipeline
            if pipeline is None:
                pipeline=NativeVerifiedT()
                self.pipeline=pipeline
            results=pipeline.search(query,top=limit)
            seen=set();items=[]
            for row in results:
                turn=row.get("turn")
                packets=row.get("original_packets")
                if type(turn) is not int or not 1<=turn<=5 or turn in seen:
                    raise StageUScopeError("Invalid or duplicate fictional turn from hosted index")
                seen.add(turn)
                if (not isinstance(packets,list) or len(packets)!=2 or
                    [p.get("author_role") for p in packets]!=["user","assistant"] or
                    [p.get("message_id") for p in packets]!=[f"t{turn:02d}u",f"t{turn:02d}a"] or
                    any(p.get("source_id")!="synthetic-native-dialogue-t" or
                        p.get("conversation_id")!="fictional_native_dialogue_t" or
                        p.get("fidelity")!="synthetic_only" or
                        p.get("capture_method")!="synthetic_native_ui"
                        for p in packets)):
                    raise StageUScopeError("Exact SQLite source identity not valid")
                evidence=[]
                for p in packets:
                    for key in ("exact_text","author_role","source_locator","content_sha256",
                                "local_id","ingested_at_utc","message_id","position"):
                        if key not in p:
                            raise StageUScopeError("Missing original SQLite source attribute "+key)
                    evidence.append({key:p.get(key) for key in (
                        "message_id","local_id","source_id","conversation_id","branch_id",
                        "position","author_role","exact_text","content_sha256",
                        "source_locator","capture_method","message_sent_at_source",
                        "message_sent_at_utc","ingested_at_utc")})
                items.append({"rank":len(items)+1,"turn":turn,
                              "original_source_packets":evidence})
            status="FOUND" if items else "NO_MATCH"
            ids=[p["message_id"] for item in items
                 for p in item["original_source_packets"]]
            self.quota.finish(event_id,status,len(items),
                              source_message_ids=ids)
            return self.public(status,items)
        except Exception:
            self.quota.finish(event_id,"ERROR",0)
            raise


def create_server(gateway=None, *, default_limit: int = 3):
    from mcp.server import MCPServer
    from mcp.types import CallToolResult, TextContent, ToolAnnotations
    gateway=gateway or HostedMemoryGatewayU()
    server=MCPServer(
        "LTM-RAG-vNext-Hosted-Memory-U",
        version="0.1.0",
        instructions=(
            "Read-only fictional Stage T conversation memory. "
            "When a question references the fabricated diary about Nimbus, Casey, "
            "Emily, Ryan, yoga, the courtyard or rowing-shell mock-up, use "
            "lookup_synthetic_memory_u to verify earlier original messages. "
            "This private synthetic tool makes semantic hosted Vector Store queries, "
            "then retrieves exact two-sided SQLite source records with authorship. "
            "Do not use for real personal history. Do not invent quotations; "
            "if tool unavailable or no source, say you cannot verify. "
            "Assistant statements are model replies, not user declarations."
        )
    )
    @server.tool(annotations=ToolAnnotations(read_only_hint=True,open_world_hint=False))
    def lookup_synthetic_memory_u(query:str,limit:int=default_limit):
        """Retrieve a fictional earlier conversation by meaning, then verify exact original user and assistant messages from SQLite. Use when fictional Ryan, Casey, Nimbus, garden, rowing shell or yoga are mentioned; no real user history."""
        packet=gateway.lookup(query,limit)
        return CallToolResult(
            content=[TextContent(type="text",text=json.dumps(packet,ensure_ascii=False))],
            structured_content=packet)
    return server


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--port",type=int,default=8792)
    parser.add_argument("--audit-log",type=Path,default=AUDIT)
    args=parser.parse_args()
    if args.port!=8792 or args.audit_log.resolve()!=AUDIT.resolve():
        parser.error("Stage U only allowed dedicated loopback 8792 and private audit path")
    gateway=HostedMemoryGatewayU(quota=CallQuotaU(args.audit_log))
    # Fail-closed before listener: verify the private T source/index has the
    # complete five-turn original set, without exposing any user data.
    checked=NativeVerifiedT().verify(upto=5)
    if checked.get("sql_original_messages")!=10:
        raise SystemExit("Stage T canonical source integrity mismatch")
    gateway.pipeline=NativeVerifiedT()
    create_server(gateway).run(
        transport="streamable-http",host="127.0.0.1",port=8792,
        json_response=True,stateless_http=True)


if __name__=="__main__":
    main()
