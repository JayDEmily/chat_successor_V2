"""Conservative, synthetic-only, offline referent selection research.

This module does NOT classify whether a user request needs memory retrieval.
It does NOT verify factual claims and is NOT wired into the live MCP server.
Candidate search ranking is never allowed to invent the referent.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class ReferentGateError(ValueError):
    """Manifest, source integrity or request violates the trial contract."""


@dataclass(frozen=True)
class AnchorEvidence:
    conversation_id: str
    text: str
    source_message_id: str
    source_locator: str
    content_sha256: str


@dataclass(frozen=True)
class ReferentDecision:
    status: str
    conversation_ids: tuple[str, ...]
    anchors: tuple[AnchorEvidence, ...]
    candidate_conversations: tuple[str, ...] | None

    @property
    def is_unique(self) -> bool:
        return self.status == "UNIQUE"


class ReferentGate:
    """Explicit same-question topic anchors validated against original records."""

    def __init__(self, manifest_path: str | Path, fixture_path: str | Path):
        manifest_path = Path(manifest_path)
        fixture_path = Path(fixture_path)
        manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
        original = fixture_path.read_bytes()
        fixture = json.loads(original.decode("utf-8-sig"))
        if (manifest.get("schema_version") != 1
                or manifest.get("synthetic_only") is not True
                or manifest.get("fixture") != "fixtures/synthetic_clean_g.json"):
            raise ReferentGateError("Invalid synthetic-only H manifest identity")
        if (not isinstance(manifest.get("fixture_sha256"), str)
                or hashlib.sha256(original).hexdigest() != manifest["fixture_sha256"]):
            raise ReferentGateError("Pinned original fictional fixture SHA-256 mismatch")
        if (fixture.get("synthetic") is not True
                or not isinstance(fixture.get("messages"), list)
                or not fixture["messages"]):
            raise ReferentGateError("Source corpus must be nonempty synthetic fixture")
        messages: dict[str, dict[str, Any]] = {}
        known_topics: set[str] = set()
        for item in fixture["messages"]:
            if not isinstance(item, dict):
                raise ReferentGateError("Invalid source record")
            mid = item.get("message_id")
            if not isinstance(mid, str) or not mid or mid in messages:
                raise ReferentGateError("Duplicate/missing original source message identity")
            if (item.get("capture_method") != "synthetic_fixture"
                    or not isinstance(item.get("conversation_id"), str)
                    or not isinstance(item.get("exact_text"), str)):
                raise ReferentGateError("Original source provenance invalid")
            messages[mid] = item
            known_topics.add(item["conversation_id"])
        topics = manifest.get("topics")
        if not isinstance(topics, list) or not topics:
            raise ReferentGateError("Empty/invalid explicit topic registry")
        self._anchors: list[tuple[re.Pattern[str], AnchorEvidence]] = []
        self._topic_ids: list[str] = []
        seen_aliases: set[str] = set()
        for topic in topics:
            if not isinstance(topic, dict):
                raise ReferentGateError("Malformed topic")
            tid = topic.get("conversation_id")
            if not isinstance(tid, str) or tid not in known_topics or tid in self._topic_ids:
                raise ReferentGateError("Unknown or duplicate topic")
            self._topic_ids.append(tid)
            aliases = topic.get("anchors")
            if not isinstance(aliases, list) or not aliases:
                raise ReferentGateError("Every topic requires explicit evidence-backed anchors")
            for alias in aliases:
                if not isinstance(alias, dict):
                    raise ReferentGateError("Invalid anchor")
                phrase,mid = alias.get("text"),alias.get("evidence_message_id")
                if (not isinstance(phrase, str) or not 2 <= len(phrase) <= 64
                        or not isinstance(mid, str) or mid not in messages):
                    raise ReferentGateError("Anchor text or source identity invalid")
                source = messages[mid]
                if (source["conversation_id"] != tid or source.get("branch_id") != "main"
                        or source.get("author_role") != "user"
                        or source.get("attribution") not in ("direct_message", "reported_recollection")):
                    raise ReferentGateError("Anchor must originate in main-branch user record")
                regex = re.compile(r"(?<![\w-])"+re.escape(phrase)+r"(?![\w-])",
                                   flags=re.IGNORECASE | re.UNICODE)
                if not regex.search(source["exact_text"]):
                    raise ReferentGateError("Alias does not appear in its original user evidence")
                key = phrase.casefold()
                if key in seen_aliases:
                    raise ReferentGateError("Duplicate/ambiguous manifest alias")
                seen_aliases.add(key)
                self._anchors.append((regex, AnchorEvidence(
                    conversation_id=tid, text=phrase, source_message_id=mid,
                    source_locator=source["source_locator"],
                    content_sha256=hashlib.sha256(source["exact_text"].encode("utf-8")).hexdigest(),
                )))
        if set(self._topic_ids) != known_topics:
            raise ReferentGateError("Manifest must enumerate exactly the fictional conversations")
        self._known = frozenset(self._topic_ids)

    def decide(self, question: str,
               candidate_conversations: list[str] | None = None) -> ReferentDecision:
        """Select only explicitly grounded topics; never infer from candidate rank.

        candidate_conversations=None means no candidate constraint was provided.
        [] means a lookup was performed and no candidate was returned.
        The caller must independently establish whether retrieval was needed.
        """
        if not isinstance(question, str) or not question.strip():
            raise ReferentGateError("Nonempty question is required")
        candidates: tuple[str, ...] | None = None
        if candidate_conversations is not None:
            if not isinstance(candidate_conversations, list):
                raise ReferentGateError("Candidates must be a list or null")
            if any(not isinstance(c, str) or c not in self._known
                   for c in candidate_conversations):
                raise ReferentGateError("Unknown or invalid candidate topic")
            if len(set(candidate_conversations)) != len(candidate_conversations):
                raise ReferentGateError("Duplicate candidate topic")
            candidates = tuple(candidate_conversations)
        matched = tuple(evidence for pattern,evidence in self._anchors
                        if pattern.search(question))
        topics = tuple(tid for tid in self._topic_ids
                       if any(hit.conversation_id == tid for hit in matched))
        if len(topics) == 0:
            status = "UNANCHORED"
        elif len(topics) >= 2:
            status = "MULTIPLE"
        elif candidates is not None and topics[0] not in candidates:
            status = "EVIDENCE_MISMATCH"
        else:
            status = "UNIQUE"
        return ReferentDecision(
            status=status, conversation_ids=topics,
            anchors=matched, candidate_conversations=candidates,
        )
