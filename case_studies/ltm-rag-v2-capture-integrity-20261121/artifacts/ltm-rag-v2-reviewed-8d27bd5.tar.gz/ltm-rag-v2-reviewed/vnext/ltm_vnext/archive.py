"""Append-only synthetic evidence catalogue with provenance-preserving retrieval."""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROLES = {"user", "assistant", "tool", "system"}
ATTRIBUTIONS = {"direct_message", "reported_recollection", "assistant_inference"}


class InvalidFixture(ValueError):
    """Input does not meet the synthetic test contract."""


class RecordConflict(ValueError):
    """Existing stable message identity has different content or metadata."""


def _normalise_sent_at(value: object) -> tuple[str | None, str | None]:
    """Preserve the supplied send-time string and normalise an aware instant.

    Never silently interpret a naive timestamp using the machine timezone.
    Absence of original-send provenance is explicitly NULL, not ingestion time.
    """
    if value is None:
        return None, None
    if type(value) is not str or not value or value.strip() != value:
        raise InvalidFixture("message_sent_at must be a timestamp string")
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise InvalidFixture("Invalid message_sent_at timestamp") from exc
    if stamp.tzinfo is None or stamp.utcoffset() is None:
        raise InvalidFixture("message_sent_at requires explicit UTC offset")
    normal = stamp.astimezone(timezone.utc).isoformat(timespec="microseconds")
    return value, normal.replace("+00:00", "Z")


def _local_id(source: str, message: str, version: str) -> str:
    return hashlib.sha256("\x00".join((source, message, version)).encode()).hexdigest()[:32]


class Archive:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        if not self.path.is_file():
            raise FileNotFoundError(f"Archive not initialised: {self.path}")

    @classmethod
    def initialise(cls, path: str | Path) -> "Archive":
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(target) as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS messages (
                    row_id INTEGER PRIMARY KEY,
                    local_id TEXT NOT NULL UNIQUE,
                    source_id TEXT NOT NULL,
                    message_id TEXT NOT NULL,
                    version_id TEXT NOT NULL,
                    conversation_id TEXT NOT NULL,
                    branch_id TEXT NOT NULL,
                    position INTEGER NOT NULL,
                    author_role TEXT NOT NULL,
                    reported_speaker TEXT,
                    attribution TEXT NOT NULL,
                    capture_method TEXT NOT NULL,
                    fidelity TEXT NOT NULL,
                    source_locator TEXT NOT NULL,
                    event_time TEXT,
                    time_precision TEXT NOT NULL,
                    message_sent_at_source TEXT,
                    message_sent_at_utc TEXT,
                    ingested_at_utc TEXT,
                    exact_text TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    supersedes_local_id TEXT,
                    UNIQUE(source_id,message_id,version_id)
                );
                CREATE VIRTUAL TABLE IF NOT EXISTS message_fts USING
                  fts5(exact_text,content='messages',content_rowid='row_id');
                CREATE TRIGGER IF NOT EXISTS messages_insert AFTER INSERT ON messages BEGIN
                  INSERT INTO message_fts(rowid, exact_text)
                  VALUES (new.row_id, new.exact_text);
                END;
            """)
            # Compatible, non-destructive migration for pre-chronology SQLite
            # archives, performed only when the caller explicitly initialises.
            existing = {col[1] for col in db.execute("PRAGMA table_info(messages)")}
            for column in ("message_sent_at_source", "message_sent_at_utc", "ingested_at_utc"):
                if column not in existing:
                    db.execute(f"ALTER TABLE messages ADD COLUMN {column} TEXT")
        return cls(target)

    @staticmethod
    def _validate(x: dict[str, Any]) -> dict[str, Any]:
        required = ("source_id", "message_id", "version_id", "conversation_id",
                    "branch_id", "position", "author_role", "attribution",
                    "capture_method", "source_locator", "exact_text")
        if any(k not in x for k in required):
            raise InvalidFixture("Missing required message fields")
        for k in ("source_id", "message_id", "version_id", "conversation_id",
                  "branch_id", "source_locator"):
            if not isinstance(x[k], str) or not x[k]:
                raise InvalidFixture(f"Invalid {k}")
        if x["capture_method"] == "synthetic_fixture":
            pass
        elif x["capture_method"] == "synthetic_native_ui":
            # This is a wholly invented scripted OWNER turn and an actual
            # native ChatGPT reply to that invented text. It is NOT a real
            # owner-authored message or genuine archive import.
            if (x.get("synthetic_only") is not True or
                (x["source_id"], x["source_locator"].startswith(
                    "synthetic-native-ui://stage-s/"),
                    x["source_locator"].startswith(
                    "synthetic-native-ui://stage-t/")) not in {
                        ("synthetic-native-dialogue-s", True, False),
                        ("synthetic-native-dialogue-t", False, True)
                    }):
                raise InvalidFixture("Native UI synthetic capture scope mismatch")
        else:
            raise InvalidFixture("Real or unlabelled captures are forbidden in this prototype")
        if x["author_role"] not in ROLES or x["attribution"] not in ATTRIBUTIONS:
            raise InvalidFixture("Unknown role or attribution")
        if type(x["position"]) is not int or x["position"] < 0:
            raise InvalidFixture("Invalid position")
        if not isinstance(x["exact_text"], str):
            raise InvalidFixture("exact_text must be a string")
        if x.get("reported_speaker") is not None and not isinstance(x["reported_speaker"], str):
            raise InvalidFixture("Invalid reported_speaker")
        if x.get("event_time") is not None and not isinstance(x["event_time"], str):
            raise InvalidFixture("Invalid event_time")
        if x.get("time_precision", "unknown") not in {"unknown", "date", "minute", "second"}:
            raise InvalidFixture("Invalid time precision")
        prior = x.get("supersedes")
        if prior is not None:
            if not isinstance(prior, dict) or any(
                not isinstance(prior.get(k), str) or not prior[k]
                for k in ("message_id", "version_id")
            ):
                raise InvalidFixture("Invalid supersedes identity")
        return dict(
            local_id=_local_id(x["source_id"], x["message_id"], x["version_id"]),
            source_id=x["source_id"], message_id=x["message_id"],
            version_id=x["version_id"], conversation_id=x["conversation_id"],
            branch_id=x["branch_id"], position=x["position"],
            author_role=x["author_role"], reported_speaker=x.get("reported_speaker"),
            attribution=x["attribution"], capture_method=x["capture_method"],
            fidelity="synthetic_only", source_locator=x["source_locator"],
            event_time=x.get("event_time"),
            time_precision=x.get("time_precision", "unknown"),
            exact_text=x["exact_text"],
            content_sha256=hashlib.sha256(x["exact_text"].encode("utf-8")).hexdigest(),
            supersedes_local_id=(
                _local_id(x["source_id"], prior["message_id"], prior["version_id"])
                if prior else None
            ),
        )

    def ingest_synthetic(self, fixture: str | Path) -> dict[str, int]:
        data = json.loads(Path(fixture).read_text(encoding="utf-8"))
        if not isinstance(data, dict) or data.get("synthetic") is not True:
            raise InvalidFixture("Required synthetic=true marker is absent")
        if not isinstance(data.get("messages"), list):
            raise InvalidFixture("Required messages array is absent")
        columns = ("local_id", "source_id", "message_id", "version_id",
                   "conversation_id", "branch_id", "position", "author_role",
                   "reported_speaker", "attribution", "capture_method", "fidelity",
                   "source_locator", "event_time", "time_precision", "exact_text",
                   "content_sha256", "supersedes_local_id")
        inserted = 0
        with sqlite3.connect(self.path) as db:
            db.row_factory = sqlite3.Row
            existing_columns = {col[1] for col in db.execute("PRAGMA table_info(messages)")}
            required_time_cols = {"message_sent_at_source", "message_sent_at_utc", "ingested_at_utc"}
            if not required_time_cols.issubset(existing_columns):
                raise InvalidFixture("Archive must be explicitly initialised for timestamp ingestion")
            for x in data["messages"]:
                if not isinstance(x, dict):
                    raise InvalidFixture("Message must be a JSON object")
                row = self._validate(x)
                sent_source, sent_utc = _normalise_sent_at(x.get("message_sent_at"))
                row["message_sent_at_source"] = sent_source
                row["message_sent_at_utc"] = sent_utc
                immutable_columns = columns + ("message_sent_at_source", "message_sent_at_utc")
                existing = db.execute("SELECT * FROM messages WHERE local_id=?",
                                      (row["local_id"],)).fetchone()
                if existing is not None:
                    if any(existing[k] != row[k] for k in immutable_columns):
                        raise RecordConflict(f"Stable identity changed: {row['local_id']}")
                    # Never replace the original ingestion instant on replay.
                    continue
                if row["supersedes_local_id"]:
                    previous = db.execute(
                        "SELECT source_id,conversation_id,branch_id FROM messages WHERE local_id=?",
                        (row["supersedes_local_id"],)
                    ).fetchone()
                    if (
                        previous is None
                        or previous["source_id"] != row["source_id"]
                        or previous["conversation_id"] != row["conversation_id"]
                        or previous["branch_id"] != row["branch_id"]
                    ):
                        raise InvalidFixture(
                            "Correction target absent or wrong source, conversation or branch"
                        )
                row["ingested_at_utc"] = (datetime.now(timezone.utc)
                    .isoformat(timespec="microseconds").replace("+00:00", "Z"))
                insert_columns = immutable_columns + ("ingested_at_utc",)
                marks = ", ".join("?" for _ in insert_columns)
                db.execute(
                    f"INSERT INTO messages ({', '.join(insert_columns)}) VALUES ({marks})",
                    tuple(row[k] for k in insert_columns),
                )
                inserted += 1
        return {"inserted": inserted, "total": len(data["messages"])}

    def _read_db(self) -> sqlite3.Connection:
        db = sqlite3.connect(f"file:{self.path.as_posix()}?mode=ro", uri=True)
        db.row_factory = sqlite3.Row
        return db

    @staticmethod
    def _packet(db: sqlite3.Connection, row: sqlite3.Row, radius: int) -> dict[str, Any]:
        packet = dict(row)
        packet.pop("row_id")
        packet["corrected_by"] = [r["local_id"] for r in db.execute(
            "SELECT local_id FROM messages WHERE supersedes_local_id=? ORDER BY row_id",
            (row["local_id"],)
        )]
        packet["neighbouring_dialogue"] = [
            {"local_id": n["local_id"], "position": n["position"],
             "author_role": n["author_role"], "exact_text": n["exact_text"],
             "content_sha256": n["content_sha256"]}
            for n in db.execute("""
                SELECT local_id,position,author_role,exact_text,content_sha256
                FROM messages WHERE source_id=? AND conversation_id=? AND branch_id=?
                  AND position BETWEEN ? AND ? AND local_id!=?
                ORDER BY position,row_id
            """, (row["source_id"], row["conversation_id"], row["branch_id"],
                  row["position"]-radius, row["position"]+radius,
                  row["local_id"]))
        ]
        packet["evidence_warning"] = (
            "Synthetic data only; a reported human recollection is not "
            "an independently verified recording of that person's words."
        )
        return packet

    def fetch(self, local_id: str, neighbours: int = 1) -> dict[str, Any] | None:
        if not isinstance(local_id, str) or type(neighbours) is not int or not 0 <= neighbours <= 3:
            raise ValueError("Invalid fetch arguments")
        with self._read_db() as db:
            row = db.execute("SELECT * FROM messages WHERE local_id=?",
                             (local_id,)).fetchone()
            return self._packet(db, row, neighbours) if row else None

    def timeline(self, source_id: str, conversation_id: str,
                 branch_id: str = "main") -> list[dict[str, Any]]:
        """Canonical authored sequence; timestamps do not rewrite branch order.

        event_time refers to the event being discussed, whereas
        message_sent_at_utc is the message's documented send time and
        ingested_at_utc is when the local archive first stored it.
        """
        if any(type(value) is not str or not value for value in
               (source_id, conversation_id, branch_id)):
            raise ValueError("Invalid timeline identity")
        with self._read_db() as db:
            records = db.execute(
                """SELECT * FROM messages
                   WHERE source_id=? AND conversation_id=? AND branch_id=?
                   ORDER BY position,row_id""",
                (source_id, conversation_id, branch_id)).fetchall()
            return [self._packet(db, record, 0) for record in records]

    def lookup(self, query: str, limit: int = 8) -> dict[str, Any]:
        if not isinstance(query, str) or type(limit) is not int or not 1 <= limit <= 20:
            raise ValueError("Invalid lookup arguments")
        terms = re.findall(r"\w+", query, flags=re.UNICODE)[:12]
        if not terms:
            return {"query": query, "count": 0, "hits": [], "synthetic_only": True}
        expression = " OR ".join('"' + t.replace('"', '""') + '"' for t in terms)
        with self._read_db() as db:
            rows = db.execute("""
                SELECT m.* FROM message_fts
                JOIN messages m ON m.row_id=message_fts.rowid
                WHERE message_fts MATCH ?
                ORDER BY bm25(message_fts),m.row_id LIMIT ?
            """, (expression, limit)).fetchall()
            hits = [self._packet(db, x, 1) for x in rows]
        return {"query": query, "count": len(hits),
                "hits": hits, "synthetic_only": True}
