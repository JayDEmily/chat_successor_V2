"""Read-only MCP v2 adapter for the synthetic integration experiment.

Binds to 127.0.0.1 only. It neither imports personal data nor starts a tunnel.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from .archive import Archive
from .audit import CallAudit


def create_server(db_path: str | Path, audit_path: str | Path | None = None):
    from mcp.server import MCPServer
    from mcp.types import CallToolResult, TextContent, ToolAnnotations

    archive = Archive(db_path)
    audit = CallAudit(audit_path if audit_path is not None else
                      os.environ.get("LTM_VNEXT_AUDIT_LOG"))
    server = MCPServer(
        "LTM-RAG-vNext-Synthetic",
        version="0.1.0",
        instructions=(
            "Read-only lookup over entirely made-up conversations. "
            "Use prior synthetic evidence when relevant; do not invent source "
            "quotations, and do not treat reported recollections as recordings. "
            "These tools cannot store or modify messages."
        ),
    )
    annotation = ToolAnnotations(read_only_hint=True, open_world_hint=False)

    def result(packet: dict) -> CallToolResult:
        return CallToolResult(
            content=[TextContent(type="text", text=json.dumps(
                packet, ensure_ascii=False
            ))],
            structured_content=packet,
        )

    @server.tool(annotations=annotation)
    def lookup_evidence(query: str, limit: int = 8):
        """Find synthetic historical passages with exact text and provenance labels."""
        packet = archive.lookup(query, limit)
        audit.record("lookup_evidence", outcome="ok", result_count=packet["count"])
        return result(packet)

    @server.tool(annotations=annotation)
    def fetch_source(local_id: str, neighbours: int = 1):
        """Read an original synthetic passage and surrounding dialogue."""
        found = archive.fetch(local_id, neighbours)
        audit.record("fetch_source", outcome="ok" if found is not None else "missing",
                     result_count=1 if found is not None else 0)
        return result(found if found is not None
                      else {"found": False, "local_id": local_id})

    return server


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", type=Path, required=True)
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument("--audit-log", type=Path, default=None)
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("--port must be between 1024 and 65535")
    create_server(args.db, audit_path=args.audit_log).run(
        transport="streamable-http", host="127.0.0.1", port=args.port,
        json_response=True, stateless_http=True,
    )


if __name__ == "__main__":
    main()
