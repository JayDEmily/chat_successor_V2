"""Optional privacy-minimised record of MCP tool invocations.

No query text, source text, API keys or authentication headers are logged.
Audit events are local operational telemetry; the archive remains read-only.
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path


class CallAudit:
    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else None

    def record(self, tool: str, *, outcome: str, result_count: int | None = None) -> None:
        if self.path is None:
            return
        if tool not in {"lookup_evidence", "fetch_source"}:
            raise ValueError("Unknown tool name")
        if outcome not in {"ok", "error", "missing"}:
            raise ValueError("Unknown outcome")
        event = {
            "event_id": str(uuid.uuid4()),
            "timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "tool": tool,
            "outcome": outcome,
            "result_count": result_count,
            "synthetic_only": True,
        }
        flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND
        descriptor = os.open(self.path, flags, 0o600)
        try:
            os.write(descriptor, (json.dumps(event, sort_keys=True) + "\n").encode("utf-8"))
        finally:
            os.close(descriptor)
