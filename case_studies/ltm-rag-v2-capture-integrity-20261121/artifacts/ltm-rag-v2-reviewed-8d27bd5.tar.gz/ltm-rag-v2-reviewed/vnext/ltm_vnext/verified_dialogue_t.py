"""Stage T clean native ChatGPT UI source reconciliation.

The original five Stage S sends, raw captures and hosted index are preserved.
No native sends or model inference calls. Newly verified response text is
read independently from the same live UI and signed by a frozen local hash.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .native_dialogue_s import (
    NativeSyntheticS, StageSFailure, ROOT, PRIVATE as S_PRIVATE,
    _private_write, _load_json, _aware_utc
)

PRIVATE_T=ROOT/".local/native-t-dialogue"
T_PLAN=ROOT/"NATIVE_DIALOGUE_T_CASES_20261120.json"
T_STORE_NAME="LTM-RAG vNext — Verified Native Dialogue T"
T_SOURCE="synthetic-native-dialogue-t"
T_CONVERSATION="fictional_native_dialogue_t"
UI_FOOTER=r"\nChatGPT can make mistakes. Check important info.\nLatest response\nAsk ChatGPT"


class NativeVerifiedT(NativeSyntheticS):
    """Only Stage T verified original source, zero new ChatGPT UI actions."""

    def __init__(self, api=None, *, private:Path=PRIVATE_T, s_private:Path=S_PRIVATE, verified_source:Path|None=None):
        self.t_plan=_load_json(T_PLAN)
        if (self.t_plan["trial_id"]!="ltm-vnext-T-verified-native-dialogue-salvage-20261120" or
            self.t_plan["original_native_sends"]!=5 or
            self.t_plan["additional_native_sends_allowed"]!=0 or
            self.t_plan["hosted_file_uploads_max"]!=5 or
            self.t_plan["hosted_store_name"]!=T_STORE_NAME):
            raise StageSFailure("Frozen Stage T registration contract mismatch")
        self.s_private=Path(s_private)
        self.transcript_path=Path(verified_source) if verified_source is not None else PRIVATE_T/"verified_transcript.json"
        if not self.transcript_path.is_file():
            raise StageSFailure("Independently verified UI transcript missing")
        if hashlib.sha256(self.transcript_path.read_bytes()).hexdigest()!=self.t_plan["verified_private_transcript_sha256"]:
            raise StageSFailure("Verified private native transcript hash drift")
        self.verified=_load_json(self.transcript_path)
        if (self.verified.get("trial_id")!="T" or
            self.verified.get("synthetic_only") is not True or
            self.verified.get("original_capture_preserved") is not True or
            len(self.verified.get("turns",[]))!=5):
            raise StageSFailure("Stage T source proof shape not recognised")
        super().__init__(api,private=private)
        # The parent class provides the original five-message S read-only
        # source/role/time contract and robust SQL/File mapping, not the S store.

    def _receipt(self,turn:int) -> dict:
        if type(turn) is not int or not 1<=turn<=5:
            raise StageSFailure("Invalid frozen T source turn")
        t=self.verified["turns"][turn-1]
        s_path=self.s_private/f"captured_{turn:02d}.json"
        marker=self.s_private/f"send_once_{turn:02d}.json"
        if not s_path.is_file() or not marker.is_file():
            raise StageSFailure("Original Stage S native evidence missing")
        source_bytes=s_path.read_bytes()
        digest=hashlib.sha256(source_bytes).hexdigest()
        if (digest!=self.t_plan["raw_private_capture_sha256"][turn-1] or
            t.get("original_raw_capture_sha256")!=digest):
            raise StageSFailure("Original frozen native receipt bytes changed")
        s=_load_json(s_path)
        m=_load_json(marker)
        planned=self.plan["case_messages"][turn-1]
        if (t.get("turn")!=turn or t.get("case_id")!=planned["id"] or
            t.get("simulated_user_text")!=planned["simulated_user_text"] or
            s.get("simulated_user_text")!=planned["simulated_user_text"] or
            s.get("assistant_generated_by")!="native_chatgpt" or
            t.get("assistant_generated_by")!="native_chatgpt" or
            t.get("exact_UIA_rendered_text_verified") is not True or
            t.get("real_user_authorship_attested") is not False or
            s.get("real_user_authorship_attested") is not False or
            m.get("phase")!="send_invoked" or m.get("turn")!=turn or
            m.get("case_id")!=planned["id"] or
            t.get("ui_send_at_utc")!=s.get("ui_send_at_utc") or
            t.get("first_observed_complete_at_utc")!=s.get("assistant_observed_complete_at_utc") or
            t.get("chat_url")!=s.get("chat_url")):
            raise StageSFailure("T original user/model identity or timings changed")
        text=t.get("assistant_verified_rendered_text")
        raw=s.get("assistant_observed_text")
        if (type(text) is not str or not text.strip() or len(text)>6000 or
            raw!=text+UI_FOOTER or
            "ChatGPT can make mistakes." in text or
            "Latest response" in text):
            raise StageSFailure("Independently verified assistant reply differs from original minus exact footer")
        for field in ("ui_send_at_utc","first_observed_complete_at_utc","native_ui_readback_at_utc"):
            _aware_utc(t.get(field))
        return {
            "synthetic_only":True,"turn":turn,"case_id":planned["id"],
            "simulated_user_text":t["simulated_user_text"],
            "assistant_observed_text":text,
            "assistant_generated_by":"native_chatgpt",
            "capture_method":"native_windows_ui_automation",
            "real_user_authorship_attested":False,
            "ui_send_at_utc":t["ui_send_at_utc"],
            "assistant_observed_complete_at_utc":t["first_observed_complete_at_utc"],
            "chat_url":t["chat_url"],
            "original_raw_sha256":digest,
            "later_ui_readback_at_utc":t["native_ui_readback_at_utc"],
        }

    def _messages(self,turn:int,row:dict) -> list[dict]:
        items=super()._messages(turn,row)
        for item in items:
            item["source_id"]=T_SOURCE
            item["message_id"]=item["message_id"].replace("s","t",1)
            item["conversation_id"]=T_CONVERSATION
            role=item["author_role"]
            item["source_locator"]=f"synthetic-native-ui://stage-t/turn-{turn:02d}/{role}"
        return items

    def _payload(self,turn:int,messages:list[dict]):
        user,assistant=messages
        lines=[
            "WHOLLY FICTIONAL NATIVE CHATGPT TEST. NOT A REAL USER DIARY.",
            "The assistant reply was independently reread from ChatGPT UIA;",
            "it excludes a verified Chrome UI footer added by a failed first capture.",
            f"Conversation: {T_CONVERSATION}",
            f"Turn: {turn:02d}",
            f"SIMULATED USER [{user['message_id']}]: {user['exact_text']}",
            f"NATIVE CHATGPT ASSISTANT [{assistant['message_id']}]: {assistant['exact_text']}",
            "",
        ]
        data="\n".join(lines).encode("utf-8")
        digest=hashlib.sha256(data).hexdigest()
        filename=f"fictional_native_t_turn_{turn:02d}_{digest[:16]}.txt"
        attrs={"synthetic_only":True,"conversation_id":T_CONVERSATION,
               "turn_index":turn,"payload_sha256":digest}
        return filename,data,attrs

    def store(self, *, allow_create:bool=False) -> str:
        if self.config.exists():
            info=_load_json(self.config)
            if info.get("name")!=T_STORE_NAME or info.get("synthetic_only") is not True:
                raise StageSFailure("Private T store binding changed")
            store_id=info["store_id"]
        else:
            if not allow_create:
                raise StageSFailure("Stage T hosted store not provisioned")
            found=[s for s in self.api.stores() if s.get("name")==T_STORE_NAME]
            if len(found)>1:
                raise StageSFailure("Several Stage T vector stores match fixed name")
            remote=found[0] if found else self.api.json("POST","/vector_stores",{
                "name":T_STORE_NAME,
                "expires_after":{"anchor":"last_active_at","days":30},
                "metadata":{"synthetic_only":"true","scope":"ltm-rag-vnext-t"},
            })
            store_id=remote.get("id")
            if type(store_id) is not str or not store_id.startswith("vs_"):
                raise StageSFailure("Wrong T vector-store ID")
            _private_write(self.config,{
                "store_id":store_id,"name":T_STORE_NAME,"synthetic_only":True
            })
        remote=self.api.retrieve_store(store_id)
        if (remote.get("id")!=store_id or remote.get("name")!=T_STORE_NAME or
            (remote.get("metadata") or {}).get("synthetic_only")!="true" or
            (remote.get("metadata") or {}).get("scope")!="ltm-rag-vnext-t" or
            (remote.get("expires_after") or {}).get("anchor")!="last_active_at" or
            (remote.get("expires_after") or {}).get("days")!=30):
            raise StageSFailure("Remote verified T store identity/expiry drift")
        return store_id
