"""Stage W: semantically neutral query scope for exact synthetic Stage T memory.

The original Stage U lexical validator remains the default, so historical U
offline evidence is reproducible. This isolated W gateway replaces *only*
model-query validation, not fixed-source validation, author/role provenance,
hosted file ID reconciliation or the one-tool MCP schema.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path

from .hosted_mcp_u import (
    CallQuotaU, HostedMemoryGatewayU, StageUScopeError, create_server,
)
from .verified_dialogue_t import NativeVerifiedT

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
PLAN=ROOT/"NATIVE_HOSTED_W_CASES_20261120.json"
PROTOCOL=ROOT/"NATIVE_HOSTED_W_PROTOCOL_20261120.md"
REGISTRATION="f02460d7f935fdb1d447ccdd4b688d0e7613aa0e"
PARENT="7329ba2d0ec29bfff73a09cf60a0f50fe777e39a"
OLD_AUDIT=ROOT/".local/trial-u-hosted-mcp-audit.jsonl"
W_AUDIT=ROOT/".local/trial-w-hosted-mcp-audit.jsonl"

# This regex prevents an explicit real-user-history request from being
# forwarded to the hosted provider. Real source access is impossible anyway:
# the gateway only connects to the immutable five-turn fictional Stage T.
REAL_HISTORY=re.compile(
    r"\b(?:my|our)\s+(?:real|actual|genuine|private|personal)\s+"
    r"(?:(?:chatgpt|chat|conversation|message|history|archive)\b)",
    re.IGNORECASE,
)


class StageWScopeError(StageUScopeError):
    def __init__(self, reason: str, *, query_characters: int | None = None,
                 retry_hint: str | None = None):
        if reason not in {"BAD_TYPE","BAD_LENGTH","UNSAFE_CONTROL",
                          "REAL_HISTORY_REQUEST","INVALID_LIMIT"}:
            raise ValueError("Non-registered W rejection code")
        self.reason = reason
        self.query_characters = query_characters
        self.retry_hint = retry_hint
        super().__init__("Stage W bounded synthetic-source query rejected")


def validate_semantic_w(
    query: object, limit: object = 3, *, min_chars: int = 8,
    max_chars: int = 640, max_pairs: int = 3,
) -> tuple[str, int]:
    """Normalize the query while keeping evidence within the verified source."""
    if type(query) is not str:
        raise StageWScopeError("BAD_TYPE")
    if any(ord(c)<32 and c not in ("\n","\r","\t") for c in query):
        raise StageWScopeError("UNSAFE_CONTROL")
    normalised=" ".join(query.split())
    if REAL_HISTORY.search(normalised):
        raise StageWScopeError("REAL_HISTORY_REQUEST")
    if not min_chars <= len(normalised) <= max_chars:
        raise StageWScopeError(
            "BAD_LENGTH",
            query_characters=len(normalised),
            retry_hint=f"Retry with a focused fictional diary query of {min_chars} to {max_chars} characters.",
        )
    if type(limit) is not int or not 1<=limit<=10:
        raise StageWScopeError("INVALID_LIMIT")
    return normalised, min(limit, max_pairs)


def validate_native_recall(query: object, limit: object) -> tuple[str, int]:
    """Accept compact terms or several episodes of the five-pair fictional diary."""
    return validate_semantic_w(query, limit, min_chars=2, max_chars=4096, max_pairs=5)


class HostedMemoryGatewayW(HostedMemoryGatewayU):
    def __init__(self, *, pipeline=None, quota=None, validator=validate_semantic_w):
        super().__init__(pipeline=pipeline, quota=quota or
            CallQuotaU(W_AUDIT, limit=3, stage="W"), validator=validator)


def git(*args:str)->bytes:
    return subprocess.run(["git","-C",str(REPO),*args],
                          capture_output=True,check=True).stdout


def check_registration():
    if git("rev-list","--parents","-n","1",REGISTRATION).decode().strip()!=(
            REGISTRATION+" "+PARENT):
        raise RuntimeError("Stage W preregistration parent changed")
    for filename in ("NATIVE_HOSTED_W_CASES_20261120.json",
                     "NATIVE_HOSTED_W_PROTOCOL_20261120.md"):
        if (ROOT/filename).read_bytes()!=git("show",REGISTRATION+":vnext/"+filename):
            raise RuntimeError("Frozen Stage W preregistration changed")
    plan=json.loads(PLAN.read_text(encoding="utf-8"))
    if (plan.get("registration_parent")!=PARENT or
        plan.get("synthetic_only") is not True or
        plan.get("max_native_user_sends")!=1 or
        plan.get("max_server_calls")!=3 or
        plan.get("source_record_mutations_allowed")!=0 or
        plan.get("new_plugin_count")!=0 or
        plan.get("new_tunnel_count")!=0):
        raise RuntimeError("Stage W source/registration scope drift")
    if not OLD_AUDIT.is_file() or hashlib.sha256(OLD_AUDIT.read_bytes()).hexdigest()!=(
            plan["historical_u_native_audit_sha256"]):
        raise RuntimeError("Historical U/V one-call audit has changed")
    verified=NativeVerifiedT().verify(upto=5)
    if verified.get("sql_original_messages")!=10:
        raise RuntimeError("Verified Stage T ten messages not intact")
    return plan


def main():
    args=argparse.ArgumentParser()
    args.add_argument("--port",type=int,default=8792)
    selected=args.parse_args()
    if selected.port!=8792:
        args.error("W may replace only the isolated U loopback listener on port 8792")
    check_registration()
    gateway=HostedMemoryGatewayW(pipeline=NativeVerifiedT())
    create_server(gateway).run(
        transport="streamable-http",host="127.0.0.1",port=8792,
        json_response=True,stateless_http=True,
    )


if __name__=="__main__":
    main()
