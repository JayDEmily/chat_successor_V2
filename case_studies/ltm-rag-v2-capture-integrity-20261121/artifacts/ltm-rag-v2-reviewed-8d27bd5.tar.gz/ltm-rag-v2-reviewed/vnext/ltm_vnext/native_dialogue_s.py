"""Stage S: real native ChatGPT replies to *fictional* UI-driven user turns.

One isolated hosted store; original UI-observed messages always canonical in
SQLite. No personal data, model inference API, auto-history capture or MCP.
"""
from __future__ import annotations
from contextlib import closing
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import time
from typing import Any

from .archive import Archive, InvalidFixture, RecordConflict
from .hosted_memory_r import HostedRFailure, OpenAIHttpR, project_key

ROOT=Path(__file__).resolve().parents[1]
CASE_FILE=ROOT/"NATIVE_DIALOGUE_S_CASES_20261120.json"
PRIVATE=ROOT/".local/native-s-dialogue"
STORE_NAME="LTM-RAG vNext — Native Synthetic Dialogue S"
SOURCE="synthetic-native-dialogue-s"
CONVERSATION="fictional_native_dialogue_s"


class StageSFailure(RuntimeError):
    pass


def _load_json(path: Path) -> dict:
    obj=json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(obj,dict):
        raise StageSFailure("Expected private JSON object")
    return obj


def _private_write(path: Path, object_data: dict):
    path.parent.mkdir(parents=True,exist_ok=True)
    os.chmod(path.parent,0o700)
    temporary=path.with_suffix(path.suffix+".tmp")
    fd=os.open(temporary, os.O_CREAT|os.O_WRONLY|os.O_TRUNC,0o600)
    with os.fdopen(fd,"w",encoding="utf-8") as stream:
        json.dump(object_data,stream,ensure_ascii=False,sort_keys=True,indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary,path)
    os.chmod(path,0o600)


def _aware_utc(value: object) -> str:
    if not isinstance(value,str):
        raise StageSFailure("Missing observed timestamp")
    try: dt=datetime.fromisoformat(value.replace("Z","+00:00"))
    except ValueError: raise StageSFailure("Invalid observed timestamp") from None
    if dt.utcoffset() is None:
        raise StageSFailure("Naive observed timestamp")
    return dt.isoformat(timespec="microseconds")


class NativeSyntheticS:
    def __init__(self, api=None, *, private: Path=PRIVATE):
        self.private=Path(private)
        self.plan=_load_json(CASE_FILE)
        if (self.plan["trial_id"]!="ltm-vnext-S-native-synthetic-dialogue-20261120"
                or len(self.plan["case_messages"])!=5
                or self.plan["authorised_native_messages_max"]!=5
                or self.plan["hosted_files_max"]!=5
                or self.plan["model_api_inference_calls"]!=0):
            raise StageSFailure("Unrecognised frozen Stage S plan")
        self.private.mkdir(parents=True,exist_ok=True)
        os.chmod(self.private,0o700)
        self.api=api or OpenAIHttpR(project_key())
        self.db=self.private/"dialogue_s.sqlite"
        self.archive=Archive.initialise(self.db)
        os.chmod(self.db,0o600)
        with sqlite3.connect(self.db) as db:
            db.execute("""CREATE TABLE IF NOT EXISTS native_s_files(
                turn_index INTEGER PRIMARY KEY,
                file_id TEXT UNIQUE NOT NULL,
                filename TEXT NOT NULL UNIQUE,
                payload_sha256 TEXT NOT NULL,
                user_local_id TEXT NOT NULL,
                assistant_local_id TEXT NOT NULL,
                assistant_observed_at_utc TEXT NOT NULL,
                chat_url TEXT NOT NULL,
                completed INTEGER NOT NULL DEFAULT 0
            )""")
        self.config=self.private/"store.json"
        self.ledger=self.private/"search_results.json"

    def store(self,*,allow_create: bool=False) -> str:
        if self.config.exists():
            cfg=_load_json(self.config)
            if cfg.get("name")!=STORE_NAME or cfg.get("synthetic_only") is not True:
                raise StageSFailure("Private store binding mismatch")
            store_id=cfg["store_id"]
        else:
            if not allow_create:
                raise StageSFailure("Store not provisioned")
            stores=self.api.stores()
            found=[s for s in stores if s.get("name")==STORE_NAME]
            if len(found)>1:
                raise StageSFailure("Ambiguous existing hosted stores")
            if found:
                remote=found[0]
            else:
                remote=self.api.json("POST","/vector_stores",{
                    "name":STORE_NAME,
                    "expires_after":{"anchor":"last_active_at","days":30},
                    "metadata":{"synthetic_only":"true","scope":"ltm-rag-vnext-s"}
                })
            store_id=remote.get("id")
            if not isinstance(store_id,str) or not store_id.startswith("vs_"):
                raise StageSFailure("Invalid created store identity")
            _private_write(self.config,{
                "store_id":store_id,"name":STORE_NAME,"synthetic_only":True
            })
        remote=self.api.retrieve_store(store_id)
        if (remote.get("id")!=store_id or remote.get("name")!=STORE_NAME or
            (remote.get("metadata") or {}).get("synthetic_only")!="true" or
            (remote.get("metadata") or {}).get("scope")!="ltm-rag-vnext-s" or
            (remote.get("expires_after") or {}).get("anchor")!="last_active_at" or
            (remote.get("expires_after") or {}).get("days")!=30):
            raise StageSFailure("Remote hosted store scope/expiry drift")
        return store_id

    def _receipt(self,turn: int) -> dict:
        if type(turn) is not int or not 1<=turn<=5:
            raise StageSFailure("Invalid frozen simulated turn")
        p=self.private/f"captured_{turn:02d}.json"
        if not p.is_file():
            raise StageSFailure("Native UI turn capture not present")
        row=_load_json(p)
        spec=self.plan["case_messages"][turn-1]
        if (row.get("synthetic_only") is not True or row.get("turn")!=turn or
            row.get("case_id")!=spec["id"] or
            row.get("simulated_user_text")!=spec["simulated_user_text"] or
            row.get("capture_method")!="native_windows_ui_automation" or
            row.get("assistant_generated_by")!="native_chatgpt" or
            row.get("real_user_authorship_attested") is not False or
            type(row.get("assistant_observed_text")) is not str or
            not 1<=len(row["assistant_observed_text"].strip())<=6000 or
            not row.get("chat_url","").startswith("chatgpt.com/c/")):
            raise StageSFailure("Malformed or mismatched native synthetic capture")
        sent=_aware_utc(row.get("ui_send_at_utc"))
        observed=_aware_utc(row.get("assistant_observed_complete_at_utc"))
        if datetime.fromisoformat(observed) < datetime.fromisoformat(sent):
            raise StageSFailure("Assistant observed before user UI send")
        return row

    def _messages(self,turn: int,row: dict) -> list[dict]:
        messages=[]
        for idx,(role,text) in enumerate((
            ("user",row["simulated_user_text"]),
            ("assistant",row["assistant_observed_text"])
        )):
            messages.append({
                "source_id":SOURCE,
                "message_id":f"s{turn:02d}{'u' if idx==0 else 'a'}",
                "version_id":"1","conversation_id":CONVERSATION,
                "branch_id":"main","position":turn*2-1+idx,
                "author_role":role,
                "attribution":"direct_message" if idx==0 else "assistant_inference",
                "capture_method":"synthetic_native_ui",
                "synthetic_only":True,
                "source_locator":f"synthetic-native-ui://stage-s/turn-{turn:02d}/{role}",
                "exact_text":text,
                **({"message_sent_at":row["ui_send_at_utc"]} if idx==0 else {}),
            })
        return messages

    def _payload(self,turn: int,messages: list[dict]) -> tuple[str,bytes,dict]:
        user,assistant=messages
        body=("\n".join([
            "FICTIONAL TEST DIALOGUE. SIMULATED USER, REAL CHATGPT-GENERATED REPLY.",
            "The original evidence is separately preserved in local SQLite.",
            f"Conversation: {CONVERSATION}",
            f"Turn: {turn:02d}",
            f"SIMULATED USER [{user['message_id']}]: {user['exact_text']}",
            f"NATIVE CHATGPT ASSISTANT [{assistant['message_id']}]: {assistant['exact_text']}",
            "",
        ])).encode("utf-8")
        digest=hashlib.sha256(body).hexdigest()
        return (f"fictional_native_s_turn_{turn:02d}_{digest[:16]}.txt",body,
                {"synthetic_only":True,"conversation_id":CONVERSATION,
                 "turn_index":turn,"payload_sha256":digest})

    def _mapping(self,turn:int):
        with sqlite3.connect(self.db) as sql:
            sql.row_factory=sqlite3.Row
            row=sql.execute("SELECT * FROM native_s_files WHERE turn_index=?",(turn,)).fetchone()
        return dict(row) if row else None

    def index_turn(self,turn: int) -> dict:
        row=self._receipt(turn)
        if turn>1:
            previous=self._mapping(turn-1)
            if not previous or previous["completed"]!=1:
                raise StageSFailure("Previous scripted turn not fully indexed")
            prior=self._receipt(turn-1)
            if prior.get("chat_url")!=row.get("chat_url"):
                raise StageSFailure("Native UI conversation changed between turns")
        messages=self._messages(turn,row)
        with tempfile.TemporaryDirectory(prefix="synthetic-native-s-") as tmp:
            p=Path(tmp)/"source.json"
            p.write_text(json.dumps({"synthetic":True,"messages":messages}),encoding="utf-8")
            try: self.archive.ingest_synthetic(p)
            except (InvalidFixture,RecordConflict) as exc:
                raise StageSFailure("Original SQLite source identity changed") from exc
        originals=[Archive._validate(msg) for msg in messages]
        filename,body,attrs=self._payload(turn,messages)
        mapping=self._mapping(turn)
        if mapping:
            if (mapping["filename"]!=filename or
                mapping["payload_sha256"]!=attrs["payload_sha256"] or
                [mapping["user_local_id"],mapping["assistant_local_id"]]!=
                  [x["local_id"] for x in originals] or
                mapping["chat_url"]!=row["chat_url"] or
                mapping["assistant_observed_at_utc"]!=row["assistant_observed_complete_at_utc"]):
                raise StageSFailure("Existing turn mapping/contents differ")
            file_id=mapping["file_id"]
        else:
            # Exactly one hosted upload if no deterministic previous filename.
            matches=[item for item in self.api.files() if item.get("filename")==filename]
            if len(matches)>1: raise StageSFailure("Multiple uploaded files with one name")
            uploaded=matches[0] if matches else self.api.upload_file(filename,body)
            file_id=uploaded.get("id")
            if not isinstance(file_id,str) or not file_id.startswith("file-"):
                raise StageSFailure("Invalid uploaded file ID")
            with sqlite3.connect(self.db) as sql:
                sql.execute("""INSERT INTO native_s_files(
                    turn_index,file_id,filename,payload_sha256,user_local_id,
                    assistant_local_id,assistant_observed_at_utc,chat_url,completed)
                    VALUES(?,?,?,?,?,?,?,?,0)""",
                    (turn,file_id,filename,attrs["payload_sha256"],
                     originals[0]["local_id"],originals[1]["local_id"],
                     row["assistant_observed_complete_at_utc"],row["chat_url"]))
        store_id=self.store()
        attached=self.api.attachment(store_id,file_id)
        if attached is None:
            attached=self.api.attach(store_id,file_id,attrs)
        if attached.get("status") in ("failed","cancelled"):
            raise StageSFailure("Hosted synthetic attachment refused")
        for _ in range(30):
            attached=self.api.attachment(store_id,file_id)
            if attached and attached.get("status")=="completed":
                if any((attached.get("attributes") or {}).get(k)!=v
                       for k,v in attrs.items()):
                    raise StageSFailure("Hosted vector file attributes mismatch")
                with sqlite3.connect(self.db) as sql:
                    sql.execute("UPDATE native_s_files SET completed=1 WHERE turn_index=?",
                                (turn,))
                return {"turn":turn,"indexed":True,"original_messages":turn*2,
                        "hosted_files":turn}
            if attached and attached.get("status") in ("failed","cancelled"):
                raise StageSFailure("Hosted indexing failed")
            time.sleep(1.5)
        raise StageSFailure("Timed out while indexing hosted synthetic file")

    def verify(self,*,upto:int):
        if not 0<=upto<=5: raise StageSFailure("Invalid verification bound")
        with sqlite3.connect(self.db) as sql:
            sql.row_factory=sqlite3.Row
            messages=sql.execute("SELECT * FROM messages ORDER BY position").fetchall()
            mappings=sql.execute("SELECT * FROM native_s_files ORDER BY turn_index").fetchall()
        if len(messages)!=2*upto or len(mappings)!=upto:
            raise StageSFailure("Unexpected original transcript or index count")
        for i in range(upto):
            turn=i+1
            receipt=self._receipt(turn)
            expected=self._messages(turn,receipt)
            a,b=messages[i*2:i*2+2]
            for actual,source in zip((a,b),expected):
                parsed=Archive._validate(source)
                if any(actual[k]!=v for k,v in parsed.items()):
                    raise StageSFailure("Canonical original bytes/role/capture drift")
                if not actual["ingested_at_utc"]:
                    raise StageSFailure("Missing immutable UTC ingestion timestamp")
                if source["author_role"]=="assistant" and actual["message_sent_at_utc"] is not None:
                    raise StageSFailure("Invented assistant original send timestamp")
                if source["author_role"]=="user" and actual["message_sent_at_utc"] is None:
                    raise StageSFailure("User UI send event timestamp missing")
            mapping=mappings[i]
            if (mapping["turn_index"]!=turn or mapping["completed"]!=1 or
                mapping["user_local_id"]!=a["local_id"] or
                mapping["assistant_local_id"]!=b["local_id"] or
                mapping["assistant_observed_at_utc"]!=receipt["assistant_observed_complete_at_utc"]):
                raise StageSFailure("Hosted index source mapping changed")
            remote=self.api.attachment(self.store(),mapping["file_id"])
            if not remote or remote.get("status")!="completed":
                raise StageSFailure("Hosted attachment status changed")
        return {"indexed_turns":upto,"sql_original_messages":2*upto,
                "assistant_replies_real_ui_observed":upto,
                "assistant_original_send_timestamps_unattested":upto,
                "native_simulated_user_send_timestamps":upto}

    def search(self,query: str, *, top:int=10):
        if not isinstance(query,str) or not query.strip() or not 1<=top<=10:
            raise StageSFailure("Invalid hosted semantic search request")
        result=self.api.search(self.store(),query,max_results=top)
        if not isinstance(result,dict) or not isinstance(result.get("data"),list):
            raise StageSFailure("Malformed hosted search result envelope")
        out=[]
        seen_files=set()
        for candidate in result["data"]:
            if not isinstance(candidate,dict) or type(candidate.get("file_id")) is not str:
                raise StageSFailure("Malformed hosted search candidate")
            file_id=candidate["file_id"]
            if not file_id:
                raise StageSFailure("Missing hosted source file ID")
            # Several overlapping vector chunks can refer to the same canonical
            # pair. Deduplicate before the U/W gateway's strict turn validator.
            if file_id in seen_files:
                continue
            seen_files.add(file_id)
            with sqlite3.connect(self.db) as sql:
                sql.row_factory=sqlite3.Row
                mapping=sql.execute("SELECT * FROM native_s_files WHERE file_id=? AND completed=1",
                                    (file_id,)).fetchone()
            if mapping is None: raise StageSFailure("Unknown hosted file candidate")
            pair=[]
            for key in ("user_local_id","assistant_local_id"):
                exact=self.archive.fetch(mapping[key],neighbours=0)
                if exact is None: raise StageSFailure("Missing SQL packet for hosted file")
                pair.append(exact)
            receipt=self._receipt(mapping["turn_index"])
            originals=[Archive._validate(x) for x in self._messages(mapping["turn_index"],receipt)]
            if any(any(p[k]!=v for k,v in orig.items())
                   for p,orig in zip(pair,originals)):
                raise StageSFailure("Canonical SQL candidate differs from native capture")
            out.append({"turn":mapping["turn_index"],"score":candidate.get("score"),
                        "original_packets":pair})
        return out
