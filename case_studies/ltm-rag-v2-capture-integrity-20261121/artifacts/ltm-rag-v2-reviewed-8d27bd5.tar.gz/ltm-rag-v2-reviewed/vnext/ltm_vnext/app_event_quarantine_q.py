"""Stage Q: quarantine synthetic native app-only results before any source scope.

This adapter does NOT authenticate the ChatGPT user, transport, app frame,
session metadata or any original message. There is deliberately no imported
archive, resolver, Stage L gateway, credential, native listener or release API.

An independently owned application controller could later use Stage L's
separate confirmation port. A native app-only result alone must never be
interpreted as that separate authorisation.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

TOPIC_IDS = frozenset({
    "merrow_prism", "vela_case", "qev_tensile",
    "ora_pier", "sova_container",
})
BASE_KEYS = frozenset({
    "schema_version", "synthetic_only", "status", "source_packets",
    "source_count", "original_user_text_attested",
    "human_consent_attested", "client_metadata_not_authorisation",
})
OPTIONAL_KEYS = frozenset({"selected_topic", "message"})
STATUS_NOT_CONFIRMED = frozenset({
    "DENIED", "EXPIRED", "AWAITING_CONFIRMATION",
})
TRANSPORT_ONLY = "CLIENT_APP_CALLBACK_UNAUTHENTICATED_NO_OWNER_GRANT"


class AppEventQuarantineQ:
    """Pure fail-closed interpretation of M's *untrusted* public envelope.

    No instance state, source handle or owner approval mechanism is held here.
    The status of a syntactically valid, non-model-confirmed app event is only
    an observational classification; not a proof that a human clicked.
    """

    @staticmethod
    def _public(status: str) -> dict[str, Any]:
        return {
            "schema_version": 1,
            "synthetic_only": True,
            "status": status,
            "trust_boundary": TRANSPORT_ONLY,
            "source_packets": [],
            "source_count": 0,
            "owner_authorised": False,
            "original_user_text_attested": False,
            "human_consent_attested": False,
        }

    @classmethod
    def observe_app_result(cls, result: object) -> dict[str, Any]:
        """Quarantine even a real-looking CONFIRMED callback.

        It cannot grant source access. Reject extra or false provenance fields
        rather than allowing a future schema expansion to silently promote an
        unsigned event into a privileged owner grant.
        """
        if not isinstance(result, Mapping):
            return cls._public("INVALID_APP_EVENT")
        keys = frozenset(result)
        if not BASE_KEYS.issubset(keys) or not keys.issubset(BASE_KEYS | OPTIONAL_KEYS):
            return cls._public("INVALID_APP_EVENT")
        if (type(result["schema_version"]) is not int or
            result["schema_version"] != 1 or
            result["synthetic_only"] is not True or
            type(result["source_packets"]) is not list or
            result["source_packets"] != [] or
            type(result["source_count"]) is not int or
            result["source_count"] != 0 or
            result["original_user_text_attested"] is not False or
            result["human_consent_attested"] is not False or
            result["client_metadata_not_authorisation"] is not True):
            return cls._public("INVALID_APP_EVENT")

        status = result["status"]
        if type(status) is not str:
            return cls._public("INVALID_APP_EVENT")
        if "message" in result and (
            type(result["message"]) is not str or
            result["message"] != "Select one invented topic using the optional synthetic UI."
        ):
            return cls._public("INVALID_APP_EVENT")
        if status == "CONFIRMED":
            if (result.get("selected_topic") not in TOPIC_IDS or
                type(result.get("selected_topic")) is not str or
                "message" in result):
                return cls._public("INVALID_APP_EVENT")
            return cls._public("QUARANTINED_APP_EVENT")
        if status in STATUS_NOT_CONFIRMED and "selected_topic" not in result:
            return cls._public("NOT_CONFIRMED_APP_EVENT")
        return cls._public("INVALID_APP_EVENT")

    @classmethod
    def model_source_attempt(cls, *_model_arguments: object,
                             **_model_keywords: object) -> dict[str, Any]:
        """No trusted owner ingress: model arguments can never fetch records."""
        return cls._public("UNTRUSTED_NO_SOURCE_SCOPE")
