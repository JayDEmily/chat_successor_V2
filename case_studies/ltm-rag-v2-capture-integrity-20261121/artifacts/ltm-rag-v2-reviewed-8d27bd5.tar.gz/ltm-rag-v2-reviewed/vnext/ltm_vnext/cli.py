"""Local CLI; synthetic fixtures only; no network calls."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from .archive import Archive


def main() -> None:
    parser = argparse.ArgumentParser(description="LTM-RAG vNext synthetic proof")
    parser.add_argument("--db", type=Path, required=True)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("init")
    seed = commands.add_parser("seed")
    seed.add_argument("fixture", type=Path)
    lookup = commands.add_parser("lookup")
    lookup.add_argument("query")
    fetch = commands.add_parser("fetch")
    fetch.add_argument("local_id")
    args = parser.parse_args()
    if args.command == "init":
        Archive.initialise(args.db)
        result = {"initialised": str(args.db)}
    else:
        archive = Archive(args.db)
        if args.command == "seed":
            result = archive.ingest_synthetic(args.fixture)
        elif args.command == "lookup":
            result = archive.lookup(args.query)
        else:
            result = archive.fetch(args.local_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
