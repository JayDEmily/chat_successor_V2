# Shadow embedding experiment: frozen synthetic Holdout C

The method was registered in SHADOW_EMBEDDING_EXPERIMENT_20261118.md
before running the local model. Holdout C was already inspected in a prior
FTS5 baseline, therefore these results are EXPLORATORY, not independent validation.

Model: BAAI/bge-small-en-v1.5 (FastEmbed 0.9.1 / ONNXRuntime 1.32.0, CPU 2 threads).
No external model inference calls; model cache and dependencies are Git-ignored.
Fixture SHA-256: 9bd02d60c7f8f49c71a9d4483b96868f5e7be3b5a556415563f9c7c23382b966
Probe SHA-256: 1171de1a3be92a7a3a59d6b5f25164fe06517b8ddf87ca7c9971cf1f2318d6c2

| Method | Explicit recall@8 | Explicit first | Implicit recall@8 | Implicit first |
|---|---:|---:|---:|---:|
| FTS5 | 8/8 | 4/8 | 6/8 | 1/8 |
| DENSE_RAW | 8/8 | 7/8 | 8/8 | 4/8 |
| DENSE_CHAIN | 8/8 | 7/8 | 8/8 | 4/8 |
| HYBRID_RRF | 8/8 | 7/8 | 7/8 | 4/8 |

| Probe | Target | FTS5 rank | Raw rank | Chain rank | Hybrid rank |
|---|---|---:|---:|---:|---:|
| E01 | c03 | 2 | 1 | 1 | 1 |
| I01 | c03 | 7 | 8 | 4 | 6 |
| E02 | c07 | 1 | 1 | 1 | 1 |
| I02 | c07 | 2 | 1 | 1 | 1 |
| E03 | c10 | 2 | 1 | 1 | 1 |
| I03 | c10 | MISS | 1 | 1 | MISS |
| E04 | c13 | 2 | 2 | 2 | 2 |
| I04 | c13 | 3 | 2 | 2 | 1 |
| E05 | c17 | 1 | 1 | 1 | 1 |
| I05 | c17 | 5 | 3 | 2 | 1 |
| E06 | c20 | 1 | 1 | 1 | 1 |
| I06 | c20 | MISS | 1 | 1 | 5 |
| E07 | c23 | 2 | 1 | 1 | 1 |
| I07 | c23 | 1 | 1 | 1 | 1 |
| E08 | c26 | 1 | 1 | 1 | 1 |
| I08 | c26 | 7 | 5 | 2 | 2 |

## Local model file SHA-256 manifest

| File | Bytes | SHA-256 |
|---|---:|---|
| models--Qdrant--bge-small-en-v1.5-onnx-Q/files_metadata.json | 723 | 8faf435b671bd2675c082edaf8a37f0fafb4482f16579dd8f26015fa40129e71 |
| models--Qdrant--bge-small-en-v1.5-onnx-Q/snapshots/aa8f8b060edb00e03bfdd08813a2949946c8ba55/config.json | 706 | 13582bcf2effc85b7bf3d3f5532e686bc1c9ce86bb009d10f0ec33cbe92299dd |
| models--Qdrant--bge-small-en-v1.5-onnx-Q/snapshots/aa8f8b060edb00e03bfdd08813a2949946c8ba55/model_optimized.onnx | 66465124 | 51f1bd0addd6e859e42c2c8021a5e5461385bb676a649f4b269aa445449f2431 |
| models--Qdrant--bge-small-en-v1.5-onnx-Q/snapshots/aa8f8b060edb00e03bfdd08813a2949946c8ba55/special_tokens_map.json | 695 | 5d5b662e421ea9fac075174bb0688ee0d9431699900b90662acd44b2a350503a |
| models--Qdrant--bge-small-en-v1.5-onnx-Q/snapshots/aa8f8b060edb00e03bfdd08813a2949946c8ba55/tokenizer.json | 711396 | d241a60d5e8f04cc1b2b3e9ef7a4921b27bf526d9f6050ab90f9267a1f9e5c66 |
| models--Qdrant--bge-small-en-v1.5-onnx-Q/snapshots/aa8f8b060edb00e03bfdd08813a2949946c8ba55/tokenizer_config.json | 1242 | 0b29c7bfc889e53b36d9dd3e686dd4300f6525110eaa98c76a5dafceb2029f53 |
| models--Qdrant--bge-small-en-v1.5-onnx-Q/trees/aa8f8b060edb00e03bfdd08813a2949946c8ba55.json | 1156 | 4da434babbdfea1afb640c0792caf42f224e06c1cfc4fb152f7b3d27ed6f23c3 |

## Boundaries

Each method ranks distinct original message identities; no branch or corrected
source was rewritten. Dense chain text uses only the record's own same-branch
superseded original and is for candidate scoring, not source evidence.
The frozen registered corrected message ID alone constitutes a hit.
These scores do not establish ChatGPT automatic invocation, source-text
quotation accuracy, robust selectivity, privacy, or generalisation.
The live six-message SQLite MCP archive and its tunnel were not changed.
A new unseen holdout is necessary before choosing a method for live integration.
