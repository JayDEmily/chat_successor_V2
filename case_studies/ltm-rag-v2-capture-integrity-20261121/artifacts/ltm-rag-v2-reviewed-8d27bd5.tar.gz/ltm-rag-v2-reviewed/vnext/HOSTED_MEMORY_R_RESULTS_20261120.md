# Stage R — OpenAI-hosted fictional conversation-memory integration

**Pilot uses synthetic scripted exchanges only. No real ChatGPT dialogue was captured or generated.**

- Preregistration: `97b5c691c81862e782d32978bf33e56b15517ba5`, direct parent `b9589cc5c7af7432c12e6e0450f3fc860872e029`; all three frozen Git blobs and fixture SHA-256 independently verified before implementation.
- One isolated OpenAI Vector Store in the newly created API project; 30-day last-active expiry. Store/file identifiers and user-provided API key are not published; project key is read only from owner-only Ubuntu `.env`.
- Each of 12 fictional consecutive exchanges was uploaded as one immutable text file after appending its user and scripted assistant messages separately to SQLite: **24 original source messages, 12 indexed files**.
- All exact source texts, content hashes, stable message/version IDs, distinct author roles, correction links, source locators and branch identities are resolved from local SQLite, never from the hosted search snippet.
- Hosted result file IDs must match the private SQLite mapping; unknown IDs, tampering or unexpected source roles fail closed. Search results are *candidates*, not endorsed answers, actual user-message attestation or relevance probabilities.

## Frozen semantic-search measurements

| Case | Indexed turns at query | Expected source turn(s) | First matching rank | Top-five |
|---|---:|---|---:|---|
| R01 | 8 | 2 | 1 | PASS |
| R02 | 8 | 8 | 1 | PASS |
| R03 | 12 | 9 | 1 | PASS |
| R04 | 12 | 11 | 1 | PASS |
| R05 | 12 | 4 | 1 | PASS |
| R06 | 12 | 10 | 1 | PASS |

**Frozen search-quality top-five result: 6/6.** Unsuccessful matches, if any, are not redefined or re-queried to improve the score.
**Remote/store readback:** 12 completed indexed turns, 24 intact SQLite records, 12 hosted completed files; read-only verification PASS.

## Scope and technical limitations

- OpenAI Vector Stores handled automated chunking, embedding and indexing; the internal embedding dimensions/model are **not asserted** to be `text-embedding-3-large`. No explicit Embeddings API request was made.
- A fixed scripted fixture is not ChatGPT's real generative output. No ChatGPT native UI send, conversation export, on-turn capture hook, production archive or GPT model inference was used.
- This validates file-ID mapping and candidate retrieval, not longitudinal memory relevance on real people, referent disambiguation, complete capture from native ChatGPT or authenticated owner consent.
- Existing original/G/I/K/M/P services, tunnels, keys and native six-event audit were left unchanged. Hosted files remain isolated synthetic records subject to the 30-day last-active expiration.

## Chronology readback following SQLite timestamp amendment

After the chronology schema was added, a separate read-only auditor rechecked the **actual pilot SQLite database and its original remote-index mapping**. `scripts/audit_hosted_memory_r_chronology.py` returned `PASS_R_SQLITE_CHRONOLOGY_AND_HOSTED_MAPPING_READBACK`:

- **24/24** exact original fictional SQLite message records have UTC `ingested_at_utc` values, retaining the first captured instant on replay. All 12 user messages and 12 scripted assistant responses have their distinct role, immutable source ID, correction links and sequence position.
- **0/24** have independently verified original `message_sent_at_source`/`message_sent_at_utc` because the frozen scripted source did not contain reliable sending metadata. These are **NULL, not inferred** from indexing/ingestion time. This is a known limitation, not a failed timestamp write.
- `event_time`/`time_precision` remain a separate description of *when the underlying event occurred*. Original per-branch `position` preserves chronology even if a source timestamp is missing, duplicated or clock-skewed.
- The read-only mapping and frozen private query ledger independently reconcile all **12 hosted file identities**, exact paired SQL source IDs, and all six frozen query results; six source targets appeared first. Hosted API independent verification returned **12 completed files / 24 original messages**. No hosted search rerun was used to improve reported ranks.
- Existing **six** native M/N/O/P audit records remained unchanged. Core regression **207/207**, separate shadow suite **40/40** and nine focused chronology tests passed.

The additive [chronology schema and migration contract](STAGE_R_CHRONOLOGY_AMENDMENT_20261120.md) was separately published at Git commit `970125b05de0767a403fc6bee62b188beac67f12`. The original frozen R case matrix, fixture and prerun registration remain byte-identical. No real-history capture or genuine ChatGPT generated assistant responses were demonstrated.
