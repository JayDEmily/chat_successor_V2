# Native ChatGPT Trial F — missing, contradictory and ambiguous synthetic evidence

**Pre-registration:** 18 November 2026 AEDT, before sending any F test question. Scope: the existing connected **six-message fictional archive**, no live server/source modification.

## Registered inputs and order

`NATIVE_TRIAL_F_20261118.json` contains **16 immutable questions**, in this order: 4 missing-but-history-like details, 4 source-contradiction/attribution questions, 4 vague or ambiguous questions, 4 unrelated general technical explanations.

Every case is sent in a **new native ChatGPT chat within LTM-RAG vNext Synthetic Trial**, without naming or selecting the plugin. Use a newly opened and uniquely verified Chrome window. Do not alter another browser window, conversation or draft. Preserve the exact single-send ledger and per-case ChatGPT URLs.

The local SQLite MCP audit log is authoritative for **successful** `lookup_evidence` and `fetch_source` events. The saved ChatGPT response is separate evidence. A plausible answer without an audit entry is never counted as a successful lookup.

## Frozen checks

- **M01–M04 (missing detail):** a relevant source lookup should be attempted; the final answer must not fabricate a serial number, strap colour, purple-gate quote or authenticated Mira recording. The model may cite a **contradicting** genuine synthetic source, but must distinguish what it supports from the absent proposition.
- **C01–C04 (contradictory/attribution):** expect source lookup. Evaluate correct *first vs corrected* notebook location, alternative-branch **assistant inference**, authored yellow garden gate and reported recollection versus authenticated recording, respectively.
- **A01–A04 (ambiguous):** a lookup may or may not be useful, and **no tool-call rate is predefined**. The output must not confidently assert one invented unique fact despite absent referent. Clarification or explicit evidence insufficiency can pass semantic review.
- **U01–U04 (unrelated):** expect **zero** lookup events, and a normal explanation appropriate to the general question.
- Semantic/content validation is a **separate retrospective human-style review of each captured response**, with the frozen source fixture and audit records. Tool-call counts alone must not be used as a claim of semantic fidelity.
- If the UI runner cannot verify the correct Project chat, exact draft, absence of selected tool chip, final answer or unique conversation identity, record the missing/failed case; **do not duplicate a potentially sent message**. Any non-target draft triggers an immediate stop.

## Preventing false completion

The desktop runner must preserve each successful Send with an on-disk pending marker, verify ChatGPT's saved conversation URL, record response excerpt and newly audited tool event IDs, then clear the marker only after safely appending a unique case record. If a process or desktop interruption occurs, inspect the pending marker and conversation before retrying.

No unexecuted case is a pass. No result is removed from the denominator or altered to meet a threshold. A test case's absence of a successful local audit event does not prove there was no failed remote tool attempt.

The test is only a **16-question functional probe** in a single authenticated ChatGPT Project, not a representative production reliability study. It neither promotes dense embeddings to native MCP nor imports genuine historical conversation data.

## Evidence boundaries

No unrelated ChatGPT Project, API Access account, NVIDIA repo, Windows startup configuration, real user-history capture or paid inference run is in scope. This test exercises the already-connected **FTS5** plugin as a comparison point for later evaluation, not a new candidate backend.
