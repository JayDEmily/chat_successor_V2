# Referent Gate H — decision and next authority boundary

**19 November 2026. Decision: ACCEPT_SHADOW_REFERENT_SELECTION_ONLY.**

The separate read-only H auditor independently compared the complete 38-case JSON, five-topic source manifest and governing protocol to Git preregistration commit 2e1535e40d0a9770037d7c47a8e5ba780402d247 before scoring. Original synthetic G fixture SHA-256 is e3531da9538eb40dc41bec43f29c089f7aed7525ee574e84d21e469fabf9dcbf.

## Result

- **38/38** frozen cases correct: **16 UNIQUE, 16 UNANCHORED, 4 MULTIPLE, 2 EVIDENCE_MISMATCH**. All expected topics were identical. The exact G13/G14 prompts now return UNANCHORED even when misleading single-source candidates are supplied.
- The selector requires named opaque identifiers or aliases evidenced in original main-branch user messages; assistant-only alternative branches cannot create authority. It preserves multi-topic comparisons rather than promoting rank 1 to a unique identity.
- Explicitly anchored questions with absent matching candidate evidence return EVIDENCE_MISMATCH rather than inventing a retrieved source.
- **22/22** new unit tests passed, covering all 38 cases plus invalid types, untrusted/duplicate aliases, cross-conversation sources, assistant-only branch claims, fixture hash mismatch, corrupt records, substring collisions and candidate ordering. Together with the preceding 79 tests this is **101/101 core**. Existing separate shadow suite remains **40/40 passing**.
- Read-only code under ltm_vnext/referent_gate.py and independent verifier scripts/audit_referent_gate_h.py are NOT imported by the original live mcp_server.py.

## Boundaries

This is **not an end-to-end native ChatGPT gate**, not a universal intent classifier and not an accepted relevance threshold. The known five-topic manifest and frozen 38 synthetic prompts cannot establish performance on real queries, unseen aliases, implicit follow-up context or translated references. In particular, UNANCHORED only means there is **no explicit supported topic in that question**, not that the question is unrelated to history; the consumer must first separately determine intent. Genuine same-chat follow-ups require an authenticated context binding rather than guessing from other Project chats.

No new native messages were sent in this stage. Both existing read-only MCP servers and tunnels retain their original 8787/8788 addresses and unchanged tool contracts. No real-history ingestion, external inference API calls, boot persistence or deployment of raw dense/cosine gating occurred.

## Next independently bounded stage

Design and preregister a **native synthetic decision-support contract** before any new connector or native test. Specify exactly how an assistant obtains the topic evidence, how it responds to UNANCHORED without forcing unrelated queries to clarify, how it handles genuine same-chat follow-up links, and how retrieval/source-fetch is audited. Preserve Trial F/G historical outcomes.

Separately, the current lookup_evidence tool already includes the exact source text, SHA-256, locator, authorship and neighbouring dialogue. Zero additional fetch_source calls in Trial G is a true trace result, but **not inherently absent source bytes**. A two-stage fetch requirement is an architecture choice requiring its own versioned interface and pre-registered test, not something to infer from a zero fetch count.

**Advance condition:** No claim that G13/G14 are fixed in native ChatGPT until a new, separately registered, connected native test actually demonstrates it. Shadow H does not grant authority to change either existing connector.
