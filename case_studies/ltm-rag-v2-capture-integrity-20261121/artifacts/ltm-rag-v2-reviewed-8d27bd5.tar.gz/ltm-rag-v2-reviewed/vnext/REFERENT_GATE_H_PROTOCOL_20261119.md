# Referent Gate H — pre-registered synthetic-only decision experiment

**Registration:** 19 November 2026, before implementing or running the proposed gate. This is a new, bounded offline decision stage **after** the completed native Trial G. It does not re-score G01–G16.

## Motivation and exact deficiency

Trial G's G13 and G14 supplied no unique fictional conversation identity. The native assistant nevertheless looked up evidence and confidently chose Merrow for both. The actual Merrow facts were accurate; the **referent selection was unsupported**. FTS5 ranking, a successful MCP call, exact source bytes and one Project's previous messages do not prove which topic the user intended.

## Scope and experimental contract

This experiment guards **unique narrative selection for an already history-dependent question**. The upstream classification of historical intent is **out of scope**; a technical/unrelated question with no explicit anchor returns UNANCHORED, not an assertion that history search is unnecessary.

The static, synthetic-only topic manifest in `REFERENT_GATE_H_MANIFEST_20261119.json` contains five distinct conversation IDs. Each permitted case-insensitive anchor must occur verbatim in the **original main-branch user** evidence message from `fixtures/synthetic_clean_g.json`, with the exact source ID, original UTF-8 and stable authorship verified on load. Speculative alternative assistant messages cannot introduce an authoritative topic alias. No machine-learned relevance threshold or inferred synonym is used.

The frozen `REFERENT_GATE_H_CASES_20261119.json` contains exactly **38** cases. Its expected status and conversation IDs are reference labels for independent verification, **not inputs to the runtime resolver**. The protocol is not a demonstration of unseen-topic generalisation.

Expected decisions:
- **UNIQUE:** exactly one source conversation explicitly anchored in the current question and, when candidate conversations are supplied, at least one matching candidate exists.
- **UNANCHORED:** no evidence-backed anchor in the current question. A ranked result, a previous unrelated Project conversation, or a single returned candidate must not turn this into a unique referent. For history-dependent questions the caller should ask which record is meant; for unrelated input the caller can answer normally without calling history retrieval.
- **MULTIPLE:** two or more different explicitly anchored conversations. Never silently reduce them to one by retrieval rank. A caller can process all explicit referents for a genuine comparison; this gate itself only denies unjustified *unique* selection.
- **EVIDENCE_MISMATCH:** exactly one explicitly anchored topic, but the optional candidate set does not contain that topic. Do not silently substitute an irrelevant retrieved topic; the caller must re-query or disclose insufficient evidence.

## Registered coverage

Five opaque identifier cases, five explicit name/speaker cases, three cross-topic comparisons, five vague questions (including the **exact G13/G14 prompts**), five adversarial retrieval-candidate traps, two missing/wrong candidate conflicts, one mixed candidate inclusion, four false substring matches, two alternative-branch questions, two reported-speech questions, two unrelated negative controls, one multi-topic candidate trap and one valid explicit candidate case.

All runtime candidates are **unverified retrieval candidates**, never referent truth. Returned selection permits downstream *source assessment*, not factual proof. Branch, version, correction, reported speaker and authentication must still be checked using original source packets.

## Preregistered acceptance and fail-closed requirements

- **38/38** identical status and topic identity against the locked case file, with no per-case special rules in production code.
- Anchor-map load rejects invented/duplicated aliases, assistant-only sources, cross-conversation aliases, missing/changed original source text, changed fixture SHA-256, duplicate topic IDs and any non-synthetic corpus.
- Invalid candidate types or unknown conversation identities are rejected; candidate order cannot alter decisions.
- Unanchored questions must remain UNANCHORED even when the only retrieval hit points to one record; explicit anchored questions with missing candidate identities must become EVIDENCE_MISMATCH.
- All existing core and shadow regression tests must still pass. No native MCP or tunnel change, no native ChatGPT sends, no genuine conversation history, no external model inference, no Windows/Ubuntu automatic startup change.
- Each Git checkpoint and final report requires remote branch SHA/tree/parent verification and GitHub file readback. Record any discrepancy rather than weakening validation.

**Limitation:** This is a conservative fixture-bound referent gate, not a generally solved natural-language coreference system. It does not resolve legitimate implicit follow-ups from trusted same-chat context; that requires a separate authenticated-context contract and tests. It is not authorised for live native deployment by a local PASS.
