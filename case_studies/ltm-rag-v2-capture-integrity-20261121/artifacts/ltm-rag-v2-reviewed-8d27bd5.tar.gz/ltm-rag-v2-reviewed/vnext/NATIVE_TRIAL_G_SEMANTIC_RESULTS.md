# Trial G — retrospective original-source semantic review

This review separately inspected all 16 saved native answers against the
original 20-record fictional G archive, its authorship, branch IDs,
correction edges and reported-speech source labels. A separate script
validated source-ID membership, review markers, complete records and
the entire local successful MCP event ledger. Marker checks alone
are not a proof of semantic correctness.

**14/16** semantically acceptable responses; **2/16** unsupported
referent selection failures (G13/G14).
Source-dependent G01–G12: **12/12** acceptable main conclusions and
**12/12** with successful G lookup initiation.
Unrelated G15–G16: **2/2** technically adequate without G lookup.
Recorded successful calls: **15 lookups**,
**0 separate fetch_source calls**.

| Case | Source/content judgement | Lookup | Supporting fictional source IDs |
|---|---|---:|---|
| G01 | PASS_SOURCE_FIDELITY | 1 | g03, g01 |
| G02 | PASS_SOURCE_FIDELITY | 1 | g11, g09 |
| G03 | PASS_SOURCE_FIDELITY | 1 | g15, g13 |
| G04 | PASS_SOURCE_FIDELITY | 1 | g19, g17 |
| G05 | PASS_SOURCE_FIDELITY | 1 | g01 |
| G06 | PASS_SOURCE_FIDELITY | 1 | g09 |
| G07 | PASS_SOURCE_FIDELITY | 1 | g16, g15 |
| G08 | PASS_SOURCE_FIDELITY | 1 | g20, g19 |
| G09 | PASS_SOURCE_FIDELITY | 1 | g05, g07 |
| G10 | PASS_SOURCE_FIDELITY | 1 | g05, g06, g07 |
| G11 | PASS_ABSTENTION | 2 | g17, g19 |
| G12 | PASS_ABSTENTION | 1 | g05, g07 |
| G13 | FAIL_UNSUPPORTED_REFERENT | 1 | g03 |
| G14 | FAIL_UNSUPPORTED_REFERENT | 1 | g01, g03 |
| G15 | PASS_UNRELATED | 0 | none |
| G16 | PASS_UNRELATED | 0 | none |

## Specific findings and limitations

**G01 first clean turn:** The answer selected locker 9 and the cobalt
optic, attributed it to main-branch user correction g03, included its
stable fixture locator and distinguished it from superseded g01.
The server's separate source-byte/hash smoke test passed. Native G01
had one successful source lookup but no separate source fetch.
G01's saved result predates the runner prompt-hash enhancement; the
first Send was preceded by frozen-prompt UI verification.

**Correction/branch authenticity:** G02–G08 preserved the original,
corrected and alternative-branch identities. The alternative pier 7
and red cabinet statements were correctly identified as assistant
speculation rather than user corrections.

**Reported speech:** G09 reproduced both Vela recollections consistent
with g05/g07. G10 correctly refused to infer authenticated audio
from user-reported recollection and the assistant's archive description.
G11/G12 invented neither a SOVA serial number nor a Vela audio file.

**Ambiguous referents:** G13 and G14 confidently assumed the Merrow
narrative, although neither question identified a narrative.
Both made a successful lookup, but a retrieval result cannot establish
which narrative the user meant. This is a semantic FAIL, not a
missed tool-call failure.

**Causal and completeness limits:** Only G01 ran in a previously
chat-empty Project. G02–G16 may use prior conversations within
that same Project even though its settings were read back as
Project-only. All native history-needed cases did invoke the new
source lookup, but no native G case invoked the separate fetch_source
tool. Successful lookup responses can contain source text and
metadata; absence of an explicit fetch should not be disguised.
These 16 synthetic cases do not establish population reliability.
No real conversation history, original MCP configuration, or
Windows/Ubuntu automatic startup was changed.

The local complete answer ledger and tool audit remain Git-ignored.
Saved Project conversations are linked in NATIVE_TRIAL_G_TRACE_RESULTS.md.
