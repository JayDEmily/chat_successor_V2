# Stage J — independent shadow trusted-turn-binding audit

**Result: 26/26 preregistered cases PASS.** The conditional
in-process owner-ingress fixture prevents model-augmented
historical referent arguments from releasing fictional sources.
This is **NOT** proof that a native ChatGPT MCP can receive a
host-authenticated current user message.

## Frozen inputs and provenance

- Registration commit: `0628a238a6f2bf80323cc9c58bfa53f6a670e059`, exact parent
  `d83695fb4a10944311eaa7bd9c7a919521abc5de`.
- Both preregistered documents were independently compared byte-for-byte
  against their committed Git blobs before case results were accepted.
- 20-message fictional original fixture SHA-256: `e3531da9538eb40dc41bec43f29c089f7aed7525ee574e84d21e469fabf9dcbf`.
- Every returned source packet matched original UTF-8 text, SHA-256,
  locator, author, branch, reported speaker and source identity.
- No live MCP transport, tunnel, connected plugin, native ChatGPT
  message or external inference endpoint was used.

## Frozen case outcomes

| Outcome | Count |
|---|---:|
| MODEL_ARGUMENT_MISMATCH | 9 |
| MULTIPLE | 2 |
| NO_BOUND_TURN | 5 |
| UNANCHORED | 5 |
| UNIQUE | 5 |

| Frozen case | Class | Result | Original source IDs |
|---|---|---|---|
| J01 | I05 original exact | UNANCHORED | none |
| J02 | I05 injected ORA | MODEL_ARGUMENT_MISMATCH | none |
| J03 | I15 original exact | UNANCHORED | none |
| J04 | I15 injected Vela | MODEL_ARGUMENT_MISMATCH | none |
| J05 | I01 original exact | UNANCHORED | none |
| J06 | I11 original exact | UNANCHORED | none |
| J07 | corrected Merrow | UNIQUE | g01, g02, g03, g04 |
| J08 | Merrow answer expanded with SOVA | MODEL_ARGUMENT_MISMATCH | none |
| J09 | Merrow answer replaced with ORA | MODEL_ARGUMENT_MISMATCH | none |
| J10 | QEV corrected | UNIQUE | g09, g10, g11, g12 |
| J11 | ORA corrected | UNIQUE | g13, g14, g15, g16 |
| J12 | Vela reported | UNIQUE | g05, g06, g07, g08 |
| J13 | SOVA corrected | UNIQUE | g17, g18, g19, g20 |
| J14 | two histories | MULTIPLE | g01, g02, g03, g04, g17, g18, g19, g20 |
| J15 | three histories | MULTIPLE | g01, g02, g03, g04, g09, g10, g11, g12, g13, g14, g15, g16 |
| J16 | unrelated exact | UNANCHORED | none |
| J17 | unrelated injected history | MODEL_ARGUMENT_MISMATCH | none |
| J18 | wrong session | NO_BOUND_TURN | none |
| J19 | wrong user | NO_BOUND_TURN | none |
| J20 | wrong turn | NO_BOUND_TURN | none |
| J21 | unregistered | NO_BOUND_TURN | none |
| J22 | missing caller context | NO_BOUND_TURN | none |
| J23 | spoofed session in tool text | MODEL_ARGUMENT_MISMATCH | none |
| J24 | changed case in tool text | MODEL_ARGUMENT_MISMATCH | none |
| J25 | added whitespace | MODEL_ARGUMENT_MISMATCH | none |
| J26 | tool text missing | MODEL_ARGUMENT_MISMATCH | none |

## Security interpretation

1. I05/I15 could not be promoted through a model-injected ORA-62
   or Vela name. Exact model-question mismatch produced no source
   packet, as did a missing/wrong out-of-band session/turn context.
2. A trusted, exact original user message did permit ordinary
   source lookup (when it explicitly named its topic). Source
   authorship and correction semantics remained those of the
   original I resolver.
3. The owner-registration method in this proof is an in-process
   harness operation **not exposed as an MCP tool**. The test
   assumes the caller already holds genuinely authenticated
   user input. The Python method's existence is not an
   authentication scheme and the test does not supply one.
4. The documented `_meta['openai/session']` is an anonymised
   **conversation** identifier for correlation, not a copy
   of the user's prompt, a per-turn authentication token,
   or by itself an access-control credential.
5. If the native ChatGPT host cannot send original user text
   independently of model-authored arguments, this gateway
   cannot be securely connected without a separate owned
   front end, a documented host interface or an explicit
   user-side confirmation mechanism. Neither has been
   verified in native ChatGPT by this experiment.

## Official source links, reviewed 19 November 2026

- MCP model-selected arguments: https://developers.openai.com/plugins/concepts/mcp-server
- ChatGPT-supplied metadata (session/subject): https://developers.openai.com/plugins/reference
- Server auth, elicitation and annotations: https://developers.openai.com/plugins/build/mcp-server
- Remote MCP does not automatically receive conversation: https://developers.openai.com/api/docs/guides/realtime-mcp
- Owning application can supply `role=user` item: https://developers.openai.com/api/docs/guides/migrate-to-responses
- Application guardrails: https://developers.openai.com/api/docs/guides/agents/guardrails-approvals
- Don't pull full conversation as workaround: https://developers.openai.com/plugins/guides/security-privacy

**Decision: PASS_SHADOW_TRUSTED_INGRESS_CONDITIONAL_ONLY.**
**Native message authentication remains unverified.**
