"""Offline negative tests for the independent semantic-review evidence validator."""
from __future__ import annotations
import copy
import json
import unittest
from unittest import mock

from scripts import verify_native_trial_f_semantics as v


class NativeFSemanticReviewTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.plan=json.loads(v.PLAN.read_text(encoding="utf8"))
        cls.review=json.loads(v.REVIEW.read_text(encoding="utf8"))
        cls.fixture=json.loads(v.FIXTURE.read_text(encoding="utf8"))

    def setUp(self):
        self.review_copy=copy.deepcopy(self.review)
        self.fake_records=[]
        for i,r in enumerate(self.review_copy["reviewed_cases"],start=1):
            snippet=" ".join(r["required_answer_markers"])
            self.fake_records.append({
                "id":r["id"],
                "answer_excerpt":"Saved synthetic answer context: "+snippet+" END",
                "lookup_count":0,"fetch_count":0,
            })
        self.patch=mock.patch.object(v,"analyse",return_value={
            "complete":True,"pending_send_marker_exists":False,
            "counts":{"lookup_calls":0,"fetch_calls":0}
        })
        self.patch.start()
        self.addCleanup(self.patch.stop)

    def check(self):
        return v.verify(self.plan,self.fake_records,[],self.review_copy,self.fixture)

    def test_valid_16_case_review_and_fixture(self):
        rows,trace=self.check()
        self.assertEqual(len(rows),16)
        self.assertEqual(rows[0]["id"],"M01")
        self.assertEqual(rows[-1]["id"],"U04")

    def test_missing_observed_marker_is_rejected(self):
        self.fake_records[0]["answer_excerpt"]="Saved synthetic answer context absent all required details"
        with self.assertRaisesRegex(ValueError,"markers not visible"):
            self.check()

    def test_unknown_source_message_is_rejected(self):
        self.review_copy["reviewed_cases"][0]["source_ids"]=["unregistered_message"]
        with self.assertRaisesRegex(ValueError,"Unknown original source"):
            self.check()

    def test_reordered_review_is_rejected(self):
        a=self.review_copy["reviewed_cases"]
        a[0],a[1]=a[1],a[0]
        with self.assertRaisesRegex(ValueError,"ordering differs"):
            self.check()

    def test_duplicate_review_identity_is_rejected(self):
        self.review_copy["reviewed_cases"][1]["id"]=self.review_copy["reviewed_cases"][0]["id"]
        with self.assertRaisesRegex(ValueError,"Duplicate grade"):
            self.check()

    def test_inconsistent_ambiguity_verdict_rejected(self):
        item=next(r for r in self.review_copy["reviewed_cases"] if r["id"]=="A01")
        item["verdict"]="CONSISTENT_WITH_FIXTURE"
        with self.assertRaisesRegex(ValueError,"ambiguity verdict"):
            self.check()

    def test_real_or_wrong_source_fixture_rejected(self):
        corrupted=copy.deepcopy(self.fixture)
        corrupted["synthetic"]=False
        with self.assertRaisesRegex(ValueError,"Original fixture"):
            v.verify(self.plan,self.fake_records,[],self.review_copy,corrupted)

    def test_truncated_saved_answer_rejected(self):
        self.fake_records[0]["answer_excerpt"]="a"*2500
        with self.assertRaisesRegex(ValueError,"clipped"):
            self.check()


if __name__=="__main__":
    unittest.main()
