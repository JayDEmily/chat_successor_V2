"""Stage S offline integration with fake provider, no model or external calls."""
from __future__ import annotations
import json
import sqlite3
import tempfile
import unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path

from ltm_vnext.native_dialogue_s import (
 NativeSyntheticS, StageSFailure, STORE_NAME, SOURCE, _private_write
)
from ltm_vnext.archive import Archive,InvalidFixture,RecordConflict


class FakeHosted:
    def __init__(self):
        self.one_store=None
        self.file_data={}
        self.attached={}
        self.next=0
        self.uploads=0
    def stores(self):return [self.one_store] if self.one_store else []
    def json(self,method,route,payload=None):
        if method=="POST" and route=="/vector_stores":
            assert self.one_store is None
            self.one_store={"id":"vs_synthetic_s","name":STORE_NAME,
                "expires_after":{"anchor":"last_active_at","days":30},
                "metadata":{"synthetic_only":"true","scope":"ltm-rag-vnext-s"}}
            return self.one_store
        raise RuntimeError("Unexpected fake provider API route")
    def retrieve_store(self,store_id):
        return {**self.one_store,"file_counts":{
            "total":len(self.attached),
            "completed":len(self.attached)}}
    def files(self):
        return [{"id":fid,"filename":file["filename"]}
                for fid,file in self.file_data.items()]
    def upload_file(self,filename,content):
        self.next+=1;self.uploads+=1
        fid="file-stage-s-"+str(self.next)
        self.file_data[fid]={"filename":filename,"bytes":content}
        return {"id":fid}
    def attachment(self,store,file_id):
        return self.attached.get(file_id)
    def attach(self,store,file_id,attrs):
        self.attached[file_id]={"file_id":file_id,"status":"completed",
                               "attributes":attrs.copy()}
        return self.attached[file_id]
    def search(self,store,query,max_results=10):
        return {"data":[{"file_id":fid,"score":0.75}
                         for fid in list(self.attached)[:max_results]]}


class NativeDialogueSOffline(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.p=Path(self.tmp.name)/"s"
        self.fake=FakeHosted()
        self.app=NativeSyntheticS(self.fake,private=self.p)
        self.assertTrue(self.app.store(allow_create=True).startswith("vs_"))
        self.plan=self.app.plan

    def make_capture(self,turn,*,content=None):
        prompt=self.plan["case_messages"][turn-1]["simulated_user_text"]
        sent=(datetime(2026,11,20,9,0,tzinfo=timezone.utc)
               +timedelta(seconds=60*turn)).isoformat()
        done=(datetime.fromisoformat(sent)+timedelta(seconds=8)).isoformat()
        row={"synthetic_only":True,"turn":turn,
             "case_id":self.plan["case_messages"][turn-1]["id"],
             "simulated_user_text":prompt,
             "assistant_observed_text":content or f"Native ChatGPT test reply for {turn}.",
             "assistant_generated_by":"native_chatgpt",
             "capture_method":"native_windows_ui_automation",
             "real_user_authorship_attested":False,
             "ui_send_at_utc":sent,
             "assistant_observed_complete_at_utc":done,
             "chat_url":"chatgpt.com/c/isolated-fictitious-test-chat"}
        _private_write(self.p/f"captured_{turn:02d}.json",row)
        return row

    def test_all_five_pairwise_index_and_verify(self):
        for n in range(1,6):
            self.make_capture(n)
            result=self.app.index_turn(n)
            self.assertTrue(result["indexed"])
            self.assertEqual(self.app.verify(upto=n)["sql_original_messages"],2*n)
        self.assertEqual(self.fake.uploads,5)
        with sqlite3.connect(self.app.db) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM messages").fetchone()[0],10)
            self.assertEqual(db.execute("SELECT count(ingested_at_utc) FROM messages").fetchone()[0],10)
            self.assertEqual(db.execute("SELECT count(message_sent_at_utc) FROM messages").fetchone()[0],5)
            self.assertEqual(db.execute("SELECT count(*) FROM native_s_files WHERE completed=1").fetchone()[0],5)
            self.assertEqual(
                db.execute("SELECT group_concat(capture_method) FROM messages").fetchone()[0].count("synthetic_native_ui"),10)
        hits=self.app.search("fictional question")
        self.assertEqual(len(hits),5)
        self.assertEqual(hits[0]["turn"],1)
        self.assertEqual([p["author_role"] for p in hits[0]["original_packets"]],
                         ["user","assistant"])

    def test_same_turn_replay_keeps_original_ingestion_time_and_zero_upload(self):
        self.make_capture(1)
        self.app.index_turn(1)
        with sqlite3.connect(self.app.db) as sql:
            before=list(sql.execute("SELECT ingested_at_utc FROM messages ORDER BY position"))
        self.app.index_turn(1)
        with sqlite3.connect(self.app.db) as sql:
            after=list(sql.execute("SELECT ingested_at_utc FROM messages ORDER BY position"))
        self.assertEqual(before,after)
        self.assertEqual(self.fake.uploads,1)

    def test_changed_assistant_response_rejected_on_replay(self):
        self.make_capture(1)
        self.app.index_turn(1)
        self.make_capture(1,content="Tampered model output")
        with self.assertRaises(StageSFailure):
            self.app.index_turn(1)
        self.assertEqual(self.fake.uploads,1)

    def test_unindexed_prior_turn_blocks_later_send_index(self):
        self.make_capture(2)
        with self.assertRaises(StageSFailure):
            self.app.index_turn(2)
        self.assertEqual(self.fake.uploads,0)

    def test_unknown_hosted_file_never_yields_original_text(self):
        self.make_capture(1)
        self.app.index_turn(1)
        self.fake.attached["file-external-fake"]={
            "file_id":"file-external-fake","status":"completed","attributes":{}}
        self.fake.search=lambda *args,**kwargs:{"data":[{"file_id":"file-external-fake"}]}
        with self.assertRaises(StageSFailure):
            self.app.search("fake source")

    def test_duplicate_vector_chunks_are_one_original_pair(self):
        self.make_capture(1)
        self.app.index_turn(1)
        file_id=next(iter(self.fake.attached))
        self.fake.search=lambda *args, **kwargs: {"data": [
            {"file_id":file_id,"score":0.96},
            {"file_id":file_id,"score":0.92},
        ]}
        rows=self.app.search("fictional repeated chunks")
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]["turn"],1)
        self.assertEqual(rows[0]["score"],0.96)

    def test_malformed_hosted_search_envelope_is_rejected(self):
        self.make_capture(1)
        self.app.index_turn(1)
        self.fake.search=lambda *args, **kwargs: {"invalid":True}
        with self.assertRaises(StageSFailure):
            self.app.search("fictional candidate")

    def test_real_archive_import_still_denied(self):
        item=self.app._messages(1,self.make_capture(1))[0]
        wrong=dict(item,capture_method="chatgpt_export")
        with self.assertRaises(InvalidFixture):
            Archive._validate(wrong)
        wrong=dict(item,synthetic_only=False)
        with self.assertRaises(InvalidFixture):
            Archive._validate(wrong)

    def test_invalid_capture_authorship_provenance_denied(self):
        row=self.make_capture(1)
        row["real_user_authorship_attested"]=True
        _private_write(self.p/"captured_01.json",row)
        with self.assertRaises(StageSFailure):
            self.app.index_turn(1)

    def test_unknown_assistant_source_time_is_not_invented(self):
        self.make_capture(1)
        self.app.index_turn(1)
        with sqlite3.connect(self.app.db) as sql:
            results=list(sql.execute("SELECT author_role,message_sent_at_utc,ingested_at_utc FROM messages ORDER BY position"))
        self.assertEqual([r[0] for r in results],["user","assistant"])
        self.assertIsNotNone(results[0][1])
        self.assertIsNone(results[1][1])
        self.assertTrue(all(r[2] for r in results))


if __name__=="__main__":
    unittest.main()
