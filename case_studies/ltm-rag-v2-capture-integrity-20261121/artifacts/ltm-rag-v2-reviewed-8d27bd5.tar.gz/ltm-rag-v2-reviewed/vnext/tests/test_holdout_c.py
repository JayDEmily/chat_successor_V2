"""Offline regression tests for frozen, multi-topic synthetic holdout C."""
from __future__ import annotations
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from ltm_vnext.archive import Archive
from scripts import run_holdout_c as benchmark


class HoldoutCTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.fixture = json.loads(benchmark.FIXTURE.read_text(encoding="utf-8"))
        cls.probes = json.loads(benchmark.PROBES.read_text(encoding="utf-8"))

    def test_registration_and_synthetic_metadata(self) -> None:
        benchmark.validate(self.fixture, self.probes)
        self.assertEqual(len(self.fixture["messages"]), 26)
        self.assertEqual(len(self.probes["probes"]), 16)
        self.assertEqual({p["kind"] for p in self.probes["probes"]}, {"explicit", "implicit"})

    def test_corrected_messages_link_originals(self) -> None:
        corrected = [m for m in self.fixture["messages"] if "supersedes" in m]
        self.assertEqual(len(corrected), 8)
        self.assertEqual(len({m["conversation_id"] for m in corrected}), 8)
        source_ids = {m["message_id"] for m in self.fixture["messages"]}
        for m in corrected:
            self.assertIn(m["supersedes"]["message_id"], source_ids)

    def test_alternative_branch_cannot_leak_into_neighbours(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            archive = Archive.initialise(Path(tmp) / "holdout.sqlite")
            archive.ingest_synthetic(benchmark.FIXTURE)
            c03 = next(r for r in archive.lookup("sextant", 20)["hits"]
                       if r["message_id"] == "c03")
            self.assertEqual(c03["branch_id"], "main")
            neighbouring = [archive.fetch(n["local_id"]) for n in c03["neighbouring_dialogue"]]
            self.assertTrue(all(n["branch_id"] == "main" for n in neighbouring))
            self.assertNotIn("c04", [n["message_id"] for n in neighbouring])

    def test_source_hashes_and_untouched_unicode(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            archive = Archive.initialise(Path(tmp) / "holdout.sqlite")
            archive.ingest_synthetic(benchmark.FIXTURE)
            packet = archive.lookup("Arden", 20)
            c03 = next(m for m in packet["hits"] if m["message_id"] == "c03")
            self.assertIn("—", c03["exact_text"])
            self.assertEqual(
                c03["content_sha256"],
                hashlib.sha256(c03["exact_text"].encode("utf-8")).hexdigest(),
            )
            self.assertEqual(c03["attribution"], "reported_recollection")
            self.assertEqual(c03["reported_speaker"], "Arden")

    def test_disposable_lexical_baseline_non_regression(self) -> None:
        rows = benchmark.run(self.fixture, self.probes)
        self.assertEqual(len(rows), 16)
        explicit_hits = sum(r["recall_at_8"] for r in rows if r["kind"] == "explicit")
        implicit_hits = sum(r["recall_at_8"] for r in rows if r["kind"] == "implicit")
        self.assertEqual(explicit_hits, 8)
        self.assertGreaterEqual(implicit_hits, 6)
        self.assertTrue(all(r["candidate_count"] <= 8 for r in rows))

    def test_frozen_probe_target_change_rejected(self) -> None:
        modified = json.loads(json.dumps(self.probes))
        modified["probes"][0]["expected_message_id"] = "c01"
        with self.assertRaisesRegex(ValueError, "target correction"):
            benchmark.validate(self.fixture, modified)

    def test_non_synthetic_capture_rejected(self) -> None:
        modified = json.loads(json.dumps(self.fixture))
        modified["messages"][4]["capture_method"] = "personal_chat_export"
        with self.assertRaisesRegex(ValueError, "Non-synthetic"):
            benchmark.validate(modified, self.probes)

    def test_missing_case_rejected(self) -> None:
        modified = json.loads(json.dumps(self.probes))
        modified["probes"].pop()
        with self.assertRaisesRegex(ValueError, "16 frozen"):
            benchmark.validate(self.fixture, modified)

    def test_no_source_is_returned_as_a_false_success(self) -> None:
        # A candidate other than the registered exact message does not satisfy recall@8.
        sample = {"expected_message_id": "c10"}
        observed = ["c08", "c09", "c11"]
        rank = observed.index(sample["expected_message_id"]) + 1 if sample["expected_message_id"] in observed else None
        self.assertIsNone(rank)


if __name__ == "__main__":
    unittest.main()
