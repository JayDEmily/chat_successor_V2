"""Verify the existing-key launch boundary without accessing real credentials."""
import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "tunnel_using_existing_key.py"
SPEC = importlib.util.spec_from_file_location("tunnel_using_existing_key", SCRIPT)
runner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(runner)


class ExistingProjectKeyRunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.key_file = self.root / ".env"
        self.key_file.write_text("OPENAI_API_KEY='synthetic-test-only-value'\n")
        self.binary = self.root / "tunnel-client"
        self.binary.touch()
        self.profile_dir = self.root / "profiles"
        self.profile_dir.mkdir()

    def test_exactly_one_existing_project_key(self):
        with patch.object(runner, "ENV_FILE", self.key_file):
            self.assertEqual(runner.project_key(), "synthetic-test-only-value")
            self.key_file.write_text("OPENAI_API_KEY=one\nOPENAI_API_KEY=two\n")
            with self.assertRaisesRegex(ValueError, "Exactly one"):
                runner.project_key()

    def test_admin_key_excluded_and_no_key_on_command_line(self):
        captured = []

        def capture(binary, arguments, environment):
            captured.append((binary, arguments, environment))

        with (
            patch.object(runner, "ENV_FILE", self.key_file),
            patch.object(runner, "BINARY", self.binary),
            patch.object(runner, "PROFILE_DIR", self.profile_dir),
            patch.object(sys, "argv", ["tunnel_using_existing_key.py", "run"]),
            patch.dict(os.environ, {
                "OPENAI_ADMIN_KEY": "synthetic-admin-do-not-forward",
                "OPENAI_API_KEY": "synthetic-other-project-key",
            }),
            patch.object(runner.os, "execve", side_effect=capture),
        ):
            runner.main()
        self.assertEqual(len(captured), 1)
        binary, args, env = captured[0]
        self.assertEqual(binary, self.binary)
        self.assertEqual(args[1], "run")
        self.assertEqual(env["CONTROL_PLANE_API_KEY"], "synthetic-test-only-value")
        self.assertNotIn("OPENAI_API_KEY", env)
        self.assertNotIn("OPENAI_ADMIN_KEY", env)
        self.assertNotIn("synthetic-test-only-value", str(args))

    def test_doctor_does_not_expose_key_on_command_line(self):
        args = []
        with (
            patch.object(runner, "ENV_FILE", self.key_file),
            patch.object(runner, "BINARY", self.binary),
            patch.object(runner, "PROFILE_DIR", self.profile_dir),
            patch.object(sys, "argv", ["tunnel_using_existing_key.py", "doctor"]),
            patch.object(runner.os, "execve",
                         side_effect=lambda binary, arguments, env: args.extend(arguments)),
        ):
            runner.main()
        self.assertIn("--json", args)
        self.assertIn("--explain", args)
        self.assertNotIn("synthetic-test-only-value", " ".join(map(str, args)))


if __name__ == "__main__":
    unittest.main()
