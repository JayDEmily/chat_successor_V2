"""Offline Trial G fixture, correction, and bounded tunnel-admin tests."""
from __future__ import annotations
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from ltm_vnext.archive import Archive, _local_id
from scripts import smoke_trial_g_http as g
from scripts import trial_g_tunnel_admin as admin


class TrialGIsolationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = g.check_fixture()
        cls.records = {x["message_id"]: x for x in cls.data["messages"]}
        cls.plan = json.loads(g.PLAN.read_text(encoding="utf-8"))

    def test_registered_first_turn_and_four_synthetic_categories(self):
        self.assertEqual(self.plan["project_id"], "g-p-6afd806ca9348191accae58eea37c74c")
        self.assertEqual(self.plan["cases"][0]["id"], "G01")
        self.assertEqual(len(self.plan["cases"]), 16)
        self.assertEqual(len(self.records), 20)

    def test_correction_edges_never_cross_source_or_branch(self):
        corrections = [m for m in self.records.values() if m.get("supersedes")]
        self.assertEqual(len(corrections), 5)
        for corrected in corrections:
            prior = self.records[corrected["supersedes"]["message_id"]]
            self.assertEqual(corrected["source_id"], prior["source_id"])
            self.assertEqual(corrected["branch_id"], prior["branch_id"])
            self.assertEqual(corrected["conversation_id"], prior["conversation_id"])
            self.assertEqual(corrected["author_role"], "user")

    def test_alternative_branches_are_assistant_inference(self):
        alternatives = [m for m in self.records.values() if m["branch_id"] == "alternative"]
        self.assertEqual(len(alternatives), 5)
        self.assertTrue(all(m["author_role"] == "assistant" and
                            m["attribution"] == "assistant_inference" for m in alternatives))

    def test_reported_speech_is_not_mislabelled_authenticated_audio(self):
        self.assertEqual(self.records["g05"]["reported_speaker"], "Vela")
        self.assertEqual(self.records["g07"]["reported_speaker"], "Vela")
        self.assertEqual(self.records["g05"]["attribution"], "reported_recollection")
        self.assertEqual(self.records["g07"]["attribution"], "reported_recollection")
        self.assertIn("\u201cThe TERN-91 folio is in the eastern drawer.\u201d",
                      self.records["g07"]["exact_text"])

    def test_disposable_sqlite_hashes_and_branch_local_neighbours(self):
        with tempfile.TemporaryDirectory(prefix="ltm-g-test-") as path:
            db = Archive.initialise(Path(path) / "fixture.sqlite")
            self.assertEqual(db.ingest_synthetic(g.FIXTURE), {"inserted":20,"total":20})
            hits = db.lookup("ULN-4827 Merrow",limit=12)["hits"]
            amended = next(m for m in hits if m["message_id"] == "g03")
            self.assertEqual(amended["content_sha256"],
                             hashlib.sha256(amended["exact_text"].encode("utf-8")).hexdigest())
            self.assertEqual(amended["supersedes_local_id"],
                             _local_id("synthetic-clean-g","g01","1"))
            self.assertNotIn(
                _local_id("synthetic-clean-g","g04","1"),
                [m["local_id"] for m in amended["neighbouring_dialogue"]])

    def test_unknown_or_non_synthetic_records_not_in_fixture(self):
        self.assertTrue(all(m["capture_method"] == "synthetic_fixture"
                            for m in self.records.values()))
        self.assertNotIn("synthetic-v1", {m["source_id"] for m in self.records.values()})

    def test_admin_key_parser_can_use_existing_env_without_printing_value(self):
        with tempfile.TemporaryDirectory() as temp:
            fake = Path(temp) / ".env"
            fake.write_text("OPENAI_API_KEY='test-project'\nOPENAI_ADMIN_KEY=\"test-admin\"\n",
                            encoding="utf-8")
            with mock.patch.object(admin, "ENV_FILE", fake):
                self.assertEqual(admin.read_key("OPENAI_ADMIN_KEY"), "test-admin")
                self.assertEqual(admin.read_key("OPENAI_API_KEY"), "test-project")

    def test_admin_duplicate_remote_name_prevents_creation(self):
        with mock.patch.object(admin, "RECEIPT", Path("/impossible/nonexistent/trial-g.json")), \
             mock.patch.object(admin, "tunnels", return_value=[{"id":"tunnel_existing",
                                                                "name":admin.NAME}]), \
             mock.patch.object(admin, "call") as invoke:
            with self.assertRaisesRegex(RuntimeError, "already exists"):
                admin.create()
            invoke.assert_not_called()


if __name__ == "__main__":
    unittest.main()
