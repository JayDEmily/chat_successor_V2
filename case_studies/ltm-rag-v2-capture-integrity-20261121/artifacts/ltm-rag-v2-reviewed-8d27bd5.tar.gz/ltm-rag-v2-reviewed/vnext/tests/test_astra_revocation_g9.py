"""Astra G9: synthetic-only revocation, suppression and recovery regression."""
from __future__ import annotations

import sqlite3
import tempfile
import unittest
from pathlib import Path

from ltm_vnext.capture_foundation_v import (
    SyntheticCaptureLedger, CaptureBoundaryError, CaptureConflict,
)


class RevocationG9Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="astra-g9-")
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "synthetic.sqlite"
        self.db = SyntheticCaptureLedger.initialise(self.path)

    def message(self, n=1, *, branch="main", msg=None, version="1",
                position=None, text=None, correction=None):
        value = {
            "synthetic_only": True, "source_id": "synthetic-capture-g9",
            "conversation_id": "fictional-g9", "branch_id": branch,
            "message_id": msg or f"g9-{n:02d}", "version_id": version,
            "position": n if position is None else position,
            "author_role": "user",
            "source_locator": f"synthetic-capture://g9/{branch}/{n}",
            "capture_method": "synthetic_ui_observation",
            "exact_text": text or f"Entirely fictional statement {n}",
        }
        if correction is not None:
            value["supersedes"] = correction
        return value

    def snapshot(self, branch="main"):
        return self.db.snapshot("synthetic-capture-g9", "fictional-g9", branch)

    def insert(self, source):
        self.db.ingest([source])
        return self.snapshot(source["branch_id"])["originals"][-1]["local_id"]

    def test_pending_original_is_immediately_suppressed(self):
        original = self.message()
        local_id = self.insert(original)
        event = self.db.revoke(local_id, "synthetic owner scope withdrawn")
        self.assertEqual(event["remote_cleanup"], "NOT_REQUIRED")
        result = self.snapshot()
        self.assertEqual(result["originals"], [])
        self.assertEqual(result["outbox"], [])
        self.assertEqual(result["coverage"][0]["state"], "REVOKED")
        self.assertEqual(result["revoked_count"], 1)
        self.assertEqual(result["remote_cleanup_pending_count"], 0)
        with self.assertRaises(CaptureBoundaryError):
            self.db.reserve_index(local_id)
        self.assertEqual(self.db.ingest([original])["inserted"], 0)
        self.assertEqual(self.db.revocation_status(local_id), event)
        self.assertEqual(self.snapshot()["originals"], [])

    def test_inflight_upload_remains_cleanup_required_after_revocation(self):
        local_id = self.insert(self.message())
        ticket = self.db.reserve_index(local_id)
        self.db.revoke(local_id, "synthetic revoke during upload")
        report = self.snapshot()
        self.assertEqual(report["remote_cleanup_pending_count"], 1)
        self.assertEqual(self.db.revocation_status(local_id)["remote_cleanup"], "REQUIRED")
        with self.assertRaises(CaptureBoundaryError):
            self.db.acknowledge_index(local_id, ticket["payload_sha256"], "file-late")
        with self.assertRaises(CaptureBoundaryError):
            self.db.remote_confirmed_absent(local_id, "synthetic missing")
        with self.assertRaises(CaptureBoundaryError):
            self.db.reserve_index(local_id)
        self.assertEqual(self.snapshot()["outbox"], [])

    def test_remote_file_arriving_after_revoke_stays_blocked(self):
        local_id = self.insert(self.message())
        ticket = self.db.reserve_index(local_id)
        self.db.revoke(local_id, "synthetic race")
        self.db.record_revoked_remote_identity(
            local_id, "file-late", "synthetic-file-listing-evidence",
        )
        with self.assertRaises(CaptureBoundaryError):
            self.db.acknowledge_index(local_id, ticket["payload_sha256"], "file-late")
        state = self.db.revocation_status(local_id)
        self.assertEqual(state["remote_cleanup"], "REQUIRED")
        self.assertEqual(state["remote_file_id"], "file-late")
        self.assertEqual(state["remote_identity_ref"],
                         "synthetic-file-listing-evidence")
        with self.assertRaises(CaptureConflict):
            self.db.record_revoked_remote_identity(local_id, "file-other", "proof")
        self.assertEqual(self.snapshot()["remote_cleanup_pending_count"], 1)

    def test_local_remote_deletion_receipt_never_claims_verified_cleanup(self):
        local_id = self.insert(self.message())
        ticket = self.db.reserve_index(local_id)
        self.db.acknowledge_index(local_id, ticket["payload_sha256"], "file-known")
        self.db.revoke(local_id, "synthetic source withdrawn")
        self.assertEqual(self.db.revocation_status(local_id)["remote_file_id"],
                         "file-known")
        with self.assertRaises(CaptureConflict):
            self.db.record_remote_delete_evidence(local_id, "file-wrong", "receipt")
        self.db.record_remote_delete_evidence(local_id, "file-known",
                                              "external-report-not-verified")
        self.assertEqual(self.db.revocation_status(local_id)["remote_cleanup"],
                         "EVIDENCE_LOGGED")
        self.assertEqual(self.db.revocation_status(local_id)["remote_delete_ref"],
                         "external-report-not-verified")
        self.assertEqual(self.snapshot()["remote_cleanup_pending_count"], 1)
        self.assertEqual(self.snapshot()["originals"], [])
        self.db.record_remote_delete_evidence(local_id, "file-known",
                                              "external-report-not-verified")
        with self.assertRaises(CaptureConflict):
            self.db.record_remote_delete_evidence(local_id, "file-known",
                                                  "different-report")

    def test_immutable_revoke_reason_and_invalid_target(self):
        with self.assertRaises(CaptureBoundaryError):
            self.db.revoke("no-record", "synthetic test")
        local_id = self.insert(self.message())
        with self.assertRaises(CaptureBoundaryError):
            self.db.revoke(local_id, "")
        self.db.revoke(local_id, "original reason")
        with self.assertRaises(CaptureConflict):
            self.db.revoke(local_id, "changed reason")
        with self.assertRaises(CaptureBoundaryError):
            self.db.record_remote_delete_evidence(local_id, "file-absent", "anything")

    def test_verified_source_refused_once_revoked(self):
        original = self.message(text="Original Unicode statement — 'not a quote'")
        local_id = self.insert(original)
        self.db.revoke(local_id, "revoke")
        with self.assertRaises(CaptureBoundaryError):
            self.db.verify_synthetic(local_id, original["exact_text"].encode(),
                                     "new-external-source")
        self.assertEqual(self.snapshot()["originals"], [])

    def test_correction_from_revoked_original_does_not_leak_predecessor(self):
        earlier = self.message(1, text="Earlier synthetic arrangement")
        first = self.insert(earlier)
        correction = self.message(
            2, text="Corrected synthetic arrangement",
            correction={"message_id": earlier["message_id"], "version_id": "1"},
        )
        later = self.insert(correction)
        self.db.revoke(first, "suppress old version")
        result = self.snapshot()
        self.assertEqual(len(result["originals"]), 1)
        visible = result["originals"][0]
        self.assertEqual(visible["local_id"], later)
        self.assertIsNone(visible["supersedes_local_id"])
        self.assertTrue(visible["predecessor_redacted"])
        self.assertEqual(result["corrected_by"], {later: []})
        self.assertEqual([x["state"] for x in result["coverage"]],
                         ["REVOKED", "OBSERVED"])
        successor = self.message(
            3, correction={"message_id": earlier["message_id"], "version_id": "1"},
        )
        with self.assertRaises(CaptureBoundaryError):
            self.db.ingest([successor])

    def test_other_branches_unchanged(self):
        main = self.insert(self.message(1, branch="main"))
        self.insert(self.message(1, branch="alternative", msg="g9-alt-01"))
        self.db.revoke(main, "only main")
        self.assertEqual(self.snapshot("main")["originals"], [])
        self.assertEqual(len(self.snapshot("alternative")["originals"]), 1)

    def test_edit_same_position_not_marked_revoked_if_version_visible(self):
        original = self.message(1, msg="editable", version="1")
        original_id = self.insert(original)
        revised = self.message(1, msg="editable", version="2",
                               text="Revised synthetic statement",
                               correction={"message_id": "editable", "version_id": "1"})
        newer_id = self.insert(revised)
        self.db.revoke(original_id, "old edited version hidden")
        readback = self.snapshot()
        self.assertEqual(len(readback["originals"]), 1)
        self.assertEqual(readback["originals"][0]["local_id"], newer_id)
        self.assertEqual(readback["coverage"][0]["state"], "OBSERVED")
        self.assertTrue(readback["originals"][0]["predecessor_redacted"])
        self.assertEqual(readback["revoked_count"], 1)

    def test_local_restore_preserves_suppression_and_no_reindex(self):
        original = self.message(1)
        local_id = self.insert(original)
        self.db.reserve_index(local_id)
        before = self.db.revoke(local_id, "persisted revocation")
        backup = Path(self.temp.name) / "restored.sqlite"
        with sqlite3.connect(self.path) as original_db, sqlite3.connect(backup) as target_db:
            original_db.backup(target_db)
        reopened = SyntheticCaptureLedger(backup)
        self.assertEqual(reopened.revocation_status(local_id), before)
        self.assertEqual(reopened.ingest([original])["inserted"], 0)
        self.assertEqual(reopened.snapshot("synthetic-capture-g9","fictional-g9","main")["originals"],[])
        with self.assertRaises(CaptureBoundaryError):
            reopened.reserve_index(local_id)

    def test_original_is_retained_only_in_private_db_for_audit(self):
        local_id = self.insert(self.message())
        self.db.revoke(local_id, "synthetic proof")
        with sqlite3.connect(self.path) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM originals").fetchone()[0], 1)
            self.assertEqual(db.execute("SELECT COUNT(*) FROM tombstones").fetchone()[0], 1)
        self.assertEqual(self.snapshot()["originals"], [])


if __name__ == "__main__":
    unittest.main()
