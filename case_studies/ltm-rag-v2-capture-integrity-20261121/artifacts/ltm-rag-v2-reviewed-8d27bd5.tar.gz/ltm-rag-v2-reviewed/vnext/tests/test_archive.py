"""Synthetic-only tests; no API calls, legacy integration or personal data."""
import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from ltm_vnext.archive import Archive, InvalidFixture, RecordConflict

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "fixtures" / "synthetic_conversations.json"


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Path(self.tmp.name) / "memory.sqlite"
        self.archive = Archive.initialise(self.db)
        self.items = json.loads(FIXTURE.read_text(encoding="utf-8"))

    def fixture(self, data):
        path = Path(self.tmp.name) / "fixture.json"
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        return path

    def seeded(self):
        self.archive.ingest_synthetic(FIXTURE)
        return self.archive

    def test_synthetic_marker_required(self):
        data = copy.deepcopy(self.items)
        data.pop("synthetic")
        with self.assertRaises(InvalidFixture):
            self.archive.ingest_synthetic(self.fixture(data))

    def test_non_synthetic_capture_rejected_atomically(self):
        data = copy.deepcopy(self.items)
        data["messages"][2]["capture_method"] = "chatgpt_export"
        with self.assertRaises(InvalidFixture):
            self.archive.ingest_synthetic(self.fixture(data))
        self.assertEqual(self.archive.lookup("notebook")["count"], 0)

    def test_exact_unicode_and_sha256(self):
        self.seeded()
        m1 = next(x for x in self.archive.lookup("train")["hits"]
                  if x["message_id"] == "m1")
        self.assertIn("“", m1["exact_text"])
        self.assertEqual(m1["content_sha256"],
                         hashlib.sha256(m1["exact_text"].encode()).hexdigest())
        self.assertEqual(m1["fidelity"], "synthetic_only")

    def test_reimport_idempotence(self):
        self.assertEqual(self.archive.ingest_synthetic(FIXTURE)["inserted"], 6)
        self.assertEqual(self.archive.ingest_synthetic(FIXTURE)["inserted"], 0)

    def test_conflicting_message_identity_rejected(self):
        self.seeded()
        data = copy.deepcopy(self.items)
        data["messages"][0]["exact_text"] = "Different text, identical identity."
        with self.assertRaises(RecordConflict):
            self.archive.ingest_synthetic(self.fixture(data))

    def test_same_text_distinct_identity_preserved(self):
        data = copy.deepcopy(self.items)
        additional = copy.deepcopy(data["messages"][0])
        additional.update(message_id="m7", position=9,
                          source_locator="fixture://notebook/m7")
        data["messages"].append(additional)
        self.archive.ingest_synthetic(self.fixture(data))
        hits = [x for x in self.archive.lookup("train")["hits"]
                if x["message_id"] in {"m1", "m7"}]
        self.assertEqual(len(hits), 2)
        self.assertNotEqual(hits[0]["local_id"], hits[1]["local_id"])

    def test_correction_preserves_original(self):
        self.seeded()
        m1 = next(x for x in self.archive.lookup("train")["hits"]
                  if x["message_id"] == "m1")
        corrected = self.archive.fetch(m1["corrected_by"][0])
        self.assertEqual(corrected["supersedes_local_id"], m1["local_id"])
        self.assertIn("library", corrected["exact_text"])
        self.assertIn("train", m1["exact_text"])

    def test_reported_speaker_not_original_author(self):
        self.seeded()
        m1 = next(x for x in self.archive.lookup("train")["hits"]
                  if x["message_id"] == "m1")
        self.assertEqual(m1["author_role"], "user")
        self.assertEqual(m1["reported_speaker"], "Mira")
        self.assertEqual(m1["attribution"], "reported_recollection")
        self.assertIn("not an independently", m1["evidence_warning"])

    def test_context_does_not_cross_branches(self):
        self.seeded()
        m1 = next(x for x in self.archive.lookup("train")["hits"]
                  if x["message_id"] == "m1")
        nearby = m1["neighbouring_dialogue"]
        self.assertEqual(len(nearby), 1)
        self.assertEqual(nearby[0]["exact_text"],
                         self.items["messages"][1]["exact_text"])

    def test_query_metacharacters_not_executable(self):
        self.seeded()
        self.assertGreater(self.archive.lookup('blue" OR * }')["count"], 0)

    def test_empty_and_unmatched_queries(self):
        self.seeded()
        self.assertEqual(self.archive.lookup('"...')['count'], 0)
        self.assertEqual(self.archive.lookup('zqzqzunmatched123')['count'], 0)

    def test_invalid_limits_and_radius(self):
        self.seeded()
        for number in (0, 21):
            with self.assertRaises(ValueError):
                self.archive.lookup("blue", number)
        with self.assertRaises(ValueError):
            self.archive.fetch("does-not-matter", neighbours=5)

    def test_invalid_correction_rolls_back_whole_import(self):
        data = copy.deepcopy(self.items)
        data["messages"][2]["supersedes"]["message_id"] = "missing"
        with self.assertRaises(InvalidFixture):
            self.archive.ingest_synthetic(self.fixture(data))
        self.assertEqual(self.archive.lookup("blue")["count"], 0)

    def test_cross_branch_correction_rejected_atomically(self):
        data = copy.deepcopy(self.items)
        # The source report is on main; a correction in alternative must not
        # silently supersede a main-branch statement.
        data["messages"][2]["branch_id"] = "alternative"
        with self.assertRaisesRegex(InvalidFixture, "branch"):
            self.archive.ingest_synthetic(self.fixture(data))
        self.assertEqual(self.archive.lookup("notebook")["count"], 0)

    def test_missing_fetch_is_none(self):
        self.seeded()
        self.assertIsNone(self.archive.fetch("missing"))

    def test_uninitialised_database_rejected(self):
        with self.assertRaises(FileNotFoundError):
            Archive(Path(self.tmp.name) / "absent.sqlite")


if __name__ == "__main__":
    unittest.main()
