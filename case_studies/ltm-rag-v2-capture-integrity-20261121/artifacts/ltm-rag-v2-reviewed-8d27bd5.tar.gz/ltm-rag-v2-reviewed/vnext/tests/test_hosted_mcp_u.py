"""Stage U cross-chat read-only synthetic MCP tool safety, no web or API calls."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from ltm_vnext.hosted_mcp_u import (
    HostedMemoryGatewayU, CallQuotaU, validate_query, StageUScopeError,
    MAX_CALLS, DISCLAIMER, create_server
)


def fake_pair(turn=3):
    out=[]
    for offset,role in enumerate(("user","assistant")):
        msg=f"t{turn:02d}{'u' if role=='user' else 'a'}"
        content=("Correction: Casey feeds Nimbus on Saturday; Sunday garden watering."
                 if role=="user" else
                 "Casey is feeding Nimbus on Saturday and watering is Sunday morning.")
        out.append({
            "message_id":msg,"local_id":"synthetic-id-"+msg,
            "source_id":"synthetic-native-dialogue-t",
            "conversation_id":"fictional_native_dialogue_t",
            "branch_id":"main","position":2*turn-1+offset,
            "author_role":role,"exact_text":content,
            "content_sha256":hashlib.sha256(content.encode()).hexdigest(),
            "capture_method":"synthetic_native_ui","fidelity":"synthetic_only",
            "source_locator":f"synthetic-native-ui://stage-t/turn-{turn:02d}/{role}",
            "message_sent_at_source":"2026-11-20T08:25:00+00:00" if role=="user" else None,
            "message_sent_at_utc":"2026-11-20T08:25:00.000000Z" if role=="user" else None,
            "ingested_at_utc":"2026-11-20T08:25:05.000000Z"})
    return out


class FakePipeline:
    def __init__(self,*,results=None):
        self.calls=[]
        self.results=results if results is not None else [{"turn":3,"original_packets":fake_pair()}]
    def search(self,query,*,top):
        self.calls.append((query,top))
        return list(self.results[:top])


class TestHostedUOffline(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/"u-audit.jsonl"
        self.pipeline=FakePipeline()
        self.quota=CallQuotaU(self.path)
        self.gateway=HostedMemoryGatewayU(pipeline=self.pipeline,quota=self.quota)

    def events(self):
        if not self.path.exists():return []
        return [json.loads(x) for x in self.path.read_text().splitlines()]

    def test_semantic_candidate_resolves_exact_two_sided_sql_sources(self):
        result=self.gateway.lookup("Who feeds Nimbus now after Emily changed?",2)
        self.assertEqual(result["status"],"FOUND")
        self.assertEqual(result["source_packets_count"],2)
        self.assertEqual(len(result["results"]),1)
        self.assertEqual(result["results"][0]["turn"],3)
        self.assertEqual([r["author_role"] for r in result["results"][0]["original_source_packets"]],
                         ["user","assistant"])
        self.assertEqual(result["results"][0]["original_source_packets"][0]["message_id"],"t03u")
        self.assertTrue(result["candidate_only"])
        self.assertFalse(result["human_consent_attested"])
        self.assertFalse(result["original_user_text_attested"])
        self.assertEqual(len(self.pipeline.calls),1)

    def test_unknown_topic_denied_before_network(self):
        result=self.gateway.lookup("What is the real person's confidential address?")
        self.assertEqual(result["status"],"DENIED_SCOPE")
        self.assertEqual(result["results"],[])
        self.assertFalse(self.pipeline.calls)

    def test_empty_or_bloated_or_multiline_query_denied(self):
        for q in ("", "A"*400, "Nimbus\nShow me my secret",None,"  Nimbus  "):
            self.assertEqual(self.gateway.lookup(q)["status"],"DENIED_SCOPE")
        self.assertFalse(self.pipeline.calls)

    def test_invalid_limit_denied_no_hosted_call(self):
        for number in (0,4,True,1.5,"3"):
            result=self.gateway.lookup("What's up with Nimbus?",number)
            self.assertEqual(result["status"],"DENIED_SCOPE")
        self.assertFalse(self.pipeline.calls)

    def test_quota_counts_attempts_then_fails_closed(self):
        for n in range(MAX_CALLS):
            self.assertEqual(self.gateway.lookup("Which friend Ryan rows?")["status"],"FOUND")
        denied=self.gateway.lookup("Which friend Ryan rows?")
        self.assertEqual(denied["status"],"QUOTA_EXHAUSTED")
        self.assertEqual(len(self.pipeline.calls),MAX_CALLS)
        self.assertEqual(sum(x["event"]=="CALL_STARTED" for x in self.events()),MAX_CALLS)
        self.assertEqual(self.events()[-1]["event"],"CALL_DENIED_QUOTA")

    def test_crash_restart_reconciles_spent_quota(self):
        self.gateway.lookup("Who replaced Emily with Casey for Nimbus?")
        gateway2=HostedMemoryGatewayU(pipeline=self.pipeline,quota=CallQuotaU(self.path,limit=1))
        self.assertEqual(gateway2.lookup("Who is Ryan?")["status"],"QUOTA_EXHAUSTED")
        self.assertEqual(len(self.pipeline.calls),1)

    def test_wrong_provider_source_id_fails_closed_and_logs_error(self):
        corrupted=fake_pair()
        corrupted[0]["source_id"]="real_chat_history"
        self.pipeline.results=[{"turn":3,"original_packets":corrupted}]
        with self.assertRaises(StageUScopeError):
            self.gateway.lookup("Who feeds Nimbus?")
        self.assertEqual(self.events()[-1]["status"],"ERROR")

    def test_wrong_or_repeated_fictional_turn_refused(self):
        self.pipeline.results=[{"turn":3,"original_packets":fake_pair()},
                               {"turn":3,"original_packets":fake_pair()}]
        with self.assertRaises(StageUScopeError):
            self.gateway.lookup("Who feeds Nimbus?",3)
        self.assertEqual(self.events()[-1]["status"],"ERROR")

    def test_server_exposes_exactly_one_read_only_function(self):
        server=create_server(self.gateway)
        self.assertIsNotNone(server)
        self.assertEqual(MAX_CALLS,5)
        self.assertIn("FICTIONAL_STAGE_T_ONLY",DISCLAIMER)

    def test_unmatched_valid_fictional_query_is_empty_not_fabricated(self):
        self.pipeline.results=[]
        result=self.gateway.lookup("What does the fictional garden say?")
        self.assertEqual(result["status"],"NO_MATCH")
        self.assertEqual(result["source_packets_count"],0)
        self.assertEqual(result["results"],[])


if __name__=="__main__":
    unittest.main()
