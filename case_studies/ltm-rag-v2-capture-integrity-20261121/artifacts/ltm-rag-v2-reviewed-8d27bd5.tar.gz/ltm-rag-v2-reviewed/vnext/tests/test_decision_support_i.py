"""Stage I, frozen synthetic offline contract + mutation-resistant source integrity."""
from __future__ import annotations

import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from ltm_vnext.archive import Archive
from ltm_vnext.decision_support_i import (
    SyntheticHistoryResolver, SourceIntegrityError, DecisionAudit
)
from ltm_vnext.referent_gate import ReferentGateError

ROOT=Path(__file__).resolve().parents[1]
FIXTURE=ROOT/"fixtures/synthetic_clean_g.json"
MANIFEST=ROOT/"REFERENT_GATE_H_MANIFEST_20261119.json"
CASES=ROOT/"NATIVE_DECISION_SUPPORT_I_20261119.json"


class DecisionIContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/"synthetic-i.sqlite"
        self.audit=Path(self.tmp.name)/"audit.jsonl"
        self.assertEqual(Archive.initialise(self.db).ingest_synthetic(FIXTURE)["inserted"],20)
        self.resolver=SyntheticHistoryResolver(self.db,FIXTURE,MANIFEST)
        self.plan=json.loads(CASES.read_text(encoding="utf-8"))

    def _tamper(self,field,value,record="g03"):
        with sqlite3.connect(self.db) as conn:
            conn.execute(f"UPDATE messages SET {field}=? WHERE message_id=?",
                         (value,record))
            conn.commit()

    def test_frozen_all_twenty_offline_decisions(self):
        self.assertEqual(self.plan["offline_case_count"],20)
        self.assertEqual(len(self.plan["offline_cases"]),20)
        self.assertEqual(self.plan["native_case_count"],16)
        self.assertEqual(len(self.plan["native_cases"]),16)
        for k,case in enumerate(self.plan["offline_cases"],1):
            with self.subTest(test=case["id"]):
                self.assertEqual(case["id"],f"I-O{k:02d}")
                d=self.resolver.resolve(case["question"])
                self.assertEqual(d["schema_version"],1)
                self.assertTrue(d["synthetic_only"])
                self.assertEqual(d["status"],case["expected_status"])
                self.assertEqual(d["action"],case["expected_action"])
                self.assertEqual(d["conversation_ids"],case["expected_topics"])
                self.assertEqual([p["message_id"] for p in d["source_packets"]],
                                 case["expected_source_message_ids"])
                self.assertEqual(d["source_count"],len(d["source_packets"]))
                if d["status"]=="UNANCHORED":
                    self.assertEqual(d["source_packets"],[])
                    self.assertEqual(d["explicit_anchor_evidence"],[])

    def test_exact_source_and_correction_edges(self):
        result=self.resolver.resolve("What does corrected ULN-4827 show?")
        rows={row["message_id"]:row for row in result["source_packets"]}
        self.assertEqual(rows["g03"]["exact_text"],
                         next(x["exact_text"] for x in
                              json.loads(FIXTURE.read_text())["messages"]
                              if x["message_id"]=="g03"))
        self.assertEqual(rows["g03"]["supersedes_local_id"],rows["g01"]["local_id"])
        self.assertIn(rows["g03"]["local_id"],rows["g01"]["corrected_by"])
        self.assertEqual(rows["g04"]["author_role"],"assistant")
        self.assertEqual(rows["g04"]["branch_id"],"alternative")
        self.assertEqual(rows["g03"]["author_role"],"user")

    def test_reported_speech_remains_user_recollection(self):
        result=self.resolver.resolve("What did Vela say?")
        rows={row["message_id"]:row for row in result["source_packets"]}
        self.assertEqual(rows["g05"]["author_role"],"user")
        self.assertEqual(rows["g05"]["reported_speaker"],"Vela")
        self.assertEqual(rows["g05"]["attribution"],"reported_recollection")
        self.assertEqual(rows["g07"]["attribution"],"reported_recollection")
        self.assertIn("not authenticated speech",result["evidence_limitations"])

    def test_unanchored_has_no_source_even_when_archive_has_ranked_hits(self):
        for prompt in ("Where did it end up in that earlier fictional record?",
                       "Was the original version first or second?",
                       "Did she actually say it?","How does thermal expansion work?"):
            with self.subTest(prompt=prompt):
                out=self.resolver.resolve(prompt)
                self.assertEqual(out["action"],"CLARIFY_IF_HISTORY_REQUEST")
                self.assertEqual(out["source_count"],0)

    def test_comparison_returns_all_8_sources_in_original_order(self):
        out=self.resolver.resolve("Compare Merrow and SOVA-88")
        self.assertEqual(out["status"],"MULTIPLE")
        self.assertEqual([x["message_id"] for x in out["source_packets"]],
                         ["g01","g02","g03","g04","g17","g18","g19","g20"])

    def test_reject_invalid_current_question(self):
        for bad in (None,"",123,[],{}):
            with self.subTest(bad=bad),self.assertRaises(ReferentGateError):
                self.resolver.resolve(bad)

    def test_revalidate_on_every_resolve(self):
        self.resolver.resolve("Merrow")
        self._tamper("exact_text","tampered fake content")
        with self.assertRaisesRegex(SourceIntegrityError,"exact_text"):
            self.resolver.resolve("Merrow")

    def test_reject_changed_author(self):
        self._tamper("author_role","assistant")
        with self.assertRaisesRegex(SourceIntegrityError,"author_role"):
            self.resolver.resolve("Merrow")

    def test_reject_changed_branch(self):
        self._tamper("branch_id","alternative")
        with self.assertRaisesRegex(SourceIntegrityError,"branch_id"):
            self.resolver.resolve("Merrow")

    def test_reject_changed_locator(self):
        self._tamper("source_locator","fixture://impostor")
        with self.assertRaisesRegex(SourceIntegrityError,"source_locator"):
            self.resolver.resolve("Merrow")

    def test_reject_changed_hash(self):
        self._tamper("content_sha256","0"*64)
        with self.assertRaisesRegex(SourceIntegrityError,"content_sha256"):
            self.resolver.resolve("Merrow")

    def test_reject_changed_correction_target(self):
        self._tamper("supersedes_local_id",None)
        with self.assertRaisesRegex(SourceIntegrityError,"supersedes_local_id"):
            self.resolver.resolve("Merrow")

    def test_reject_reassigned_speaker(self):
        self._tamper("reported_speaker","SomebodyElse",record="g05")
        with self.assertRaisesRegex(SourceIntegrityError,"reported_speaker"):
            self.resolver.resolve("Vela")

    def test_reject_forged_original_message_identity(self):
        self._tamper("local_id","impostor")
        with self.assertRaisesRegex(SourceIntegrityError,"source identity"):
            self.resolver.resolve("Merrow")

    def test_reject_missing_row(self):
        with sqlite3.connect(self.db) as c:
            c.execute("DELETE FROM messages WHERE message_id='g04'")
        with self.assertRaisesRegex(SourceIntegrityError,"count differs"):
            self.resolver.resolve("Merrow")

    def test_reject_extra_row(self):
        with sqlite3.connect(self.db) as c:
            c.execute("INSERT INTO messages (local_id,source_id,message_id,version_id,"
                      "conversation_id,branch_id,position,author_role,attribution,"
                      "capture_method,fidelity,source_locator,time_precision,exact_text,"
                      "content_sha256) SELECT 'impostor','synthetic-clean-g','g99',"
                      "'1','merrow_prism','main',99,'user','direct_message',"
                      "'synthetic_fixture','synthetic_only','fixture://fake','unknown',"
                      "'not actual evidence','deadbeef' FROM messages LIMIT 1")
        with self.assertRaisesRegex(SourceIntegrityError,"count differs"):
            self.resolver.resolve("Merrow")

    def test_no_logging_of_questions_or_source_text(self):
        audit=DecisionAudit(self.audit)
        audit.record(outcome="ok",source_count=4)
        item=json.loads(self.audit.read_text().strip())
        self.assertEqual(item["tool"],"resolve_history_reference")
        self.assertEqual(item["result_count"],4)
        self.assertTrue(item["synthetic_only"])
        self.assertNotIn("question",item)
        self.assertNotIn("exact_text",item)
        self.assertEqual(self.audit.stat().st_mode & 0o777,0o600)
