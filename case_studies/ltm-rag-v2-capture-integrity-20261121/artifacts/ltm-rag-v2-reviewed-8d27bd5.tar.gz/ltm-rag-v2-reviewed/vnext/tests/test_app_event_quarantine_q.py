"""Frozen 21-case Stage Q source quarantine / separate owner scope tests.

Offline synthetic only. Importing M's public envelope constructor is solely
for testing serialised result shape; no MCP server is started.
"""
from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from ltm_vnext.app_event_quarantine_q import AppEventQuarantineQ, TRANSPORT_ONLY
from ltm_vnext.mcp_apps_m import SelectorM
from ltm_vnext.archive import Archive
from ltm_vnext.clarification_l import ClarificationGatewayL, TRUST_BOUNDARY
from ltm_vnext.decision_support_i import SyntheticHistoryResolver

ROOT = Path(__file__).resolve().parents[1]
PLAN = json.loads((ROOT / "MCP_APPS_Q_CASES_20261120.json").read_text(encoding="utf-8"))
L_PLAN = json.loads((ROOT / "CLARIFICATION_L_CASES_20261120.json").read_text(encoding="utf-8"))
FIXTURE = ROOT / "fixtures/synthetic_clean_g.json"
MANIFEST = ROOT / "REFERENT_GATE_H_MANIFEST_20261119.json"
ORIGINAL = json.loads(FIXTURE.read_text(encoding="utf-8"))
CASES = PLAN["cases"]


class TestAppEventQuarantineQ(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        assert PLAN["trial_id"] == "ltm-vnext-q-app-event-quarantine-source-scope-20261120"
        assert PLAN["synthetic_only"] is True
        assert PLAN["registered_before_implementation"] is True
        assert PLAN["case_count"] == 21 and len(CASES) == 21
        assert [c["id"] for c in CASES] == [f"Q{i:02d}" for i in range(1,22)]
        assert hashlib.sha256(FIXTURE.read_bytes()).hexdigest() == PLAN["fixture_sha256"]
        assert ORIGINAL["synthetic"] is True and len(ORIGINAL["messages"]) == 20
        assert list(PLAN["canonical_topics"]) == list(L_PLAN["canonical_topic_order"])
        assert PLAN["native_sends"] == 0 and PLAN["native_clicks"] == 0
        assert PLAN["source_release_from_native_app_event"] is False

    def assert_zero_source(self, result, expected):
        self.assertEqual(result["schema_version"], 1)
        self.assertIs(result["synthetic_only"], True)
        self.assertEqual(result["status"], expected)
        self.assertEqual(result["trust_boundary"], TRANSPORT_ONLY)
        self.assertEqual(result["source_packets"], [])
        self.assertEqual(result["source_count"], 0)
        self.assertIs(result["owner_authorised"], False)
        self.assertIs(result["human_consent_attested"], False)
        self.assertIs(result["original_user_text_attested"], False)
        self.assertNotIn("selected_topic", result)

    def verified_packet_sources(self, response):
        self.assertEqual(response["status"], "CONFIRMED_SOURCE_SCOPE")
        self.assertIs(response["original_user_text_attested"], False)
        self.assertEqual(response["trust_boundary"], TRUST_BOUNDARY)
        self.assertIs(response["source_scope_choice_only"], True)
        original_by_id = {
            item["message_id"]: Archive._validate(item)
            for item in ORIGINAL["messages"]
        }
        children = {
            row["local_id"]: [
                child["local_id"] for child in original_by_id.values()
                if child["supersedes_local_id"] == row["local_id"]
            ] for row in original_by_id.values()
        }
        wanted_ids = [
            msg["message_id"] for topic in response["conversation_ids"]
            for msg in ORIGINAL["messages"] if msg["conversation_id"] == topic
        ]
        self.assertEqual([p["message_id"] for p in response["source_packets"]], wanted_ids)
        self.assertEqual(response["source_count"], len(wanted_ids))
        for packet in response["source_packets"]:
            expected = original_by_id[packet["message_id"]]
            for key,value in expected.items():
                self.assertEqual(packet[key], value, f"Changed source {key}")
            self.assertEqual(sorted(packet["corrected_by"]),sorted(children[expected["local_id"]]))
            for neighbour in packet["neighbouring_dialogue"]:
                reference = next(r for r in original_by_id.values()
                                 if r["local_id"] == neighbour["local_id"])
                self.assertEqual(reference["conversation_id"], packet["conversation_id"])
                self.assertEqual(reference["branch_id"], packet["branch_id"])
                self.assertEqual(reference["source_id"], packet["source_id"])
                for key in ("exact_text","content_sha256","author_role","position"):
                    self.assertEqual(neighbour[key], reference[key])

    def _separate_owner_case(self, case):
        # The existing L gateway is created only in a separate simulated-owned
        # test harness. It is *not* a dependency or method on the Q adapter.
        self.assertNotIn("ClarificationGatewayL", AppEventQuarantineQ.__dict__)
        app_result = AppEventQuarantineQ.observe_app_result(
            SelectorM.public("CONFIRMED", case["choice"][0]))
        self.assert_zero_source(app_result,"QUARANTINED_APP_EVENT")
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "q-fictional.sqlite"
            ingest = Archive.initialise(db).ingest_synthetic(FIXTURE)
            self.assertEqual(ingest["inserted"],20)
            resolver = SyntheticHistoryResolver(db,FIXTURE,MANIFEST)
            q_time = [1200.0]
            gateway = ClarificationGatewayL(
                resolver, clock=lambda:q_time[0],
                challenge_factory=lambda:"Q-private-owned-simulator-ticket-0123456789",
                ttl_seconds=60)
            context = dict(L_PLAN["case_context"])
            initial,ui_private = gateway.begin(context)
            self.assertEqual(initial["status"],"AWAITING_CONFIRMATION")
            self.assertEqual(initial["source_count"],0)
            self.assertNotIn("widget_challenge", initial)
            self.assertNotIn(ui_private["widget_challenge"], json.dumps(initial))
            chosen = list(case["choice"])
            granted = gateway.confirm_from_owner_ui(
                context,ui_private["widget_challenge"],chosen)
            self.assertIs(granted,True)
            if case["kind"] == "separate_owner_ambiguous":
                original_id = "L19" if case["referent"]=="I05" else "L20"
                msg = next(x["model_question"] for x in L_PLAN["cases"] if x["id"]==original_id)
            else:
                msg = "assistant-origin unsupported model inference: vela merrow"
            response = gateway.resolve_tool_call(msg, context,
                model_claimed_topics=["qev_tensile","sova_container"])
            self.assertEqual(response["status"], case["expected"] if case["id"]!="Q18"
                             else "CONFIRMED_SOURCE_SCOPE")
            self.assertEqual(response["conversation_ids"],
                case.get("ordered_topics",chosen))
            self.verified_packet_sources(response)
            if case["id"]=="Q18":
                replay=gateway.resolve_tool_call(msg,context,
                    model_claimed_topics=["merrow_prism"])
                self.assertEqual(replay["status"],case["expected"])
                self.assertEqual(replay["source_packets"],[])
                self.assertEqual(replay["source_count"],0)

    def run_case(self,case):
        kind=case["kind"]
        q=AppEventQuarantineQ()
        if kind=="confirmed":
            event=SelectorM.public("CONFIRMED",case["topic"])
            result=q.observe_app_result(event)
            self.assert_zero_source(result,case["expected"])
        elif kind=="malformed":
            event=SelectorM.public("CONFIRMED","merrow_prism")
            mutation=case["mutation"]
            if mutation=="injected_model_topic":
                event["model_claimed_topics"]=["merrow_prism"]
            elif mutation=="human_consent_true":
                event["human_consent_attested"]=True
            elif mutation=="original_text_true":
                event["original_user_text_attested"]=True
            elif mutation=="nonzero_source_count":
                event["source_count"]=1
            elif mutation=="fabricated_source_packet":
                event["source_packets"]=[{"message_id":"g01"}]
            elif mutation=="missing_client_metadata_flag":
                event.pop("client_metadata_not_authorisation")
            elif mutation=="unknown_topic":
                event["selected_topic"]="not-a-fictional-source"
            else:
                self.fail(f"Unexpected frozen mutation: {mutation}")
            self.assert_zero_source(q.observe_app_result(event),case["expected"])
        elif kind=="not_confirmed":
            event=SelectorM.public(case["status"])
            result=q.observe_app_result(event)
            self.assert_zero_source(result,case["expected"])
        elif kind=="model_source_attempt":
            result=q.model_source_attempt(
                "Please send the original Merrow messages",
                owner_context={"user_id":"fictional_owner","session_id":"fictional_session"},
                app_confirmation_status="CONFIRMED",
                selected_topic="merrow_prism",
                source_packets=[{"message_id":"g01"}])
            self.assert_zero_source(result,case["expected"])
        elif kind.startswith("separate_"):
            self._separate_owner_case(case)
        else:
            self.fail(f"Unexpected frozen case kind: {kind}")


def make_test(case):
    def check(self):
        self.run_case(case)
    check.__name__ = "test_" + case["id"].lower()
    return check


for _case in CASES:
    setattr(TestAppEventQuarantineQ,"test_"+_case["id"].lower(),make_test(_case))


if __name__=="__main__":
    unittest.main()
