"""Invocation evidence must omit content and credentials."""
import asyncio
import json
import os
import tempfile
import unittest
from pathlib import Path

from mcp import Client
from ltm_vnext.archive import Archive
from ltm_vnext.mcp_server import create_server

ROOT = Path(__file__).resolve().parents[1]


class ToolAuditTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Path(self.tmp.name) / "archive.sqlite"
        self.log = Path(self.tmp.name) / "tool-audit.jsonl"
        Archive.initialise(self.db).ingest_synthetic(
            ROOT / "fixtures" / "synthetic_conversations.json"
        )

    def test_invocations_recorded_without_content(self):
        async def run():
            async with Client(create_server(self.db, audit_path=self.log)) as c:
                found = await c.call_tool(
                    "lookup_evidence", {"query": "blue notebook"}
                )
                self.assertFalse(found.is_error)
                first = found.structured_content["hits"][0]
                fetched = await c.call_tool(
                    "fetch_source", {"local_id": first["local_id"]}
                )
                self.assertFalse(fetched.is_error)
        asyncio.run(run())
        logs = self.log.read_text(encoding="utf-8")
        entries = [json.loads(line) for line in logs.splitlines()]
        self.assertEqual([e["tool"] for e in entries],
                         ["lookup_evidence", "fetch_source"])
        self.assertTrue(all(e["outcome"] == "ok" for e in entries))
        self.assertTrue(all(e["synthetic_only"] for e in entries))
        self.assertNotIn("notebook", logs)
        self.assertNotIn("blue", logs)
        self.assertNotIn("local_id", logs)
        self.assertEqual(self.log.stat().st_mode & 0o777, 0o600)

    def test_disabled_by_default(self):
        async def run():
            async with Client(create_server(self.db, audit_path="")) as c:
                result = await c.call_tool(
                    "lookup_evidence", {"query": "blue notebook"}
                )
                self.assertFalse(result.is_error)
        asyncio.run(run())
        self.assertFalse(self.log.exists())


if __name__ == "__main__":
    unittest.main()
