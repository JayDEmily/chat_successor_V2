"""Stage L preregistered conditional shadow; never a native user-click test."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from ltm_vnext.archive import Archive
from ltm_vnext.clarification_l import (
    ClarificationGatewayL, ClarificationLContractError, TRUST_BOUNDARY,
)
from ltm_vnext.decision_support_i import SyntheticHistoryResolver, SourceIntegrityError

ROOT = Path(__file__).resolve().parents[1]
PLAN = ROOT / "CLARIFICATION_L_CASES_20261120.json"
FIXTURE = ROOT / "fixtures/synthetic_clean_g.json"
MANIFEST = ROOT / "REFERENT_GATE_H_MANIFEST_20261119.json"


class StageLTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        db = Path(self.temp.name) / "l-only.sqlite"
        outcome = Archive.initialise(db).ingest_synthetic(FIXTURE)
        self.assertEqual(outcome["inserted"], 20)
        self.resolver = SyntheticHistoryResolver(db, FIXTURE, MANIFEST)
        self.now = [1000.0]
        self.new_gateway = lambda: ClarificationGatewayL(
            self.resolver, clock=lambda: self.now[0],
            challenge_factory=lambda: "nonpublished-offline-test-challenge-0123456789ABCDEF")
        self.base = {"user_id": "fictional_owner", "session_id": "fictional_session",
                     "turn_id": "fictional_flow"}

    def variant(self, key):
        context = dict(self.base)
        if key == "wrong_principal":
            context["user_id"] = "different_fictional_user"
        elif key == "wrong_session":
            context["session_id"] = "different_fictional_session"
        elif key == "wrong_flow":
            context["turn_id"] = "different_fictional_flow"
        elif key != "valid":
            self.fail("Unexpected frozen UI context variant: " + key)
        return context

    def test_all_twenty_frozen_cases(self):
        plan = json.loads(PLAN.read_text(encoding="utf-8"))
        self.assertTrue(plan["registered_before_implementation"])
        self.assertEqual(plan["cases_count"], 20)
        self.assertEqual(len(plan["cases"]), 20)
        self.assertEqual(plan["fixture_sha256"],
                         hashlib.sha256(FIXTURE.read_bytes()).hexdigest())
        self.assertEqual(plan["case_context"], self.base)
        originals = {x["message_id"]: x for x in json.loads(
            FIXTURE.read_text(encoding="utf-8"))["messages"]}
        for n,case in enumerate(plan["cases"], 1):
            with self.subTest(case=case["id"]):
                self.now[0] = 1000.0
                gateway = self.new_gateway()
                public,priv = gateway.begin(self.base)
                self.assertEqual(case["id"], f"L{n:02d}")
                self.assertEqual(public["status"], "AWAITING_CONFIRMATION")
                self.assertEqual(public["source_packets"], [])
                self.assertNotIn(priv["widget_challenge"],
                                 json.dumps(public, sort_keys=True))
                self.assertEqual(priv["topic_ids"],plan["canonical_topic_order"])
                self.now[0] += case["clock_advance_seconds"]
                confirmed = None
                if case["ui_choice"] is not None:
                    ticket = (priv["widget_challenge"] if case["ui_token"]=="valid"
                              else "guessed-not-owner-challenge-001")
                    confirmed = gateway.confirm_from_owner_ui(
                        self.variant(case["ui_context"]), ticket, case["ui_choice"])
                self.assertEqual(confirmed,case["expected_confirm"] if
                                 case["ui_choice"] is not None else None)
                result = gateway.resolve_tool_call(
                    case["model_question"],self.variant(case["release_context"]),
                    model_claimed_topics=case["model_claimed_topics"])
                self.assertEqual(result["status"],case["expected_release_status"])
                self.assertEqual(result["conversation_ids"],case["expected_topics"])
                self.assertEqual([p["message_id"] for p in result["source_packets"]],
                                 case["expected_original_message_ids"])
                self.assertEqual(result["source_count"],len(result["source_packets"]))
                self.assertIs(result["original_user_text_attested"],False)
                self.assertEqual(result["trust_boundary"],TRUST_BOUNDARY)
                for packet in result["source_packets"]:
                    original = originals[packet["message_id"]]
                    for k,v in Archive._validate(original).items():
                        self.assertEqual(packet[k],v, f"{case['id']} {k}")
                if case["expect_replay_denied"]:
                    other = gateway.resolve_tool_call(
                        case["model_question"],self.base,
                        model_claimed_topics=case["expected_topics"])
                    self.assertEqual(other["status"],"NO_CONFIRMED_SCOPE")
                    self.assertEqual(other["source_count"],0)

    def test_no_provenance_from_model_arguments(self):
        g=self.new_gateway()
        public,ui=g.begin(self.base)
        forged={"user_id":"fictional_owner","session_id":"fictional_session",
                "turn_id":"fictional_flow","widget_challenge":ui["widget_challenge"],
                "selected_topics":["merrow_prism"]}
        result=g.resolve_tool_call(forged,self.base,["merrow_prism"])
        self.assertEqual(result["status"],"AWAITING_CONFIRMATION")
        self.assertEqual(result["source_count"],0)

    def test_reused_or_overlapping_request_rejected(self):
        g=self.new_gateway()
        g.begin(self.base)
        with self.assertRaises(ClarificationLContractError):
            g.begin(self.base)
        with self.assertRaises(ClarificationLContractError):
            g.begin({**self.base,"turn_id":"another_flow"})

    def test_no_rebind_after_spending(self):
        g=self.new_gateway()
        _,p=g.begin(self.base)
        self.assertTrue(g.confirm_from_owner_ui(
            self.base,p["widget_challenge"],["merrow_prism"]))
        self.assertEqual(g.resolve_tool_call("model ignored",self.base)["source_count"],4)
        with self.assertRaises(ClarificationLContractError):
            g.begin(self.base)
        self.assertFalse(g.confirm_from_owner_ui(
            self.base,p["widget_challenge"],["vela_case"]))

    def test_no_change_after_first_approval(self):
        g=self.new_gateway()
        _,p=g.begin(self.base)
        self.assertTrue(g.confirm_from_owner_ui(
            self.base,p["widget_challenge"],["merrow_prism"]))
        self.assertFalse(g.confirm_from_owner_ui(
            self.base,p["widget_challenge"],["vela_case"]))
        released=g.resolve_tool_call("What about Vela?",self.base,["vela_case"])
        self.assertEqual(released["conversation_ids"],["merrow_prism"])

    def test_expiry_without_source(self):
        g=self.new_gateway()
        _,p=g.begin(self.base)
        self.now[0]+=60
        self.assertFalse(g.confirm_from_owner_ui(
            self.base,p["widget_challenge"],["merrow_prism"]))
        self.assertEqual(g.resolve_tool_call("",self.base)["status"],"EXPIRED")
        self.assertEqual(g.resolve_tool_call("",self.base)["status"],"NO_CONFIRMED_SCOPE")

    def test_foreign_or_malformed_context_ignored(self):
        g=self.new_gateway()
        _,p=g.begin(self.base)
        for ctx in (None,{},{"user_id":"fictional_owner"},
                    {**self.base,"user_id":"other"},
                    {**self.base,"session_id":"other"},
                    {**self.base,"turn_id":"other"}):
            with self.subTest(context=ctx):
                self.assertFalse(g.confirm_from_owner_ui(
                    ctx,p["widget_challenge"],["merrow_prism"]))
                self.assertEqual(g.resolve_tool_call("Merrow",ctx)["source_count"],0)
        self.assertEqual(g.active_flow_count,1)

    def test_corrupt_archive_cannot_release(self):
        g=self.new_gateway()
        _,p=g.begin(self.base)
        self.assertTrue(g.confirm_from_owner_ui(
            self.base,p["widget_challenge"],["merrow_prism"]))
        with sqlite3.connect(self.resolver.db_path) as db:
            db.execute("UPDATE messages SET exact_text=? WHERE message_id=?",
                       ("CORRUPTED SYNTHETIC TEST", "g01"))
        with self.assertRaises(SourceIntegrityError):
            g.resolve_tool_call("Merrow",self.base)
        self.assertEqual(g.resolve_tool_call("Merrow",self.base)["source_count"],0)


if __name__ == "__main__":
    unittest.main()
