"""Offline synthetic H referent gate: frozen 38 cases and adversarial integrity tests."""
from __future__ import annotations

import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from ltm_vnext.referent_gate import ReferentGate, ReferentGateError

ROOT=Path(__file__).resolve().parents[1]
MANIFEST=ROOT/"REFERENT_GATE_H_MANIFEST_20261119.json"
FIXTURE=ROOT/"fixtures/synthetic_clean_g.json"
CASES=ROOT/"REFERENT_GATE_H_CASES_20261119.json"


class ReferentGateHTests(unittest.TestCase):
    def setUp(self):
        self.gate=ReferentGate(MANIFEST,FIXTURE)
        self.cases=json.loads(CASES.read_text(encoding="utf-8"))
        self.manifest=json.loads(MANIFEST.read_text(encoding="utf-8"))
        self.source=json.loads(FIXTURE.read_text(encoding="utf-8"))

    def _build(self,mutator,fixture_mutator=None):
        with tempfile.TemporaryDirectory() as path:
            root=Path(path)
            manifest=copy.deepcopy(self.manifest)
            source=copy.deepcopy(self.source)
            mutator(manifest)
            if fixture_mutator:
                fixture_mutator(source)
            fixture_file=root/"synthetic_clean_g.json"
            fixture_data=(json.dumps(source,ensure_ascii=False)+"\n").encode("utf-8")
            fixture_file.write_bytes(fixture_data)
            manifest["fixture_sha256"]=hashlib.sha256(fixture_data).hexdigest()
            manifest_file=root/"manifest.json"
            manifest_file.write_text(json.dumps(manifest,ensure_ascii=False),encoding="utf-8")
            return ReferentGate(manifest_file,fixture_file)

    def test_all_38_preregistered_cases(self):
        self.assertTrue(self.cases["preregistered"])
        self.assertEqual(self.cases["count"],38)
        self.assertEqual(self.cases["trial_id"],self.manifest["evaluation"])
        self.assertEqual(len(self.cases["cases"]),38)
        ids=[]
        for case in self.cases["cases"]:
            ids.append(case["id"])
            with self.subTest(case=case["id"],kind=case["kind"]):
                decision=self.gate.decide(case["prompt"],case["candidate_conversations"])
                self.assertEqual(decision.status,case["expected"]["status"])
                self.assertEqual(list(decision.conversation_ids),case["expected"]["topics"])
                self.assertEqual(decision.is_unique,decision.status=="UNIQUE")
        self.assertEqual(ids,[f"H{x:02d}" for x in range(1,39)])

    def test_candidates_cannot_promote_unanchored_question(self):
        q="Where did it end up in that earlier fictional record?"
        for options in (None,[],["merrow_prism"],["qev_tensile","merrow_prism"]):
            with self.subTest(options=options):
                outcome=self.gate.decide(q,options)
                self.assertEqual(outcome.status,"UNANCHORED")
                self.assertEqual(outcome.conversation_ids,())

    def test_missing_candidates_cannot_retarget_explicit_question(self):
        d=self.gate.decide("What corrected SOVA-88 colour?",["merrow_prism"])
        self.assertEqual(d.status,"EVIDENCE_MISMATCH")
        self.assertEqual(d.conversation_ids,("sova_container",))

    def test_candidate_order_is_not_authority(self):
        query="Which QEV-73 record was amended?"
        a=self.gate.decide(query,["merrow_prism","qev_tensile"])
        b=self.gate.decide(query,["qev_tensile","merrow_prism"])
        self.assertEqual(a.status,b.status)
        self.assertEqual(a.conversation_ids,b.conversation_ids)
        self.assertEqual(a.conversation_ids,("qev_tensile",))

    def test_unicode_casefold_and_substring_boundaries(self):
        self.assertEqual(self.gate.decide("What happened in the mErRoW log?").status,"UNIQUE")
        for bad in ("ULN-48270","ORA-620","SOVA-880","prefixSOVA-88suffix","Merrowish"):
            self.assertEqual(self.gate.decide("Did "+bad+" change?").status,"UNANCHORED")

    def test_referent_does_not_prove_speaker_authenticity(self):
        d=self.gate.decide("What did Vela say?")
        self.assertEqual(d.status,"UNIQUE")
        match=next(x for x in d.anchors if x.text=="Vela")
        g05=next(m for m in self.source["messages"] if m["message_id"]=="g05")
        self.assertEqual(match.source_message_id,g05["message_id"])
        self.assertEqual(match.source_locator,g05["source_locator"])
        self.assertEqual(match.content_sha256,hashlib.sha256(
            g05["exact_text"].encode("utf-8")).hexdigest())
        self.assertEqual(g05["attribution"],"reported_recollection")
        self.assertEqual(g05["reported_speaker"],"Vela")

    def test_reject_alternative_branch_assistant_alias(self):
        def mutate(m):
            m["topics"][3]["anchors"].append(
                {"text":"pier 7","evidence_message_id":"g16"})
        with self.assertRaisesRegex(ReferentGateError,"main-branch user"):
            self._build(mutate)

    def test_reject_assistant_main_branch_alias(self):
        def mutate(m):
            m["topics"][0]["anchors"].append(
                {"text":"physical inspection","evidence_message_id":"g02"})
        with self.assertRaisesRegex(ReferentGateError,"main-branch user"):
            self._build(mutate)

    def test_reject_cross_conversation_anchor(self):
        def mutate(m):
            m["topics"][4]["anchors"].append(
                {"text":"violet optic","evidence_message_id":"g01"})
        with self.assertRaisesRegex(ReferentGateError,"main-branch user"):
            self._build(mutate)

    def test_reject_new_unverified_alias(self):
        def mutate(m):
            m["topics"][0]["anchors"].append(
                {"text":"supercalifragilistic","evidence_message_id":"g01"})
        with self.assertRaisesRegex(ReferentGateError,"does not appear"):
            self._build(mutate)

    def test_reject_duplicate_alias(self):
        def mutate(m):
            m["topics"][1]["anchors"].append(
                {"text":"Vela","evidence_message_id":"g05"})
        with self.assertRaisesRegex(ReferentGateError,"Duplicate/ambiguous"):
            self._build(mutate)

    def test_reject_duplicate_conversation_topic(self):
        def mutate(m):
            m["topics"].append(copy.deepcopy(m["topics"][0]))
        with self.assertRaisesRegex(ReferentGateError,"duplicate topic"):
            self._build(mutate)

    def test_reject_missing_topic(self):
        def mutate(m):
            m["topics"].pop()
        with self.assertRaisesRegex(ReferentGateError,"exactly"):
            self._build(mutate)

    def test_reject_bad_original_fixture_sha(self):
        with tempfile.TemporaryDirectory() as path:
            p=Path(path)/"synthetic_clean_g.json"
            p.write_bytes(FIXTURE.read_bytes()+b" ")
            with self.assertRaisesRegex(ReferentGateError,"SHA-256"):
                ReferentGate(MANIFEST,p)

    def test_reject_unlabelled_non_synthetic_fixture(self):
        with self.assertRaisesRegex(ReferentGateError,"synthetic fixture"):
            self._build(lambda m:None,
                        fixture_mutator=lambda f:f.update(synthetic=False))

    def test_reject_changed_original_source_even_if_repinned(self):
        def mutate(f):
            f["messages"][0]["exact_text"]="Erased the original fictional log."
        with self.assertRaisesRegex(ReferentGateError,"does not appear"):
            self._build(lambda m:None,fixture_mutator=mutate)

    def test_reject_unknown_candidate_topic(self):
        with self.assertRaisesRegex(ReferentGateError,"candidate topic"):
            self.gate.decide("Where is Merrow?",["fabricated_conversation"])

    def test_reject_duplicate_candidate_topic(self):
        with self.assertRaisesRegex(ReferentGateError,"Duplicate candidate"):
            self.gate.decide("Where is Merrow?",["merrow_prism","merrow_prism"])

    def test_reject_candidate_string_instead_of_list(self):
        with self.assertRaisesRegex(ReferentGateError,"list or null"):
            self.gate.decide("Where is Merrow?","merrow_prism")

    def test_reject_empty_question(self):
        for bad in (None,"", "   ", 42):
            with self.subTest(bad=bad):
                with self.assertRaises(ReferentGateError):
                    self.gate.decide(bad)

    def test_freeze_manifest_original_evidence_sha(self):
        self.assertEqual(hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),
                         self.manifest["fixture_sha256"])

    def test_live_mcp_interface_not_imported(self):
        source=(ROOT/"ltm_vnext/mcp_server.py").read_text(encoding="utf-8")
        self.assertNotIn("referent_gate",source)


if __name__=="__main__":
    unittest.main()
