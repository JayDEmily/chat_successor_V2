"""Astra G5: provider file-list pagination, hermetic and credential-free."""
from __future__ import annotations

import unittest

from ltm_vnext.hosted_memory_r import OpenAIHttpR, HostedRFailure


class FilePaginationTests(unittest.TestCase):
    @staticmethod
    def client(responses):
        client = object.__new__(OpenAIHttpR)
        requests = []

        def no_network_json(method, endpoint, payload=None):
            requests.append((method, endpoint))
            return responses[endpoint]
        client.json = no_network_json
        return client, requests

    def test_two_pages_return_all_files_in_order(self):
        responses = {
            "/files?purpose=assistants&limit=100": {
                "data": [{"id": "file-1"}, {"id": "file:2"}],
                "has_more": True,
            },
            "/files?purpose=assistants&limit=100&after=file%3A2": {
                "data": [{"id": "file-3"}],
                "has_more": False,
            },
        }
        client, requests = self.client(responses)
        self.assertEqual([x["id"] for x in client.files()],
                         ["file-1", "file:2", "file-3"])
        self.assertEqual(len(requests), 2)
        self.assertTrue(all(method == "GET" for method, _ in requests))

    def test_duplicate_file_across_pages_is_denied(self):
        responses = {
            "/files?purpose=assistants&limit=100": {
                "data": [{"id": "file-1"}], "has_more": True,
            },
            "/files?purpose=assistants&limit=100&after=file-1": {
                "data": [{"id": "file-1"}], "has_more": False,
            },
        }
        client, _ = self.client(responses)
        with self.assertRaisesRegex(HostedRFailure, "Duplicate"):
            client.files()

    def test_empty_unfinished_page_is_denied(self):
        client, _ = self.client({
            "/files?purpose=assistants&limit=100": {
                "data": [], "has_more": True,
            }
        })
        with self.assertRaisesRegex(HostedRFailure, "did not progress"):
            client.files()

    def test_missing_has_more_is_denied_not_treated_as_complete(self):
        client, _ = self.client({
            "/files?purpose=assistants&limit=100": {
                "data": [{"id": "file-1"}],
            }
        })
        with self.assertRaisesRegex(HostedRFailure, "Malformed"):
            client.files()

    def test_duplicate_same_page_is_denied(self):
        client, _ = self.client({
            "/files?purpose=assistants&limit=100": {
                "data": [{"id": "file-1"}, {"id": "file-1"}],
                "has_more": False,
            }
        })
        with self.assertRaisesRegex(HostedRFailure, "Duplicate"):
            client.files()

    def test_hundred_page_bound_fails_explicitly(self):
        calls = []
        client = object.__new__(OpenAIHttpR)

        def provider(method, endpoint, payload=None):
            calls.append(endpoint)
            return {"data": [{"id": f"file-{len(calls)}"}],
                    "has_more": True}
        client.json = provider
        with self.assertRaisesRegex(HostedRFailure, "bounded pages"):
            client.files()
        self.assertEqual(len(calls), 100)

    def test_one_page_is_valid_without_more(self):
        client, requests = self.client({
            "/files?purpose=assistants&limit=100": {
                "data": [{"id": "file-1"}], "has_more": False,
            }
        })
        self.assertEqual(client.files()[0]["id"], "file-1")
        self.assertEqual(len(requests), 1)


if __name__ == "__main__":
    unittest.main()
