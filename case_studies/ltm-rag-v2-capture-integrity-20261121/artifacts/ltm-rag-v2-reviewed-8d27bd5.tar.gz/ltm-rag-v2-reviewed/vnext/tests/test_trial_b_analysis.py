"""Check reliability reporting without reading private ChatGPT test ledgers."""
from __future__ import annotations

import json
import unittest

from scripts import summarise_trial_b as s


class TrialBAnalysisTests(unittest.TestCase):
    def setUp(self) -> None:
        self.plan = json.loads(s.PLAN.read_text(encoding="utf-8"))
        self.result = {
            "id": "H01", "kind": "history", "ordinal": 1,
            "chat_url": "chatgpt.com/g/" + s.PROJECT + "/c/test-case-001",
            "completed": True,
            "lookup_count": 1, "fetch_count": 1,
            "added_event_ids": ["e1", "e2"],
            "matched_terms": list(self.plan["cases"][0]["expected_terms"]),
            "initiation_or_selectivity_pass": True,
            "content_pass": True,
        }
        self.audit = [{"event_id": "e1", "tool": "lookup_evidence"}, {"event_id": "e2", "tool": "fetch_source"}]

    def test_wilson_interval_for_small_sample(self) -> None:
        low, _ = s.wilson(10, 10)
        _, high = s.wilson(0, 10)
        self.assertGreater(low, 0.72)
        self.assertLess(low, 0.73)
        self.assertGreater(high, 0.27)
        self.assertLess(high, 0.29)

    def test_wilson_rejects_invalid_counts(self) -> None:
        with self.assertRaises(ValueError):
            s.wilson(3, 2)

    def test_partial_dataset_is_not_terminal(self) -> None:
        result = s.analyse(self.plan, [self.result], self.audit)
        self.assertFalse(result["complete"])
        self.assertEqual(result["counts"]["history_primary"], 1)
        with self.assertRaisesRegex(ValueError, "No final report"):
            s.write_report(result)

    def test_runner_score_mismatch_is_rejected(self) -> None:
        mutated = dict(self.result, content_pass=False)
        with self.assertRaisesRegex(ValueError, "Scoring contradiction"):
            s.analyse(self.plan, [mutated], self.audit)

    def test_missing_audit_event_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "Missing/duplicate"):
            s.analyse(self.plan, [self.result], [{"event_id": "e1", "tool": "lookup_evidence"}])

    def test_non_project_url_is_rejected(self) -> None:
        mutated = dict(self.result, chat_url="chatgpt.com/c/foreign")
        with self.assertRaisesRegex(ValueError, "non-Project"):
            s.analyse(self.plan, [mutated], self.audit)

    def test_audit_tool_type_mismatch_is_rejected(self) -> None:
        audit = [{"event_id": "e1", "tool": "fetch_source"}, {"event_id": "e2", "tool": "fetch_source"}]
        with self.assertRaisesRegex(ValueError, "tool types"):
            s.analyse(self.plan, [self.result], audit)


if __name__ == "__main__":
    unittest.main()
