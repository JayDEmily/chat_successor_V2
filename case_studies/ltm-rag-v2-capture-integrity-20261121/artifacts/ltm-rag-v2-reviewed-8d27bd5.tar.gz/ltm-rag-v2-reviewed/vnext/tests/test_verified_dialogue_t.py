"""Stage T verified native conversation recovery, fake hosted index only."""
from __future__ import annotations
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

from ltm_vnext.verified_dialogue_t import NativeVerifiedT, T_STORE_NAME, UI_FOOTER
from ltm_vnext.native_dialogue_s import StageSFailure, _private_write
from ltm_vnext.archive import Archive, InvalidFixture


class FakeProviderT:
    def __init__(self):
        self.store_data=None
        self.files_data={}
        self.attached={}
        self.uploads=0
    def stores(self):
        return [self.store_data] if self.store_data else []
    def json(self,method,endpoint,payload=None):
        if method=="POST" and endpoint=="/vector_stores":
            assert self.store_data is None
            self.store_data={"id":"vs_synthetic_t","name":payload["name"],
                "metadata":payload["metadata"],
                "expires_after":payload["expires_after"]}
            return self.store_data
        raise AssertionError("Unexpected hosted fake request")
    def retrieve_store(self,store_id):
        return {**self.store_data,
                "file_counts":{"completed":len(self.attached),"total":len(self.attached)}}
    def files(self):
        return [{"id":fid,"filename":item["filename"]}
                for fid,item in self.files_data.items()]
    def upload_file(self,filename,content):
        self.uploads+=1
        fid=f"file-synthetic-t-{self.uploads}"
        self.files_data[fid]={"filename":filename,"content":content}
        return {"id":fid}
    def attachment(self,store,file_id):
        return self.attached.get(file_id)
    def attach(self,store,file_id,attrs):
        result={"file_id":file_id,"status":"completed","attributes":attrs.copy()}
        self.attached[file_id]=result
        return result
    def search(self,store,query,max_results=10):
        return {"data":[{"file_id":fid,"score":0.91}
                         for fid in list(self.attached)[:max_results]]}


class NativeVerifiedTOffline(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.p=Path(self.tmp.name)/"clean-t"
        self.api=FakeProviderT()
        self.gateway=NativeVerifiedT(self.api,private=self.p)
        self.assertEqual(self.gateway.store(allow_create=True),"vs_synthetic_t")

    def test_five_verified_native_replies_sql_hosted_exact(self):
        for turn in range(1,6):
            receipt=self.gateway._receipt(turn)
            self.assertNotIn("ChatGPT can make mistakes",receipt["assistant_observed_text"])
            self.assertNotIn(UI_FOOTER,receipt["assistant_observed_text"])
            indexed=self.gateway.index_turn(turn)
            self.assertTrue(indexed["indexed"])
            checked=self.gateway.verify(upto=turn)
            self.assertEqual(checked["sql_original_messages"],turn*2)
        self.assertEqual(self.api.uploads,5)
        with sqlite3.connect(self.gateway.db) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM messages").fetchone()[0],10)
            self.assertEqual(db.execute("SELECT count(ingested_at_utc) FROM messages").fetchone()[0],10)
            self.assertEqual(db.execute("SELECT count(message_sent_at_utc) FROM messages").fetchone()[0],5)
            actual=db.execute("SELECT exact_text FROM messages ORDER BY position").fetchall()
        self.assertEqual([a[0] for a in actual][1::2],
                         [self.gateway._receipt(n)["assistant_observed_text"] for n in range(1,6)])
        self.assertEqual([a[0] for a in actual][::2],
                         [self.gateway._receipt(n)["simulated_user_text"] for n in range(1,6)])

    def test_true_unicode_survives_clean_reindex(self):
        text=self.gateway._receipt(3)["assistant_observed_text"]
        self.assertTrue(("’" in text) or ("'" in text))
        self.gateway.index_turn(1)
        packets=self.gateway.search("fictional query")
        self.assertEqual(packets[0]["original_packets"][1]["capture_method"],"synthetic_native_ui")
        self.assertNotIn("ChatGPT can make mistakes",packets[0]["original_packets"][1]["exact_text"])

    def test_duplicate_vector_chunks_do_not_duplicate_t_pairs(self):
        self.gateway.index_turn(1)
        fid=next(iter(self.api.attached))
        self.api.search=lambda *args,**kwargs: {"data": [
            {"file_id":fid,"score":0.88},
            {"file_id":fid,"score":0.73},
        ]}
        hits=self.gateway.search("fictional original")
        self.assertEqual(len(hits),1)
        self.assertEqual(hits[0]["turn"],1)

    def test_duplicate_vector_chunks_survive_gateway_validation(self):
        from ltm_vnext.hosted_mcp_u import HostedMemoryGatewayU, CallQuotaU

        self.gateway.index_turn(1)
        file_id=next(iter(self.api.attached))
        self.api.search=lambda *args,**kwargs: {"data": [
            {"file_id":file_id,"score":0.89},
            {"file_id":file_id,"score":0.78},
        ]}
        target=HostedMemoryGatewayU(
            pipeline=self.gateway,
            quota=CallQuotaU(Path(self.tmp.name)/"gateway-audit.jsonl",limit=1),
        )
        result=target.lookup("What did Ryan say in the fictional note?",1)
        self.assertEqual(result["status"],"FOUND")
        self.assertEqual(result["source_packets_count"],2)
        self.assertEqual(len(result["results"]),1)

    def test_wrong_original_raw_receipt_hash_denied(self):
        self.assertTrue(all(len(h)==64 for h in self.gateway.t_plan["raw_private_capture_sha256"]))
        self.gateway.t_plan["raw_private_capture_sha256"][0]="0"*64
        with self.assertRaises(StageSFailure):
            self.gateway._receipt(1)

    def test_untrusted_generated_model_reply_cannot_be_synthesised(self):
        receipt=self.gateway._receipt(1)
        receipt["assistant_generated_by"]="fake_llm"
        # The original authorised receipts are used by _receipt, never caller args.
        self.assertEqual(self.gateway._receipt(1)["assistant_generated_by"],"native_chatgpt")
        self.gateway.index_turn(1)
        with sqlite3.connect(self.gateway.db) as db:
            stored=db.execute("SELECT exact_text FROM messages WHERE author_role='assistant'").fetchone()[0]
        self.assertEqual(stored,self.gateway._receipt(1)["assistant_observed_text"])

    def test_refuse_unlabelled_real_chat_import_to_archive(self):
        item=self.gateway._messages(1,self.gateway._receipt(1))[0]
        with self.assertRaises(InvalidFixture):
            Archive._validate(dict(item,source_id="real_person_archive"))
        with self.assertRaises(InvalidFixture):
            Archive._validate(dict(item,capture_method="chatgpt_export"))

    def test_original_native_raw_stage_s_not_rewritten(self):
        for i in range(1,6):
            receipt=self.gateway._receipt(i)
            self.assertEqual(len(receipt["original_raw_sha256"]),64)
            self.assertTrue(receipt["assistant_observed_text"])
        self.assertEqual(self.api.uploads,0)


if __name__=="__main__":
    unittest.main()
