"""Stage M locked synthetic offline cases and MCP Apps visibility tests."""
from __future__ import annotations
import asyncio
import hashlib
import json
import unittest
from pathlib import Path

from ltm_vnext.mcp_apps_m import (
    SelectorM,create_server,TOOL_OPEN,TOOL_CONFIRM,RESOURCE,TOPICS,WIDGET
)

ROOT=Path(__file__).resolve().parents[1]
PLAN=ROOT/"MCP_APPS_M_CASES_20261120.json"
META={"openai/session":"synthetic-session-a",
      "openai/subject":"synthetic-subject-a"}
TOKEN="synthetic-ephemeral-test-token-0123456789ABCDEF"

class MCPAppsMTests(unittest.TestCase):
    def setUp(self):
        self.now=[1000.0]
        self.probe=SelectorM(clock=lambda:self.now[0],token_factory=lambda:TOKEN)
        self.plan=json.loads(PLAN.read_text(encoding="utf-8"))

    def test_all_sixteen_frozen_cases(self):
        p=self.plan
        self.assertEqual(p["cases_count"],16)
        self.assertEqual(len(p["cases"]),16)
        self.assertTrue(p["registered_before_implementation"])
        self.assertTrue(p["synthetic_only"])
        self.assertEqual(p["tool_names"],[TOOL_OPEN,TOOL_CONFIRM])
        self.assertEqual(p["resource_uri"],RESOURCE)
        self.assertEqual(p["topic_ids"],list(TOPICS))
        self.assertEqual(p["ttl_seconds"],60)
        for n,case in enumerate(p["cases"],1):
            with self.subTest(case=case["id"]):
                self.now[0]=1000
                probe=SelectorM(clock=lambda:self.now[0],
                                token_factory=lambda:TOKEN)
                self.assertEqual(case["id"],f"M{n:02d}")
                kind=case["kind"]
                expected=case["expected"]
                if kind=="descriptor":
                    tools=asyncio.run(create_server().list_tools())
                    data={t.name:t.meta["ui"] for t in tools}
                    self.assertEqual(set(data),{TOOL_OPEN,TOOL_CONFIRM})
                    self.assertEqual(data[TOOL_OPEN]["visibility"],["model","app"])
                    self.assertEqual(data[TOOL_CONFIRM]["visibility"],["app"])
                    actual="TWO_TOOLS_CORRECT_VISIBILITY"
                elif kind=="resource":
                    resources=asyncio.run(create_server().list_resources())
                    self.assertEqual(len(resources),1)
                    self.assertEqual(str(resources[0].uri),RESOURCE)
                    self.assertEqual(resources[0].mime_type,p["resource_mime"])
                    html=WIDGET.read_text(encoding="utf-8")
                    self.assertIn("ui/initialize",html)
                    self.assertIn("ui/notifications/initialized",html)
                    self.assertIn("tools/call",html)
                    self.assertIn("event.source!==host",html)
                    self.assertNotIn("fetch(",html)
                    self.assertNotIn("XMLHttpRequest",html)
                    actual="ONE_MCP_APPS_HTML_RESOURCE"
                else:
                    public,private=probe.begin(META)
                    self.assertEqual(public["status"],"AWAITING_CONFIRMATION")
                    self.assertEqual(public["source_packets"],[])
                    self.assertEqual(public["source_count"],0)
                    self.assertFalse(public["original_user_text_attested"])
                    self.assertNotIn(TOKEN,json.dumps(public))
                    self.assertEqual(private["stage_m"]["challenge"],TOKEN)
                    self.assertEqual([t["id"] for t in private["stage_m"]["topics"]],
                                     list(TOPICS))
                    if kind=="open_only":
                        actual="AWAITING_CONFIRMATION_NO_SOURCES"
                    elif kind=="model_only":
                        self.assertEqual(case["claimed"],"ora_pier")
                        self.assertEqual(probe.public("AWAITING_CONFIRMATION")["source_count"],0)
                        self.assertFalse(probe.flows[probe.context(META)].consumed)
                        actual="AWAITING_CONFIRMATION_NO_SOURCES"
                    elif kind=="overlap":
                        response,secret=probe.begin(META)
                        self.assertEqual(response["status"],"ACTIVE_FLOW_ALREADY_EXISTS")
                        self.assertEqual(secret,{})
                        actual="SECOND_ACTIVE_FLOW_REJECTED"
                    elif kind=="cross_chat":
                        wrong={**META,"openai/session":"synthetic-session-b"}
                        result=probe.confirm(wrong,TOKEN,case["selected"])
                        self.assertEqual(result["status"],"DENIED")
                        self.assertEqual(result["source_count"],0)
                        actual="WRONG_SESSION_DENIED"
                    else:
                        context=dict(META)
                        if case.get("context")=="wrong_session":
                            context["openai/session"]="synthetic-session-b"
                        if case.get("context")=="wrong_subject":
                            context["openai/subject"]="synthetic-subject-b"
                        challenge=TOKEN if case.get("token")=="valid" else (
                            None if case.get("token")=="missing" else
                            "guess-0123456789ABCDEFGHIJKLMNOP")
                        self.now[0]+=case.get("advance_seconds",0)
                        topic=case["selected"]
                        result=probe.confirm(context,challenge,topic)
                        self.assertEqual(result["source_count"],0)
                        self.assertEqual(result["source_packets"],[])
                        if kind=="replay":
                            self.assertEqual(result["status"],"CONFIRMED")
                            next_result=probe.confirm(context,challenge,topic)
                            self.assertEqual(next_result["status"],"DENIED")
                            actual="FIRST_ONLY"
                        else:
                            actual=result["status"]
                            self.assertTrue(actual in ("CONFIRMED","DENIED","EXPIRED"))
                            if actual=="CONFIRMED":
                                self.assertEqual(result["selected_topic"],topic)
                self.assertEqual(actual,expected)

    def test_no_meta_no_ui_token(self):
        result,private=self.probe.begin(None)
        self.assertEqual(result["status"],"NO_SESSION_CONTEXT")
        self.assertEqual(private,{})
        self.assertEqual(result["source_count"],0)

    def test_concurrent_scope_wrong_subject_cannot_confirm(self):
        self.probe.begin(META)
        wrong={**META,"openai/subject":"fiction-b"}
        self.assertEqual(self.probe.confirm(wrong,TOKEN,"merrow_prism")["status"],"DENIED")
        self.assertEqual(self.probe.confirm(META,TOKEN,"merrow_prism")["status"],"CONFIRMED")

    def test_expired_flow_never_releases(self):
        self.probe.begin(META)
        self.now[0]+=60
        self.assertEqual(self.probe.confirm(META,TOKEN,"merrow_prism")["status"],"EXPIRED")
        self.assertEqual(self.probe.confirm(META,TOKEN,"merrow_prism")["status"],"DENIED")

    def test_non_string_and_invalid_meta_fail_closed(self):
        for meta in (None,{},{"openai/session":"x"},
                     {"openai/session":"x","openai/subject":4},
                     {"openai/session":" ","openai/subject":"y"}):
            self.assertEqual(self.probe.begin(meta)[0]["status"],"NO_SESSION_CONTEXT")

    def test_output_never_attests_human_or_original_message(self):
        self.probe.begin(META)
        result=self.probe.confirm(META,TOKEN,"merrow_prism")
        self.assertFalse(result["human_consent_attested"])
        self.assertFalse(result["original_user_text_attested"])
        self.assertTrue(result["client_metadata_not_authorisation"])
        self.assertEqual(result["source_packets"],[])

if __name__=="__main__":
    unittest.main()
