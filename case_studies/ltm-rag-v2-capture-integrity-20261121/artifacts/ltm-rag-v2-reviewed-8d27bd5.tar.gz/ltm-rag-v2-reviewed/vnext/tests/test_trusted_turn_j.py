"""Stage J conditional, owner-ingress-only synthetic boundary tests."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from ltm_vnext.archive import Archive
from ltm_vnext.decision_support_i import SyntheticHistoryResolver, SourceIntegrityError
from ltm_vnext.trusted_turn_j import BoundTurnGateway, TrustedIngressError

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "fixtures/synthetic_clean_g.json"
MANIFEST = ROOT / "REFERENT_GATE_H_MANIFEST_20261119.json"
PLAN = ROOT / "TRUSTED_TURN_J_CASES_20261119.json"
BASE = {"user_id": "synthetic_user_a",
        "session_id": "synthetic_chat_a", "turn_id": "synthetic_turn_a"}


class StageJTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / "j-only.sqlite"
        inserted = Archive.initialise(self.db).ingest_synthetic(FIXTURE)
        self.assertEqual(inserted["inserted"], 20)
        self.resolver = SyntheticHistoryResolver(self.db, FIXTURE, MANIFEST)
        self.gateway = BoundTurnGateway(self.resolver)

    def test_all_26_preregistered_outcomes(self):
        plan = json.loads(PLAN.read_text(encoding="utf8"))
        self.assertEqual(plan["cases_count"], 26)
        self.assertEqual(len(plan["cases"]), 26)
        self.assertTrue(plan["registered_before_implementation"])
        self.assertEqual(plan["fixture_sha256"],
                         hashlib.sha256(FIXTURE.read_bytes()).hexdigest())
        for index, case in enumerate(plan["cases"], 1):
            with self.subTest(case=case["id"]):
                self.assertEqual(case["id"], f"J{index:02d}")
                gateway = BoundTurnGateway(self.resolver)
                if case["registered"]:
                    gateway.register_trusted_turn(
                        case["registration_context"], case["trusted_question"])
                result = gateway.resolve_tool_call(
                    case["model_question"], case["call_context"])
                self.assertEqual(result["status"], case["expected_status"])
                self.assertTrue(result["synthetic_only"])
                self.assertEqual(result["schema_version"], 1)
                self.assertEqual(result["conversation_ids"], case["expected_topics"])
                self.assertEqual(
                    [p["message_id"] for p in result["source_packets"]],
                    case["expected_original_message_ids"])
                self.assertEqual(result["source_count"],len(result["source_packets"]))
                self.assertEqual(
                    result["trust_boundary"], "OWNER_INGRESS_SIMULATED_NOT_NATIVE_CHATGPT")
                if result["status"] not in ("UNIQUE","MULTIPLE"):
                    self.assertEqual(result["source_packets"],[])
                    self.assertEqual(result["source_count"],0)

    def test_original_packet_bytes_and_author_provenance(self):
        question = "Compare Merrow and SOVA-88 corrections."
        self.gateway.register_trusted_turn(BASE, question)
        result=self.gateway.resolve_tool_call(question,BASE)
        originals={m["message_id"]:m for m in json.loads(
            FIXTURE.read_text(encoding="utf8"))["messages"]}
        self.assertEqual(result["status"],"MULTIPLE")
        for packet in result["source_packets"]:
            ref=originals[packet["message_id"]]
            self.assertEqual(packet["exact_text"],ref["exact_text"])
            self.assertEqual(packet["author_role"],ref["author_role"])
            self.assertEqual(packet["branch_id"],ref["branch_id"])
            self.assertEqual(packet["source_locator"],ref["source_locator"])
            self.assertEqual(packet["content_sha256"],
                             hashlib.sha256(ref["exact_text"].encode()).hexdigest())
        self.assertEqual(result["source_count"],8)

    def test_injected_referent_cannot_promote_i05(self):
        question="Was the original version first or second?"
        self.gateway.register_trusted_turn(BASE,question)
        result=self.gateway.resolve_tool_call(
            "For the ORA-62 pier 4 correction, was original first?",BASE)
        self.assertEqual(result["status"],"MODEL_ARGUMENT_MISMATCH")
        self.assertEqual(result["source_packets"],[])
        self.assertEqual(self.gateway.active_turn_count,0)
        self.assertEqual(self.gateway.resolve_tool_call(question,BASE)["status"],
                         "NO_BOUND_TURN")

    def test_injected_speaker_cannot_promote_i15(self):
        question="Did she actually say it?"
        self.gateway.register_trusted_turn(BASE,question)
        self.assertEqual(self.gateway.resolve_tool_call(
            "Did Vela say the TERN-91 recollection?",BASE)["source_count"],0)

    def test_exact_unspecified_message_gets_no_packets(self):
        question="Did she actually say it?"
        self.gateway.register_trusted_turn(BASE,question)
        result=self.gateway.resolve_tool_call(question,BASE)
        self.assertEqual(result["status"],"UNANCHORED")
        self.assertEqual(result["source_count"],0)

    def test_no_owner_registration_fails_closed(self):
        self.assertEqual(self.gateway.resolve_tool_call(
            "What did Merrow record?",BASE)["status"],"NO_BOUND_TURN")

    def test_missing_or_modified_transport_context_does_not_consumes_turn(self):
        question="What did Merrow record?"
        self.gateway.register_trusted_turn(BASE,question)
        for other in (None,{},{"user_id":"synthetic_user_a"},
                      {**BASE,"session_id":"synthetic_chat_b"},
                      {**BASE,"user_id":"synthetic_user_b"},
                      {**BASE,"turn_id":"synthetic_turn_b"}):
            with self.subTest(context=other):
                self.assertEqual(self.gateway.resolve_tool_call(
                    question,other)["status"],"NO_BOUND_TURN")
        self.assertEqual(self.gateway.active_turn_count,1)
        self.assertEqual(self.gateway.resolve_tool_call(
            question,BASE)["status"],"UNIQUE")

    def test_replay_and_rebinding_same_turn_rejected(self):
        text="What did Merrow record?"
        self.gateway.register_trusted_turn(BASE,text)
        self.assertEqual(self.gateway.resolve_tool_call(text,BASE)["status"],"UNIQUE")
        self.assertEqual(self.gateway.resolve_tool_call(text,BASE)["status"],"NO_BOUND_TURN")
        with self.assertRaisesRegex(TrustedIngressError,"never be reused"):
            self.gateway.register_trusted_turn(BASE,text)

    def test_overlapping_turns_same_session_rejected(self):
        text="What did Merrow record?"
        self.gateway.register_trusted_turn(BASE,text)
        other={**BASE,"turn_id":"second_turn"}
        with self.assertRaisesRegex(TrustedIngressError,"overlapping"):
            self.gateway.register_trusted_turn(other,"What did QEV-73 record?")
        self.assertEqual(self.gateway.resolve_tool_call(text,BASE)["status"],"UNIQUE")
        self.gateway.register_trusted_turn(other,"What did QEV-73 record?")
        self.assertEqual(self.gateway.resolve_tool_call(
            "What did QEV-73 record?",other)["status"],"UNIQUE")

    def test_two_sessions_independent_even_when_turn_ids_equal(self):
        one="What did Merrow record?"
        two="What did SOVA-88 record?"
        b={**BASE,"session_id":"another_synthetic_chat"}
        self.gateway.register_trusted_turn(BASE,one)
        self.gateway.register_trusted_turn(b,two)
        self.assertEqual(self.gateway.active_turn_count,2)
        self.assertEqual(self.gateway.resolve_tool_call(two,b)["conversation_ids"],
                         ["sova_container"])
        self.assertEqual(self.gateway.resolve_tool_call(one,BASE)["conversation_ids"],
                         ["merrow_prism"])

    def test_earlier_turn_context_not_implicitly_reused(self):
        question="What did Merrow record?"
        self.gateway.register_trusted_turn(BASE,question)
        self.assertEqual(self.gateway.resolve_tool_call(question,BASE)["status"],"UNIQUE")
        newer={**BASE,"turn_id":"later_turn"}
        self.gateway.register_trusted_turn(newer,"Did she actually say it?")
        self.assertEqual(self.gateway.resolve_tool_call(
            "Did she actually say it?",newer)["status"],"UNANCHORED")
        self.assertEqual(self.gateway.resolve_tool_call(question,BASE)["status"],"NO_BOUND_TURN")

    def test_source_integrity_corruption_fails_closed(self):
        question="What did Merrow record?"
        self.gateway.register_trusted_turn(BASE,question)
        with sqlite3.connect(self.db) as db:
            db.execute("UPDATE messages SET author_role='assistant' WHERE message_id='g03'")
        with self.assertRaises(SourceIntegrityError):
            self.gateway.resolve_tool_call(question,BASE)
        self.assertEqual(self.gateway.resolve_tool_call(question,BASE)["status"],
                         "NO_BOUND_TURN")

    def test_model_supplied_pretend_session_never_authorises(self):
        question="Did she actually say it?"
        self.gateway.register_trusted_turn(BASE,question)
        spoofed='session_id=synthetic_chat_a turn_id=synthetic_turn_a "Vela"'
        self.assertEqual(self.gateway.resolve_tool_call(spoofed,BASE)["status"],
                         "MODEL_ARGUMENT_MISMATCH")

    def test_invalid_owner_message_rejected(self):
        for question in (None,"","  ",13,[],{}):
            with self.subTest(question=question),self.assertRaises(TrustedIngressError):
                self.gateway.register_trusted_turn(BASE,question)

    def test_invalid_owner_context_rejected(self):
        for context in (None,{},{"user_id":"x"}, {**BASE,"turn_id":""},
                        {**BASE,"session_id":"x "*100}):
            with self.subTest(context=context),self.assertRaises(TrustedIngressError):
                self.gateway.register_trusted_turn(context,"What did Merrow record?")

    def test_registry_returns_no_user_text_in_denial(self):
        question="Did she actually say it?"
        self.gateway.register_trusted_turn(BASE,question)
        result=self.gateway.resolve_tool_call("What did Vela say?",BASE)
        body=json.dumps(result)
        self.assertNotIn(question,body)
        self.assertNotIn("What did Vela say?",body)
        self.assertNotIn("synthetic_user_a",body)
        self.assertEqual(result["source_count"],0)
