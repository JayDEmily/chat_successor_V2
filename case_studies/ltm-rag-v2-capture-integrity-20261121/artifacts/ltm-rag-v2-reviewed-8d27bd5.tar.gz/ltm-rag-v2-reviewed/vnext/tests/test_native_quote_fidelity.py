"""Offline negative and positive tests for retrospective synthetic quote auditing."""
from __future__ import annotations

import json
import unittest

from scripts import audit_native_quote_fidelity as auditor


class QuoteFidelityTests(unittest.TestCase):
    def setUp(self) -> None:
        self.fixture = json.loads(auditor.SOURCE.read_text(encoding="utf-8"))
        self.plan = json.loads(auditor.PLAN.read_text(encoding="utf-8"))
        self.by_mid = {m["message_id"]: m for m in self.fixture["messages"]}
        self.results = []
        for ordinal, case in enumerate(self.plan["cases"], 1):
            if case["kind"] == "history":
                text = " ".join(
                    auditor.source_span(self.by_mid[mid], mode)
                    for mid, mode in auditor.TARGETS[case["id"]]
                )
            else:
                text = "Unrelated physics answer."
            self.results.append({
                "id": case["id"], "completed": True, "answer_excerpt": text,
                "fetch_count": 1 if case["kind"] == "history" else 0,
                "lookup_count": 1 if case["kind"] == "history" else 0,
                "ordinal": ordinal,
            })

    def test_exact_spans_are_preserved(self) -> None:
        rows = auditor.audit(self.fixture, self.plan, self.results)
        self.assertEqual(len(rows), 10)
        self.assertEqual(sum(r["all_exact"] for r in rows), 10)
        self.assertEqual(sum(len(r["targets"]) for r in rows), 13)

    def test_quote_mark_substitution_is_not_exact(self) -> None:
        original = self.by_mid["m3"]["exact_text"]
        changed = original.replace("\u201c", "\u2018").replace("\u201d", "\u2019")
        self.assertNotEqual(original, changed)
        self.assertEqual(auditor.compare_span(original, changed), "punctuation_only")

    def test_word_substitution_not_misclassified_as_punctuation(self) -> None:
        original = self.by_mid["m3"]["exact_text"]
        changed = original.replace("library", "drawer")
        self.assertEqual(auditor.compare_span(original, changed), "not_observed")

    def test_inner_direct_speech_is_a_contiguous_source_span(self) -> None:
        source = self.by_mid["m1"]
        expected = "\u201cThe blue notebook is on the train.\u201d"
        self.assertEqual(auditor.source_span(source, "speech"), expected)

    def test_rejects_incomplete_trial(self) -> None:
        with self.assertRaisesRegex(ValueError, "complete"):
            auditor.audit(self.fixture, self.plan, self.results[:-1])

    def test_rejects_reordered_results(self) -> None:
        self.results[0], self.results[1] = self.results[1], self.results[0]
        with self.assertRaisesRegex(ValueError, "order"):
            auditor.audit(self.fixture, self.plan, self.results)

    def test_rejects_clipped_excerpt(self) -> None:
        self.results[0]["answer_excerpt"] = "a" * 1200
        with self.assertRaisesRegex(ValueError, "truncated"):
            auditor.audit(self.fixture, self.plan, self.results)

    def test_rejects_unregistered_source_reference(self) -> None:
        previous = auditor.TARGETS
        try:
            auditor.TARGETS = {**previous, "H01": (("m4", "full"),)}
            with self.assertRaisesRegex(ValueError, "not in registered"):
                auditor.audit(self.fixture, self.plan, self.results)
        finally:
            auditor.TARGETS = previous

    def test_report_does_not_claim_trial_rescoring(self) -> None:
        rows = auditor.audit(self.fixture, self.plan, self.results)
        report = auditor.format_report(rows)
        self.assertIn("RETROSPECTIVE", report.upper())
        self.assertIn("13/13", report)
        self.assertIn("H03", report)
        self.assertIn("H10", report)


if __name__ == "__main__":
    unittest.main()
