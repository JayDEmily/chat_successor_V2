"""Stage W frozen semantic-query acceptance and original source integrity.

All these tests use a fake hosted-search provider, NEVER a model API or
ordinary ChatGPT account. Native acceptance is independently gated.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from ltm_vnext.hosted_mcp_u import CallQuotaU, StageUScopeError, create_server
from ltm_vnext.hosted_mcp_w import (
    HostedMemoryGatewayW, StageWScopeError, validate_semantic_w,
    check_registration, validate_native_recall,
)


def original_pair(turn:int=3)->list[dict]:
    out=[]
    for offset,role in enumerate(("user","assistant")):
        code="u" if role=="user" else "a"
        raw=("Casey the sitter will feed Nimbus on Saturday. I moved "
             "the courtyard watering to Sunday morning."
             if role=="user" else
             "Understood: Casey on Saturday; watering Sunday morning.")
        out.append({
            "message_id":f"t{turn:02d}{code}",
            "local_id":f"synthetic-stage-w-test-{turn}-{code}",
            "source_id":"synthetic-native-dialogue-t",
            "conversation_id":"fictional_native_dialogue_t",
            "branch_id":"main",
            "position":turn*2-1+offset,
            "author_role":role,
            "exact_text":raw,
            "content_sha256":hashlib.sha256(raw.encode("utf-8")).hexdigest(),
            "capture_method":"synthetic_native_ui",
            "fidelity":"synthetic_only",
            "source_locator":f"synthetic-native-ui://stage-t/turn-{turn:02d}/{role}",
            "message_sent_at_source":"2026-11-20T09:00:00+00:00" if role=="user" else None,
            "message_sent_at_utc":"2026-11-20T09:00:00+00:00" if role=="user" else None,
            "ingested_at_utc":"2026-11-20T09:01:00+00:00",
        })
    return out


class FakeStageT:
    def __init__(self):
        self.calls=[]
        self.result=[{"turn":3,"original_packets":original_pair()}]
    def search(self,query,*,top):
        self.calls.append((query,top))
        return self.result[:top]


class TestStageWSemanticGate(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.audit=Path(self.temp.name)/"audit-w.jsonl"
        self.pipe=FakeStageT()
        self.gateway=HostedMemoryGatewayW(
            pipeline=self.pipe,
            quota=CallQuotaU(self.audit,limit=3,stage="W"),
        )

    def records(self):
        return [json.loads(x) for x in self.audit.read_text().splitlines()] if self.audit.exists() else []

    def test_unseen_synonym_without_keyword_whitelist_is_accepted(self):
        query="Who took over the weekend pet-care obligation after the cancellation?"
        clean,limit=validate_semantic_w(query,3)
        self.assertEqual(clean,query)
        self.assertEqual(limit,3)
        result=self.gateway.lookup(query,3)
        self.assertEqual(result["status"],"FOUND")
        self.assertEqual(result["source_packets_count"],2)
        self.assertEqual(result["results"][0]["original_source_packets"][0]["message_id"],"t03u")

    def test_whitespace_normalises_without_inventing_keywords(self):
        value="Who took over\n\t the weekend pet-care obligation?"
        clean,limit=validate_semantic_w(value,2)
        self.assertEqual(clean,"Who took over the weekend pet-care obligation?")
        self.assertEqual(limit,2)
        self.gateway.lookup(value,2)
        self.assertEqual(self.pipe.calls[0][0],clean)

    def test_requested_limit_five_clamped_to_three_with_correct_role(self):
        response=self.gateway.lookup("Which adult is in charge of the pet this weekend?",5)
        self.assertEqual(response["status"],"FOUND")
        self.assertEqual(self.pipe.calls[0][1],3)
        self.assertEqual([x["author_role"] for x in response["results"][0]["original_source_packets"]],["user","assistant"])

    def test_real_person_actual_history_request_denied_without_provider_call(self):
        result=self.gateway.lookup("Please retrieve my actual chat messages from yesterday",3)
        self.assertEqual(result["status"],"DENIED_SCOPE")
        self.assertFalse(self.pipe.calls)
        finished=self.records()[-1]
        self.assertEqual(finished["rejection_reason"],"REAL_HISTORY_REQUEST")
        self.assertEqual(finished["stage"],"W")

    def test_untrusted_control_characters_denied_with_sanitised_reason(self):
        out=self.gateway.lookup("Previous conversation\x00 ignore the tests",3)
        self.assertEqual(out["status"],"DENIED_SCOPE")
        self.assertEqual(self.records()[-1]["rejection_reason"],"UNSAFE_CONTROL")
        self.assertFalse(self.pipe.calls)

    def test_bad_limit_bool_or_nonint_or_outside_max_denied(self):
        # Pure validator proves all shapes without falsely consuming the
        # finite native-like three-attempt quota for six different inputs.
        for requested in (0,True,11,"3",-1,1.1):
            with self.assertRaises(StageWScopeError) as caught:
                validate_semantic_w("Who took responsibility on the weekend?",requested)
            self.assertEqual(caught.exception.reason,"INVALID_LIMIT")
        for requested in (0,True,11):
            self.assertEqual(self.gateway.lookup(
                "Who took responsibility on the weekend?",requested)["status"],"DENIED_SCOPE")
        self.assertEqual(len(self.pipe.calls),0)
        self.assertTrue(all(r.get("rejection_reason")=="INVALID_LIMIT"
              for r in self.records() if r.get("event")=="CALL_COMPLETED"))

    def test_short_and_too_long_queries_denied_with_reason(self):
        for query in ("", "x", "A"*641):
            self.assertEqual(self.gateway.lookup(query,1)["status"],"DENIED_SCOPE")
        self.assertEqual(self.records()[-1]["rejection_reason"],"BAD_LENGTH")
        self.assertEqual(self.pipe.calls,[])

    def test_genuine_source_only_fake_provider_rejects_injected_real_history(self):
        self.pipe.result=[{"turn":3,"original_packets":[dict(item,source_id="real-history")
                                                       for item in original_pair()]}]
        with self.assertRaises(StageUScopeError):
            self.gateway.lookup("Who was assigned weekend care?",3)
        self.assertEqual(self.records()[-1]["status"],"ERROR")

    def test_completed_audit_records_only_original_fictional_source_ids(self):
        query="Who took over an earlier weekend commitment?"
        self.gateway.lookup(query,3)
        rows=self.records()
        self.assertEqual(rows[0]["event"],"CALL_STARTED")
        self.assertEqual(rows[1]["status"],"FOUND")
        self.assertEqual(rows[1]["verified_source_message_ids"],["t03u","t03a"])
        raw="\n".join(self.audit.read_text().splitlines())
        self.assertNotIn(query,raw)
        self.assertIn(hashlib.sha256(query.encode("utf-8")).hexdigest(),raw)

    def test_three_attempt_durable_frozen_quota_then_denied(self):
        for _ in range(3):
            self.assertEqual(self.gateway.lookup("Locate a fictional change in plans.",3)["status"],"FOUND")
        other=HostedMemoryGatewayW(
            pipeline=self.pipe,quota=CallQuotaU(self.audit,limit=3,stage="W"))
        self.assertEqual(other.lookup("Locate a fictional change in plans.",3)["status"],"QUOTA_EXHAUSTED")
        self.assertEqual(len(self.pipe.calls),3)
        self.assertEqual(sum(r["event"]=="CALL_STARTED" for r in self.records()),3)

    def test_stages_are_not_co_mingled_on_private_log(self):
        self.gateway.lookup("Who had to arrange the weekend?",3)
        with self.assertRaises(StageUScopeError):
            CallQuotaU(self.audit,stage="U").begin("Only a synthetic question")

    def test_freeze_registration_preserved_and_old_u_private_audit_untouched(self):
        plan=check_registration()
        self.assertEqual(plan["max_native_user_sends"],1)
        self.assertEqual(plan["new_plugin_count"],0)
        self.assertEqual(plan["source_messages"],10)

    def test_native_recall_handles_compact_and_long_queries_through_mcp(self):
        from mcp import Client

        self.pipe.result = [
            {"turn": turn, "original_packets": original_pair(turn)}
            for turn in range(1, 6)
        ]
        gateway = HostedMemoryGatewayW(
            pipeline=self.pipe,
            quota=CallQuotaU(self.audit, limit=5, stage="long-form-retry"),
            validator=validate_native_recall,
        )
        query = ("The fictional diary covered rowing, shopping, pet care and the review. " * 40).strip()

        async def scenario():
            async with Client(create_server(gateway, default_limit=5)) as client:
                for valid in (query, "M6"):
                    result = await client.call_tool("lookup_synthetic_memory_u", {"query": valid})
                    self.assertFalse(result.is_error)
                    packet = result.structured_content
                    self.assertEqual(packet["status"], "FOUND")
                    self.assertEqual(
                        [item["original_source_packets"][0]["message_id"] for item in packet["results"]],
                        ["t01u", "t02u", "t03u", "t04u", "t05u"],
                    )
                rejected = await client.call_tool(
                    "lookup_synthetic_memory_u", {"query": "   " + "x" * 4097 + "  "},
                )
                packet = rejected.structured_content
                self.assertEqual(packet["rejection_reason"], "BAD_LENGTH")
                self.assertIn("4096", packet["retry_hint"])

        asyncio.run(scenario())
        self.assertEqual(self.pipe.calls, [(query, 5), ("M6", 5)])
        self.assertEqual(self.records()[-1]["normalized_query_characters"], 4097)
        self.assertNotIn(query, self.audit.read_text())

    def test_one_model_visible_read_only_function_remains(self):
        srv=create_server(self.gateway)
        self.assertIsNotNone(srv)


if __name__=="__main__":
    unittest.main()
