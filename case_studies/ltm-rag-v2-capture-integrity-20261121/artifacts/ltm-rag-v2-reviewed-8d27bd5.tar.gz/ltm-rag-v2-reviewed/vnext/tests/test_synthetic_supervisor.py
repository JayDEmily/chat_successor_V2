"""Deterministic, non-network tests for bounded synthetic-only process supervision."""
from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from scripts import supervise_synthetic_services as supervisor


class RestartBudgetTests(unittest.TestCase):
    def test_allows_three_starts_in_window_then_rejects(self) -> None:
        budget = supervisor.RestartBudget(limit=3, window_seconds=120)
        self.assertTrue(budget.admit(100.0))
        self.assertTrue(budget.admit(101.0))
        self.assertTrue(budget.admit(102.0))
        self.assertFalse(budget.admit(103.0))

    def test_budget_expires_at_window_boundary(self) -> None:
        budget = supervisor.RestartBudget(limit=2, window_seconds=10)
        self.assertTrue(budget.admit(1.0))
        self.assertTrue(budget.admit(5.0))
        self.assertFalse(budget.admit(9.0))
        self.assertTrue(budget.admit(11.0))
        self.assertTrue(budget.admit(15.0))

    def test_budget_tracks_only_actual_admissions(self) -> None:
        budget = supervisor.RestartBudget(limit=1, window_seconds=10)
        self.assertTrue(budget.admit(5.0))
        self.assertFalse(budget.admit(6.0))
        self.assertFalse(budget.admit(7.0))
        self.assertTrue(budget.admit(15.0))


class SyntheticScopeTests(unittest.TestCase):
    def test_current_fixture_is_explicitly_synthetic(self) -> None:
        supervisor.assert_synthetic_fixture()

    def test_rejects_non_synthetic_fixture(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fixture = Path(tmp) / "fake.json"
            fixture.write_text(json.dumps({
                "synthetic": False,
                "messages": [{"source_id": "synthetic-v1"}] * 6,
            }), encoding="utf-8")
            with mock.patch.object(supervisor, "FIXTURE", fixture):
                with self.assertRaisesRegex(RuntimeError, "Synthetic gate failed"):
                    supervisor.assert_synthetic_fixture()

    def test_rejects_unrecognised_source(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fixture = Path(tmp) / "fake.json"
            fixture.write_text(json.dumps({
                "synthetic": True,
                "messages": [{"source_id": "synthetic-v1"}] * 5
                + [{"source_id": "personal"}],
            }), encoding="utf-8")
            with mock.patch.object(supervisor, "FIXTURE", fixture):
                with self.assertRaisesRegex(RuntimeError, "unrecognised"):
                    supervisor.assert_synthetic_fixture()

    def test_child_inherits_no_openai_api_secrets(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            service = supervisor.ManagedService("synthetic-test", ["/bin/true"])
            with (
                mock.patch.object(supervisor, "LOCAL", Path(tmp)),
                mock.patch.object(supervisor, "record_event"),
                mock.patch.object(supervisor.subprocess, "Popen") as spawn,
                mock.patch.dict(os.environ, {
                    "OPENAI_ADMIN_KEY": "fake-admin",
                    "OPENAI_API_KEY": "fake-project",
                    "CONTROL_PLANE_API_KEY": "fake-control",
                    "SYNTHETIC_TEST_MARKER": "kept",
                }),
            ):
                service.start()
                passed_env = spawn.call_args.kwargs["env"]
                for key in ("OPENAI_ADMIN_KEY", "OPENAI_API_KEY", "CONTROL_PLANE_API_KEY"):
                    self.assertNotIn(key, passed_env)
                self.assertEqual(passed_env["SYNTHETIC_TEST_MARKER"], "kept")
                self.assertTrue(spawn.call_args.kwargs["start_new_session"])
                self.assertEqual(spawn.call_args.kwargs["stdin"], supervisor.subprocess.DEVNULL)
                service.log_stream.close()


if __name__ == "__main__":
    unittest.main()
