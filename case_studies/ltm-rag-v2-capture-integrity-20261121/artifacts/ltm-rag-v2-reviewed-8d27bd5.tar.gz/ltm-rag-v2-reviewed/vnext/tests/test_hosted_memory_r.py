"""Offline correctness/partial-failure tests for hosted Stage R indexing."""
from __future__ import annotations
import hashlib
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from ltm_vnext.hosted_memory_r import SyntheticConversationR, HostedRFailure

ROOT=Path(__file__).resolve().parents[1]
FIXTURE=ROOT/"fixtures/synthetic_diary_r_20261120.json"
EXPECTED_FIXTURE_SHA="6e2ce2a8c9a838c92dd9ca8d2add7163d1120cb1a5f6bc3710cbde35bfd44955"


class FakeOpenAIR:
    def __init__(self):
        self.project_files=[]
        self.attachments={}
        self.upload_calls=0
        self.attach_calls=0
        self.fail_attach_once=False
        self.fail_search=False
        self.override_search=None

    def files(self):
        return self.project_files[:]

    def upload_file(self, filename, data):
        self.upload_calls+=1
        record={"id":f"file-test-{self.upload_calls:03d}",
                "filename":filename,"sha256":hashlib.sha256(data).hexdigest()}
        self.project_files.append(record)
        return record

    def attachment(self, store_id, file_id):
        return self.attachments.get((store_id,file_id))

    def attach(self, store_id, file_id, attrs):
        self.attach_calls+=1
        if self.fail_attach_once:
            self.fail_attach_once=False
            raise HostedRFailure("SIMULATED_REMOTE_ATTACH_FAILURE")
        data={"file_id":file_id,"status":"completed","attributes":attrs}
        self.attachments[(store_id,file_id)]=data
        return data

    def search(self, store_id, query, *, max_results=10):
        if self.fail_search:
            return {"nonsense":True}
        if self.override_search is not None:
            return self.override_search
        return {"data":[{"file_id":f["id"],"score":0.75,"content":[
            {"type":"text","text":"UNTRUSTED_PROVIDER_TEXT"}]}
            for f in self.project_files[:max_results]]}


class TestHostedMemoryR(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix="r-hosted-offline-")
        self.addCleanup(self.temp.cleanup)
        self.api=FakeOpenAIR()
        self.db=Path(self.temp.name)/"synthetic.sqlite"
        self.pipeline=SyntheticConversationR(self.db,FIXTURE,self.api,"vs_test_fake")

    def test_01_fixture_frozen(self):
        self.assertEqual(hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),
                         EXPECTED_FIXTURE_SHA)
        self.assertEqual(len(self.pipeline.expected),24)
        self.assertEqual(len(self.pipeline.by_turn),12)

    def test_02_incremental_storage_and_hosted_uploads(self):
        for turn in range(1,13):
            result=self.pipeline.index_turn(turn)
            self.assertEqual(result["turn"],turn)
            self.assertIs(result["indexed"],True)
            state=self.pipeline.validate_all_local()
            self.assertEqual(state["original_messages"],turn*2)
            self.assertEqual(state["indexed_turns"],list(range(1,turn+1)))
        self.assertEqual(self.api.upload_calls,12)
        self.assertEqual(self.api.attach_calls,12)

    def test_03_idempotent_indexing(self):
        for turn in range(1,9): self.pipeline.index_turn(turn)
        for turn in range(1,9): self.pipeline.index_turn(turn)
        self.assertEqual(self.api.upload_calls,8)
        self.assertEqual(self.api.attach_calls,8)
        self.assertEqual(self.pipeline.validate_all_local()["original_messages"],16)

    def test_04_original_roles_and_message_hashes(self):
        self.pipeline.index_turn(1)
        packets=self.pipeline.search_candidates("busy day")
        self.assertEqual(len(packets),1)
        user,assistant=packets[0]["source_packets"]
        self.assertEqual((user["author_role"],assistant["author_role"]),
                         ("user","assistant"))
        self.assertEqual((user["message_id"],assistant["message_id"]),
                         ("r01u","r01a"))
        for packet in (user,assistant):
            self.assertEqual(hashlib.sha256(packet["exact_text"].encode("utf-8")).hexdigest(),
                             packet["content_sha256"])
            self.assertEqual(packet["fidelity"],"synthetic_only")
        self.assertIs(packets[0]["candidate_only"],True)
        self.assertNotEqual(user["exact_text"],"UNTRUSTED_PROVIDER_TEXT")

    def test_05_correction_links_canonical(self):
        for turn in range(1,9):self.pipeline.index_turn(turn)
        user=self.pipeline._evidence(
            next(m["local_id"] for m in self.pipeline.expected.values()
                 if m["message_id"]=="r08u"))
        assistant=self.pipeline._evidence(
            next(m["local_id"] for m in self.pipeline.expected.values()
                 if m["message_id"]=="r08a"))
        self.assertEqual(user["supersedes_local_id"],next(
            m["local_id"] for m in self.pipeline.expected.values()
            if m["message_id"]=="r06u"))
        self.assertEqual(assistant["supersedes_local_id"],next(
            m["local_id"] for m in self.pipeline.expected.values()
            if m["message_id"]=="r06a"))

    def test_06_unknown_hosted_file_rejected(self):
        self.pipeline.index_turn(1)
        self.api.override_search={"data":[{"file_id":"file-unauthorised","score":1}]}
        with self.assertRaisesRegex(HostedRFailure,"Unrecognised hosted file"):
            self.pipeline.search_candidates("anything")

    def test_07_corrupted_original_packet_rejected(self):
        self.pipeline.index_turn(1)
        with sqlite3.connect(self.db) as db:
            db.execute("UPDATE messages SET exact_text=? WHERE message_id=?",
                       ("altered bytes","r01u"))
        with self.assertRaisesRegex(HostedRFailure,"integrity"):
            self.pipeline.search_candidates("busy day")

    def test_08_attachment_failure_retry_no_duplicate_upload(self):
        self.api.fail_attach_once=True
        with self.assertRaisesRegex(HostedRFailure,"SIMULATED"):
            self.pipeline.index_turn(1)
        self.assertEqual(self.api.upload_calls,1)
        self.pipeline.index_turn(1)
        self.assertEqual(self.api.upload_calls,1)
        self.assertEqual(self.api.attach_calls,2)
        self.assertEqual(self.pipeline.validate_all_local()["original_messages"],2)

    def test_09_orphan_uploaded_filename_reconciliation(self):
        filename,body,attrs=self.pipeline.payload(1)
        original_file=self.api.upload_file(filename,body)
        indexed=self.pipeline.index_turn(1)
        self.assertEqual(indexed["file_id"],original_file["id"])
        self.assertEqual(self.api.upload_calls,1)

    def test_10_duplicate_orphan_filename_refused(self):
        filename,body,attrs=self.pipeline.payload(1)
        self.api.upload_file(filename,body)
        self.api.upload_file(filename,body)
        with self.assertRaisesRegex(HostedRFailure,"Ambiguous duplicate"):
            self.pipeline.index_turn(1)

    def test_11_corrupt_hosted_envelope_rejected(self):
        self.pipeline.index_turn(1)
        self.api.fail_search=True
        with self.assertRaisesRegex(HostedRFailure,"Malformed search"):
            self.pipeline.search_candidates("busy day")

    def test_12_duplicate_hosted_file_candidate_deduplicated(self):
        self.pipeline.index_turn(1)
        file_id=self.api.project_files[0]["id"]
        self.api.override_search={"data":[{"file_id":file_id,"score":0.5},
                                            {"file_id":file_id,"score":0.3}]}
        hits=self.pipeline.search_candidates("busy day")
        self.assertEqual(len(hits),1)
        self.assertEqual(hits[0]["rank"],1)

    def test_13_wrong_turn_schema_fails_closed(self):
        data=json.loads(FIXTURE.read_text(encoding="utf-8"))
        data["messages"][1]["author_role"]="user"
        path=Path(self.temp.name)/"wrong_fixture.json"
        path.write_text(json.dumps(data),encoding="utf-8")
        with self.assertRaisesRegex(HostedRFailure,"Turn authorship"):
            SyntheticConversationR(Path(self.temp.name)/"other.sqlite",path,
                                   self.api,"vs_test_fake")

    def test_14_replay_with_changed_payload_refused(self):
        self.pipeline.index_turn(1)
        self.pipeline.by_turn[1][0]["exact_text"]="tampered"
        with self.assertRaisesRegex(HostedRFailure,"Changed turn payload"):
            self.pipeline.index_turn(1)

    def test_15_no_nonsynthetic_or_blank_queries(self):
        self.pipeline.index_turn(1)
        for bad in ("", "   ", None):
            with self.subTest(bad=bad),self.assertRaises(HostedRFailure):
                self.pipeline.search_candidates(bad)

    def test_16_search_result_source_metadata_separated(self):
        self.pipeline.index_turn(1)
        result=self.pipeline.search_candidates("old friend")
        self.assertEqual(len(result),1)
        self.assertEqual(set(result[0]),{
            "rank","turn_index","file_id","score","source_packets","candidate_only"})
        self.assertNotIn("content",result[0])

    def test_17_unmapped_local_source_rejected(self):
        self.pipeline.index_turn(1)
        with sqlite3.connect(self.db) as db:
            db.execute("INSERT INTO hosted_r_files(turn_index,file_id,filename,payload_sha256,user_local_id,assistant_local_id,completed) VALUES(?,?,?,?,?,?,1)",
                       (99,"file-not-real","h","hash","bad","bad"))
        self.api.override_search={"data":[{"file_id":"file-not-real","score":1}]}
        with self.assertRaises(HostedRFailure):
            self.pipeline.search_candidates("nonsense")


if __name__=="__main__":
    unittest.main()
