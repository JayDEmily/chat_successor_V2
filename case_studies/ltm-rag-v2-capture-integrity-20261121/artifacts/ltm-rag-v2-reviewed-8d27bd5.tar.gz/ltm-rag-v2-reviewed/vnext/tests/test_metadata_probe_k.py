"""Stage K synthetic metadata boundary tests, independent of connected plugins."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from ltm_vnext.metadata_probe_k import MetadataProbeK,create_server,TOOL_NAME


ROOT=Path(__file__).resolve().parents[1]
PLAN=ROOT/"MCP_METADATA_K_CASES_20261119.json"


class MetadataKTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.events=Path(self.tmp.name)/"test-events.jsonl"
        self.probe=MetadataProbeK(audit_path=self.events,ephemeral_key=b"k"*32)

    def test_frozen_10_cases_in_order(self):
        plan=json.loads(PLAN.read_text(encoding="utf8"))
        self.assertEqual(plan["expected_case_count"],10)
        self.assertEqual(len(plan["offline_cases"]),10)
        prior={}
        for index,case in enumerate(plan["offline_cases"],1):
            with self.subTest(id=case["id"]):
                self.assertEqual(case["id"],f"K{index:02d}")
                result,private=self.probe.inspect(
                    case["meta"],tool_arguments=case["tool_args"])
                self.assertEqual(result["session_present"],case["expected_session"])
                self.assertEqual(result["subject_present"],case["expected_subject"])
                self.assertEqual(result["usable_session_and_subject"],case["expected_usable"])
                self.assertEqual(result["native_user_text_attested"],False)
                self.assertEqual(result["raw_metadata_disclosed"],False)
                self.assertEqual(result["trust_boundary"],
                                 "CLIENT_SUPPLIED_META_NOT_TRUSTED_USER_MESSAGE")
                if "compare_to" in case:
                    compare=prior[case["compare_to"]]
                    self.assertEqual(
                        private["session_fingerprint"]==compare["session_fingerprint"],
                        case["expected_session_equal"])
                    self.assertEqual(
                        private["subject_fingerprint"]==compare["subject_fingerprint"],
                        case["expected_subject_equal"])
                if case.get("assert_no_raw_ids"):
                    body=json.dumps(result)
                    for original in ("fiction-session-A","fiction-user-A","Neverland"):
                        self.assertNotIn(original,body)
                prior[case["id"]]=private

    def test_explicit_tool_arguments_cannot_spoof_meta(self):
        args={"openai/session":"fake","openai/subject":"fake"}
        first,_=self.probe.inspect(None,tool_arguments=args)
        second,_=self.probe.inspect(None,tool_arguments=None)
        self.assertEqual(first,second)
        self.assertFalse(first["session_present"])

    def test_session_hash_stable_only_within_process(self):
        same=self.probe.fingerprint("fiction-session-A")
        self.assertEqual(same,self.probe.fingerprint("fiction-session-A"))
        other=MetadataProbeK(ephemeral_key=b"z"*32)
        self.assertNotEqual(same,other.fingerprint("fiction-session-A"))
        self.assertNotEqual(same,self.probe.fingerprint("fiction-session-B"))

    def test_empty_unicode_and_whitespace_invalid(self):
        for value in (None,1,False,[],""," "," x ","\t",str("a"*513)):
            with self.subTest(value=repr(value)):
                self.assertIsNone(self.probe.fingerprint(value))

    def test_fingerprint_avoids_raw_value(self):
        f=self.probe.fingerprint("fiction-session-A")
        self.assertNotIn("fiction-session-A",f)
        self.assertEqual(len(f),64)

    def test_elicitation_capability_not_ui_proof(self):
        flags,_=self.probe.inspect(None,capabilities={"elicitation":{}})
        self.assertTrue(flags["elicitation_capability_advertised"])
        self.assertFalse(flags["native_user_text_attested"])
        no,_=self.probe.inspect(None,capabilities={})
        self.assertFalse(no["elicitation_capability_advertised"])

    def test_pydantic_style_capabilities_supported(self):
        yes,_=self.probe.inspect(None,capabilities=SimpleNamespace(elicitation=object()))
        self.assertTrue(yes["elicitation_capability_advertised"])
        no,_=self.probe.inspect(None,capabilities=SimpleNamespace(elicitation=None))
        self.assertFalse(no["elicitation_capability_advertised"])

    def test_audit_event_contains_only_flags_and_ephemeral_fingerprints(self):
        flags,private=self.probe.inspect(
            {"openai/session":"fiction-session-A","openai/subject":"fiction-user-A",
             "openai/userLocation":{"city":"Neverland"}},
            tool_arguments={"question":"Sensitive test text"})
        event_id=self.probe.record(flags,private)
        recorded=json.loads(self.events.read_text().strip())
        self.assertEqual(recorded["event_id"],event_id)
        self.assertEqual(recorded["tool"],TOOL_NAME)
        self.assertEqual(recorded["session_fingerprint"],private["session_fingerprint"])
        for raw in ("fiction-session-A","fiction-user-A","Neverland","Sensitive test text"):
            self.assertNotIn(raw,self.events.read_text())
        self.assertFalse(recorded["native_user_text_attested"])

    def test_audit_mode_private(self):
        flags,private=self.probe.inspect(None)
        self.probe.record(flags,private)
        self.assertEqual(self.events.stat().st_mode & 0o777,0o600)

    def test_no_audit_path_still_returns_event_id(self):
        probe=MetadataProbeK(ephemeral_key=b"a"*32)
        flags,private=probe.inspect(None)
        self.assertTrue(probe.record(flags,private))

    def test_server_lists_only_one_tool(self):
        server=create_server(None)
        # Verified at actual MCP layer by separate HTTP smoke.
        self.assertEqual(server.name,"LTM-RAG-vNext-Metadata-K-Synthetic")

    def test_offline_cases_have_no_genuine_history(self):
        plan=json.loads(PLAN.read_text(encoding="utf8"))
        self.assertTrue(plan["synthetic_only"])
        text=json.dumps(plan)
        self.assertNotIn("real user name",text)
        self.assertNotIn("OPENAI_API_KEY",text)
        self.assertEqual(len(plan["native_probes"]),3)

if __name__=="__main__":
    unittest.main()
