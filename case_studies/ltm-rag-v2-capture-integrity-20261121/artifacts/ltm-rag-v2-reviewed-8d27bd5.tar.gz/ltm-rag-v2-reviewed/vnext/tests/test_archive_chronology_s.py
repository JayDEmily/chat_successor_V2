"""Chronology regression for synthetic SQLite source records.

Do not infer original send time from local ingestion time. The R fixture is
pre-registered and cannot be altered to fabricate original timestamps.
"""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

from ltm_vnext.archive import Archive, InvalidFixture, RecordConflict

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "fixtures/synthetic_conversations.json"
R = ROOT / "fixtures/synthetic_diary_r_20261120.json"


class ChronologyTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/"chrono.sqlite"
        self.archive=Archive.initialise(self.db)
        self.data=json.loads(FIXTURE.read_text(encoding="utf-8"))

    def fixture(self, data):
        target=Path(self.tmp.name)/"case.json"
        target.write_text(json.dumps(data,ensure_ascii=False),encoding="utf-8")
        return target

    def test_new_record_has_actual_utc_ingestion_timestamp(self):
        before=datetime.now(timezone.utc)
        self.archive.ingest_synthetic(FIXTURE)
        after=datetime.now(timezone.utc)
        packet=self.archive.timeline("synthetic-notebook","notebook") if False else None
        with sqlite3.connect(self.db) as db:
            stamps=[v[0] for v in db.execute("SELECT ingested_at_utc FROM messages")]
        self.assertEqual(len(stamps),6)
        for timestamp in stamps:
            self.assertIsInstance(timestamp,str)
            self.assertTrue(timestamp.endswith("Z"))
            parsed=datetime.fromisoformat(timestamp.replace("Z","+00:00"))
            self.assertGreaterEqual(parsed,before)
            self.assertLessEqual(parsed,after)

    def test_message_send_time_keeps_original_offset_and_canonical_utc(self):
        item=self.data["messages"][0]
        item["message_sent_at"]="2026-11-20T08:15:24+11:00"
        item["event_time"]="2026-11-18"
        item["time_precision"]="date"
        self.archive.ingest_synthetic(self.fixture(self.data))
        result=self.archive.fetch(Archive._validate(item)["local_id"])
        self.assertEqual(result["message_sent_at_source"],"2026-11-20T08:15:24+11:00")
        self.assertEqual(result["message_sent_at_utc"],"2026-11-19T21:15:24.000000Z")
        self.assertEqual(result["event_time"],"2026-11-18")
        self.assertEqual(result["time_precision"],"date")
        self.assertNotEqual(result["ingested_at_utc"],result["message_sent_at_utc"])

    def test_replay_does_not_change_capture_time(self):
        self.archive.ingest_synthetic(FIXTURE)
        with sqlite3.connect(self.db) as conn:
            before=list(conn.execute("SELECT local_id,ingested_at_utc FROM messages ORDER BY row_id"))
        self.assertEqual(self.archive.ingest_synthetic(FIXTURE)["inserted"],0)
        with sqlite3.connect(self.db) as conn:
            after=list(conn.execute("SELECT local_id,ingested_at_utc FROM messages ORDER BY row_id"))
        self.assertEqual(before,after)

    def test_original_message_send_timestamp_may_not_be_rewritten(self):
        msg=self.data["messages"][0]
        msg["message_sent_at"]="2026-11-20T08:15:24+11:00"
        self.archive.ingest_synthetic(self.fixture(self.data))
        msg["message_sent_at"]="2026-11-20T08:15:25+11:00"
        with self.assertRaises(RecordConflict):
            self.archive.ingest_synthetic(self.fixture(self.data))

    def test_naive_timestamp_rejected_without_partial_ingestion(self):
        self.data["messages"][2]["message_sent_at"]="2026-11-20T08:15:24"
        with self.assertRaisesRegex(InvalidFixture,"explicit UTC offset"):
            self.archive.ingest_synthetic(self.fixture(self.data))
        with sqlite3.connect(self.db) as conn:
            self.assertEqual(conn.execute("SELECT count(*) FROM messages").fetchone()[0],0)

    def test_unparseable_timestamp_rejected_without_partial_ingestion(self):
        self.data["messages"][1]["message_sent_at"]="2026-11-99T08:15:24+11:00"
        with self.assertRaisesRegex(InvalidFixture,"Invalid message_sent_at"):
            self.archive.ingest_synthetic(self.fixture(self.data))
        with sqlite3.connect(self.db) as conn:
            self.assertEqual(conn.execute("SELECT count(*) FROM messages").fetchone()[0],0)

    def test_timeline_respects_original_authored_order_not_ingestion_time(self):
        self.archive.ingest_synthetic(FIXTURE)
        one=self.data["messages"][0]
        branch=self.archive.timeline(one["source_id"],one["conversation_id"],one["branch_id"])
        self.assertEqual([p["position"] for p in branch],sorted(p["position"] for p in branch))
        self.assertEqual([p["message_id"] for p in branch],
                         [p["message_id"] for p in self.data["messages"]
                          if p["source_id"]==one["source_id"]
                          and p["conversation_id"]==one["conversation_id"]
                          and p["branch_id"]==one["branch_id"]])
        self.assertTrue(all("ingested_at_utc" in p for p in branch))

    def test_old_archive_migration_keeps_old_capture_timestamps_unknown(self):
        self.archive.ingest_synthetic(FIXTURE)
        with sqlite3.connect(self.db) as db:
            for col in ("message_sent_at_source","message_sent_at_utc","ingested_at_utc"):
                db.execute("ALTER TABLE messages DROP COLUMN "+col)
            db.commit()
        Archive.initialise(self.db)
        with sqlite3.connect(self.db) as db:
            counts=db.execute("SELECT count(*),count(ingested_at_utc) FROM messages").fetchone()
        self.assertEqual(counts,(6,0))
        self.assertEqual(self.archive.ingest_synthetic(FIXTURE)["inserted"],0)

    def test_frozen_r_fixture_has_24_capture_instants_and_unclaimed_send_time(self):
        self.assertEqual(Archive.initialise(self.db).ingest_synthetic(R)["inserted"],24)
        data=json.loads(R.read_text(encoding="utf-8"))
        self.assertTrue(all("message_sent_at" not in m for m in data["messages"]))
        with sqlite3.connect(self.db) as db:
            count,sent,captured=db.execute(
                "SELECT count(*),count(message_sent_at_utc),count(ingested_at_utc) FROM messages"
            ).fetchone()
        self.assertEqual((count,sent,captured),(24,0,24))
        timeline=self.archive.timeline("fictional-diary-r-20261120","fictional_diary_r")
        self.assertEqual(len(timeline),24)
        self.assertEqual([t["position"] for t in timeline],list(range(1,25)))
        self.assertEqual([t["author_role"] for t in timeline],["user","assistant"]*12)


if __name__=="__main__":
    unittest.main()
