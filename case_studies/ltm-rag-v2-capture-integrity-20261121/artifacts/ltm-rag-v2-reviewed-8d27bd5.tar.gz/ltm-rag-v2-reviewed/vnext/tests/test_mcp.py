"""Exercise MCP tool listing, annotations and structured lookup in-process."""
import asyncio
import tempfile
import unittest
from pathlib import Path

from ltm_vnext.archive import Archive

try:
    from mcp import Client
    from ltm_vnext.mcp_server import create_server
except ImportError:
    Client = None

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "fixtures" / "synthetic_conversations.json"


@unittest.skipIf(Client is None, "Install MCP SDK v2 for adapter tests")
class ReadOnlyMcpTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Path(self.tmp.name) / "synthetic.sqlite"
        archive = Archive.initialise(self.db)
        archive.ingest_synthetic(FIXTURE)

    def test_tools_and_read_only_metadata(self):
        async def scenario():
            async with Client(create_server(self.db)) as client:
                tools = (await client.list_tools()).tools
                self.assertEqual({x.name for x in tools},
                                 {"lookup_evidence", "fetch_source"})
                for tool in tools:
                    self.assertTrue(tool.annotations.read_only_hint)
                    self.assertFalse(tool.annotations.open_world_hint)
                result = await client.call_tool(
                    "lookup_evidence", {"query": "blue notebook", "limit": 5}
                )
                self.assertFalse(result.is_error)
                self.assertIsNotNone(result.structured_content)
                self.assertIn("synthetic_only", str(result.structured_content))
        asyncio.run(scenario())

    def test_source_fetch_protocol(self):
        async def scenario():
            with Archive(self.db)._read_db() as db:
                local_id = db.execute(
                    "SELECT local_id FROM messages WHERE message_id='m1'"
                ).fetchone()[0]
            async with Client(create_server(self.db)) as client:
                result = await client.call_tool(
                    "fetch_source", {"local_id": local_id}
                )
                self.assertFalse(result.is_error)
                self.assertIn("train", str(result.structured_content))
                self.assertIn("reported_recollection",
                              str(result.structured_content))
        asyncio.run(scenario())


if __name__ == "__main__":
    unittest.main()
