"""Deterministic safety checks of native F trace, independent of private ledger."""
from __future__ import annotations
import copy
import json
import unittest

from scripts import summarise_native_trial_f as trial

class NativeFTraceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.plan=json.loads(trial.PLAN.read_text(encoding="utf8"))

    def setUp(self):
        self.row={
            "id":"M01","kind":"missing","ordinal":1,
            "sent_at_utc":"2026-11-18T09:00:00+00:00",
            "observed_at_utc":"2026-11-18T09:00:20+00:00",
            "completed":True,
            "chat_url":"chatgpt.com/g/"+trial.PROJECT+"-ltm-rag-vnext-synthetic-trial/c/fictional-unique-uuid",
            "lookup_count":1,"fetch_count":0,
            "added_event_ids":["event-f1"],"trace_pass":True,
            "semantic_review":"PENDING",
        }
        self.events=[{"event_id":"event-f1","tool":"lookup_evidence",
                      "timestamp_utc":"2026-11-18T09:00:10+00:00"}]

    def test_valid_one_case_partial_is_not_complete(self):
        result=trial.analyse(self.plan,[self.row],self.events)
        self.assertEqual(result["cases"],1)
        self.assertFalse(result["complete"])
        self.assertEqual(result["counts"]["missing_trace_pass"],1)

    def test_unregistered_case_identity_is_rejected(self):
        altered=copy.deepcopy(self.row)
        altered["id"]="other"
        with self.assertRaisesRegex(ValueError,"Out-of-order"):
            trial.analyse(self.plan,[altered],self.events)

    def test_wrong_chatgpt_project_rejected(self):
        altered=copy.deepcopy(self.row)
        altered["chat_url"]="chatgpt.com/c/foreign"
        with self.assertRaisesRegex(ValueError,"Project"):
            trial.analyse(self.plan,[altered],self.events)

    def test_missing_audit_event_rejected(self):
        with self.assertRaisesRegex(ValueError,"unavailable"):
            trial.analyse(self.plan,[self.row],[])

    def test_fetch_is_not_miscounted_as_lookup(self):
        altered=[dict(self.events[0],tool="fetch_source")]
        with self.assertRaisesRegex(ValueError,"tool count"):
            trial.analyse(self.plan,[self.row],altered)

    def test_out_of_window_audit_rejected(self):
        altered=[dict(self.events[0],timestamp_utc="2026-11-18T09:08:00+00:00")]
        with self.assertRaisesRegex(ValueError,"outside"):
            trial.analyse(self.plan,[self.row],altered)

    def test_trace_pass_not_equivalent_to_semantic_pass(self):
        altered=copy.deepcopy(self.row)
        altered["semantic_review"]="PASS"
        with self.assertRaisesRegex(ValueError,"Semantic outcome"):
            trial.analyse(self.plan,[altered],self.events)

    def test_fabricated_trace_result_is_rejected(self):
        altered=copy.deepcopy(self.row)
        altered["trace_pass"]=False
        with self.assertRaisesRegex(ValueError,"trace score"):
            trial.analyse(self.plan,[altered],self.events)

if __name__=="__main__":
    unittest.main()
