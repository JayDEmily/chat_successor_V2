# Long-form normal ChatGPT recall trial

**The recap met the length target. Live archive recall failed.** The 515-word fictional dictation produced a 441-word recap and a separate source note, observed 79.268 seconds after sending. The unrelated control passed.

| Registered case | Browser result | Archive trace |
| --- | --- | --- |
| LF-N01 | Normal Chat submitted the 515-word dictation with the connector unselected. The recap covered Ryan and Emily, the M6 shopping list, the Casey and watering correction, and the possible missed yoga class. It identified the lack of a recorded clock time. | One of five attempts started, then returned `DENIED_SCOPE` with diagnostic `BAD_LENGTH`. Zero hosted results or original records were returned. |
| LF-N02 | A distinct normal chat answered the 18-word unrelated prompt in a 23-word sentence. | Zero archive attempts. |

The archive accepts semantic queries of 8 to 640 normalized characters. The rejected query's digest differed from the registered prompt and its whitespace-normalized form. The trace ends after the length rejection. The rendered source note attributed the wording to conversation history, displayed three original IDs as unverified, and attributed the matching SQLite ingestion timestamp to an earlier reply. The current turn retrieved none of the four required records.

The successful Chrome path started from the known ChatGPT HTTPS page in the dedicated test window. Keyboard navigation opened each fresh chat, and the accessible composer value matched the registered prompt before each send. Two durable send markers, both saved-chat captures, and the final audit snapshot are under ignored `vnext/.local/native-long-form`. The audit snapshot SHA-256 is `ac675d4b54f21fdd37382f983e1ef492330771b45f8adc4777ea963a0bff8f22`.

The [cases](NATIVE_RECALL_LONG_FORM_CASES_20261121.json) were committed and read back before the run at `f56bcd9c843cef8092eaebd74dc535bb44e4efee`. The tested candidate is `e1f9be615a592ee47c02f88bfbd28f230a4e7376` and used private plugin version 1.0.2. The core suite passed 244 tests with a simulated hosted readback for the Stage W core check. The shadow suite passed 40 tests. Startup separately verified the existing hosted store and local source through the private connector without consuming a retrieval attempt.

The prior skill content was restored byte for byte in release `1.0.3` and verified through the plugin registry. The original routing mode was restored on port 8792, and the existing private tunnel reported ready. The long-form launcher and frozen result remain available for later verification on this branch.
