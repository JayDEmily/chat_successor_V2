# vNext work scope

Keep new code inside vnext/. Legacy repository code and deployment are not a vNext design specification.
Use the 21 November 2026 complementary-memory review as the current architecture starting point: COMPLEMENTARY_MEMORY_REVIEW_20261121.md, reviews/20261121_complementary_memory/ADR_COMPLEMENTARY_MEMORY.md (still proposed), reviews/20261121_complementary_memory/GATES_AND_EVALS.md (G1-G10, not numbered implementation leaves), and reviews/20261121_complementary_memory/OFFLINE_CAPTURE_AND_RECOVERY.md for the capture priority. The 18 November report remains historical evidence.
Preserve original-source text and exact authorship separately from reported speakers, historical corrections and inferred interpretations.
All current fixtures are synthetic. Do not import real conversation history, call external inference APIs, create public endpoints or start a production ingestion service on this branch.
Prove a real native ChatGPT unprompted lookup before adding archival import or background researchers. A local unit test does not satisfy that gate.


## Standing continuation grant (owner, 20 November 2026)

Follow [CONTINUOUS_AUTONOMOUS_WORK.md](CONTINUOUS_AUTONOMOUS_WORK.md) for this synthetic-only vNext branch. Within each active ChatGPT turn, continue from one verified step to the next without stopping for ordinary preflight, stage registration, test completion or GitHub checkpoint. Publish evidence and keep moving where in scope; request input only for material authority, safety or identity boundaries. Never assume a background worker exists after the turn ends, and never reuse an exhausted native action budget. Preserve Stage L/P's distinction between synthetic app-only callbacks and authenticated owner-approved source scope.

## Hosted synthetic Vector Store grant — 20 November 2026

The owner explicitly created a separate OpenAI API project and project key and authorised one hosted Vector Store pilot for wholly fictional conversation data. This limited grant covers **Stage R Files/Vector Stores storage, automatic embedding/indexing and direct hosted search only**. Do not treat it as permission for a paid Responses/model inference call, genuine archive import, native ChatGPT capture or any production connector reconfiguration. The store has a 30-day last-active expiry and must preserve local SQLite as authoritative evidence. See [HOSTED_MEMORY_R_PROTOCOL_20261120.md](HOSTED_MEMORY_R_PROTOCOL_20261120.md) and its independent test result. **ChatGPT Work is prohibited in this project.**

## Bounded native simulated-chat capture grant — 20 November 2026

The owner explicitly authorised a dedicated **normal ChatGPT browser** synthetic conversation test: send fictional user prompts from the owner's signed-in account, observe the actual ChatGPT model's replies, append separate source-stamped user and model records to SQLite and index them into an isolated OpenAI hosted Vector Store. The five-send Stage S budget was fully consumed and its controller's initial assistant-source capture included a global ChatGPT UI footer; it **must not** be reused or claimed clean. The separate zero-send Stage T source recovery independently verified original native replies, created a separate canonical clean SQL/index and passed exact source and provider readback. See [Stage S](NATIVE_DIALOGUE_S_RESULTS_20261120.md) and [Stage T](NATIVE_DIALOGUE_T_RESULTS_20261120.md). This does **not** authorise genuine ChatGPT history import, unprompted cross-chat extraction, additional Native S/T messages, background capture, public services, paid model inference or ChatGPT Work.


## Stage S/T bounded native synthetic conversation authority — 20 November 2026

The owner expressly authorised a *single real ChatGPT native UI* synthetic conversation, with the automation controller speaking for a **fictional** user and capturing genuine model responses. The five-message finite Stage S budget is **now exhausted**: do not resend, replay or infer additional authorised native sends from this trial. Stage S initial assistant captures included non-model-authored page footer text and thus are **PARTIAL source-fidelity evidence**, despite successful hosted search. Stage T, with **zero** additional ChatGPT sends, independently reread the same conversation, checked the exact original words, and built a distinct clean SQLite + hosted Vector Store index. Use [NATIVE_DIALOGUE_T_RESULTS_20261120.md](NATIVE_DIALOGUE_T_RESULTS_20261120.md) for the accepted clean source boundary. The original S raw captures and five-file hosted index remain frozen as forensic evidence; no retrofit of S's pass verdict is allowed. The simulated user's role is NOT attested human ownership. Actual assistant server-send timestamps and cross-chat automatic vector retrieval have NOT been proved. No real-history import, production deployment, additional project API model inference, ChatGPT Work, background daemon or OS autostart is authorised.


## Frozen development/review/merge process (owner direction, 21 November)

The repository-root [GUARDRAILS.md](../GUARDRAILS.md) and [AGENTS.md](../AGENTS.md) define the worker -> fresh independent tester -> PR -> GitHub Actions -> authorised merge loop. Read them before selecting a task. The worker develops and commits in Ubuntu, publishes a pinned GitHub candidate, and cannot self-certify; a distinct ChatGPT thread independently reviews it. After reviewer clearance, submit a PR, require actual passing Ubuntu Actions checks, and only then merge under applicable authority. A failed review returns a bounded defect to the worker. The proposed R2 CI checks a reproducible synthetic subset; neither a passing PR run nor automatic LTM-specific reviewer launch has been established.

The 20 November continuous-work grant continues to restrict synthetic data, native-send budgets, credentials and deployment. Its former Stage P/Q 'next engineering sequence' was written before the 21 November Astra review and is historical priority guidance, not permission to bypass the newer capture-first architectural assessment. The original 21 November ADR is proposed until the owner separately accepts it. There is no accepted numbered LTM-RAG leaf plan yet; do not invent it from the gate table.
