# Stage J decision — native message authenticity versus conditional owner-controlled ingress

**19 November 2026 | Evidence status: documentary verification + offline prototype only**

**Decision: ACCEPT_SHADOW_TRUSTED_INGRESS_CONDITIONAL_ONLY; NATIVE_CHATGPT_ORIGINAL_USER_INPUT_UNVERIFIED.**

Stage I’s 16 native results, including I05/I15 unsupported unique referent selections, stand unchanged. Do not describe Stage J as a native repair, a production ingestion design, an automatic memory solution, or a validated ChatGPT host integration.

## 1. Primary-source technical findings

| Mechanism | Official evidence | What is established | What is not established |
|---|---|---|---|
| MCP `tools/call.arguments` | [OpenAI Plugins MCP server](https://developers.openai.com/plugins/concepts/mcp-server) | The model selects the tool and supplies its arguments | Argument `question` is *not* automatically the user's exact latest message |
| ChatGPT MCP `_meta["openai/session"]` | [OpenAI Plugins reference](https://developers.openai.com/plugins/reference) | Anonymised **conversation identifier** for correlating tool calls | Not a per-turn original prompt, integrity signature, identity proof or Project-wide memory identifier |
| ChatGPT MCP `_meta["openai/subject"]` | Same reference | Anonymised user identifier for rate limiting/identification | Not attestation of user-message content; no tested guarantee of presence on this connector |
| MCP server-side checks | [OpenAI Plugins build guide](https://developers.openai.com/plugins/build/mcp-server) | Enforce request authorisation in server, do not treat tool annotations as auth | Read-only annotation, source hash, prompt instruction, or extra source fetch cannot attest an input message |
| MCP conversation exposure | [OpenAI Realtime MCP guide](https://developers.openai.com/api/docs/guides/realtime-mcp) | Remote MCP does not automatically receive the full conversation; model-sent data can be exposed through calls | No documented ChatGPT custom-MCP field for exact host-attested current user text found in the inspected documentation |
| Owned agent/app controller | [OpenAI Responses API](https://developers.openai.com/api/docs/guides/migrate-to-responses) and [Agents guardrails](https://developers.openai.com/api/docs/guides/agents/guardrails-approvals) | An application can supply its own user-role input and run input/tool checks | Does not establish the existing ChatGPT native plugin can obtain that independent owner message |
| User clarification | [OpenAI Plugins build guide](https://developers.openai.com/plugins/build/mcp-server) | MCP elicitation is documented for requesting otherwise missing information | Whether a particular native ChatGPT plugin build will present and authenticate this flow has **not** been tested |
| Data minimisation | [OpenAI Plugins security](https://developers.openai.com/plugins/guides/security-privacy) | Validate model input and avoid requesting wholesale conversation transcripts as a workaround | No permission to ingest genuine conversation history in this project |

These primary sources were consulted on 19 November 2026. Their described protocol fields and API controls are documentary facts; live I did not log or verify the metadata fields. **I do not know whether a different ChatGPT host interface can furnish independently authenticated original user-message content.** The inspected documented ChatGPT custom-MCP contract does not establish one.

## 2. Reproduced conditional Stage J result

Frozen before implementation at [Git registration `0628a23`](https://github.com/JayDEmily/LTM_RAG/commit/0628a238a6f2bf80323cc9c58bfa53f6a670e059), parent `d83695fb4a10944311eaa7bd9c7a919521abc5de`.

- **26/26** preregistered synthetic shadow decisions passed independently. Five original messages with no anchors returned no packets; nine model-argument mismatches released no original text; five genuine single-record and two multi-record requests returned exactly their original packets; five missing/wrong-bound-turn contexts were denied. Original source SHA-256, exact Unicode text, branch, authorship and reported-speaker metadata were rechecked independently.
- **16 new dedicated unit tests** cover replay, duplicate binding, overlapping same-session turns, per-session isolation, wrong principal/turn, model-injected context, changed spacing/case, unchanged original source packets and corrupted SQLite. **134/134** full core and **40/40** shadow regressions passed.
- `ltm_vnext/trusted_turn_j.py` is a **pure in-process shadow module**. It contains no MCP server, HTTP listener, remote attestation mechanism, tool-name registration, external model inference or production source ingestion. It assumes owner-controlled caller code has received and stored an authentic user message **before** tool selection; no test demonstrates that this prerequisite exists for native ChatGPT.
- The simulated model only controls `model_question`. The out-of-band owner context and stored exact original user text are separate. If those values do not agree, the shadow gate releases zero source packets and consumes the turn. It is structurally impossible for a model-controlled question **alone** to create an owner binding in this particular harness.

The [independent audit](TRUSTED_TURN_J_OFFLINE_RESULTS_20261119.md) and [frozen plan](TRUSTED_TURN_J_CASES_20261119.json) contain exact case-level outcomes.

## 3. Recommended engineering direction

For a **hard, deterministic** referent-selection guarantee, the strongest supported approach is an **application-owned turn ingress**, where the app holds the actual current user text prior to model execution. Apply existing H source-grounded anchors to that text; allow the assistant to request evidence, but **never let the assistant supply the authority for which conversation the user meant**. Apply an immutable per-turn scope and server-side source-integrity checks. Responses API / Agents SDK documentation gives an implementation path when the app owns its input; a future design must separately authenticate its client, scope every turn and test concurrency/replay. This path is not authorised for external inference or production integration now.

For **the current ChatGPT custom plugin**, treat `openai/session` as optional correlation only; it cannot silently supply an exact message, and a past Project chat cannot be assumed to identify the current referent. Until a verified host-attested input route or a separately tested direct-user clarification flow exists, retain Stage I only as experimental synthetic retrieval and **do not treat model prompting as a guaranteed ambiguity gate**.

**Next bounded task:** independently test **metadata presence/transport and user elicitation capability** in a new synthetic-only connector without touching the old services; preregister its protocols first. A metadata-presence test would establish at most whether `openai/session` exists for calls; it would not establish the authenticity of user text. If a direct clarification flow is available, test whether a user *explicitly* chose a fictional referent without conflating that with an attested copy of earlier prompt text.

No real history import, key creation, operating-system autostart, production deployment, change to 8787/8788/8789, or native Stage I replay has occurred in Stage J.
