# Native ChatGPT retrieval reliability trial B — pre-registration

**Scope:** 20 fully fictional, short conversational prompts in the user's existing authenticated ChatGPT Plus account, using only the dedicated ChatGPT Project `LTM-RAG vNext Synthetic Trial`. The tool server serves the same 6 invented fixture messages. No import of actual conversations or deployment changes.

## Locked design before first trial message

- Source fixture: `vnext/fixtures/synthetic_conversations.json`, six synthetic messages from two fictional conversations.
- Exact test inputs and fixed order: `RELIABILITY_TRIAL_B_20261118.json`. The JSON is committed **before execution**; no adaptive or cherry-picked prompts.
- Ten `history` cases and ten `unrelated` controls, **alternating in the stated order**. Controls deliberately share lexical terms with the fictional source to test over-eager retrieval.
- Each case starts from a **new conversation within the dedicated synthetic ChatGPT Project**, to avoid previous answers serving as evidence. Every prompt omits both the plugin name and instructions to select a tool. The tool must activate by itself if warranted.
- The same connected private plugin and existing Ubuntu tunnel are used throughout. No model API calls are initiated by the worker.
- Record the ChatGPT test conversation URL, actual model answer, audited `lookup_evidence` and `fetch_source` events (timestamps and IDs), and any failures or interruptions. The private local audit log contains no prompt or retrieved source text.

## Frozen primary scoring

- `history` **initiated retrieval** only if at least one successful `lookup_evidence` event is observed during that isolated turn. A plausible model answer without a matching server call is a failure.
- `history` **end-to-end evidence retrieval** only if at least one `fetch_source` event occurs and the answer contains each registered `expected_terms` marker, with the right attribution/branch mechanism when material. The registered `expected_message_ids` constrain later human evidence review but are not treated as proof solely because the model repeats an ID.
- `unrelated` **correctly selective** only if zero `lookup_evidence` calls occur during that turn, and the answer addresses the standalone question. A lookup without a fetch still counts as unnecessary.
- On an unavailable source, tool error or incomplete response: record as a failure rather than excluding the case. A UI/desktop automation break before any confirmed send is recorded separately as `not_executed` and the trial cannot be treated as a complete 20-turn dataset.
- No tool-chip / explicit-plugin selection is permitted. Do not transfer earlier model answers as source data.
- Duplicate attempted sends, unverified chat identity or concurrent other use of the same tunnel must be recorded as an ambiguous/incomplete case; do not silently repair the outcome.

## Measurement and uncertainty

- Initial descriptive initiation rate: count of history cases with successful lookup / 10.
- Initial unnecessary lookup rate: count of unrelated cases with lookup / 10.
- Relevant source-fetch and content/attribution scores are reported separately.
- Calculate two-sided Wilson 95% confidence intervals for the two binomial proportions, **without** using the small-sample point estimates as acceptance of a population-level reliability target.
- Astra's *proposed* later-stage thresholds: initiation at least 90% on history-needed turns, unnecessary searches at most 10% on unrelated turns. This 20-turn bounded stress-test is **insufficient by design to prove either population bound**, even if 20/20 outcomes are favourable.
- Any mid-run pause, timeout, response variation, tool errors or ambiguous classifications remain disclosed. Do not round untested cases into passes.

## Isolation and end condition

No unrelated browser project, user draft or conversation is modified. The existing GitHub working branch is the only authorised code publication target. Stop the native test runner on unexpected non-synthetic material, collision with other desktop use, repeated controller failure, or suspected duplicate sends; preserve the partial ledger. Only publish a complete verdict for the cases directly observed. Legacy AWS, API Access project, personal account history and production services are out of scope.

Registered before execution: 18 November 2026 AEDT.
