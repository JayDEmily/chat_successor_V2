# Referent Gate H — frozen synthetic offline evaluation

**Result: 38/38 frozen cases PASS; 0 FAIL.**
This is a conservative current-question narrative selector, **not a
native ChatGPT behaviour improvement**. The original MCP/ChatGPT
connectors were not changed or tested by this run.

## Pre-registration integrity

- Cases, source-manifest and protocol were frozen before code at Git
  commit 2e1535e40d0a9770037d7c47a8e5ba780402d247, whose parent is
  b68fd630b7c4f3c04322fe01a0f1385ede9967f9.
- All three preregistered files were compared byte-for-byte with
  that exact local Git commit by a separate read-only Python auditor.
- The original 20-message synthetic fixture SHA-256 was pinned to
  e3531da9538eb40dc41bec43f29c089f7aed7525ee574e84d21e469fabf9dcbf.
- Each manifest anchor was validated in the original main-branch
  user source message, not invented by retrieval or an assistant.

## Decisions observed

- Explicit UNIQUE: 16.
- UNANCHORED: 16, including both previously
  failing G13/G14 prompts and candidate-rank traps.
- MULTIPLE: 4; explicit comparison topics
  remain represented as multiple, not silently collapsed.
- EVIDENCE_MISMATCH: 2; an explicit
  topic was not replaced with a wrong retrieved candidate.

| Case | Category | Registered | Observed | Result |
|---|---|---|---|---|
| H01 | explicit_identifier | UNIQUE | UNIQUE | PASS |
| H02 | explicit_identifier | UNIQUE | UNIQUE | PASS |
| H03 | explicit_identifier | UNIQUE | UNIQUE | PASS |
| H04 | explicit_identifier | UNIQUE | UNIQUE | PASS |
| H05 | explicit_identifier | UNIQUE | UNIQUE | PASS |
| H06 | explicit_name | UNIQUE | UNIQUE | PASS |
| H07 | explicit_name | UNIQUE | UNIQUE | PASS |
| H08 | explicit_name | UNIQUE | UNIQUE | PASS |
| H09 | explicit_name | UNIQUE | UNIQUE | PASS |
| H10 | reported_speaker | UNIQUE | UNIQUE | PASS |
| H11 | multiple_explicit | MULTIPLE | MULTIPLE | PASS |
| H12 | multiple_explicit | MULTIPLE | MULTIPLE | PASS |
| H13 | multiple_explicit | MULTIPLE | MULTIPLE | PASS |
| H14 | unanchored | UNANCHORED | UNANCHORED | PASS |
| H15 | unanchored | UNANCHORED | UNANCHORED | PASS |
| H16 | unanchored | UNANCHORED | UNANCHORED | PASS |
| H17 | unanchored | UNANCHORED | UNANCHORED | PASS |
| H18 | unanchored | UNANCHORED | UNANCHORED | PASS |
| H19 | candidate_trap | UNANCHORED | UNANCHORED | PASS |
| H20 | candidate_trap | UNANCHORED | UNANCHORED | PASS |
| H21 | candidate_trap | UNANCHORED | UNANCHORED | PASS |
| H22 | candidate_trap | UNANCHORED | UNANCHORED | PASS |
| H23 | candidate_trap | UNANCHORED | UNANCHORED | PASS |
| H24 | wrong_candidate | EVIDENCE_MISMATCH | EVIDENCE_MISMATCH | PASS |
| H25 | wrong_candidate | EVIDENCE_MISMATCH | EVIDENCE_MISMATCH | PASS |
| H26 | candidate_overlap | UNIQUE | UNIQUE | PASS |
| H27 | substring_collision | UNANCHORED | UNANCHORED | PASS |
| H28 | substring_collision | UNANCHORED | UNANCHORED | PASS |
| H29 | substring_collision | UNANCHORED | UNANCHORED | PASS |
| H30 | substring_collision | UNANCHORED | UNANCHORED | PASS |
| H31 | branch_provenance | UNIQUE | UNIQUE | PASS |
| H32 | branch_provenance | UNIQUE | UNIQUE | PASS |
| H33 | reported_speech | UNIQUE | UNIQUE | PASS |
| H34 | reported_speech | UNIQUE | UNIQUE | PASS |
| H35 | unrelated_not_classified | UNANCHORED | UNANCHORED | PASS |
| H36 | unrelated_not_classified | UNANCHORED | UNANCHORED | PASS |
| H37 | multi_candidate_trap | MULTIPLE | MULTIPLE | PASS |
| H38 | explicit_candidate | UNIQUE | UNIQUE | PASS |

## Governing distinction and limits

A unique explicit topic identifies a **conversation to investigate**,
not a verified answer, a source relevance judgement or an authentic
spoken quotation. A user-reported recollection retains its original
authorship even when its reported speaker is named.

UNANCHORED means the question did not identify any of these five
fictional conversations. For a separately established historical
request, the consumer should clarify the referent; for a technical
question not requiring memory, the consumer can answer normally.
This selector deliberately **does not** classify history intent.

Contextual follow-ups within an authenticated, single conversation
are not yet supported. A ranking score or model-inferred synonym
cannot override a missing current-question referent. The five-topic
manifest is small, fixed and pre-known; performance does **not**
generalise to unknown stories, translations or ordinary conversation.

The original live six-record FTS5 tool and separate Trial G 20-record
tool already deliver full source text and provenance on lookup.
No additional fetch_source call is intrinsically necessary for
that tool contract, but lack of fetch cannot be relabelled as
two-tool compliance. Future native evaluation must separately
test actual model use of this kind of decision support.

No native test messages, new tunnel/client, public port, real data
import, external inference API use, original evidence rewrite or
operating-system startup change occurred in this offline stage.
