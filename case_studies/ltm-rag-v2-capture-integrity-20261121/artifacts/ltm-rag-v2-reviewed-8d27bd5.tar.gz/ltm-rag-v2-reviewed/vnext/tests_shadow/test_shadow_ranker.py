"""Offline unit tests for generic shadow candidate retrieval (no model download)."""
from __future__ import annotations
import copy
import json
import unittest
import numpy as np
from scripts import run_shadow_embeddings as shadow
from scripts import run_shadow_holdout_d as dtrial


class ShadowRankerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture=json.loads(dtrial.FIXTURE.read_text(encoding="utf-8"))
        cls.probes=json.loads(dtrial.PROBES.read_text(encoding="utf-8"))

    def test_registered_holdout_d_structure(self):
        dtrial.validate(self.fixture,self.probes)
        self.assertEqual(len(self.fixture["messages"]),40)
        self.assertEqual(len(self.probes["probes"]),32)

    def test_source_text_unchanged_by_chain(self):
        messages=copy.deepcopy(self.fixture["messages"])
        original=[m["exact_text"] for m in messages]
        chains=shadow.correction_chain_texts(messages)
        self.assertEqual(original,[m["exact_text"] for m in messages])
        self.assertEqual(len(chains),40)

    def test_correction_only_adds_its_same_branch_original(self):
        messages=self.fixture["messages"]
        ids={m["message_id"]:i for i,m in enumerate(messages)}
        text=shadow.correction_chain_texts(messages)
        self.assertIn(messages[ids["d01"]]["exact_text"],text[ids["d03"]])
        self.assertIn("Corrected statement",text[ids["d03"]])
        self.assertNotIn("Superseded",text[ids["d01"]])
        self.assertEqual(text[ids["d37"]],messages[ids["d37"]]["exact_text"])
        self.assertNotIn("roof",text[ids["d03"]])

    def test_cross_branch_correction_fails(self):
        altered=copy.deepcopy(self.fixture["messages"])
        altered[2]["branch_id"]="alternative"
        with self.assertRaisesRegex(ValueError,"Cross-branch"):
            shadow.correction_chain_texts(altered)

    def test_dangling_correction_fails(self):
        altered=copy.deepcopy(self.fixture["messages"])
        altered[2]["supersedes"]["message_id"]="missing"
        with self.assertRaisesRegex(ValueError,"Broken"):
            shadow.correction_chain_texts(altered)

    def test_normalisation(self):
        vectors=shadow.normalized([[3,4],[0,2]])
        np.testing.assert_allclose(np.linalg.norm(vectors,axis=1),[1,1],atol=1e-7)
        with self.assertRaisesRegex(ValueError,"zero embedding"):
            shadow.normalized([[0,0],[1,2]])

    def test_stable_score_tie(self):
        self.assertEqual(
            shadow.order_by_score(["a","b","c"],np.array([.5,.5,.8])),
            ["c","a","b"])

    def test_rrf_deterministic_and_rejects_duplicates(self):
        self.assertEqual(shadow.reciprocal_rank_fusion(["a","b","c"],["b","a"])[:2],["a","b"])  # rank tie: dense input order
        with self.assertRaisesRegex(ValueError,"Invalid ranks"):
            shadow.reciprocal_rank_fusion(["a","a"],["a"])

    def test_original_target_requires_original_record(self):
        altered=copy.deepcopy(self.probes)
        p=next(p for p in altered["probes"] if p["kind"]=="original")
        p["expected_message_id"]="d03"
        with self.assertRaisesRegex(ValueError,"Original query"):
            dtrial.validate(self.fixture,altered)

    def test_alternative_target_requires_alternative_branch(self):
        altered=copy.deepcopy(self.probes)
        p=next(p for p in altered["probes"] if p["kind"]=="alternative")
        p["expected_message_id"]="d03"
        with self.assertRaisesRegex(ValueError,"Alternative query"):
            dtrial.validate(self.fixture,altered)

    def test_non_synthetic_holdout_rejected(self):
        altered=copy.deepcopy(self.fixture)
        altered["synthetic"]=False
        with self.assertRaisesRegex(ValueError,"Expected"):
            dtrial.validate(altered,self.probes)


if __name__=="__main__":
    unittest.main()
