"""Failure-injection tests for read-only exact SQLite source-packet resolution."""
from __future__ import annotations
import copy
import hashlib
import json
import math
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from ltm_vnext.archive import Archive, _local_id
from scripts import run_relevance_holdout_e as e_trial
from scripts.shadow_source_packets import ShadowPacketResolver,PacketIntegrityError


class SourcePacketTests(unittest.TestCase):
    def setUp(self):
        self.folder=tempfile.TemporaryDirectory(prefix="shadow-packet-tests-")
        self.addCleanup(self.folder.cleanup)
        self.dbfile=Path(self.folder.name)/"test.sqlite"
        self.archive=Archive.initialise(self.dbfile)
        self.archive.ingest_synthetic(e_trial.FIXTURE)
        self.fixture=json.loads(e_trial.FIXTURE.read_text(encoding="utf8"))
        self.resolver=ShadowPacketResolver(self.archive,self.fixture)

    def local(self,mid):
        m=self.resolver.records[mid]
        return _local_id(m["source_id"],m["message_id"],m["version_id"])

    def corrupt(self,mid,field,value):
        allowed={"source_locator","branch_id","exact_text","content_sha256",
                 "attribution","reported_speaker","supersedes_local_id"}
        if field not in allowed:
            raise ValueError("Non-test field")
        with sqlite3.connect(self.dbfile) as db:
            db.execute("UPDATE messages SET "+field+"=? WHERE local_id=?",(value,self.local(mid)))

    def test_exact_packet_preserves_text_and_hash(self):
        x=self.resolver.resolve([("e03",0.66)])[0]
        self.assertEqual(x["candidate_relevance"],"unverified_candidate")
        self.assertEqual(x["source_integrity"],"verified_against_synthetic_fixture_only")
        self.assertEqual(x["source"]["exact_text"],self.resolver.records["e03"]["exact_text"])
        self.assertEqual(
            x["source"]["content_sha256"],
            hashlib.sha256(x["source"]["exact_text"].encode("utf8")).hexdigest(),
        )

    def test_alternative_branch_inference_is_not_main_correction(self):
        x=self.resolver.resolve([("e31",0.5)])[0]["source"]
        self.assertEqual(x["branch_id"],"alternative")
        self.assertEqual(x["author_role"],"assistant")
        self.assertEqual(x["attribution"],"assistant_inference")
        self.assertIsNone(x["supersedes_local_id"])

    def test_main_correction_points_back_and_original_points_forward(self):
        old=self.resolver.resolve([("e01",0.7)])[0]["source"]
        new=self.resolver.resolve([("e03",0.7)])[0]["source"]
        self.assertEqual(new["supersedes_local_id"],old["local_id"])
        self.assertEqual(old["corrected_by"],[new["local_id"]])

    def test_adjacent_messages_always_from_same_branch(self):
        packet=self.resolver.resolve([("e03",0.8),("e31",0.6)])
        for item in packet:
            own=item["source"]
            for neighbour in own["neighbouring_dialogue"]:
                m=self.resolver.local_ids[neighbour["local_id"]]
                self.assertEqual(m["branch_id"],own["branch_id"])
                self.assertEqual(m["conversation_id"],own["conversation_id"])

    def test_duplicate_candidate_rejected(self):
        with self.assertRaisesRegex(ValueError,"Duplicate candidate"):
            self.resolver.resolve([("e03",0.9),("e03",0.1)])

    def test_unknown_candidate_rejected(self):
        with self.assertRaisesRegex(PacketIntegrityError,"outside"):
            self.resolver.resolve([("missing",0.5)])

    def test_more_than_eight_rejected(self):
        with self.assertRaisesRegex(ValueError,"eight"):
            self.resolver.resolve([(m["message_id"],0.5) for m in self.fixture["messages"][:9]])

    def test_non_finite_or_out_of_range_score_rejected(self):
        for bad in (math.inf,math.nan,-2.0):
            with self.subTest(value=repr(bad)):
                with self.assertRaisesRegex(ValueError,"Invalid cosine"):
                    self.resolver.resolve([("e03",bad)])

    def test_real_source_fixture_rejected(self):
        corrupted=copy.deepcopy(self.fixture)
        corrupted["messages"][0]["capture_method"]="real_user_export"
        with self.assertRaisesRegex(PacketIntegrityError,"Non-synthetic"):
            ShadowPacketResolver(self.archive,corrupted)

    def test_corrupted_original_text_detected(self):
        self.corrupt("e03","exact_text","invented text replacement")
        with self.assertRaisesRegex(PacketIntegrityError,"exact_text"):
            self.resolver.resolve([("e03",0.7)])

    def test_corrupted_sha_detected(self):
        self.corrupt("e03","content_sha256","0"*64)
        with self.assertRaisesRegex(PacketIntegrityError,"SHA-256"):
            self.resolver.resolve([("e03",0.7)])

    def test_changed_source_locator_detected(self):
        self.corrupt("e03","source_locator","fixture://different")
        with self.assertRaisesRegex(PacketIntegrityError,"source_locator"):
            self.resolver.resolve([("e03",0.7)])

    def test_wrong_branch_detected(self):
        self.corrupt("e03","branch_id","alternative")
        with self.assertRaisesRegex(PacketIntegrityError,"branch_id"):
            self.resolver.resolve([("e03",0.7)])

    def test_misattributed_reported_speaker_detected(self):
        self.corrupt("e03","reported_speaker","someone else")
        with self.assertRaisesRegex(PacketIntegrityError,"reported_speaker"):
            self.resolver.resolve([("e03",0.7)])

    def test_missing_supersession_detected(self):
        self.corrupt("e03","supersedes_local_id",None)
        with self.assertRaisesRegex(PacketIntegrityError,"Supersession"):
            self.resolver.resolve([("e03",0.7)])

    def test_corrupted_correction_descendant_detected(self):
        self.corrupt("e03","supersedes_local_id",None)
        with self.assertRaisesRegex(PacketIntegrityError,"descendants"):
            self.resolver.resolve([("e01",0.7)])

    def test_injected_foreign_neighbour_rejected(self):
        packet=self.archive.fetch(self.local("e03"))
        foreign=self.archive.fetch(self.local("e31"))
        packet["neighbouring_dialogue"].append({
            "local_id":foreign["local_id"],"position":foreign["position"],
            "author_role":foreign["author_role"],
            "exact_text":foreign["exact_text"],"content_sha256":foreign["content_sha256"],
        })
        with mock.patch.object(self.archive,"fetch",return_value=packet):
            with self.assertRaisesRegex(PacketIntegrityError,"Cross-branch"):
                self.resolver.resolve([("e03",0.7)])


if __name__=="__main__":
    unittest.main()
