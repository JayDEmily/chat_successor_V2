"""Deterministic negative tests for frozen abstention-gate calibration and E scoring."""
from __future__ import annotations
import copy
import json
import unittest
import numpy as np

from scripts import calibrate_raw_relevance as calibration
from scripts import run_relevance_holdout_e as eval_e


class RelevanceGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cfg=json.loads(calibration.CAL.read_text(encoding="utf8"))
        cls.gate=json.loads(eval_e.GATE.read_text(encoding="utf8"))
        cls.fixture=json.loads(eval_e.FIXTURE.read_text(encoding="utf8"))
        cls.probes=json.loads(eval_e.PROBES.read_text(encoding="utf8"))

    def test_frozen_holdout_e_and_gate_pass_validation(self):
        eval_e.check_locked_inputs(self.fixture,self.probes,self.gate)

    def test_only_synthetic_e_records(self):
        self.assertEqual(len(self.fixture["messages"]),34)
        self.assertTrue(self.fixture["synthetic"])
        self.assertEqual(len(self.probes["probes"]),58)

    def test_registration_is_complete_and_separate_from_calibration(self):
        self.assertEqual(len(self.cfg["negative_queries"]),24)
        self.assertEqual(self.gate["negative_total"],24)
        self.assertEqual(self.gate["positive_total"],48)
        self.assertTrue(self.gate["e_holdout_not_accessed"])

    def test_exact_float32_calibration_rule(self):
        a=np.float32(self.gate["max_negative_float32"])
        b=np.nextafter(a,np.float32(np.inf))
        self.assertEqual(float(b),self.gate["threshold_float32"])

    def test_calibration_file_change_rejected(self):
        bad=copy.deepcopy(self.gate)
        bad["calibration_sha256"]="bad"
        with self.assertRaisesRegex(ValueError,"Calibration file differs"):
            eval_e.check_locked_inputs(self.fixture,self.probes,bad)

    def test_threshold_tampering_rejected(self):
        bad=copy.deepcopy(self.gate)
        bad["threshold_float32"]=0.25
        with self.assertRaisesRegex(ValueError,"formula"):
            eval_e.check_locked_inputs(self.fixture,self.probes,bad)

    def test_model_swap_rejected(self):
        bad=copy.deepcopy(self.gate)
        bad["model"]="other"
        with self.assertRaisesRegex(ValueError,"Model mismatch"):
            eval_e.check_locked_inputs(self.fixture,self.probes,bad)

    def test_real_data_source_rejected(self):
        bad=copy.deepcopy(self.fixture)
        bad["messages"][0]["capture_method"]="personal_chat_export"
        with self.assertRaisesRegex(ValueError,"Real or unlabelled"):
            eval_e.check_locked_inputs(bad,self.probes,self.gate)

    def test_negative_target_must_be_none(self):
        bad=copy.deepcopy(self.probes)
        query=next(x for x in bad["probes"] if x["kind"]=="hard_negative")
        query["expected_message_id"]="e03"
        with self.assertRaisesRegex(ValueError,"Negative/ambiguous"):
            eval_e.check_locked_inputs(self.fixture,bad,self.gate)

    def test_original_and_alternative_targets_are_type_checked(self):
        bad=copy.deepcopy(self.probes)
        query=next(x for x in bad["probes"] if x["kind"]=="original")
        query["expected_message_id"]="e03"
        with self.assertRaisesRegex(ValueError,"Historical original"):
            eval_e.check_locked_inputs(self.fixture,bad,self.gate)
        bad=copy.deepcopy(self.probes)
        query=next(x for x in bad["probes"] if x["kind"]=="alternative")
        query["expected_message_id"]="e03"
        with self.assertRaisesRegex(ValueError,"Alternative target"):
            eval_e.check_locked_inputs(self.fixture,bad,self.gate)

    def test_duplicate_probe_identity_rejected(self):
        bad=copy.deepcopy(self.probes)
        bad["probes"][1]["id"]=bad["probes"][0]["id"]
        with self.assertRaisesRegex(ValueError,"Duplicate E probe"):
            eval_e.check_locked_inputs(self.fixture,bad,self.gate)

    def test_aggregation_keeps_no_source_cases_separate(self):
        fake=[
            {"kind":"hard_negative","lexical_candidates":1,"lexical_rank8":None,
             "raw_rank8":None,"raw_correct1":False,"gate_promotes":True,
             "gated_target8":False,"gated_correct1":False,"target":None},
            {"kind":"implicit","lexical_candidates":1,"lexical_rank8":None,
             "raw_rank8":1,"raw_correct1":True,"gate_promotes":False,
             "gated_target8":False,"gated_correct1":False,"target":"e03"},
        ]
        result=eval_e.aggregate(fake)
        self.assertEqual(result["hard_negative"]["gate_promotes"],1)
        self.assertEqual(result["implicit"]["raw_correct8"],1)
        self.assertEqual(result["implicit"]["gated_correct8"],0)


if __name__=="__main__":
    unittest.main()
