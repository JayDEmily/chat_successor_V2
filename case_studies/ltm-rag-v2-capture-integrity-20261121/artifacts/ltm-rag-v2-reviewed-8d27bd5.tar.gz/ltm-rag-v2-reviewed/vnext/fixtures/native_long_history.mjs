function buildLongHistory(paragraphsPerTurn) {
  const original = [
    "This is a wholly fictional conversation-memory test. I've had an exhausting day. I saw my old friend Ryan, who enjoys designing rowing shells, and my neighbour Emily at lunch, then rushed to yoga. Please reply naturally in one brief sentence.",
    "In this fictional diary, tomorrow I need to feed my rescue dog Nimbus, water the courtyard garden and pick up M6 bolts for an engineering mock-up. I'm a little overwhelmed. Please reply in one brief sentence.",
    "One correction to my fictional plans: Emily cannot feed Nimbus this Saturday after all. My pet sitter Casey will do it, and I'll move the garden watering to Sunday morning. Please reply in one brief sentence.",
    "Next week I have a technical review of a rowing-shell prototype with the same old friend I mentioned, and I may have to miss yoga to finish the drawings. It's a lot to juggle. Please reply in one brief sentence.",
  ];
  const themes = [
    "community printmaking exhibition", "secondhand book table", "ceramic tile collection",
    "photograph display", "little theatre wardrobe", "neighbourhood music room",
    "paper model display", "natural dye workshop",
  ];
  const people = ["Mae", "Oren", "Nell", "Ivo", "Lina", "Etta", "Milo", "Sylvie", "Oona", "June", "Leon", "Tess", "Finn"];
  const places = ["back gallery", "ticket hall", "side annex", "entry alcove", "west stairwell", "reading room", "old office", "covered arcade", "front studio", "east corridor", "map room"];
  const items = ["folded map", "paper sleeve", "glass slide", "small frame", "wooden peg", "swatch card", "linen cloth", "round tray", "letter stencil", "cork board", "label strip"];
  const colors = ["ochre", "russet", "ivory", "sage", "violet", "pewter", "plum", "turquoise", "amber"];
  const acknowledgement = "Please acknowledge these notes in one short sentence so I can go on.";
  return themes.map((theme, turn) => {
    const entries = Array.from({length: paragraphsPerTurn}, (_, index) => {
      const sequence = index + turn * paragraphsPerTurn;
      const contact = people[(sequence * 5 + turn) % people.length];
      const colleague = people[(sequence * 3 + turn + 6) % people.length];
      const place = places[(sequence * 7 + turn) % places.length];
      const item = items[(sequence * 3 + index + 2 * turn) % items.length];
      const color = colors[(sequence * 5 + index) % colors.length];
      const bin = 37 + sequence * 17 % 809;
      const booking = 13 + sequence * 23 % 176;
      const windows = 2 + sequence * 7 % 15;
      const page = 58 + sequence * 11 % 347;
      switch ((sequence + turn * 3) % 6) {
        case 0:
          return `The person I reached about the ${theme} was ${contact}, who keeps the keys to the ${place}. I asked that the ${color} ${item} go in box ${bin}, with the corner that has the pencil mark facing upward. ${colleague} thought there would be ${windows} spaces left on the shelf, but the shelf comes apart in two pieces and nobody had measured the end piece. I left a note on page ${page} that the box number is provisional. I'd rather move one small thing now than have everyone unpack when the doors open.`;
        case 1:
          return `There was a misunderstanding at the ${place} over booking ${booking}. ${contact} had written the number down beside a ${item} and nearly filed that with the receipts. The item belongs to the ${theme}. It will show up as the ${color} one in the photographs, which should help ${colleague} find it. The receipts, by contrast, belong in box ${bin}. I said to leave us ${windows} minutes between the two parties arriving, because sharing the desk works only if one person has time to clear a place for the next one.`;
        case 2:
          return `When I finally sat down in the ${place}, ${contact} handed me page ${page} with a note about the ${theme}. It suggested setting aside ${windows} copies of the guide for people who come in late. That seems sensible. I looked through box ${bin} for a spare ${item} and found only the ${color} sample. ${colleague} thinks the black lettering will be easier to read if we put it under the sample. I want to try it in the hallway light before I say yes. The light in the room made every sample look a little warmer.`;
        case 3:
          return `I walked through the ${place} with ${contact} again and we counted ${windows} openings along the rail. The measurements next to booking ${booking} seemed to describe a different rail. Our ${color} ${item} would cover one opening on the actual rail and more than two on the drawing. I told ${colleague} to leave the item in box ${bin} pending a new sketch for the ${theme}. If I forget the reason later, it is the gap on the left that matters. The right side lines up quite well with the old drawing.`;
        case 4:
          return `The discussion about the ${theme} in the ${place} went more smoothly once ${contact} put the material on the table. There was a ${color} ${item}, a list of ${windows} people for the next session, and a torn copy of page ${page}. ${colleague} wanted a new copy for each person. I think we can give the torn one to the volunteer who asked a question about the old layout and put a fresh one beside booking ${booking}. Write that decision beside the short list so whoever prints it knows why we need one extra copy.`;
        default:
          return `I made a second note about box ${bin} because ${contact} put the ${color} ${item} on the wrong trolley. It had been standing in the ${place} next to the delivery for the ${theme}. ${colleague} spotted the mix-up when page ${page} came off the top and the box label showed. We had ${windows} minutes to move it before someone locked the west door. I asked them to leave the trolley where it was afterwards. Tomorrow there'll be another delivery and the floor needs to be clear enough to pass with both doors open.`;
      }
    });
    const opening = turn === 0
      ? "I am collecting some fictional diary passages for a discussion. Here are four short notes I wrote earlier, in order.\n\n" + original.join("\n\n") + "\n\n"
      : "";
    const latest = turn === themes.length - 1
      ? "\n\nOne decision before I forget: use cobalt blue for the drawer labels in the natural dye display."
      : "";
    return opening + `Here is the next set of notes about the ${theme}.\n\n`
      + entries.join("\n\n") + latest + "\n\n" + acknowledgement;
  });
}

process.stdout.write(JSON.stringify(buildLongHistory(Number(process.argv[2]))));
