# Shadow retrieval comparison — registered before local model evaluation

**Date:** 18 November 2026 AEDT. This is a **synthetic-only offline experiment**. The existing six-message native ChatGPT MCP, tunnel, SQLite records and legacy repository code must remain unchanged.

## Prior evidence and explicit scope

The frozen Holdout C dataset has 26 entirely invented messages and 16 registered candidate-retrieval questions. Existing FTS5 baseline: **8/8 explicit** and **6/8 implicit** recall@8, with rank-one performance 4/8 and 1/8 respectively. The two implicit misses, I03/I06, are known before the experiment. This benchmark is therefore an **exploratory comparison on an already examined dataset**, NOT an independent holdout validation of any proposed improvement. The model must not receive registered answer IDs or query-specific synonyms as input.

## Library/model fixed in advance

- Local CPU implementation: `fastembed==0.9.1`, `onnxruntime==1.32.0`, `numpy==2.5.5`, installed under the Git-ignored `vnext/.local/shadow-embedding-venv` (not the production MCP virtualenv).
- One fixed 384-dimensional English embedding model: `BAAI/bge-small-en-v1.5` through FastEmbed. Model files downloaded to ignored `vnext/.local/shadow-models` and later loaded locally. Record their SHA-256 hashes and provenance without checking weights into Git.
- CPU-only with maximum **2 ONNX threads**, to minimise interference with unrelated Windows tasks. No external **model inference API**, no model generation, no personal data and no new MCP endpoint. Initial model **weights download** may access the model repository; subsequent inference is local.
- All 26 source messages, including assistant interpretations, superseded reports and alternative branches, remain distinct retrieval candidates and retain their exact original metadata/UTF-8 source text.

## Algorithms, fixed without trial-specific word aliases

Three deterministic candidates compared against unchanged FTS5:

1. **DENSE_RAW**: embed each source message's `exact_text` and each registered question; rank all 26 source messages by cosine similarity (ties by stable input order), return first 8.
2. **DENSE_CHAIN**: for an *individual correction record only*, embed its exact text plus the exact text of the record referenced in `supersedes` (separated by a fixed labelled boundary). Other candidates remain their original exact text. Do not infer branch linkage from text; use only verified source/conversation/branch matching.
3. **HYBRID_RRF**: reciprocal-rank fusion of **DENSE_CHAIN** and existing independent FTS5 ordering with fixed `k=60`. All source candidates may rank on the dense side; a source absent from lexical results contributes nothing from lexical. No adjustable weights or query-specific aliases.

For each, report exact registered-target **recall@8**, **rank-1**, missed case IDs, full per-case rank and the same fixed input hashes. Measure explicit and implicit separately. Do not claim a 16-case retrospective selection proves population performance. A result worse than baseline is legitimate evidence; do not alter the frozen plan to improve apparent results.

## Source fidelity and failure modes

- Retrieval only produces **source identities**, never a rewritten source. Exact original text/metadata remain exclusively in SQLite and are resolved through the existing archive `fetch` path if needed.
- A model can retrieve a semantically similar **wrong** version or branch. Count only the exact registered source ID; report first-ranked mismatches. Never merge two branches to improve recall.
- Any network/model download failure, resource error or dependency/API incompatibility must be reported precisely. The prior baseline stays valid, and the native MCP service must not be restarted or patched to conceal the failure.
- If results justify further work, make **new unseen** synthetic cases and register them before any second evaluation. No live integration merely on the strength of this exploratory sample.

## Evaluation order

Publish this design to the existing branch; then execute isolated CPU embeddings and inspect all observed outcomes. Preserve all non-improving outcomes in the report. Run the full existing unit suite and separate smoke test to verify the live synthetic service remains functional.
