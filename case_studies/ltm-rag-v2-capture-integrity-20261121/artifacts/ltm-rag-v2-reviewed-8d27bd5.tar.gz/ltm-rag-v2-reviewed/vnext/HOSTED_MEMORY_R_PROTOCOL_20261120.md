# Stage R — first hosted OpenAI vector-store conversation-memory pilot

**20 November 2026. Preregistered before creating the store or uploading files.**

## Owner authority and limitations

The owner explicitly created the new **LTM-RAG vNext — Conversation Memory** OpenAI Platform project and service-account key, had the latter installed separately as `OPENAI_LTM_RAG_VNEXT_API_KEY` in Ubuntu, and instructed us to **provision its vector store and connect the synthetic conversation-memory pipeline**. This specifically authorises bounded hosted file indexing and hosted retrieval on fabricated data, overriding earlier no-external-inference language **only for these vector-store operations**. No paid Responses/chat completion inference, authentic ChatGPT conversation capture, genuine personal-history import, native plugin repoint, new credentials, production ingestion, OS autostart or ChatGPT Work.

The purpose is to validate incremental *two-sided scripted conversation* preservation, search indexing, file-ID-to-SQL mapping, and exact original text recovery. The assistant messages in the fixture are **prewritten**, not actual generated ChatGPT answers. Do not claim the full native ChatGPT capture loop is solved merely because synthetic R passes.

## Frozen data and admission boundary

- Parent repository checkpoint `b9589cc5c7af7432c12e6e0450f3fc860872e029`, branch `work/ltm-rag-vnext-synthetic-20261118`.
- Frozen fixture `fixtures/synthetic_diary_r_20261120.json`, SHA-256 `6e2ce2a8c9a838c92dd9ca8d2add7163d1120cb1a5f6bc3710cbde35bfd44955`: one invented diary conversation, 12 consecutive user/assistant pairs, 24 immutable messages, explicit author-role and content hashes, two directed fictional correction links. All exact text remains in local SQLite.
- One dedicated OpenAI-hosted Vector Store with exact name **LTM-RAG vNext — Synthetic Conversation Memory R**, one in the newly created API project, `expires_after={anchor:last_active_at,days:30}` so a test index does not accumulate indefinite storage charges. This is an evaluation-only expiry, not a production memory policy.
- At most 12 immutable **one-turn files** (each contains one user and one prewritten assistant message, labelled distinctly). One hosted vector-store file per pair: named by turn and content digest and tagged with `synthetic_only=true`, conversation, turn and content digest. No wholesale document rewriting, no whole-chat model inference. For retries, check the existing store and index manifest before adding any resource.
- Canonical local SQLite rows use the existing `Archive._validate`/append-only `Archive.ingest_synthetic` source contract, with source locator, author role, exact UTF-8 text, stable message IDs and hashes, branch, position and correction links. Store hosted file_ID -> exact two source local IDs in an isolated SQLite mapping table.
- On hosted search, reject unknown `file_id` or mismatched source hashes, and return only the original SQLite packets plus explicit source provenance. Hosted text chunks and similarity scores are **untrusted candidates**, not evidence or verified user intent. The query path never promotes an assistant-scripted turn into a user-authored fact.

## Frozen execution order and tests

1. Independently verify complete preregistration protocol, case bytes and fixture SHA from the pinned GitHub registration commit before implementing the uploader.
2. Implement a reusable synthetic-only, idempotent `ingest_one_turn` (two SQLite inserts then one uploaded file/attached vector-store file, with manifest and replay protection) and `search_candidates` (hosted ranking => exact SQLite source packets). No MCP plugin changes.
3. Run isolated fake transport tests, including incremental 12-turn capture, duplicate replays, role separation, correction references, untrusted/unknown file IDs, packet corruption, and failed uploads/partial indexing. Run existing core and shadow regressions.
4. Check new project key read-only via hosted vector-store API. Create/reuse exactly one named store, record store/file IDs only in Git-ignored private configuration; do not write secrets to Git, files, console or report.
5. Index turns 1–8, then run frozen `R01`/`R02`. Index turns 9–12, then run `R03`–`R06`. Search up to 10 candidates, record exact target rank and whether the named source was in the **top five**. Non-matching cases are real measured misses, not a licence to change the frozen queries.
6. Independently read back store state, all hosted indexed-file statuses, local 24 original messages, all exact mapped packets, and result scores/IDs without implying semantic scores are probability. Preserve existing M/N/O/P six-event audit and original/G/I/K tunnels.
7. Publish an evidence-backed pass/partial/fail report with every observed rank and index status, tests, idempotency limits and source fidelity. Commit/push and verify GitHub HEAD/parent/tree/blobs.

**R acceptance:** One and only one isolated hosted store, ≤12 indexed synthetic files, 24 exact SQLite source messages, all source-role/packet mappings verified, local regression tests pass, and live search results measured. Search-quality acceptance is **6/6 frozen targets in top five**; if fewer hit, report the real misses without retroactive tuning or extra API queries. No requirement to claim that real ChatGPT messages were captured or that it can automatically call this hosted store.
