# Stage I — separate native connector and clean-Project verification

**19 November 2026. Synthetic-only.** This is the third independent read-only MCP/ChatGPT integration. It does **not** replace the original six-source MCP or the separate 20-source Trial G MCP.

## Frozen authority and original evidence

- Governing vNext scope: `vnext/AGENTS.md`. Stage H offline referent gate remains nondeployed.
- Stage I protocol and 20 offline + 16 native questions were preregistered and pushed at Git `bdc5dc7b6862531c5c0f29d56503e3fb5ee9876d`, parent `d05bae31ded0ce17eb55c0b7b3cfdb2b5c1055e3`. GitHub connector independently fetched the commit and both frozen files **before** I implementation.
- The initial isolated adapter and 20/20 successful offline cases were pushed at `7889920ff68fc250b44a3f69fd6c9a2c9bce98b3`; independent GitHub readback verified source/report blobs. The original G archive SHA-256 is `e3531da9538eb40dc41bec43f29c089f7aed7525ee574e84d21e469fabf9dcbf`.

## Distinct local service, tunnel and plugin

- Private I SQLite: `vnext/.local/trial-i-synthetic.sqlite`, 20 fictional records, mode 0600, distinct from the G database. Native read-only MCP server runs at **127.0.0.1:8789**, no public listener, and exposes **only** `resolve_history_reference(question)`.
- Separate tunnel ID **`tunnel_6afe70da5ba48191a332a48d7fb53fa4`**, name `LTM-RAG-vNext-decision-I-20261119`; private remote create receipt with the expected organisation, name and remote tunnel ID was independently verified. Connection profile `vnext/.local/profiles/ltm-vnext-decision-i.yaml` points only at 8789. Health endpoint `127.0.0.1:39509/readyz` returned `ready`.
- Tunnel launcher `scripts/tunnel_i_using_existing_key.py` uses only the existing owner-approved runtime credential from Ubuntu private `.env` through process-only key mapping. No new API key or credential was issued; no key is committed. Remote admin tunnel helper is `scripts/trial_i_tunnel_admin.py`, which stores only a separate ignored nonsecret creation/verification receipt.
- Using an isolated Chrome window, ChatGPT Plugins → Add → Add custom MCP server → Tunnel, a **distinct private plugin** named **`LTM-RAG vNext Decision I`** was created and connected with no additional server authentication (the tunnel control plane handles authenticated routing). The installed-plugin settings were independently searched and displayed the expected name and synthetic-only description and low-risk permission setting. The existing `LTM-RAG vNext Synthetic Recall` and `LTM-RAG vNext Clean G` were not disconnected, changed or reused.

## Clean Project and the native first-turn boundary

- Created new **`LTM-RAG vNext Decision I Clean Context`** ChatGPT Project, ID **`g-p-6afe74761d848191830dc78a328d29c1`**, exclusively for I. At creation chose **Project-only memory**, then independently reopened Project settings and read back the Project-only description. The sidebar and Project main view both showed **No chats** before I01. The private Chrome window handle and project details remain in ignored local test state.
- I01 sent only after independent service/tunnel/plugin/Project verification; it was the sole originally chat-empty Project turn. I02–I16 were sent as **15 separate new chats in the same Project**, with a durable `about_to_send` marker before each Send, exact frozen prompt SHA-256, project identity check, distinct saved conversation URLs and unique tool-event attribution. No pre-send marker remains after all 16 confirmed answers. No double Send or native G rewrite occurred.
- I01 called the new I tool, received zero source packets, and asked which record the user intended. The independent audit observed 14 successful I tool calls for 16 cases; all 12 required/avoided invocation checks passed. Source-scope and semantic results independently exposed **two failures**, I05 and I15. See `NATIVE_DECISION_SUPPORT_I_TRACE_RESULTS_20261119.md` and `NATIVE_DECISION_SUPPORT_I_SEMANTIC_RESULTS_20261119.md`.
- Original service's last local MCP event: **2026-11-18 23:59:07.648 UTC**, and G service's last local MCP event: **2026-11-18 23:59:07.946 UTC**. Native I sends occurred **2026-11-19 04:05–04:14 UTC**; thus the recorded original/G audit ledgers contain no tool events during the native I run. This is an audit observation, not proof that no unobserved unsuccessful remote call was attempted.

## Explicit limits and nonchanges

- The model's **actual I tool argument text was not logged**; only event ID, timestamp, outcome and packet count were retained. The I05/I15 packet-count mismatches prove that the returned records exceeded the user question's explicit referents; they do **not** identify the exact expanded argument or prove cross-chat memory as the cause.
- Project-only settings were inspected, but instantaneous memory-mode propagation cannot be retrospectively proved. The later 15 cases may share earlier same-Project chats.
- Both old listeners/tunnels continued on 8787/8788 (health 32883/34419); Stage I used new 8789 only. No changes to original/G MCP schema, original-source bytes, Windows/Ubuntu autostart, legacy production deployment or genuine conversation history. No paid external model inference job was launched by these local tools.

**Stage I connection verdict: CONNECTED_NATIVE_SYNTHETIC_ONLY. Stage I referent-safety verdict: NOT_ACCEPTED (I05/I15).**
