# Ubuntu restart recovery — synthetic vNext

**Date:** 18 November 2026 (AEDT). **Scope:** Existing LTM-RAG vNext synthetic MCP and completed Native Trial F.

## Preserved after Ubuntu restart

- Windows desktop `DESKTOP-I188O30` online via Remote Desktop Commander; WSL Ubuntu user `jds`.
- Git branch `work/ltm-rag-vnext-synthetic-20261118` at `d7e0eee74d058473794aa3efa95f04e2dae4f375`, independently matched to the GitHub remote before new work.
- The full **16/16 Trial F** private ledger retained, with **no pending-send marker** or unsent/retried question. Tool audit records 6 successful `lookup_evidence` calls and 4 `fetch_source` calls. The M04 trace failure is preserved.
- Existing synthetic MCP port 8787 and its tunnel were both stopped, as expected following a WSL restart. No automatic startup mechanism was installed.

## Manual restoration and evidence

- Ran `supervise_synthetic_services.py preflight`: **PASS**, exactly six synthetic source messages, existing credential file still available.
- Initial tunnel `doctor` correctly failed only the local MCP-reachability/OAuth checks while the server was offline. Credential configuration checks passed.
- Started `supervise_synthetic_services.py run` manually; output `SYNTHETIC_SUPERVISOR_RUNNING children=2 loopback_only=true`. Logged new child PIDs **1111 (MCP)** and **1118 (tunnel)**, ready at **2026-11-18T10:17:50Z**.
- Repeated tunnel `doctor`: **result=ok**. Local Streamable HTTP lookup/fetch and supervisor smoke tests **PASS**.
- Extracted the **new ephemeral health URL** from the tunnel's own startup log: `http://127.0.0.1:33885`; the previous pre-restart port `44355` was no longer active. `/readyz` and `/health?details=true` returned **HTTP 200**. At 2026-11-18T10:21:28Z, health reported `live=true`, `ready=true`, control plane `status=ok`, `state=polling`, successful last poll at 10:21:22Z and **zero consecutive failures**.
- Health's detailed MCP channel was `not_observed` due to unsupported child-transport evidence; do **not** infer a new native ChatGPT tool call merely from tunnel readiness. The already complete Native Trial F needed no duplicate sends after the reboot.

## Completed Trial F review

- 16 registered answers separately assessed against the canonical six-message fictional source fixture; all case/source identities and answer-marker observations validated by `scripts/verify_native_trial_f_semantics.py`.
- Eight history-related answers had main conclusions consistent with the synthetic fixture, but only **5/8** made an audited MCP lookup. M04 also had exact-quotation punctuation drift.
- All four ambiguous prompts selected an insufficiently justified unique notebook referent, one after a lookup. All four unrelated technical explanations avoided MCP lookup.
- OpenAI's official [Projects documentation](https://help.openai.com/en/articles/10169521-projects-in-chatgpt) confirms chats in the same Project may reference one another; whether that happened in any specific response is unknown.
- **71/71 core tests** and **40/40 shadow tests** passed. The original archived records were not rewritten.

No Windows or Ubuntu boot configuration, API key, public endpoint, native MCP interface or personal conversation import was changed.
