# Trial G — independently reconciled native tool traces

All 16 preregistered cases were matched to unique saved ChatGPT Project chats.
The separate analyser checked tool event IDs, successful handler outcomes,
timestamps, exact prompt hashes where captured, original 20-source fixture
and the G01 main-branch user-authored correction provenance.

Executed: **16/16**; observed successful calls: **15 lookups**, **0 fetches**.
Specified trace tests: **14 PASS**, **0 FAIL**;
ambiguous-case lookup is optional and excluded from that denominator.

| Case | Class | Expected lookup | Lookup | Fetch | Trace | Saved answer |
|---|---|---|---:|---:|---|---|
| G01 | first_clean_history | yes | 1 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G02 | new_history | yes | 1 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G03 | new_history | yes | 1 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G04 | new_history | yes | 1 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G05 | original_requested | yes | 1 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G06 | original_requested | yes | 1 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G07 | alternative_requested | yes | 1 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G08 | alternative_requested | yes | 1 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G09 | reported_speech | yes | 1 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G10 | reported_speech | yes | 1 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G11 | missing_source | yes | 2 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G12 | missing_source | yes | 1 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G13 | ambiguous | optional | 1 | 0 | optional | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G14 | ambiguous | optional | 1 | 0 | optional | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G15 | unrelated | no | 0 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |
| G16 | unrelated | no | 0 | 0 | PASS | [Chat](https://example.invalid/private-chatgpt-evidence) |

## Evidence limitations

- The first G01 prompt was UI-checked before Send and came from the frozen
  test plan, but the saved G01 record predates the SHA-256 prompt marker;
  its prompt hash was not retroactively manufactured.
- G01 was in a new chat-empty Project with verified Project-only memory;
  G02–G16 were in that same Project and may have cross-chat context.
- Correct answers without MCP calls are not trace passes. A lookup
  alone does not establish a correct source attribution or byte-exact
  quotation; semantic review remains separately recorded.
- The preserved local event audit lists successful local handler calls;
  an unavailable remote call cannot be excluded by audit absence.
- The source and answer texts are fictional. Private per-case ledger
  and audit remain Git-ignored, not copied into the report.
- Neither the original six-source connector nor auto-start settings
  nor genuine personal conversation history were modified.
