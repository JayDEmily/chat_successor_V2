# Holdout E: candidate relevance, abstention and ambiguity

**Registration date: 18 November 2026 (AEDT).** This protocol, calibration queries, 34-message fictional corpus, 58-case test questions, classifications and expected exact source IDs are committed **before any embedding evaluation on E**.

## Why this boundary exists

Holdout C/D showed that local dense retrieval improves finding paraphrased corrected records. However a nearest-neighbour index produces a top match even when a question is unrelated. C/D had mostly positive/source-needed prompts; their scores alone cannot demonstrate safe abstention.

## Locked data and class definitions

- `RELEVANCE_CALIBRATION_20261118.json`: positive calibration = all existing 16 C and 32 D registered questions (previously tested), negative calibration = 24 new *generic explanatory questions* referring to topics in those corpora but not requesting an archived fact (12 per corpus).
- `fixtures/synthetic_holdout_e.json`: **34 new, entirely fictional records** (10 original, 10 assistant caveat, 10 correction, 4 alternative-branch assistant inference). None of these records were in C/D. It is an isolated disposable SQLite database, not the live six-message catalogue.
- `HOLDOUT_E_PROBES_20261118.json`: **58 fixed cases**. Registered classes: 10 explicit correction queries, 10 implicit/paraphrased correction queries, 6 deliberately asking for the superseded *original*, 4 asking for the *alternative branch*, 10 hard-negative general explanatory questions sharing topical vocabulary, 10 unrelated general-science negatives, and 8 *ambiguous* requests for a memory without sufficient entity/time/branch identification.
- **Positive target score:** a hit only if the registered exact source `message_id` is present in the top 8; rank 1 is reported separately. Answers about another version or branch never count as the right source.
- **Negative target score:** a new query has **no relevant archived source**; its desired single-source result is `abstain`. If retrieval returns a candidate, count an *unnecessary candidate promotion*, **not** a claim that ChatGPT would hallucinate.
- **Ambiguous target score:** **no uniquely identifiable registered source**. A confident single-source promotion is an undesirable ambiguity handling event; retrieving multiple possible sources for clarification is distinct from a proven wrong answer. Report ambiguity as a separate descriptive category.

## Frozen model and gate — calibration must not inspect E

- Candidate ranker: **DENSE_RAW only**, `BAAI/bge-small-en-v1.5` via local FastEmbed 0.9.1 / ONNXRuntime 1.32.0, CPU two threads, embeddings of unmodified source `exact_text`. No query-specific words, source identifiers, expected outcomes or synthetic answer aliases are inserted into embeddings.
- Score: cosine similarity of unit-normalised source and query vectors; rank all messages by descending similarity, ties by original source order.
- **Threshold fixed by mathematical rule**, not by looking at E results: for each of the 24 negative calibration questions on its own C/D corpus, compute its **highest** raw-dense similarity. Set the single score cutoff `T = nextafter(max(all 24 negative calibration top-1 scores), +infinity)` in IEEE float32. This is a deliberately conservative no-false-positive-on-calibration rule, not a statistical decision boundary.
- `RAW_GATED`: promote the top-8 source candidates **only when best cosine >= T**; otherwise return abstention, no exact source. No extra query classifier, rank-margin, synonyms, prompt-category flags or post-hoc threshold tuning.
- Compare unchanged `FTS5` (any nonempty hit, no abstention threshold), unchanged `DENSE_RAW` (always returns top 8), and `RAW_GATED`. The latter two share **identical candidate rankings**; only the frozen top-score gate changes.
- Calculate C+D positive accepted/target recall separately from E. Report all 24 calibration negative scores, the fixed T and calibration positive pass count; show E positive recall@8, post-gate accepted correct-target rate, irrelevant promotion on 10 hard and 10 unrelated negatives, ambiguity promotions on eight ambiguous prompts, wrong-version/source rank-one cases, and full per-case scores.
- **Do not modify E or T** after first E evaluation. A negative or ambiguous case with high similarity is a recorded failure. Zero false positives on 24 calibration negatives is by construction and must never be advertised as independent validation.

## Isolation, limitations, decision

All 34 new source records and all queries are invented and evaluated in a disposable offline SQLite corpus; no ChatGPT, external inference API, real conversation import, background researcher, public endpoint or Windows reboot/startup change is performed.

If E exposes false promotions, preserve the result; do not silently install the gate. A useful outcome may simply establish that similarity thresholding alone cannot safely distinguish topical questions from a genuine archival request. A more robust native retrieval/abstention contract would need a **separately registered** test and source-faithful output validation before deployment.

This is a hand-built functional benchmark, **not** a representative random sample or proof of population safety/reliability. `AGENTS.md` synthetic-only boundaries remain unchanged.
