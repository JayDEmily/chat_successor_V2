# H10 diagnosis — distinguish test-contract failure from source inaccuracy

**Date:** 18 November 2026. **Scope:** Synthetic-only native reliability trial B. No product source code changed during this diagnosis.

## Observed result (immutable)

The pre-registered H10 case asked ChatGPT to contrast the fictional notebook's corrected location and the alternative-branch drawer inference. Its native answer correctly distinguished the main-branch user-reported library correction from the assistant-authored alternative drawer inference, citing `fixture://notebook/m3` and `fixture://notebook/m4`.

The local MCP audit recorded **one successful `lookup_evidence` call** (five matches) and **zero `fetch_source` calls** during H10. Trial B's published scoring explicitly required a fetch for end-to-end source completion. Therefore H10 remains:

- Lookup initiation: **PASS**
- Extra source-fetch requirement: **FAIL**
- Registered answer markers: **PASS**
- Provenance accuracy from complete, independent review of all rendered text: **not established**; no incorrect answer was demonstrated

The answer's apparent correctness must not be used to alter the frozen test result.

## Mechanism verified by code inspection

The actual vNext implementation does **not** make `lookup_evidence` a reference-only search:

- `ltm_vnext/archive.py`, `Archive.lookup()`: the FTS5 query returns full matching message rows, and each match is converted using `self._packet(db, x, 1)`.
- `_packet()`: exposes each source's complete `exact_text`, `content_sha256`, `source_locator`, stable message identity, reported-speaker and attribution labels, correction links and one neighbouring turn's exact text/hash.
- `ltm_vnext/mcp_server.py`, `lookup_evidence()`: returns that full structured packet and an equivalent JSON text packet; it does **not** mask `exact_text` until a later `fetch_source`.
- `fetch_source()`: separately retrieves the same original packet by `local_id` with configurable neighbouring dialogue.

Consequently the model could construct a properly attributed answer from its **initial lookup result alone**. The absence of a later fetch establishes failure of the stricter trial *trace requirement*, not by itself a missing original text, failure of integrity metadata or a hallucinated quotation.

## Comparison against Astra's design

Astra's 18 November assessment recommended read-only **lookup and source-fetch tools**, faithful quotations, source-linked findings, explicit branch/correction boundaries and independent code-level exact-span verification. It did not prescribe that **every relevant answer must make two distinct tool calls**. The 20-case protocol deliberately introduced that stricter observable requirement; it may be a conservative test, not an inherent property of the proposed system.

Astra's objective is original-source fidelity. A model-executed `fetch_source` call is one useful signal but not sufficient alone: a later answer can still misquote or misuse a properly fetched source. Conversely a lookup that delivers the full exact source packet can ground an answer without a second fetch.

## Decision and next bounded experiment

**Do not silently relabel H10 as passed. Do not redesign the live retrieval tool solely to make the existing 20-case test green.** Retain the exact 10/10 initiation, 9/10 required fetch+answer, 0/10 unnecessary lookup figures.

For the next evaluation, distinguish two evidence metrics *before* collecting new cases:

1. **Grounding fidelity:** whether the model's rendered factual claim and quoted span match the independently recovered original exact text and provenance (hash, branch, author, correction). Code should perform independent checks, not rely on a claimed tool ID.
2. **Two-tool protocol compliance:** whether an explicit `fetch_source` occurred after candidate lookup, when mandated by a separately chosen interface contract.

Only if the two-stage separation itself is accepted as an architectural requirement should a new version of `lookup_evidence` return bounded identifiers/snippets rather than full original text; that would be a new tool contract requiring new tests and new live validation. Otherwise retain the present full-source lookup and measure *actual content fidelity*.

No real ChatGPT archive, external inference model, legacy AWS branch or API Access gateway is changed by this diagnosis.
