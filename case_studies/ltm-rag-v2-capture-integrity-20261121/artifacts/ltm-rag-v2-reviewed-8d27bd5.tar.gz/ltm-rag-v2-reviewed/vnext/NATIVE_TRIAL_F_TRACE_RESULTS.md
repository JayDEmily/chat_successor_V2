# Native ChatGPT Trial F — verified tool traces (semantic review separate)

All 16 questions were registered and committed before execution at 98a7017.
The tested connected plugin still uses the unchanged six-message fictional
SQLite FTS5 catalogue. Each question was submitted once into its own verified
fresh ChatGPT Project conversation, with no selected-tool chip.

## Observed successful MCP lookup/fetch trace

| Category | Cases | Completed | With a lookup | Required/avoided trace PASS |
|---|---:|---:|---:|---:|
| missing | 4 | 4 | 3 | 3/4 |
| contradiction | 4 | 4 | 2 | 2/4 |
| ambiguous | 4 | 4 | 1 | not specified |
| unrelated | 4 | 4 | 0 | 4/4 |

Successful, locally audited MCP calls: 6 lookups; 4 source fetches.
These figures do not count outbound attempts that failed before reaching the local handler.

| Case | Category | Expected lookup | Actual lookup | Fetch | Trace check | ChatGPT Project answer |
|---|---|---|---:|---:|---|---|
| M01 | missing | yes | 1 | 1 | PASS | [Read](https://example.invalid/private-chatgpt-evidence) |
| M02 | missing | yes | 1 | 0 | PASS | [Read](https://example.invalid/private-chatgpt-evidence) |
| M03 | missing | yes | 1 | 1 | PASS | [Read](https://example.invalid/private-chatgpt-evidence) |
| M04 | missing | yes | 0 | 0 | FAIL | [Read](https://example.invalid/private-chatgpt-evidence) |
| C01 | contradiction | yes | 1 | 2 | PASS | [Read](https://example.invalid/private-chatgpt-evidence) |
| C02 | contradiction | yes | 0 | 0 | FAIL | [Read](https://example.invalid/private-chatgpt-evidence) |
| C03 | contradiction | yes | 1 | 0 | PASS | [Read](https://example.invalid/private-chatgpt-evidence) |
| C04 | contradiction | yes | 0 | 0 | FAIL | [Read](https://example.invalid/private-chatgpt-evidence) |
| A01 | ambiguous | optional | 0 | 0 | not specified | [Read](https://example.invalid/private-chatgpt-evidence) |
| A02 | ambiguous | optional | 0 | 0 | not specified | [Read](https://example.invalid/private-chatgpt-evidence) |
| A03 | ambiguous | optional | 1 | 0 | not specified | [Read](https://example.invalid/private-chatgpt-evidence) |
| A04 | ambiguous | optional | 0 | 0 | not specified | [Read](https://example.invalid/private-chatgpt-evidence) |
| U01 | unrelated | no | 0 | 0 | PASS | [Read](https://example.invalid/private-chatgpt-evidence) |
| U02 | unrelated | no | 0 | 0 | PASS | [Read](https://example.invalid/private-chatgpt-evidence) |
| U03 | unrelated | no | 0 | 0 | PASS | [Read](https://example.invalid/private-chatgpt-evidence) |
| U04 | unrelated | no | 0 | 0 | PASS | [Read](https://example.invalid/private-chatgpt-evidence) |

## Independent semantic evidence boundary

Tool trace alone does NOT establish a correct or source-faithful answer. This
document deliberately leaves the semantic verdict unassigned until every
saved response is compared with the exact original synthetic fixture.
A case without lookup may still give a plausible answer but does not prove
that its archive was checked. A reported human recollection is not an
authenticated recording. An answer about a missing detail must not
fabricate an original quote, serial number or authenticated timestamp.

Original answer excerpts and per-event IDs are retained only under the
Git-ignored local Trial F ledger. No personal history was imported or
pushed to GitHub; no native backend was modified in this test.
