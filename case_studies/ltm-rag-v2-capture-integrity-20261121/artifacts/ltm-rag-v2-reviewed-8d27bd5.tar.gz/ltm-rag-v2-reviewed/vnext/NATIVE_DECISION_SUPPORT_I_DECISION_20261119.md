# Native Decision-Support I — source-grounded decision after completed trial

**19 November 2026. Verdict: RETURN_NATIVE_REFERENT_SELECTION, ACCEPT_ISOLATED_SOURCE_FIDELITY_AND_TOOL_INVOCATION_ONLY.**

Stage I is an experimental read-only synthetic plugin, **not accepted as a reliable native ambiguity/clarification gate**. Preserve the separate successful offline results; do not retroactively relabel native failures or silently deploy the Stage H/I selector to real conversation history.

## Independently verified results

| Contract | Observation | Decision |
|---|---|---|
| Preregistered offline I decisions | 20/20 correct, with original-source hash/packet audit | PASS_OFFLINE |
| Isolated MCP transport | 1 read-only tool, 0 packets on offline ambiguous question, exact source packets when anchored | PASS_TRANSPORT |
| Native executed cases | 16/16, distinct saved chats, no pending/double sends | COMPLETE |
| Native specified invocation/selectivity | 12/12 PASS; 10 source-dependent cases invoked I, 2 unrelated cases did not | PASS_INVOCATION |
| Native source-packet referent scope | 14/16 PASS, **I05/I15 FAIL** | **FAIL_REFERENT_SCOPE** |
| Retrospective original-source answer semantics | 14/16 acceptable; **I05/I15 arbitrary referent selection** | **FAIL_NATIVE_GATE** |
| Current dedicated Python tests | 118/118 core + 40/40 shadow before native; re-run at final checkpoint | REGRESSION_PASS |

The source and report are audited in `NATIVE_DECISION_SUPPORT_I_TRACE_RESULTS_20261119.md` and `NATIVE_DECISION_SUPPORT_I_SEMANTIC_RESULTS_20261119.md`. Complete answer text, the per-case SHA-256 ledger and event IDs remain Git-ignored.

## The two real failures

**I05** asked `Was the original version first or second?`, with no reference to a particular fictional history. A successful I resolver event returned **12 packets**, and the assistant answered using ORA-62 source messages g13/g15, although the user had never identified that topic. The facts about ORA-62 were true *within the fictional dataset*, but the selected narrative was unsupported. This is not a source-text accuracy pass for the user's request.

**I15** asked `Did she actually say it?`, again with no speaker or narrative identity. A successful I resolver event returned **four Vela packets**, and the assistant selected the Vela/TERN-91 story. It correctly described the Vela narrative as an unauthenticated recollection, but that truthful caveat does not justify assuming who `she` meant.

Two other ambiguous questions, **I01** (first clean turn) and **I11**, successfully asked for clarification and returned zero original packets. Thus ambiguity resolution was **2/4 semantically correct**, not a consistently safe native gate.

## Mechanism and authority boundary

Offline H and offline I evaluate a **supplied current-question string** faithfully. However, a native MCP argument supplied by an assistant is **model-authored**, not automatically independently authenticated as the user's literal current message. The tool validates the argument it receives; it cannot infer from ordinary source integrity that this argument accurately represents the user request.

The two source-count mismatches show that I received question arguments effectively sufficient to select fictional topics although the actual user prompts did not identify them. The exact tool arguments were deliberately not logged, and the origin of extra context is unknown. Later cases may be influenced by earlier chats in the same Project, but that causal mechanism is **not proven**.

The previous zero-fetch issue is not the cause: Stage I intentionally returns complete original source packets in one tool call. Adding a second source-fetch call would not authenticate referent selection.

## Decision and next bounded implementation question

- **Do not** connect real conversation data, replace either existing synthetic MCP or mark the native selector production-ready.
- Keep Stage I’s separate fixture, tool version, plugin and private tunnel as a clearly labelled experimental test environment; retain failing evidence and original G/F reports.
- The next candidate is a **separately preregistered trusted-current-user-message boundary investigation**: determine from current authoritative platform documentation and inspectable tool interfaces whether a read-only MCP handler can receive a host-attested original user message or valid, scope-restricted conversation identifier independently of model-authored tool inputs. Do not assert such a capability exists without verification. If absent, report the limit and evaluate architecture-level alternatives, rather than pretending an internally computed hash or assistant-provided chat ID provides authenticity.
- A secondary, separately registered native trial may investigate instruction sensitivity and fresh-Project first-turn repeatability, but better prompting alone does not establish deterministic referent authentication.

**No external inference model, original MCP rewrite, new key, real-data import or Windows/Ubuntu auto-start was authorised or performed.**
