# LTM-RAG vNext — native ChatGPT synthetic MCP evidence

**Date:** 18 November 2026 (AEDT). **Repository branch:** `work/ltm-rag-vnext-synthetic-20261118`.

## Setup and scope

The user's existing authenticated Windows Chrome account was used to create a private ChatGPT plugin named **LTM-RAG vNext Synthetic Recall**, with Tunnel connection `tunnel_6afd0f1439e88191862ade433921b3f9` and **No authentication** for the MCP endpoint. ChatGPT displayed **“LTM-RAG vNext Synthetic Recall is now connected”**. The Ubuntu tunnel daemon used the existing project key under a process-only `CONTROL_PLANE_API_KEY` mapping, as authorised. It reported `200 ready`, `200 live` and active successful control-plane polling. No OpenAI supplementary Responses inference was submitted from Ubuntu.

All data in the local archive was explicitly synthetic (6 records). The MCP server exposed only `lookup_evidence` and `fetch_source`. This test made no personal-chat export or import.

## Directly observed native conversations

| Test | ChatGPT native input | Browser result | Ubuntu audit | Verdict |
|---|---|---|---|---|
| **E1 — explicit discovery** | “Using the connected LTM-RAG vNext Synthetic Recall tool, search the synthetic archive for blue notebook and fetch the exact source message…” | Retrieved original train recollection, corrected library recollection, and alternate drawer branch; preserved correction and attribution distinctions | 1 `lookup_evidence` (4 hits) + 3 `fetch_source` | **PASS** — actual plugin/tool invocation |
| **H1 — unprompted history** | “Earlier we discussed a fictional blue notebook story. What was the corrected location, and what were the exact words in the correction? Please distinguish a reported recollection from independently verified speech.” | Recovered verbatim `Correction: Mira actually said "The blue notebook is at the library."`, and identified it as reported recollection, not authenticated speech | 1 `lookup_evidence` (5 hits) + 1 `fetch_source` | **PASS** — unprompted relevant recall |
| **N1 — unrelated control** | “In two sentences, explain why the daytime sky appears blue.” | Answered with Rayleigh scattering; no reference to notebook | **0 new calls** (total log remained 6) | **PASS** — no irrelevant recall |
| **H2 — unprompted contextual history** | “In the earlier fictional discussion involving Mira, where did the alternative branch place the object, and was that statement a correction or an inference? Please identify the evidence rather than guessing.” | Recovered `Alternate branch: notebook was in a drawer.`, correctly labelled assistant inference on `alternative` branch, source `fixture://notebook/m4` | 1 `lookup_evidence` (4 hits) + 1 `fetch_source` | **PASS** — unprompted relevant recall |

The H1 and H2 prompts **did not name or select the plugin**, and browser accessibility inspection found no selected-plugin chip before either send. H2 did not even say “notebook”. E1 explicitly named the plugin, so it is not counted as unprompted. The N1 prompt was wholly unrelated. These were separate ordinary native ChatGPT chats rather than a single sequential context; none was confirmed to be inside a ChatGPT Project.

**Saved native chats:**
- H1: https://example.invalid/private-chatgpt-evidence
- H2: https://example.invalid/private-chatgpt-evidence

The E1 and N1 chat IDs were not independently recorded, so their URLs are not invented here. They were inspected through the authenticated desktop's browser accessibility tree.

## Content-minimised local invocation audit

Private local log: `vnext/.local/mcp-tool-audit.jsonl` (mode 0600, ignored by Git). The log records tool name, UTC timestamp, event ID and result count, not query or result text. The eight actual events are:

| AEDT time | Event ID | Tool | Result |
|---|---|---|---|
| 14:17:31 | `fd5984d3-d6af-4b5b-8dde-a639fad02ee5` | `lookup_evidence` | 4 hits |
| 14:17:36 | `3285eb28-a2ff-470e-990a-e7e9010c7b50` | `fetch_source` | 1 |
| 14:17:36 | `af649d85-41a0-4749-97d4-581211061f94` | `fetch_source` | 1 |
| 14:17:36 | `edf6334d-b6ab-462b-82e3-e8ae994bb45c` | `fetch_source` | 1 |
| 14:21:00 | `0b359dd7-55c7-4804-9064-314abd35fce2` | `lookup_evidence` | 5 hits |
| 14:21:04 | `ea8bdc17-6711-42f3-85e7-67f1ab6fd55c` | `fetch_source` | 1 |
| 14:26:36 | `a12c2591-125c-4cfc-9a2f-7e8a1c5737c0` | `lookup_evidence` | 4 hits |
| 14:26:40 | `a78b84c0-a0b6-47f3-9424-9575ec58a25c` | `fetch_source` | 1 |

At this first, pre-Project checkpoint the observed total was **3 successful lookups, 5 successful fetches, 0 errors**. Later Project and recovery events are documented below; the final cumulative total is 12 successful tool calls. Client chat IDs are not recorded by the MCP server, so event attribution relies on test timing and the independently observed ChatGPT output, not a direct correlation identifier.

## Acceptance and limits

**Preliminary functional compatibility PASS:** native ChatGPT invoked the installed private plugin, performed exact-source recall and preserved the essential attribution/correction distinction. On **2/2** history-needed *unprompted* test prompts ChatGPT retrieved the relevant synthetic record; on **0/1** unrelated controls did it invoke memory.

**Not yet accepted:** Astra's proposed aggregate reliability thresholds (90% initiation for history-needed turns and at most 10% unnecessary searches) are **not established by this small, non-random sample**. Native ChatGPT **Project** context and controlled outage/recovery were subsequently tested (see below), but personal historical export/import, privacy handling of real records and long-running process supervision remain unverified.

The read-only synthetic gate should be retained while designing a larger, separately documented native test set. Do not conflate successful functional trials with production readiness. The later API Access inference/token-budget stage is still deferred.

## Native ChatGPT Project and failure/recovery — later tests

A dedicated ChatGPT Project, **LTM-RAG vNext Synthetic Trial**, was created in the authorised logged-in Windows Chrome session with no non-synthetic source uploaded. The first project chat is:
https://example.invalid/private-chatgpt-evidence

| Test | Input/context | ChatGPT response verified in browser | Ubuntu evidence | Verdict |
|---|---|---|---|---|
| **P1 — Project unprompted history** | New Project chat: “In the fictional Mira conversation we discussed earlier, what was the corrected location of the object? Give the exact reported wording, and say whether that proves Mira said it.” No tool name or chip | Exact library correction; source `fixture://notebook/m3`, attribution `reported_recollection`, SHA-256; explicitly not proof Mira spoke it | 14:33:34 `lookup_evidence` (3 hits) + 14:33:37 `fetch_source` (1) | **PASS** — unprompted recall within native Project |
| **P2 — Project unrelated follow-up** | Same Project thread: “In two sentences, explain how rainbows form.” | Correctly explained refraction and internal reflection; no memory citations | **0 new calls**, log remained 10 events | **PASS** — no unnecessary memory call despite preceding history discussion |
| **O1 — controlled outage** | Sent after stopping only the local synthetic MCP server: “In our fictional garden record, what colour was the gate beside the bicycle? Quote the archived source only if you can actually retrieve it; otherwise say that the source is unavailable.” | “Source unavailable. I attempted to retrieve the fictional garden record from the connected synthetic archive, but the retrieval tool failed. I cannot verify the gate's colour or quote the original wording.” | Local process PID `149390` terminated with SIGINT; `curl -I http://127.0.0.1:8787/mcp` failed to connect. No new **successful local** tool audit events. | **PASS** — honest inability to verify during outage |
| **R1 — recovery** | After service restart, same Project thread: “Please retry the fictional garden archive lookup now. What was the exact sentence about the bicycle and gate, and what is its source? Do not guess.” | Retrieved exact sentence “The blue bicycle was parked beside a yellow gate.”, `fixture://garden/m5`, `direct_message`, author User, hash `f239c5e2b9e61ce67c1ffb2af46e1106c703b4827f68bca31f7f2e41365a80ca` | Restarted server PID `158559`; tunnel `doctor` `result=ok`; `/readyz` returned `ready`; 14:39:40 lookup (2 hits) + 14:39:43 source fetch (1) | **PASS** — restored end-to-end retrieval |

The extra four successful local tool audit events were:

| AEDT time | Event ID | Tool | Result |
|---|---|---|---|
| 14:33:34 | `60ea1d89-31c3-4bd2-b9ca-904374cc0700` | `lookup_evidence` | 3 hits |
| 14:33:37 | `a31a1f62-37f0-4dd6-b518-aa0a9437341b` | `fetch_source` | 1 |
| 14:39:40 | `4a7db1e1-3d90-41cd-9b49-0dda4bebe779` | `lookup_evidence` | 2 hits |
| 14:39:43 | `29aad1b5-342d-4039-a7de-bdf7b17659f8` | `fetch_source` | 1 |

**Final native call accounting:** 12 successful audited calls in Ubuntu (5 lookups, 7 source fetches). These exclude the unsuccessful outbound tool attempt in O1 because it never reached the local MCP handler; a zero-increment log does **not** prove ChatGPT did not attempt retrieval. Directly observed Project failure text establishes that an unsuccessful attempt occurred.

**Final small-sample functional matrix:** 3/3 history-needed prompts where the user did **not** name or select the plugin (H1, H2, P1) resulted in successful relevant retrieval; 0/2 unrelated prompts (N1, P2) triggered a memory call; 1/1 simulated outage prompted truthful source-unavailability, followed by 1/1 successful explicit retry after restoration. These are observed functional outcomes, **not validated statistical estimates of future reliability**. Retain the synthetic-only deployment, avoid prematurely importing private conversations, and continue with larger pre-registered selectivity testing and operational supervision evaluation.

## Independent byte-level rendered-text checks

A further direct UI Automation readback from the dedicated logged-in Chrome test window extracted the **actual rendered text** of the two target ChatGPT source quotations. Each was UTF-8 encoded and SHA-256 hashed independently of the MCP tool's advertised metadata. The original fixture texts were separately hashed from the UTF-8 JSON source in Ubuntu:

| Source message | Browser text SHA-256 | Fixture exact_text SHA-256 | Result |
|---|---|---|---|
| `m3` corrected recollection | `929487cefd54df342815cfe65be6b392208c6d6d04d33e28c87848c4b6d7be40` | Same | **Byte-identical** |
| `m5` garden sentence | `f239c5e2b9e61ce67c1ffb2af46e1106c703b4827f68bca31f7f2e41365a80ca` | Same | **Byte-identical** |

In particular, UI Automation confirmed the quotation marks in the rendered `m3` correction are `U+201C` and `U+201D`, as in the original fixture, notwithstanding text rendering in terminal readbacks that may visually substitute straight marks. This **proves fidelity for these two independently inspected rendered passages**, not for every retrieved record or for unsupported historical claims.
