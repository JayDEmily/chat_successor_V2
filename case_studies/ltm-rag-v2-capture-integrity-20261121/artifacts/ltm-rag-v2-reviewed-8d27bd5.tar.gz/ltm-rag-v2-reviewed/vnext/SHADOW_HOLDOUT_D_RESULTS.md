# Independent synthetic Holdout D — offline source candidate rankings

Data/questions fixed before embedding execution: HOLDOUT_D_PROTOCOL_20261118.md.
New fictional 40-record corpus; 32 questions (12 explicit, 12 implicit,
4 original and 4 alternative-branch). Registered target ID alone counts as a hit.
C had been inspected before D was designed; D is new but still handcrafted.

All algorithms were fixed in SHADOW_EMBEDDING_EXPERIMENT_20261118.md
before evaluation on C and D. Model: BAAI/bge-small-en-v1.5
(FastEmbed 0.9.1, ONNX Runtime 1.32.0, CPU two threads).
No remote inference API or live service changes.

Fixture SHA-256: cc0971ef3fd4c260dac3d21b77f92b8b978ee40f369f92702271c4a15529e89b
Probe SHA-256: 29ed2bcec689ab86b8d5b49fd85bbf989c81468f41725bdbed584f56ff29f10b

| Question type | Method | Source recall@8 | Correct source ranked first |
|---|---|---:|---:|
| explicit | FTS5 | 12/12 | 7/12 |
| explicit | DENSE_RAW | 12/12 | 10/12 |
| explicit | DENSE_CHAIN | 12/12 | 11/12 |
| explicit | HYBRID_RRF | 12/12 | 11/12 |
| implicit | FTS5 | 5/12 | 1/12 |
| implicit | DENSE_RAW | 12/12 | 8/12 |
| implicit | DENSE_CHAIN | 12/12 | 12/12 |
| implicit | HYBRID_RRF | 8/12 | 5/12 |
| original | FTS5 | 4/4 | 2/4 |
| original | DENSE_RAW | 4/4 | 2/4 |
| original | DENSE_CHAIN | 4/4 | 0/4 |
| original | HYBRID_RRF | 4/4 | 1/4 |
| alternative | FTS5 | 4/4 | 4/4 |
| alternative | DENSE_RAW | 4/4 | 4/4 |
| alternative | DENSE_CHAIN | 4/4 | 4/4 |
| alternative | HYBRID_RRF | 4/4 | 4/4 |

| Probe | Group | Expected | FTS5 | Dense raw | Dense chain | Hybrid |
|---|---|---|---:|---:|---:|---:|
| E01 | explicit | d03 | 2 | 2 | 1 | 1 |
| I01 | implicit | d03 | 1 | 1 | 1 | 1 |
| E02 | explicit | d06 | 1 | 1 | 1 | 1 |
| I02 | implicit | d06 | 2 | 1 | 1 | 1 |
| E03 | explicit | d09 | 1 | 1 | 1 | 1 |
| I03 | implicit | d09 | MISS | 2 | 1 | MISS |
| E04 | explicit | d12 | 2 | 1 | 1 | 1 |
| I04 | implicit | d12 | 5 | 1 | 1 | 1 |
| E05 | explicit | d15 | 2 | 1 | 1 | 1 |
| I05 | implicit | d15 | MISS | 1 | 1 | MISS |
| E06 | explicit | d18 | 1 | 1 | 1 | 1 |
| I06 | implicit | d18 | MISS | 1 | 1 | 5 |
| E07 | explicit | d21 | 2 | 1 | 1 | 1 |
| I07 | implicit | d21 | MISS | 1 | 1 | MISS |
| E08 | explicit | d24 | 2 | 1 | 1 | 1 |
| I08 | implicit | d24 | MISS | 2 | 1 | 5 |
| E09 | explicit | d27 | 1 | 1 | 1 | 1 |
| I09 | implicit | d27 | 5 | 1 | 1 | 1 |
| E10 | explicit | d30 | 1 | 1 | 1 | 1 |
| I10 | implicit | d30 | 2 | 2 | 1 | 1 |
| E11 | explicit | d33 | 1 | 1 | 1 | 1 |
| I11 | implicit | d33 | MISS | 1 | 1 | 3 |
| E12 | explicit | d36 | 1 | 2 | 2 | 2 |
| I12 | implicit | d36 | MISS | 2 | 1 | MISS |
| O01 | original | d01 | 1 | 1 | 2 | 1 |
| O02 | original | d04 | 2 | 2 | 2 | 2 |
| O03 | original | d25 | 1 | 1 | 2 | 2 |
| O04 | original | d31 | 2 | 2 | 2 | 2 |
| A01 | alternative | d37 | 1 | 1 | 1 | 1 |
| A02 | alternative | d38 | 1 | 1 | 1 | 1 |
| A03 | alternative | d39 | 1 | 1 | 1 | 1 |
| A04 | alternative | d40 | 1 | 1 | 1 | 1 |

## Interpretation boundary

These are source-candidate rankings, not generated answers or conversational
memory initiation. An incorrect original or alternative branch ID is counted
as failure even if the result text is topically similar.
The test is small and handwritten, not a random sample of genuine history.
All text stays synthetic, with isolated temporary SQLite and local CPU
embeddings; source versioning and SHA-256 remain in authoritative SQLite.
No candidate method is promoted to the live MCP search by this experiment.
