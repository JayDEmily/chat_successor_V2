# Stage N — frozen single native under-TTL UI confirmation probe

**Preregister before execution — 20 November 2026, AEDT. Synthetic only.**

## Authority and purpose

This stage continues immutable Stage M at checkpoint `ec90ed9188b7090140ae20a0be83fe7b31e19241`; it is **not** a re-run or amendment of M-N01/M-N02. M demonstrated one native model-opened MCP Apps widget and one app-only callback that correctly returned `EXPIRED` after 262.618 seconds versus 60-second TTL. A single new separate native Stage N experiment tests whether a fresh app-only click can reach `CONFIRMED` **within 60 seconds**, using the same untouched synthetic-only private Stage M MCP server. Stage M's one-send and one-click allowance remains exhausted.

Read: `vnext/AGENTS.md`, Stage M registered protocol/cases, M native results, `ltm_vnext/mcp_apps_m.py`, original-source trust constraints. Official reference: https://developers.openai.com/plugins/reference and https://developers.openai.com/plugins/build/app-quickstart.

## Frozen artifacts and scope

- Exactly one **fresh ChatGPT conversation** with the existing installed native private ChatGPT MCP plugin `plugin_asdk_app_6affaf818f3481919433489e25b52471`, which binds existing tunnel `tunnel_6affa48f70b0819187bbe06449bf2750`, targeting existing loopback 127.0.0.1:8791/mcp. Do **not** create any new plugin/tunnel, alter listener, change any token/credential, or restart/repoint original/G/I/K/M.
- Use plugin's existing `Try in chat` action to make a fresh ChatGPT composer. The host may prepend a separate plugin mention; distinguish from the exact frozen user-text suffix. No additional unrelated prompts.
- Exactly one frozen N-N01 prompt, specified byte-for-byte in `MCP_APPS_N_CASES_20261120.json`, and at most **one** automated, explicitly synthetic click on `Confirm fictional topic: Merrow calibration log` in the actual embedded widget, N-N02. Never send or click a second time under Stage N, even on error. Preserve durable local Windows pre-send and pre-click markers before acting, and check the prior M audit event count is exactly 2.
- The automated click must occur **as soon as the requested live widget button appears**. Do not perform screenshot/research/process inventory between opening call and click. If the widget does not render sufficiently soon, or the session/UI cannot be uniquely attributed, **do not click**; record `NATIVE_UI_NOT_VERIFIED`. No retry.
- The baseline `vnext/.local/trial-m-mcp-audit.jsonl` has exactly two Stage M native events `AWAITING_CONFIRMATION`, `EXPIRED`. New tool events must be individually counted after baseline and distinguishable by tool and event order, with one opening event and zero or one callback event. If additional unsolicited calls arrive, preserve rather than erase and fail exact count. Raw native session/subject IDs, chat URL, current user text, challenge, event IDs and any real private metadata stay out of tracked Git.
- The frozen 60-second server TTL and process-local correlation check remain unchanged. Never modify Python Stage M handler, HTML or preregistration expectations to improve this native result. The plugin is bound to **synthetic-only no-archive** tools and **does not authenticate user identity, current question or real consent**.

## Primary finite verdicts

- `PASS_N_NATIVE_ACCEPTED_UI_CALLBACK_TRANSPORT_ONLY` requires exactly one frozen native prompt (or plugin mention plus exact frozen text), saved-message readback, exactly one opening event `AWAITING_CONFIRMATION` (no source packets), one **automated** Merrow click within 60 seconds, second callback event `CONFIRMED` (no source packets), corresponding visible widget success, and independently verified timing/one-send/one-click receipts. This confirms the functional UI-to-server happy path **only**. It does not prove host authorisation of app-only tools, authenticated human consent, current original-user-message provenance, source relevance, or I05/I15 repair.
- `NATIVE_N_EXPIRED` if callback is observed but time exceeds TTL or status is `EXPIRED`, with cause recorded.
- `NATIVE_N_NO_CALLBACK` if a click was issued but callback audit not observed; `NATIVE_N_UI_NOT_VERIFIED` if widget not proven or click withheld; `NATIVE_N_SEND_UNRESOLVED` if send/registration evidence cannot be linked; `NATIVE_N_PROTOCOL_DEVIATION` if extra native sends/clicks or tool calls.
- Claim neither successful selection nor verified human action merely because a UI button was rendered or automation clicked. All positive claims require server evidence.

## Independent audit and publication

Prepare a private Windows one-send/click script, frozen prompt hash, and ignored `vnext/.local` UI verification record. Publish a dated native Stage N results report in `vnext/` with exactly observed outcomes and limitations, new audit script, updates to `vnext/PROGRESS.md` and `vnext/README.md`. Independently verify preregistration Git bytes, the original unchanged M server handler and exact native event delta, run 160 core and 40 shadow regressions, inspect diff, commit/push same work branch, and independently read back GitHub commit/tree/parent/files. No staging of private chat IDs or credentials.

**Stop after one native prompt and one automated Merrow click (if safe), with no further native sends.** Stage I remains 14/16 and Stage K original deviation unchanged. No real history or production deployment.
