# Stage U — native cross-chat memory retrieval, from hosted semantic search to SQLite originals

**20 November 2026 | Freeze before implementation/native sends.**

## Decision gate

Stage T proved exact *native normal ChatGPT* model output can be captured and indexed in OpenAI Vector Stores with an independent original SQLite source. **It has not proved a distinct new ChatGPT conversation can retrieve those records automatically.** Stage U specifically probes that missing end-to-end link.

Existing vNext synthetic-only authority permits a **new, separate**, read-only *fictional-only* MCP server and private tunnel/plugin; all original/G/I/K/M and Stage S/T stores and native action budgets are untouched. The new tool `lookup_synthetic_memory_u(query, limit=3)` must perform **one remote hosted Vector Store semantic search** and then exact local **SQLite** original source readback via verified file-ID mappings. It must never fabricate original quotes, accept external-source IDs, import history, mutate source data or authorise real history. The model-initiated tool invocation **does not prove authenticated owner approval**, and the installed plugin uses no OAuth because it exposes *only fictional records*. ChatGPT Work prohibited.

One fixed source: the already independently validated five-file 30-day OpenAI-hosted Stage T Vector Store and ten fictional original SQLite messages. Use the already existing project-scoped key only inside the Ubuntu process; never package it into a plugin, log it or display it. Query length and maximum result count must be bounded; source packets must have message role, exact UTF-8 text/hash, source IDs, send-action timestamp and capture time. Server should return **only allowlisted synthetic source** with `candidate_only=true`; no source-scope token or claims about human consent. Use durable private audit events, recording counts/hash not user text or private remote IDs.

## Pre-registered finite native evaluations

The case matrix `NATIVE_HOSTED_U_CASES_20261120.json` defines two separate **maximum** real ChatGPT sends, never repeated.

- `U-N01`: one new ChatGPT conversation, **no app/tool name or explicit MCP invocation** in prompt. Ask who feeds Nimbus Saturday after correction and when watering moved. Tool must *actually be available* to the new ChatGPT host, but no named tool prompt. A native answer without a matching new backend audit event is **NOT** unprompted retrieval proven even if it happens to be factually correct through normal ChatGPT/Project memory.
- `U-N02`: an independently labelled explicitly-directed tool query about Ryan (rowing-shell friend) and engineering M6 bolts. It is a different trial condition and must not be confused with the unprompted result. It only proceeds if the new private plugin is verified accessible in the dedicated new conversation. Tool audit and returned SQLite original IDs are required. Do not repeat the U-N01 question to improve invocation metrics.
- A unique browser window/one new conversation distinct from Stage S, no unrelated tabs modified, no auto-resends after a send-once marker. Do not expose personal historical messages, use a real user archive or claim the automated simulated-user prompts are the human owner's own words.
- Each call first records source search in private audit (query digest, count, UTC) and only returns original exact packets after hash/role/hosted-file validation. If a provider timeout, plugin discovery error, UI issue or source integrity mismatch occurs, preserve evidence and **stop that probe**, continuing independent offline work.
- Before sending any native prompt: independent preregistration GitHub commit parent/tree/blob readback; new MCP local unit and streamable-HTTP tests, server bounds and fail-closed tests, tunnel check + private plugin identity and target URL readback. Preserve all six original M/N/O/P audit events exactly; do not modify other synthetic connectors.
- Set limit of **five** server hosted-search calls total in the bounded U native experiment; tool refusal/over-budget events count and cannot be quietly retried. No more than one new private tunnel or one new private plugin is created under this experiment.

## Acceptance and truthfulness

**Unprompted native retrieval PASS** only if distinct fresh ChatGPT prompt U-N01 caused ≥1 actual recorded Stage U server-side tool invocation, that invocation returned exact Stage T verified SQLite original packets including turn 3, and native assistant answer was checked for faithful correction and chronology. An answer from the model without tool trace is not a pass.

**Explicitly routed native retrieval PASS** only if U-N02 has an attributable actual server call, original Stage T user statements supporting both Ryan and M6, and answer doesn't confuse model-generated reply with user-origin facts.

Publish accurate PASS/PARTIAL/BLOCKED per predicate, full offline and shadow regressions, source integrity readback, GitHub remote HEAD/parent/tree/blob verification. Do not infer true owner-authored text, general always-on background retrieval or other conversations' contents from this bounded synthetic test.
