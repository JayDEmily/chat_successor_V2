# Stage V — native ChatGPT cross-chat hosted-memory tool experiment

**20 November 2026 | Final registered verdict: UNPROMPTED_NO_TOOL; EXPLICIT_TOOL_CALLED_BUT_DENIED_SCOPE.**

## Preregistered controlled conditions

Stage V protocol and exact two-message case matrix were independently pushed and verified as commit `a52f5511167e74638d7b33fa1f707c72ac5f0593`, parent `23286c98bff035cadc93873d4d0d8542485c638b`. The native U package plugin did not expose a normal-chat launcher, so the owner-authorised separate custom MCP connector installation was performed once in the normal signed-in ChatGPT Plugins UI using **Add custom MCP server → Tunnel → No authentication → Create as a plugin**, then the native **Connect** step. A single new private connector was registry-read back with exact display name `LTM-RAG vNext Hosted Memory U Native`, a synthetic-only source description, and the U private tunnel. The installed native plugin detail page displayed **Try in chat**. New tunnel creations at this step: zero.

### V-N01 — fresh chat without explicitly selecting plugin

One registered fictional user question about corrected Nimbus Saturday care and garden watering was sent into a **new**, empty normal ChatGPT conversation without any tool/plugin selection. The initial Windows accessibility reader errored **after** sending; the one-send marker prevented replay. Independent read-only observation of that exact saved chat captured one genuine ChatGPT reply. It answered correctly that **Casey feeds Nimbus Saturday and watering is Sunday morning**. The U server audit remained **absent: zero tool invocations**. Therefore correct reply is NOT evidence of autonomous hosted-vector lookup: ChatGPT's separate account/project context could have supplied it. **V-N01 verdict: UNPROMPTED_NATIVE_TOOL_RETRIEVAL_NOT_ESTABLISHED.**

### V-N02 — distinct fresh chat, plugin explicitly selected

The new native plugin was selected via **Try in chat** exactly once in a second separate fresh conversation. The composer displayed its explicit plugin mention. The registered Ryan/rowing-shell/M6 question was sent exactly once, with unique send marker; one actual ChatGPT reply was captured and checked in that saved chat. The backend U private audit recorded a real server-side tool invocation **CALL_STARTED**, then **CALL_COMPLETED: DENIED_SCOPE**, returning zero SQLite source packets. Its response correctly reported `DENIED_SCOPE`, acknowledged original SQLite/source IDs were unavailable, and did **not** invent authenticated original source identifiers. Ryan and M6 facts in the answer may have come from ordinary ChatGPT context; no exact Stage T source had been released. **V-N02 verdict: NATIVE_EXPLICIT_PLUGIN_CALL_PROVEN; SOURCE_RETRIEVAL_NOT_PROVEN.**

## Integrity and boundaries

Exactly **two** native messages in two distinct saved ChatGPT conversations; no additional sends and no retries. The original Stage S five-message budget was not used again. Private pending-send markers, original response text, saved chat URLs, model tool input hash and audit events remain ignored under `vnext/.local` or local Windows temp, **not committed**. The native V-N02 tool query hash does not match its frozen user prompt; tool input values were not logged, so the **precise DENIED_SCOPE validator reason is not known**. There is no evidence of authenticated original-owner typed-message provenance or automatic always-on cross-chat retrieval.

**Next finite test:** A new, separately preregistered Stage W should replace U's overly lexical model-query gate with **fixed-source-scoped** semantically neutral validation and privacy-preserving explicit rejection-reason audit. Maintain strict Stage T source identity, bounded results, and durable call quota. Reuse the **existing** U tunnel/native plugin; no new connector. Do not resend or rescore V-N01/V-N02.
