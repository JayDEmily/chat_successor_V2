"""Evaluate a precommitted raw-dense abstention gate on unseen synthetic Holdout E.

The gate is frozen in RELEVANCE_GATE_T_20261118.json and must never be
refitted using any E source, question, target or outcome.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import tempfile
from collections import Counter
from pathlib import Path

import numpy as np
from ltm_vnext.archive import Archive
from scripts.run_shadow_embeddings import CACHE, MODEL, normalized, order_by_score

ROOT=Path(__file__).resolve().parents[1]
FIXTURE=ROOT/"fixtures/synthetic_holdout_e.json"
PROBES=ROOT/"HOLDOUT_E_PROBES_20261118.json"
GATE=ROOT/"RELEVANCE_GATE_T_20261118.json"
CAL=ROOT/"RELEVANCE_CALIBRATION_20261118.json"
REPORT=ROOT/"HOLDOUT_E_RELEVANCE_RESULTS.md"
GROUPS=("explicit","implicit","original","alternative","hard_negative","unrelated_negative","ambiguous")
POSITIVE=set(GROUPS[:4])
NEGATIVE=set(GROUPS[4:])

def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check_locked_inputs(fixture: dict, plan: dict, gate: dict) -> None:
    if fixture.get("synthetic") is not True or len(fixture.get("messages",[])) != 34:
        raise ValueError("Wrong synthetic E fixture")
    if plan.get("trial_id")!="ltm-vnext-synthetic-holdout-e-20261118":
        raise ValueError("Wrong frozen E trial")
    if not plan.get("registered_before_execution") or plan.get("top_k")!=8:
        raise ValueError("Missing frozen E markers")
    if len(plan.get("probes",[]))!=58:
        raise ValueError("Expected 58 preregistered probes")
    ids={m["message_id"]:m for m in fixture["messages"]}
    if len(ids)!=34 or {m["source_id"] for m in ids.values()}!={"synthetic-holdout-e"}:
        raise ValueError("Wrong E source namespace or duplicate ID")
    if any(m["capture_method"]!="synthetic_fixture" for m in ids.values()):
        raise ValueError("Real or unlabelled capture")
    count=Counter(p["kind"] for p in plan["probes"])
    if dict(count)!=plan["counts"] or set(count)!=set(GROUPS):
        raise ValueError("Registered class counts changed")
    if len({p["id"] for p in plan["probes"]})!=58:
        raise ValueError("Duplicate E probe ID")
    for q in plan["probes"]:
        if q["limit"]!=8:
            raise ValueError("Changed topK")
        target=q["expected_message_id"]
        if q["kind"] in POSITIVE and target not in ids:
            raise ValueError("Unknown required target")
        if q["kind"] in NEGATIVE and target is not None:
            raise ValueError("Negative/ambiguous probe secretly has a target")
        if q["kind"] in ("explicit","implicit") and not ids[target].get("supersedes"):
            raise ValueError("Positive correction target is not corrected")
        if q["kind"]=="original" and ids[target]["position"]!=1:
            raise ValueError("Historical original target is not original")
        if q["kind"]=="alternative" and ids[target]["branch_id"]!="alternative":
            raise ValueError("Alternative target is not on alternative branch")
    if gate.get("gate_id")!="raw-dense-cd-calibration-20261118":
        raise ValueError("Wrong calibration gate identity")
    if gate.get("calibration_sha256")!=sha256(CAL):
        raise ValueError("Calibration file differs from frozen digest")
    if gate.get("positive_total")!=48 or gate.get("negative_total")!=24:
        raise ValueError("Unexpected previous calibration populations")
    if gate.get("negative_accepted")!=0 or not gate.get("e_holdout_not_accessed"):
        raise ValueError("Calibration not frozen independently of E")
    threshold=np.float32(gate["threshold_float32"])
    if not np.isfinite(threshold) or threshold!=np.nextafter(
            np.float32(gate["max_negative_float32"]),np.float32(np.inf)):
        raise ValueError("Frozen threshold does not satisfy registered formula")
    if gate.get("model")!=MODEL:
        raise ValueError("Model mismatch")

def run(model, fixture: dict, plan: dict, gate: dict) -> list[dict]:
    check_locked_inputs(fixture,plan,gate)
    messages=fixture["messages"]
    ids=[m["message_id"] for m in messages]
    vectors=normalized(model.embed([m["exact_text"] for m in messages],batch_size=16))
    queries=normalized(model.embed([p["query"] for p in plan["probes"]],batch_size=16))
    similarity=queries@vectors.T
    threshold=np.float32(gate["threshold_float32"])
    rows=[]
    with tempfile.TemporaryDirectory(prefix="ltm-holdout-e-") as folder:
        archive=Archive.initialise(Path(folder)/"e.sqlite")
        ingested=archive.ingest_synthetic(FIXTURE)
        if ingested!={"inserted":34,"total":34}:
            raise ValueError("Unexpected E source count")
        for idx,q in enumerate(plan["probes"]):
            scores=similarity[idx]
            ranking=order_by_score(ids,scores)
            best=np.float32(scores.max())
            top=ranking[:8]
            promoted=bool(best>=threshold)
            original=archive.lookup(q["query"],limit=8)["hits"]
            lexical=[m["message_id"] for m in original]
            target=q["expected_message_id"]
            rank=(top.index(target)+1) if target in top else None
            lexrank=(lexical.index(target)+1) if target in lexical else None
            rows.append({
                "id":q["id"],"kind":q["kind"],"target":target,
                "raw_top1":top[0],"raw_score":float(best),
                "raw_rank8":rank,"raw_correct1":rank==1,
                "gate_promotes":promoted,
                "gated_target8":bool(promoted and rank is not None),
                "gated_correct1":bool(promoted and rank==1),
                "lexical_top1":lexical[0] if lexical else None,
                "lexical_candidates":len(lexical),
                "lexical_rank8":lexrank,
            })
    return rows

def aggregate(rows: list[dict]) -> dict:
    data={}
    for group in GROUPS:
        subset=[r for r in rows if r["kind"]==group]
        data[group]={
            "total":len(subset),
            "ft_nonempty":sum(r["lexical_candidates"]>0 for r in subset),
            "ft_correct8":sum(r["lexical_rank8"] is not None for r in subset),
            "ft_correct1":sum(r["lexical_rank8"]==1 for r in subset),
            "raw_correct8":sum(r["raw_rank8"] is not None for r in subset),
            "raw_correct1":sum(r["raw_correct1"] for r in subset),
            "gate_promotes":sum(r["gate_promotes"] for r in subset),
            "gated_correct8":sum(r["gated_target8"] for r in subset),
            "gated_correct1":sum(r["gated_correct1"] for r in subset),
            "wrong_first_when_promoted":sum(
                r["gate_promotes"] and r["target"] is not None and not r["raw_correct1"]
                for r in subset
            ),
        }
    return data

def report(rows: list[dict], gate: dict) -> str:
    summary=aggregate(rows)
    lines=[
        "# Independent Holdout E: raw cosine abstention versus lexical candidate retrieval",
        "",
        "All 58 case labels, exact registered target source IDs and questions were committed",
        "as the synthetic E corpus BEFORE any E embeddings were computed.",
        "The cosine threshold was calibrated ONLY on C/D and committed at an earlier",
        "checkpoint; it was not refitted or selected after viewing E.",
        "",
        "Synthetic fixture SHA-256: "+sha256(FIXTURE),
        "Frozen queries SHA-256: "+sha256(PROBES),
        "Frozen calibration gate SHA-256: "+sha256(GATE),
        "Calibrated float32 cosine threshold: "+format(gate["threshold_float32"],".9f"),
        "Model: BAAI/bge-small-en-v1.5 through isolated local CPU FastEmbed 0.9.1",
        "",
        "## Outcomes by fixed class",
        "",
        "| Class | N | FTS5 candidates | FTS5 exact target@8 | Raw exact target@8 | Gate promotions | Gate accepted correct target@8 |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for group in GROUPS:
        x=summary[group]
        fmt=lambda n: str(n)+"/"+str(x["total"])
        target=(fmt(x["ft_correct8"]) if group in POSITIVE else "not applicable")
        target_raw=(fmt(x["raw_correct8"]) if group in POSITIVE else "not applicable")
        accepted=(fmt(x["gated_correct8"]) if group in POSITIVE else "not applicable")
        lines.append("| "+group+" | "+str(x["total"])+" | "+fmt(x["ft_nonempty"])+" | "+
                     target+" | "+target_raw+" | "+fmt(x["gate_promotes"])+" | "+accepted+" |")
    lines+=["", "## First-rank source quality on positives", "",
            "| Positive class | FTS5 target rank1 | Raw dense target rank1 | Gated correct rank1 | Wrong source first after gate |",
            "|---|---:|---:|---:|---:|"]
    for group in GROUPS[:4]:
        x=summary[group]
        fm=lambda k:str(x[k])+"/"+str(x["total"])
        lines.append("| "+group+" | "+fm("ft_correct1")+" | "+fm("raw_correct1")+" | "+
                     fm("gated_correct1")+" | "+fm("wrong_first_when_promoted")+" |")
    lines+=["", "## Every registered case", "",
            "| Case | Class | Expected target | FTS5 top | FTS5 rank@8 | Raw top | Raw rank@8 | Raw top cosine | Gate |",
            "|---|---|---|---|---:|---|---:|---:|---|"]
    for r in rows:
        fmt=lambda v:"MISS" if v is None else str(v)
        lines.append("| "+r["id"]+" | "+r["kind"]+" | "+str(r["target"] or "no unique source")+
                     " | "+str(r["lexical_top1"] or "none")+" | "+fmt(r["lexical_rank8"])+
                     " | "+str(r["raw_top1"])+" | "+fmt(r["raw_rank8"])+
                     " | "+format(r["raw_score"],".6f")+" | "+("PROMOTE" if r["gate_promotes"] else "ABSTAIN")+" |")
    lines += [
        "", "## What these scores do and do not establish", "",
        "A negative FTS5 candidate is an unnecessary or irrelevant retrieval candidate,",
        "NOT evidence that the final ChatGPT assistant would assert the source was relevant.",
        "Similarly, an ambiguous query with high cosine gives a questionable single-source",
        "promotion; retrieving several candidates for clarification is not itself wrong.",
        "The raw embedding method always has a nearest neighbour, even with no relevant",
        "source. The gate prevents promotion solely when top similarity is below the",
        "fixed C/D-calibrated cutoff; no semantic relevance classifier is used.",
        "",
        "The data are 34 entirely invented sources and hand-authored questions.",
        "The study is not representative of real personal chat history or a population",
        "reliability estimate. The live MCP server still uses its original six-message",
        "FTS5 archive, and source text/attribution were not rewritten.",
        "",
    ]
    return "\n".join(lines)

def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("status","write"))
    action=parser.parse_args().action
    gate=json.loads(GATE.read_text(encoding="utf8"))
    fixture=json.loads(FIXTURE.read_text(encoding="utf8"))
    plan=json.loads(PROBES.read_text(encoding="utf8"))
    check_locked_inputs(fixture,plan,gate)
    from fastembed import TextEmbedding
    model=TextEmbedding(model_name=MODEL,cache_dir=str(CACHE),threads=2,
                        providers=["CPUExecutionProvider"],cuda=False)
    rows=run(model,fixture,plan,gate)
    summary=aggregate(rows)
    print(json.dumps(summary,sort_keys=True))
    if action=="write":
        REPORT.write_text(report(rows,gate),encoding="utf8")
        print("INDEPENDENT_HOLDOUT_E_REPORT_WRITTEN")

if __name__=="__main__":
    main()
