"""Stage U read-only MCP tools/list smoke; consumes zero source searches."""
import asyncio
from pathlib import Path
from mcp.client.streamable_http import streamable_http_client
from mcp import ClientSession

async def main():
    async with streamable_http_client("http://127.0.0.1:8792/mcp") as (reader,writer):
        async with ClientSession(reader,writer) as session:
            await session.initialize()
            tools=await session.list_tools()
            names=[x.name for x in tools.tools]
            if names!=["lookup_synthetic_memory_u"]:
                raise RuntimeError("U server exposes unexpected tools")
            annotations=tools.tools[0].annotations
            if not annotations or annotations.read_only_hint is not True:
                raise RuntimeError("U lookup missing read-only annotation")
            print("STAGE_U_LOCAL_MCP_TOOLS_LIST_PASS tools=1 read_only=true hosted_calls=0")
if __name__=="__main__":
    asyncio.run(main())
