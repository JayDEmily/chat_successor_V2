"""Verify the already-running, supervisor-managed synthetic loopback MCP instance."""
from __future__ import annotations

import asyncio
import socket

from scripts.smoke_http import exercise


def main() -> None:
    with socket.create_connection(("127.0.0.1", 8787), timeout=3):
        pass
    asyncio.run(exercise("http://127.0.0.1:8787/mcp"))
    print("SUPERVISED_MCP_SMOKE: PASS, live_loopback_server=true")


if __name__ == "__main__":
    main()
