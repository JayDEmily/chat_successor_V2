"""Independent Stage L preregistration + packet audit; no model or native send."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import tempfile
from collections import Counter
from pathlib import Path

from ltm_vnext.archive import Archive
from ltm_vnext.decision_support_i import SyntheticHistoryResolver
from ltm_vnext.clarification_l import ClarificationGatewayL, TRUST_BOUNDARY

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
REGISTERED="d5e7649333153d8ba5e0b7e91cb33fa480945974"
PARENT="9227a20562c157876e1966ef9527a76e4edcca4d"
FROZEN=("CLARIFICATION_L_PROTOCOL_20261120.md",
        "CLARIFICATION_L_CASES_20261120.json")
PLAN=ROOT/FROZEN[1]
FIXTURE=ROOT/"fixtures/synthetic_clean_g.json"
MANIFEST=ROOT/"REFERENT_GATE_H_MANIFEST_20261119.json"
REPORT=ROOT/"CLARIFICATION_L_OFFLINE_RESULTS_20261120.md"


def git(*args: str) -> bytes:
    return subprocess.run(["git","-C",str(REPO),*args],capture_output=True,
                          check=True).stdout


def audit() -> dict:
    parent=git("rev-list","--parents","-n","1",REGISTERED).decode().strip()
    if parent != REGISTERED+" "+PARENT:
        raise RuntimeError("Stage L registration commit parent mismatch")
    hashes={}
    for name in FROZEN:
        local=(ROOT/name).read_bytes()
        if local != git("show",REGISTERED+":vnext/"+name):
            raise RuntimeError("Stage L frozen preregistration bytes changed "+name)
        hashes[name]=hashlib.sha256(local).hexdigest()
    plan=json.loads(PLAN.read_text(encoding="utf-8"))
    original=json.loads(FIXTURE.read_text(encoding="utf-8"))
    if (plan["trial_id"]!="ltm-vnext-L-conditional-ui-selection-shadow-20261120"
            or not plan["synthetic_only"] or not plan["registered_before_implementation"]
            or plan["cases_count"]!=20 or len(plan["cases"])!=20
            or plan["ttl_seconds"]!=60 or not original["synthetic"]
            or len(original["messages"])!=20
            or hashlib.sha256(FIXTURE.read_bytes()).hexdigest()!=plan["fixture_sha256"]):
        raise RuntimeError("Frozen plan/fixture identity invalid")
    source={m["message_id"]:Archive._validate(m) for m in original["messages"]}
    children={r["local_id"]:[] for r in source.values()}
    for row in source.values():
        if row["supersedes_local_id"]:
            children[row["supersedes_local_id"]].append(row["local_id"])
    counts=Counter()
    with tempfile.TemporaryDirectory() as tmp:
        db=Path(tmp)/"stage-l-auditor.sqlite"
        assert Archive.initialise(db).ingest_synthetic(FIXTURE)["inserted"]==20
        resolver=SyntheticHistoryResolver(db,FIXTURE,MANIFEST)
        if list(resolver.gate._topic_ids)!=plan["canonical_topic_order"]:
            raise RuntimeError("Manifest changed after registration")
        for index,case in enumerate(plan["cases"],1):
            if case["id"]!=f"L{index:02d}":
                raise RuntimeError("Case order changed")
            now=[900.0]
            g=ClarificationGatewayL(
                resolver,clock=lambda:now[0],
                challenge_factory=lambda:"stage-L-auditor-hidden-challenge-0123456789",
                ttl_seconds=plan["ttl_seconds"])
            base=dict(plan["case_context"])
            public,private=g.begin(base)
            token=private["widget_challenge"]
            if (public["status"]!="AWAITING_CONFIRMATION" or
                    public["source_count"]!=0 or token in json.dumps(public) or
                    "widget_challenge" in public):
                raise RuntimeError("UI-only challenge leaked model-side")
            if private["topic_ids"]!=plan["canonical_topic_order"]:
                raise RuntimeError("Wrong safe topic choices")
            now[0]+=case["clock_advance_seconds"]
            if case["ui_choice"] is not None:
                ctx=dict(base)
                if case["ui_context"]!="valid":
                    field={"wrong_principal":"user_id","wrong_session":"session_id",
                           "wrong_flow":"turn_id"}[case["ui_context"]]
                    ctx[field]="foreign_test_scope"
                candidate=(token if case["ui_token"]=="valid" else
                           "attacker-challenge-without-private-ui")
                did_confirm=g.confirm_from_owner_ui(ctx,candidate,case["ui_choice"])
                if did_confirm is not case["expected_confirm"]:
                    raise RuntimeError("Confirmation outcome mismatch "+case["id"])
            elif case["expected_confirm"] is not False:
                # No UI callback occurred; null expected is required.
                if case["expected_confirm"] is not None:
                    raise RuntimeError("Frozen unconfirmed expected status malformed")
            if case["release_context"]!="valid":
                raise RuntimeError("Unsupported frozen release context")
            result=g.resolve_tool_call(case["model_question"],base,
                                       case["model_claimed_topics"])
            if (result["status"]!=case["expected_release_status"] or
                    result["conversation_ids"]!=case["expected_topics"] or
                    result["source_count"]!=len(case["expected_original_message_ids"]) or
                    [p["message_id"] for p in result["source_packets"]]
                        !=case["expected_original_message_ids"] or
                    result["original_user_text_attested"] is not False or
                    result["trust_boundary"]!=TRUST_BOUNDARY):
                raise RuntimeError("Source admission case failed "+case["id"])
            for packet in result["source_packets"]:
                expect=source[packet["message_id"]]
                for k,v in expect.items():
                    if packet[k]!=v:
                        raise RuntimeError("Original source packet mismatch "+
                                           case["id"]+" "+k)
                if sorted(packet["corrected_by"])!=sorted(
                        children[expect["local_id"]]):
                    raise RuntimeError("Correction descendants changed "+case["id"])
                for neighbour in packet["neighbouring_dialogue"]:
                    lookup={r["local_id"]:r for r in source.values()}
                    ref=lookup.get(neighbour["local_id"])
                    if (ref is None or ref["source_id"]!=packet["source_id"] or
                            ref["conversation_id"]!=packet["conversation_id"] or
                            ref["branch_id"]!=packet["branch_id"]):
                        raise RuntimeError("Cross-branch neighbour "+case["id"])
                    for key in ("position","author_role","exact_text","content_sha256"):
                        if neighbour[key]!=ref[key]:
                            raise RuntimeError("Neighbour integrity "+case["id"])
            if case["expect_replay_denied"]:
                replay=g.resolve_tool_call(case["model_question"],base)
                if replay["status"]!="NO_CONFIRMED_SCOPE" or replay["source_count"]!=0:
                    raise RuntimeError("Replay permit "+case["id"])
            counts[result["status"]]+=1
    return {"registration":REGISTERED,"parent":PARENT,"file_sha256":hashes,
            "case_count":len(plan["cases"]),"passed":len(plan["cases"]),
            "statuses":dict(counts),"originals_validated":20,
            "native_chatgpt_messages":0,"trusted_user_click_demonstrated":False}


def write_report(data: dict) -> None:
    lines=[
        "# Stage L — independently audited synthetic clarification gate",
        "",
        "**20/20 frozen offline cases PASS; 0 native ChatGPT messages or user clicks.**",
        "",
        "## Immutable registration",
        "",
        f"- Git registration commit: `{data['registration']}`; exact parent: `{data['parent']}`.",
        "- Frozen protocol and case plan checked byte-for-byte against preregistration Git blobs:",
        f"  - Protocol SHA-256: `{data['file_sha256'][FROZEN[0]]}`",
        f"  - Cases SHA-256: `{data['file_sha256'][FROZEN[1]]}`",
        "- Original source fixture: 20/20 records checked; complete version, branch, source locator, authorship,",
        "  report-versus-authenticated speech and correction link integrity checked against original bytes.",
        "",
        "## Results and interpretation",
        "",
        f"- Frozen outcomes: {json.dumps(data['statuses'],sort_keys=True)}.",
        "- Missing owner confirmation, forged model topic, wrong principal/session/flow, guessed challenge,",
        "  duplicate or invalid option, expiry and post-release replay all returned zero original source packets.",
        "- A positive UI choice (simulated owner-only callback) scoped one-time release to exactly the chosen",
        "  fictional narrative(s), ordered by the preregistered original manifest—not the model's argument.",
        "- Original ambiguous I05/I15 *utterances* can be accompanied by a separately confirmed fictional",
        "  source scope, but the specific original utterance, speaker reference and semantic intent remain",
        "  **unattested**. This is not an I05/I15 native repair.",
        "- Challenge/token kept private to simulated UI return, excluded from model-public response;",
        "  no runtime credential, real chat text, user identifiers or API inference used.",
        "",
        "## Limitations and admission boundary",
        "",
        "**PASS_L_CONDITIONAL_OWNER_UI_SHADOW_ONLY.** The trusted owner-UI callback is a simulated",
        "test premise. Neither ChatGPT's real UI event provenance, the app-only tool route,",
        "host attestation, native message binding nor native elicitation was demonstrated.",
        "An untrusted client that obtains the private challenge could impersonate a UI callback;",
        "native integration would require its own authenticated transport, authorisation and",
        "preregistered user-interaction test. Do not install this offline adapter into",
        "original/G/I/K or import genuine conversation history.",
        "",
    ]
    REPORT.write_text("\n".join(lines),encoding="utf-8")


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("action",choices=["status","write"])
    a=ap.parse_args()
    result=audit()
    print(json.dumps(result,sort_keys=True))
    if a.action=="write":
        write_report(result)
        print("STAGE_L_OFFLINE_REPORT_WRITTEN")

if __name__=="__main__":
    main()
