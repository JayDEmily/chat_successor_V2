"""Independent read-only Stage R audit (no re-indexing or search replay).

Checks frozen Git registration, actual hosted file attachments, exact local
source bytes, correction relationships, persisted six search measurements and
no native MCP audit mutation. Never logs API keys or hosted private IDs.
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import stat
import subprocess
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen

from ltm_vnext.archive import Archive
from ltm_vnext.hosted_memory_r import project_key

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
REG="97b5c691c81862e782d32978bf33e56b15517ba5"
PARENT="b9589cc5c7af7432c12e6e0450f3fc860872e029"
FROZEN=("HOSTED_MEMORY_R_PROTOCOL_20261120.md",
        "HOSTED_MEMORY_R_CASES_20261120.json",
        "fixtures/synthetic_diary_r_20261120.json")
LOCAL=ROOT/".local/hosted-memory-r"
DB=LOCAL/"synthetic_conversation.sqlite"
AUDIT=ROOT/".local/trial-m-mcp-audit.jsonl"
EXPECTED_NATIVE_SHA="65aee8025541240eac6fde67d0b47bcc870c3b02f99e3c68b53f90ed90cb769a"


def git(*args):
    return subprocess.run(["git","-C",str(REPO),*args],
                          capture_output=True,check=True).stdout


def openai_get(key,route):
    request=Request("https://api.openai.com/v1"+route,method="GET",
                    headers={"Authorization":"Bearer "+key,
                             "Accept":"application/json"})
    try:
        with urlopen(request,timeout=30) as response:
            result=json.load(response)
    except HTTPError as error:
        raise RuntimeError("Independent hosted readback HTTP "+str(error.code)) from None
    if not isinstance(result,dict):
        raise RuntimeError("Independent hosted readback JSON type mismatch")
    return result


def audit():
    if git("rev-list","--parents","-n","1",REG).decode().strip()!=REG+" "+PARENT:
        raise RuntimeError("Frozen Git registration parent changed")
    for name in FROZEN:
        if (ROOT/name).read_bytes()!=git("show",REG+":vnext/"+name):
            raise RuntimeError("Frozen registration blob changed "+name)
    plan=json.loads((ROOT/FROZEN[1]).read_text(encoding="utf-8"))
    fixed=json.loads((ROOT/FROZEN[2]).read_text(encoding="utf-8"))
    if (len(fixed["messages"])!=24 or fixed["synthetic"] is not True or
        len(plan["query_cases"])!=6 or plan["max_file_uploads"]!=12 or
        hashlib.sha256((ROOT/FROZEN[2]).read_bytes()).hexdigest()!=plan["fixture_sha256"]):
        raise RuntimeError("Frozen synthetic fixture changed")
    if stat.S_IMODE(LOCAL.stat().st_mode)!=0o700:
        raise RuntimeError("Private directory permissions not owner-only")
    for name in ("store.json","results.json","synthetic_conversation.sqlite"):
        if stat.S_IMODE((LOCAL/name).stat().st_mode)!=0o600:
            raise RuntimeError("Private local state file permissions are not 0600")
    cfg=json.loads((LOCAL/"store.json").read_text(encoding="utf-8"))
    ledger=json.loads((LOCAL/"results.json").read_text(encoding="utf-8"))
    if (cfg.get("name")!=plan["store_name"] or
        cfg.get("fixture_sha256")!=plan["fixture_sha256"] or
        cfg.get("synthetic_only") is not True or
        ledger.get("trial_id")!="R"):
        raise RuntimeError("Private project/store/fixture binding changed")
    store=cfg.get("store_id")
    if type(store) is not str or not store.startswith("vs_"):
        raise RuntimeError("Invalid private vector-store identifier")
    original={Archive._validate(row)["local_id"]:Archive._validate(row)
              for row in fixed["messages"]}
    if len(original)!=24:
        raise RuntimeError("Duplicate original source keys")
    with sqlite3.connect(DB) as sql:
        sql.row_factory=sqlite3.Row
        existing=[dict(x) for x in sql.execute("SELECT * FROM messages ORDER BY position")]
        maps=[dict(x) for x in sql.execute("SELECT * FROM hosted_r_files ORDER BY turn_index")]
    if len(existing)!=24 or len(maps)!=12:
        raise RuntimeError("Wrong indexed original or hosted mapping counts")
    for expected_position,actual in enumerate(existing,1):
        source=original.get(actual["local_id"])
        if source is None or actual["position"]!=expected_position:
            raise RuntimeError("Unexpected/duplicated original source")
        for key,value in source.items():
            if actual[key]!=value:
                raise RuntimeError("Original message/source integrity broken")
    by_id={x["message_id"]:x for x in existing}
    if (by_id["r08u"]["supersedes_local_id"]!=by_id["r06u"]["local_id"]
        or by_id["r08a"]["supersedes_local_id"]!=by_id["r06a"]["local_id"]):
        raise RuntimeError("Original fictional correction links changed")
    file_ids=set()
    for turn,record in enumerate(maps,1):
        if (record["turn_index"]!=turn or record["completed"]!=1 or
                record["file_id"] in file_ids):
            raise RuntimeError("Incorrect hosted mapping order/completion")
        file_ids.add(record["file_id"])
        source1,source2=fixed["messages"][(turn-1)*2:turn*2]
        if (record["user_local_id"]!=by_id[source1["message_id"]]["local_id"] or
            record["assistant_local_id"]!=by_id[source2["message_id"]]["local_id"]):
            raise RuntimeError("Hosted file maps to wrong original authors")
        lines=["WHOLLY FICTIONAL TEST CONVERSATION. NOT A REAL PERSON'S CHAT.",
               "Conversation: fictional_diary_r",f"Turn: {turn:02d}",
               f"USER original message ID [{source1['message_id']}]: {source1['exact_text']}",
               f"ASSISTANT scripted response ID [{source2['message_id']}]: {source2['exact_text']}",""]
        payload="\n".join(lines).encode("utf-8")
        digest=hashlib.sha256(payload).hexdigest()
        expect_filename=f"fictional_diary_r_turn_{turn:02d}_{digest[:16]}.txt"
        if record["filename"]!=expect_filename or record["payload_sha256"]!=digest:
            raise RuntimeError("Hosted mapping digest differs from original text")
    key=project_key()
    remote=openai_get(key,"/vector_stores/"+quote(store,safe=""))
    if (remote.get("id")!=store or remote.get("name")!=plan["store_name"] or
        (remote.get("metadata") or {}).get("synthetic_only")!="true" or
        (remote.get("metadata") or {}).get("scope")!="ltm-rag-vnext-r" or
        (remote.get("expires_after") or {}).get("days")!=30 or
        (remote.get("file_counts") or {}).get("completed")!=12 or
        (remote.get("file_counts") or {}).get("total")!=12):
        raise RuntimeError("Remote store metadata/file count differs from 12-file proof")
    for row in maps:
        remote_file=openai_get(key,"/vector_stores/"+quote(store,safe="")+
                   "/files/"+quote(row["file_id"],safe=""))
        turn=row["turn_index"]
        attrs=remote_file.get("attributes") or {}
        if (remote_file.get("status")!="completed" or
            attrs.get("synthetic_only") is not True or
            attrs.get("turn_index")!=turn or
            attrs.get("conversation_id")!="fictional_diary_r" or
            attrs.get("payload_sha256")!=row["payload_sha256"]):
            raise RuntimeError("Remote indexed file metadata/source binding mismatch")
    if set(ledger["queries"])!={x["id"] for x in plan["query_cases"]}:
        raise RuntimeError("Missing/extra frozen search record")
    ranks={}
    for case in plan["query_cases"]:
        record=ledger["queries"][case["id"]]
        ranked=record["ranked_turns"]
        matched=[index+1 for index,x in enumerate(ranked)
                 if x in case["expected_turns"]]
        target=min(matched) if matched else None
        if (record["query"]!=case["query"] or
            record["after_turn"]!=case["after_turn"] or
            record["expected_turns"]!=case["expected_turns"] or
            record["target_rank"]!=target or
            record["top5_pass"] is not (target is not None and target<=5) or
            record["returned_candidates"]!=len(ranked) or
            len(record["scores"])!=len(ranked) or
            any(type(n) is not int or n<1 or n>case["after_turn"] for n in ranked) or
            len(set(ranked))!=len(ranked)):
            raise RuntimeError("Stage R frozen search outcome/sequence inconsistent")
        ranks[case["id"]]=target
    if hashlib.sha256(AUDIT.read_bytes()).hexdigest()!=EXPECTED_NATIVE_SHA:
        raise RuntimeError("Original native six-event audit changed")
    return {"verdict":"PASS_R_HOSTED_SOURCE_INTEGRITY_READBACK",
            "original_sources":len(existing),"indexed_files":len(maps),
            "frozen_search_ranks":ranks,
            "pass_top5":sum(v is not None and v<=5 for v in ranks.values()),
            "frozen_query_count":6,"native_audit_unchanged":True,
            "unprompted_chatgpt_capture_proven":False,
            "real_histories_uploaded":0}


if __name__=="__main__":
    print(json.dumps(audit(),sort_keys=True))
