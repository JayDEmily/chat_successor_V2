"""Ephemeral localhost MCP v2 transport smoke for K metadata probe.

This is deliberately NOT native ChatGPT: the local Python client can inject
any tool _meta values it wishes. Private audit is held in a temporary directory.
"""
from __future__ import annotations

import asyncio
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from mcp import Client

ROOT=Path(__file__).resolve().parents[1]


async def transport(port: int):
    async with Client(f"http://127.0.0.1:{port}/mcp") as client:
        tools=(await client.list_tools()).tools
        if [x.name for x in tools]!=["inspect_metadata_presence_k"]:
            raise AssertionError("Tool surface not isolated")
        if not tools[0].annotations.read_only_hint:
            raise AssertionError("Read-only annotation missing")
        def public(result):
            if result.is_error:
                raise AssertionError("Tool call reported error")
            payload=result.structured_content
            if payload is None:
                raise AssertionError("Missing structuredContent")
            if payload.get("native_user_text_attested") is not False:
                raise AssertionError("Unwarranted original-message attestation")
            return payload
        missing=public(await client.call_tool("inspect_metadata_presence_k",{}))
        if missing["session_present"] or missing["subject_present"]:
            raise AssertionError("Local client unexpectedly supplied ChatGPT metadata")
        synthetic_meta={"openai/session":"fiction-session-A",
                        "openai/subject":"fiction-user-A"}
        one=public(await client.call_tool(
            "inspect_metadata_presence_k",{},meta=synthetic_meta))
        two=public(await client.call_tool(
            "inspect_metadata_presence_k",{},meta=synthetic_meta))
        different=public(await client.call_tool(
            "inspect_metadata_presence_k",{},
            meta={"openai/session":"fiction-session-B",
                  "openai/subject":"fiction-user-A"}))
        for case in (one,two,different):
            if not case["session_present"] or not case["subject_present"]:
                raise AssertionError("Injected synthetic meta was not delivered to MCP tool")
        print("K_LOCAL_HTTP_MCP_PASS one_readonly_tool=true synthetic_meta_present=true "
              "no_native_chatgpt_claim=true")


def main():
    with tempfile.TemporaryDirectory() as temp:
        directory=Path(temp)
        audit=directory/"events.jsonl"
        with socket.socket() as sock:
            sock.bind(("127.0.0.1",0))
            port=sock.getsockname()[1]
        env=os.environ.copy()
        env["PYTHONPATH"]=str(ROOT)
        p=subprocess.Popen([
            sys.executable,"-m","ltm_vnext.metadata_probe_k",
            "--port",str(port),"--audit-log",str(audit),
        ],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
        try:
            for _ in range(100):
                if p.poll() is not None:
                    raise RuntimeError("K listener stopped before readiness")
                try:
                    with socket.create_connection(("127.0.0.1",port),timeout=.2):
                        break
                except OSError:
                    time.sleep(.1)
            else:
                raise TimeoutError("K listener not ready on random loopback port")
            asyncio.run(transport(port))
            events=[json.loads(x) for x in audit.read_text().splitlines()]
            if len(events)!=4:
                raise AssertionError("Expected exact 4 private metadata events")
            if any("fiction-session" in json.dumps(e)
                   or "fiction-user" in json.dumps(e) for e in events):
                raise AssertionError("Raw ids written to local audit")
            if events[0]["session_fingerprint"] is not None:
                raise AssertionError("Missing meta promoted to a session")
            if (events[1]["session_fingerprint"] != events[2]["session_fingerprint"]
                or events[1]["session_fingerprint"] == events[3]["session_fingerprint"]
                or events[1]["subject_fingerprint"] != events[3]["subject_fingerprint"]):
                raise AssertionError("Local correlation fingerprint evidence failed")
            if any(e["native_user_text_attested"] for e in events):
                raise AssertionError("Fake native message attestation")
            print("K_LOCAL_PRIVATE_AUDIT_PASS 4_events exact_session_equalities=true "
                  "source_text_logged=false")
        finally:
            p.terminate()
            try:
                _,err=p.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill()
                _,err=p.communicate(timeout=5)
            if p.returncode not in (0,-15):
                print(err[-900:],file=sys.stderr)


if __name__=="__main__":
    main()
