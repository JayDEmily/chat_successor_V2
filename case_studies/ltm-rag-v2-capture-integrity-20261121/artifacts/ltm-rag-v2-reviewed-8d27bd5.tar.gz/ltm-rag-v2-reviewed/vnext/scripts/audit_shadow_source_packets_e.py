"""End-to-end OFFLINE source packet integrity on dense-ranked synthetic E.

Tests the read-only Archive.fetch boundary, not native ChatGPT source selection.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import tempfile
import time
from collections import Counter
from pathlib import Path

from ltm_vnext.archive import Archive
from scripts.run_shadow_embeddings import CACHE, MODEL, normalized, order_by_score
from scripts.run_relevance_holdout_e import check_locked_inputs, FIXTURE, PROBES, GATE, POSITIVE
from scripts.shadow_source_packets import ShadowPacketResolver

ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/"SHADOW_PACKET_INTEGRITY_E_RESULTS.md"

def checksum(path:Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(model, fixture:dict, plan:dict, gate:dict) -> tuple[list[dict],float]:
    check_locked_inputs(fixture,plan,gate)
    start=time.perf_counter()
    messages=fixture["messages"]
    ids=[m["message_id"] for m in messages]
    data=normalized(model.embed([m["exact_text"] for m in messages],batch_size=16))
    queries=normalized(model.embed([q["query"] for q in plan["probes"]],batch_size=16))
    scores=queries@data.T
    rows=[]
    with tempfile.TemporaryDirectory(prefix="ltm-shadow-packets-e-") as dirname:
        archive=Archive.initialise(Path(dirname)/"e.sqlite")
        actual=archive.ingest_synthetic(FIXTURE)
        if actual!={"inserted":34,"total":34}:
            raise ValueError("Synthetic evidence count mismatch")
        resolver=ShadowPacketResolver(archive,fixture)
        for index,question in enumerate(plan["probes"]):
            order=order_by_score(ids,scores[index])[:8]
            packets=resolver.resolve([
                (mid,float(scores[index,ids.index(mid)])) for mid in order
            ])
            if len(packets)!=8 or any(p["candidate_relevance"]!="unverified_candidate" for p in packets):
                raise ValueError("Undeclared source evidence status")
            target=question["expected_message_id"]
            rank=(order.index(target)+1 if target in order else None)
            source_ids=[p["source"]["message_id"] for p in packets]
            if source_ids!=order:
                raise ValueError("Source ID order changed after SQLite fetch")
            if any(p["source"]["fidelity"]!="synthetic_only" for p in packets):
                raise ValueError("Non-synthetic source resolved")
            rows.append({
                "id":question["id"],"kind":question["kind"],
                "target":target,"rank8":rank,
                "top1_source":source_ids[0],
                "resolved":len(packets),
                "all_candidate_statuses_unverified":True,
            })
    duration=time.perf_counter()-start
    return rows,duration

def document(rows:list[dict], seconds:float) -> str:
    positives=[r for r in rows if r["kind"] in POSITIVE]
    nonunique=[r for r in rows if r["kind"] not in POSITIVE]
    total=sum(r["resolved"] for r in rows)
    exact=sum(r["rank8"] is not None for r in positives)
    if len(rows)!=58 or len(positives)!=30 or len(nonunique)!=28 or total!=464:
        raise ValueError("Incomplete packet audit")
    lines=[
        "# Shadow dense candidate IDs to exact SQLite source packets — Holdout E",
        "",
        "This is **offline synthetic-only** evidence. The live MCP plugin, original",
        "six-message archive and active tunnel were not modified.",
        "",
        "- Frozen Holdout E fixture SHA-256: "+checksum(FIXTURE),
        "- Frozen Holdout E probes SHA-256: "+checksum(PROBES),
        "- Local model: BAAI/bge-small-en-v1.5 (FastEmbed ONNX CPU two threads).",
        "- Exact source packet reads and hash/integrity checks: "+str(total)+"/"+str(total)+".",
        "- Ranked relevant targets appearing in top 8: "+str(exact)+"/30.",
        "- No-unique-source questions: "+str(len(nonunique))+
          "; each produces 8 **unverified** ranked candidates; none is marked relevant.",
        "- Time for this local embedding + SQLite audit (one observation): "+format(seconds,".3f")+" seconds.",
        "",
        "| Case | Class | Expected exact message | Rank in 8 | Source packets | Relevance status |",
        "|---|---|---|---:|---:|---|",
    ]
    for r in rows:
        rank=str(r["rank8"]) if r["rank8"] is not None else "no registered target"
        lines.append("| "+r["id"]+" | "+r["kind"]+" | "+str(r["target"] or "no unique source")+
                     " | "+rank+" | "+str(r["resolved"])+
                     " | unverified candidate |")
    lines += [
        "", "## Exact-source integrity checks performed per packet", "",
        "For each dense-ranked message ID, the resolver reads the record through",
        "the existing read-only Archive.fetch API using its stable source/message/version",
        "identity. It checks: local ID, author role, reported speaker, attribution,",
        "source locator, conversation, branch, correction predecessor, corrected_by",
        "descendants, UTF-8 exact_text and SHA-256, and adjacent same-branch source",
        "text, position and SHA-256. Any mismatch raises PacketIntegrityError.",
        "",
        "This proves match to these synthetic fixture originals, not independent",
        "authentication of a real human utterance. The cosine similarity score",
        "does not classify relevance. In particular, the 28 non-unique-source",
        "questions produce 224 technically valid source packets that are **not**",
        "evidence supporting an answer to their generic or ambiguous question.",
        "A separate ChatGPT invocation/answer-grounding mechanism is required.",
        "No packet was advertised as an authenticated external source or a verified",
        "answer. No real personal conversation import or model inference API occurred.",
        "",
    ]
    return "\n".join(lines)

def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("status","write"))
    action=parser.parse_args().action
    from fastembed import TextEmbedding
    fixture=json.loads(FIXTURE.read_text(encoding="utf8"))
    plan=json.loads(PROBES.read_text(encoding="utf8"))
    gate=json.loads(GATE.read_text(encoding="utf8"))
    model=TextEmbedding(model_name=MODEL,cache_dir=str(CACHE),
                        threads=2,providers=["CPUExecutionProvider"],cuda=False)
    rows,seconds=run(model,fixture,plan,gate)
    hits=sum(r["rank8"] is not None for r in rows if r["kind"] in POSITIVE)
    result={"queries":len(rows),"source_packet_reads":sum(r["resolved"] for r in rows),
            "registered_positive_targets_found":hits,
            "negative_or_ambiguous_queries":sum(r["kind"] not in POSITIVE for r in rows),
            "duration_seconds":round(seconds,3)}
    print(json.dumps(result,sort_keys=True))
    if action=="write":
        REPORT.write_text(document(rows,seconds),encoding="utf8")
        print("SHADOW_PACKET_SOURCE_INTEGRITY_REPORT_WRITTEN")

if __name__=="__main__":
    main()
