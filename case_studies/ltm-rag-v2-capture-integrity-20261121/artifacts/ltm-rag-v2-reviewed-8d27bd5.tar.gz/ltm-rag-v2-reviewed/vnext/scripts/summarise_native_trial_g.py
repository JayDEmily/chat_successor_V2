"""Independently reconcile saved native Trial G responses with local MCP audit."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from datetime import datetime, timedelta
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
PLAN=ROOT/"NATIVE_TRIAL_G_20261119.json"
FIXTURE=ROOT/"fixtures/synthetic_clean_g.json"
LEDGER=ROOT/".local/native-trial-g-results.jsonl"
AUDIT=ROOT/".local/trial-g-mcp-audit.jsonl"
PENDING=ROOT/".local/native-trial-g-pending.json"
REPORT=ROOT/"NATIVE_TRIAL_G_TRACE_RESULTS.md"
PROJECT_ID="g-p-6afd806ca9348191accae58eea37c74c"

def load(path):
    if not path.exists():return []
    return [json.loads(x) for x in path.read_text(encoding="utf-8-sig").splitlines() if x.strip()]

def verify():
    plan=json.loads(PLAN.read_text(encoding="utf8"))
    fixture=json.loads(FIXTURE.read_text(encoding="utf8"))
    rows,events=load(LEDGER),load(AUDIT)
    if plan.get("trial_id")!="ltm-vnext-native-trial-g-cleancontext-20261119" or len(plan["cases"])!=16:
        raise ValueError("Wrong frozen G plan")
    messages=fixture["messages"]
    by_source={m["message_id"]:m for m in messages}
    if not fixture.get("synthetic") or len(messages)!=20 or len(by_source)!=20:
        raise ValueError("Not exactly 20 independent synthetic source messages")
    g03=by_source["g03"]
    if g03["supersedes"]["message_id"]!="g01" or g03["branch_id"]!="main" or g03["author_role"]!="user":
        raise ValueError("G first-turn original-source correction identity corrupted")
    if len(rows)>16:raise ValueError("Too many native responses")
    indexed={x["event_id"]:x for x in events}
    if len(indexed)!=len(events):raise ValueError("Duplicate G audit event IDs")
    consumed=set()
    urls=set()
    counts=Counter()
    checked=[]
    for i,row in enumerate(rows):
        case=plan["cases"][i]
        if (row.get("id"),row.get("kind"),row.get("ordinal"))!=(case["id"],case["kind"],i+1):
            raise ValueError("Case order/identity mismatch")
        url=row.get("chat_url","")
        if not url.startswith("chatgpt.com/g/"+PROJECT_ID) or "/c/" not in url or url in urls:
            raise ValueError("Foreign or duplicate G saved ChatGPT chat")
        urls.add(url)
        expected_hash=hashlib.sha256(case["prompt"].encode("utf8")).hexdigest()
        if i==0 and row.get("prompt_sha256") is None:
            counts["g01_no_saved_prompt_hash"]+=1
        elif row.get("prompt_sha256")!=expected_hash:
            raise ValueError("Frozen prompt/hash conflict: "+case["id"])
        start=datetime.fromisoformat(row["sent_at_utc"])
        end=datetime.fromisoformat(row["observed_at_utc"])
        if end<start or not row.get("completed"):
            raise ValueError("Incomplete or time-reversed G answer")
        actual=Counter()
        ids=row["added_event_ids"]
        if len(ids)!=len(set(ids)):
            raise ValueError("Case reused audit event")
        for eid in ids:
            if eid not in indexed or eid in consumed:
                raise ValueError("Missing/reused audit identity: "+eid)
            consumed.add(eid)
            event=indexed[eid]
            if event.get("outcome")!="ok" or event.get("synthetic_only") is not True:
                raise ValueError("Unsuccessful/non-synthetic audit identity")
            when=datetime.fromisoformat(event["timestamp_utc"].replace("Z","+00:00"))
            if not start-timedelta(seconds=3)<=when<=end+timedelta(seconds=3):
                raise ValueError("Audit call outside saved question interval")
            if event["tool"] not in ("lookup_evidence","fetch_source"):
                raise ValueError("Unknown audit tool type")
            actual[event["tool"]]+=1
        nlook,nfetch=actual["lookup_evidence"],actual["fetch_source"]
        if nlook!=row["lookup_count"] or nfetch!=row["fetch_count"] or len(ids)!=nlook+nfetch:
            raise ValueError("Audit counts conflict")
        expected=case["lookup_expected"]
        trace=(nlook>0 if expected else nlook==0) if expected is not None else None
        if trace!=row.get("trace_pass"):
            raise ValueError("Runner trace verdict conflict")
        if row.get("semantic_review")!="PENDING" or len(row.get("answer_text",""))<12:
            raise ValueError("Answer absent or prematurely adjudicated")
        counts["completed"]+=1
        counts["lookup_calls"]+=nlook
        counts["fetch_calls"]+=nfetch
        counts["with_lookup"]+=int(nlook>0)
        counts["trace_pass"]+=int(trace is True)
        counts["trace_fail"]+=int(trace is False)
        counts[case["kind"]]+=1
        checked.append((case,row,trace))
    return {"cases":len(rows),"complete":len(rows)==16 and not PENDING.exists(),
            "pending":PENDING.exists(),"counts":dict(counts),"audited_events":len(events)},checked

def write_report(summary,checked):
    if not summary["complete"]:
        raise ValueError("Do not publish complete Trial G report while cases missing/pending")
    c=summary["counts"]
    out=[
        "# Trial G — independently reconciled native tool traces","",
        "All 16 preregistered cases were matched to unique saved ChatGPT Project chats.",
        "The separate analyser checked tool event IDs, successful handler outcomes,",
        "timestamps, exact prompt hashes where captured, original 20-source fixture",
        "and the G01 main-branch user-authored correction provenance.","",
        f"Executed: **{c['completed']}/16**; observed successful calls: "
        f"**{c['lookup_calls']} lookups**, **{c['fetch_calls']} fetches**.",
        f"Specified trace tests: **{c['trace_pass']} PASS**, **{c['trace_fail']} FAIL**;",
        "ambiguous-case lookup is optional and excluded from that denominator.","",
        "| Case | Class | Expected lookup | Lookup | Fetch | Trace | Saved answer |",
        "|---|---|---|---:|---:|---|---|",
    ]
    for case,row,trace in checked:
        expected=("optional" if case["lookup_expected"] is None
                  else "yes" if case["lookup_expected"] else "no")
        grade=("optional" if trace is None else "PASS" if trace else "FAIL")
        out.append(f"| {case['id']} | {case['kind']} | {expected} | "
                   f"{row['lookup_count']} | {row['fetch_count']} | {grade} | "
                   f"[Chat](https://{row['chat_url']}) |")
    out.extend([
        "","## Evidence limitations","",
        "- The first G01 prompt was UI-checked before Send and came from the frozen",
        "  test plan, but the saved G01 record predates the SHA-256 prompt marker;",
        "  its prompt hash was not retroactively manufactured.",
        "- G01 was in a new chat-empty Project with verified Project-only memory;",
        "  G02–G16 were in that same Project and may have cross-chat context.",
        "- Correct answers without MCP calls are not trace passes. A lookup",
        "  alone does not establish a correct source attribution or byte-exact",
        "  quotation; semantic review remains separately recorded.",
        "- The preserved local event audit lists successful local handler calls;",
        "  an unavailable remote call cannot be excluded by audit absence.",
        "- The source and answer texts are fictional. Private per-case ledger",
        "  and audit remain Git-ignored, not copied into the report.",
        "- Neither the original six-source connector nor auto-start settings",
        "  nor genuine personal conversation history were modified.","",
    ])
    REPORT.write_text("\n".join(out),encoding="utf8")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("action",choices=("status","write"))
    args=ap.parse_args()
    summary,checked=verify()
    print(json.dumps(summary,sort_keys=True))
    if args.action=="write":
        write_report(summary,checked)
        print("TRIAL_G_TRACE_REPORT_WRITTEN")

if __name__=="__main__":
    main()
