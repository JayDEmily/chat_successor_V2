"""Bounded user-space supervisor for the synthetic-only MCP + OpenAI tunnel.

Explicitly launched; it does not install a system service, alter boot configuration,
run other projects, or persist secret values. Only children it starts are stopped.
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
import signal
import socket
import subprocess
import sys
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOCAL = ROOT / ".local"
LOCK = LOCAL / "synthetic-supervisor.lock"
EVENTS = LOCAL / "synthetic-supervisor-events.jsonl"
FIXTURE = ROOT / "fixtures" / "synthetic_conversations.json"
MCP_START = ROOT / "scripts" / "run_synthetic_mcp.sh"
TUNNEL_START = ROOT / "scripts" / "tunnel_using_existing_key.py"


def is_mcp_listening(port: int = 8787) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.5):
            return True
    except OSError:
        return False


def assert_synthetic_fixture() -> None:
    data = json.loads(FIXTURE.read_text(encoding="utf-8"))
    messages = data.get("messages", [])
    if data.get("synthetic") is not True or len(messages) != 6:
        raise RuntimeError("Synthetic gate failed: expected exactly six invented fixture messages")
    if not all(m.get("source_id") == "synthetic-v1" for m in messages):
        raise RuntimeError("Synthetic gate failed: unrecognised source ID")


def has_existing_tunnel() -> bool:
    """Detect only an already-running tunnel with our *exact* private profile."""
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit() or entry.name == str(os.getpid()):
            continue
        try:
            argv = (entry / "cmdline").read_bytes().split(b"\0")
        except (PermissionError, FileNotFoundError, ProcessLookupError):
            continue
        args = [part.decode("utf-8", errors="replace") for part in argv if part]
        if not args:
            continue
        if (
            Path(args[0]).name == "tunnel-client"
            and "run" in args
            and "ltm-vnext-synthetic" in args
        ):
            return True
    return False


class RestartBudget:
    def __init__(self, limit: int = 3, window_seconds: float = 120.0) -> None:
        self.limit = limit
        self.window_seconds = window_seconds
        self._attempts: deque[float] = deque()

    def admit(self, now: float) -> bool:
        while self._attempts and (now - self._attempts[0]) >= self.window_seconds:
            self._attempts.popleft()
        if len(self._attempts) >= self.limit:
            return False
        self._attempts.append(now)
        return True


def record_event(event: str, service: str | None = None, **details: object) -> None:
    LOCAL.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(LOCAL, 0o700)
    item = {
        "time_utc": datetime.now(timezone.utc).isoformat(),
        "event": event,
        "service": service,
        **details,
    }
    fd = os.open(EVENTS, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    try:
        with os.fdopen(fd, "a", encoding="utf-8") as stream:
            stream.write(json.dumps(item, sort_keys=True) + "\n")
    except Exception:
        raise


@dataclass
class ManagedService:
    name: str
    command: list[str]
    process: subprocess.Popen[bytes] | None = None
    log_stream: object | None = None
    budget: RestartBudget = field(default_factory=RestartBudget)

    def start(self) -> None:
        log_path = LOCAL / f"synthetic-{self.name}-child.log"
        fd = os.open(log_path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        self.log_stream = os.fdopen(fd, "ab", buffering=0)
        clean_env = os.environ.copy()
        clean_env.pop("OPENAI_ADMIN_KEY", None)
        clean_env.pop("OPENAI_API_KEY", None)
        clean_env.pop("CONTROL_PLANE_API_KEY", None)
        self.process = subprocess.Popen(
            self.command, cwd=ROOT, env=clean_env,
            stdin=subprocess.DEVNULL, stdout=self.log_stream,
            stderr=subprocess.STDOUT, start_new_session=True,
        )
        record_event("started", self.name, pid=self.process.pid)

    def stop(self) -> None:
        process = self.process
        if process is not None and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=6)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=3)
        record_event("stopped", self.name, pid=process.pid if process else None)
        self.process = None
        if self.log_stream is not None:
            self.log_stream.close()
            self.log_stream = None


def run_supervisor(poll_seconds: float = 1.0) -> int:
    LOCAL.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(LOCAL, 0o700)
    assert_synthetic_fixture()
    if not MCP_START.is_file() or not TUNNEL_START.is_file():
        raise RuntimeError("Synthetic scripts missing")
    if not Path("/home/jds/.env").is_file():
        raise RuntimeError("Existing project key file missing")
    with LOCK.open("a+b") as lockfile:
        try:
            fcntl.flock(lockfile, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("Another synthetic supervisor already owns the lock")
        if is_mcp_listening():
            raise RuntimeError("Synthetic MCP port is already occupied: will not duplicate owner")
        if has_existing_tunnel():
            raise RuntimeError("Existing project-specific tunnel is already running")

        services = [
            ManagedService("mcp", ["/bin/bash", str(MCP_START)]),
            ManagedService("tunnel", [sys.executable, str(TUNNEL_START), "run"]),
        ]
        shutting_down = False

        def request_shutdown(_sig: int, _frame: object) -> None:
            nonlocal shutting_down
            shutting_down = True

        old_handlers = {
            sig: signal.signal(sig, request_shutdown)
            for sig in (signal.SIGINT, signal.SIGTERM)
        }
        try:
            services[0].start()
            for _ in range(40):
                if shutting_down or services[0].process.poll() is not None:
                    break
                if is_mcp_listening():
                    break
                time.sleep(0.25)
            if not is_mcp_listening():
                raise RuntimeError("Synthetic MCP failed its initial loopback start")
            services[1].start()
            record_event("supervisor_ready", mcp_port=8787)
            print("SYNTHETIC_SUPERVISOR_RUNNING children=2 loopback_only=true", flush=True)

            while not shutting_down:
                for item in services:
                    if shutting_down:
                        break
                    process = item.process
                    if process is not None and process.poll() is None:
                        continue
                    exit_code = process.returncode if process is not None else None
                    record_event("unexpected_exit", item.name, exit_code=exit_code)
                    if not item.budget.admit(time.monotonic()):
                        record_event("restart_budget_exhausted", item.name)
                        print(f"SYNTHETIC_SUPERVISOR_STOP restart_budget_exhausted={item.name}", flush=True)
                        return 3
                    item.stop()
                    time.sleep(0.75)
                    item.start()
                    print(f"SUPERVISOR_RESTART service={item.name}", flush=True)
                time.sleep(poll_seconds)
            return 0
        finally:
            for item in reversed(services):
                item.stop()
            for sig, old in old_handlers.items():
                signal.signal(sig, old)
            record_event("supervisor_stopped")
            print("SYNTHETIC_SUPERVISOR_STOPPED", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Synthetic-only bounded user-space service supervisor")
    parser.add_argument("action", choices=("run", "preflight", "status"))
    args = parser.parse_args()
    if args.action == "status":
        print(json.dumps({
            "synthetic_mcp_port_8787_open": is_mcp_listening(),
            "existing_project_tunnel_running": has_existing_tunnel(),
            "local_events_exists": EVENTS.is_file(),
            "user_service_not_installed": True,
        }, sort_keys=True))
        return 0
    if args.action == "preflight":
        assert_synthetic_fixture()
        print("SYNTHETIC_SUPERVISOR_PREFLIGHT_PASS fixture=six_synthetic_records")
        return 0
    return run_supervisor()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, OSError, ValueError) as error:
        print(f"SYNTHETIC_SUPERVISOR_ERROR {error}", file=sys.stderr)
        raise SystemExit(2) from None
