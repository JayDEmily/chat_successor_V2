"""One-time M04 native UI recovery: reconcile a sent-but-unrecorded response.

Requires exact pending marker, saved in-Project response and no new MCP audit
events. Never re-sends the user message or invents a tool event.
"""
from __future__ import annotations
import json
import os
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
LOCAL=ROOT/".local"
PLAN=ROOT/"NATIVE_TRIAL_F_20261118.json"
PENDING=LOCAL/"native-trial-f-pending.json"
LEDGER=LOCAL/"native-trial-f-results.jsonl"
AUDIT=LOCAL/"mcp-tool-audit.jsonl"
SAVED=LOCAL/"native-f-m04-saved-response.txt"
URL="chatgpt.com/g/g-p-6afd1c455970819197ab1bdad8acf53d-ltm-rag-vnext-synthetic-trial/c/6afd744b-eb50-83ec-a6f8-c8e1d4f26f6e"

def lines(path:Path) -> list[dict]:
    return [json.loads(row) for row in path.read_text(encoding="utf-8-sig").splitlines() if row.strip()]

def main() -> None:
    config=json.loads(PLAN.read_text(encoding="utf8"))
    pending=json.loads(PENDING.read_text(encoding="utf-8-sig"))
    rows=lines(LEDGER)
    events=lines(AUDIT)
    if len(rows)!=3 or [r["id"] for r in rows]!=["M01","M02","M03"]:
        raise RuntimeError("Unexpected previous F results: refuse reconciliation")
    if pending["case_id"]!="M04" or pending["ordinal"]!=4:
        raise RuntimeError("Not the exact unrecorded M04 send")
    if len(events)!=pending["audit_before"]:
        raise RuntimeError("New MCP audit events need independent attribution")
    test=config["cases"][3]
    if test["id"]!="M04" or test["kind"]!="missing" or test["lookup_expected"] is not True:
        raise RuntimeError("Frozen plan changed")
    answer=SAVED.read_text(encoding="utf-8-sig")
    if not all(x.lower() in answer.lower() for x in (
        "No authenticated audio recording", "fixture://notebook/m3",
        "fixture://notebook/m2"
    )):
        raise RuntimeError("Saved response does not identify exact synthetic M04 sources")
    sent=pending["written_at_utc"]
    seen=datetime.now(timezone.utc).isoformat()
    if datetime.fromisoformat(seen)<=datetime.fromisoformat(sent):
        raise RuntimeError("Invalid recovery chronology")
    record={
        "id":"M04","kind":"missing","ordinal":4,
        "sent_at_utc":sent,"observed_at_utc":seen,
        "completed":True,"chat_url":URL,
        "lookup_count":0,"fetch_count":0,
        "added_event_ids":[],"expected_lookup":True,"trace_pass":False,
        "semantic_review":"PENDING",
        "review_concepts":test["review_concepts"],
        "answer_excerpt":answer[:2500],
        "ambiguity_note":("Answer became visible after stopping own prolonged Thinking UI. "
                          "No successful local MCP lookup or fetch occurred during this case."),
        "recovery_type":"no_resend_visible_reply_after_bounded_stop",
    }
    with LEDGER.open("a",encoding="utf8") as f:
        f.write(json.dumps(record,ensure_ascii=False,separators=(",",":"))+"\n")
        f.flush()
        os.fsync(f.fileno())
    os.chmod(LEDGER,0o600)
    PENDING.unlink()
    print("M04_RECOVERED_WITHOUT_RESEND",
          "ledger_records=4","lookup=0","fetch=0",
          "trace_expected_but_missing=true","source_reply_visible=true")

if __name__=="__main__":
    main()
