# Stage P one-send/one UIA Invoke synthetic-only trial.
# Distinct from exhausted M/N/O tests. Requires preregistration 340fe6e.
# Never reads source archive or handles genuine user text.
[CmdletBinding()]
param([switch]$PreflightOnly)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class StagePWindow {
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
}
'@

$root='\\wsl.localhost\Ubuntu\home\jds\ltm-rag-vnext-20261118\vnext'
. (Join-Path $root 'scripts\NativeAppsUiDiagnostics.ps1') -Mode Library
$plan=Get-Content -Raw (Join-Path $root 'MCP_APPS_P_CASES_20261120.json')|ConvertFrom-Json
$trace=Join-Path $root $(if($PreflightOnly){'.local\trial-p-controller-preflight.jsonl'}else{'.local\trial-p-native-controller-trace.jsonl'})
$temp=Join-Path $env:LOCALAPPDATA 'Temp'
$windowMarker=Join-Path $temp 'ltm_p_dedicated_window_once.json'
$tryMarker=Join-Path $temp 'ltm_p_try_chat_once.json'
$sendMarker=Join-Path $temp 'ltm_p_n01_send_once.json'
$invokeMarker=Join-Path $temp 'ltm_p_n02_invoke_once.json'
$audit=Join-Path $root '.local\trial-m-mcp-audit.jsonl'
$chrono=[Diagnostics.Stopwatch]::StartNew()
$sent=$false
$invoked=$false

function Trace([string]$stage,[string]$reason,[hashtable]$flags=@{}){
 $item=New-TraceRecord $stage $reason ([int]$chrono.ElapsedMilliseconds) $flags
 Append-PrivateTrace $trace $item
 Write-Output ('P_TRACE '+$stage+' '+$reason+' elapsed_ms='+[int]$chrono.ElapsedMilliseconds)
}
function Require([bool]$yes,[string]$message){
 if(-not $yes){throw $message}
}
try{
 Require (-not (Test-Path $trace)) 'Trace exists: controller already attempted'
 Require (-not (Test-Path $sendMarker) -and -not (Test-Path $invokeMarker)) 'P native send or invoke already attempted'
 Require ($plan.trial_id -eq 'ltm-vnext-p-apps-native-uia-invoke-20261120' -and
     $plan.old_audit_lines -eq 4 -and $plan.native_messages_max -eq 1 -and
     $plan.automated_invokes_max -eq 1 -and $plan.ttl_seconds -eq 60) 'Frozen P plan mismatch'
 $prompt=[string]$plan.cases[0].prompt
 Require ($plan.cases[0].id -eq 'P-N01' -and $plan.cases[1].id -eq 'P-N02') 'Frozen case IDs mismatch'
 Require ($plan.cases[0].tool -eq 'open_topic_selector_m' -and $plan.cases[1].tool -eq 'confirm_topic_m') 'Frozen tool shape mismatch'
 $digest=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($prompt))).Replace('-','').ToLowerInvariant()
 $old=[IO.File]::ReadAllBytes($audit)
 $oldHash=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($old)).Replace('-','').ToLowerInvariant()
 Require ($oldHash -eq $plan.old_audit_sha256) 'Native M/N/O audit baseline has changed'
 $events=@(Get-Content -Path $audit | Where-Object{$_.Trim().Length -gt 0})
 Require ($events.Count -eq 4) 'Unexpected audit count'
 foreach($path in @('ltm_vnext\mcp_apps_m.py','ltm_vnext\mcp_apps_m_widget.html','scripts\NativeAppsUiDiagnostics.ps1')){
  $bytes=[IO.File]::ReadAllBytes((Join-Path $root $path))
  $sha=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($bytes)).Replace('-','').ToLowerInvariant()
  $key=switch($path){
   'ltm_vnext\mcp_apps_m.py' {'m_source_sha256'}
   'ltm_vnext\mcp_apps_m_widget.html' {'widget_sha256'}
   default {'diagnostics_sha256'}
  }
  Require ($sha -eq $plan.$key) ('Pinned source drift '+$key)
 }
 Require ((Test-Path $windowMarker) -and (Test-Path $tryMarker)) 'Dedicated window/try-chat markers missing'
 $wrec=Get-Content -Raw $windowMarker|ConvertFrom-Json
 $trec=Get-Content -Raw $tryMarker|ConvertFrom-Json
 Require ($wrec.phase -eq 'unique_native_plugin_detail_window_verified' -and
   $trec.phase -eq 'try_chat_invoked_once' -and
   $wrec.window_handle -eq $trec.window_handle -and
   $trec.plugin_id -eq $plan.native_plugin_id) 'Mismatched dedicated Chrome source'
 $h=[IntPtr][int64]$wrec.window_handle
 $rootElement=[System.Windows.Automation.AutomationElement]::RootElement
 $win=@($rootElement.FindAll([System.Windows.Automation.TreeScope]::Children,
   [System.Windows.Automation.Condition]::TrueCondition)|Where-Object{
    $_.Current.NativeWindowHandle -eq $h.ToInt64() -and
    $_.Current.ClassName -eq 'Chrome_WidgetWin_1'})
 Require ($win.Count -eq 1) 'Dedicated Stage P Chrome window missing'
 $w=$win[0]
 $es=$w.FindAll([System.Windows.Automation.TreeScope]::Descendants,
   [System.Windows.Automation.Condition]::TrueCondition)
 $addr=@($es|Where-Object{$_.Current.Name -eq 'Address and search bar' -and
    $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Edit'})
 Require ($addr.Count -eq 1 -and $addr[0].GetCurrentPattern(
   [System.Windows.Automation.ValuePattern]::Pattern).Current.Value -eq 'chatgpt.com') 'Not blank ChatGPT composer'
 $edit=@($es|Where-Object{$_.Current.Name -eq 'Ask ChatGPT' -and
    $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Edit'})
 Require ($edit.Count -eq 1) 'Composer missing or duplicated'
 $oldComposer=$edit[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
 Require ($oldComposer -match 'LTM-RAG vNext Native Apps M' -and
   $oldComposer.Length -lt 90 -and -not $oldComposer.Contains($prompt)) 'Selected native plugin missing or composer already occupied'
 Trace 'PREFLIGHT' 'VERIFIED_DEDICATED_PLUGIN_COMPOSER'
 if($PreflightOnly){Write-Output 'P_PREFLIGHT_ONLY_PASS native_send_count=0 invoke_count=0';return}
 Require ([StagePWindow]::SetForegroundWindow($h)) 'Cannot focus dedicated test window'
 Start-Sleep -Milliseconds 130
 Require ([StagePWindow]::GetForegroundWindow() -eq $h) 'Dedicated test window not foreground'
 $edit[0].SetFocus()
 [System.Windows.Forms.SendKeys]::SendWait('{END}')
 [System.Windows.Forms.SendKeys]::SendWait($prompt)
 Start-Sleep -Milliseconds 180
 $es=$w.FindAll([System.Windows.Automation.TreeScope]::Descendants,
   [System.Windows.Automation.Condition]::TrueCondition)
 $edit=@($es|Where-Object{$_.Current.Name -eq 'Ask ChatGPT' -and
    $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Edit'})
 Require ($edit.Count -eq 1) 'Draft editor vanished'
 $message=$edit[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
 Require ($message.EndsWith($prompt) -and
   $message.Contains('LTM-RAG vNext Native Apps M') -and
   $message.Length -lt 460) 'Frozen draft text or mention not verified'
 $button=@($es|Where-Object{$_.Current.Name -eq 'Send' -and
    $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Button' -and $_.Current.IsEnabled})
 Require ($button.Count -eq 1) 'Send button not unique or enabled'
 $sendAction=$button[0].GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
 Require ([StagePWindow]::GetForegroundWindow() -eq $h) 'Foreground changed before send'
 $receipt=[ordered]@{stage='P';phase='about_to_invoke_send';plugin_id=$plan.native_plugin_id;
  prompt_sha256=$digest;window_handle=$h.ToInt64();intended_send_count=1;
  ui_added_plugin_mention=$true;timestamp_utc=[DateTimeOffset]::UtcNow.ToString('o')}
 [IO.File]::WriteAllText($sendMarker,($receipt|ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false))
 Trace 'SEND' 'PRESEND_MARKER_FLUSHED'
 $sendAction.Invoke()
 $sent=$true
 $receipt.phase='one_send_invoked'
 [IO.File]::WriteAllText($sendMarker,($receipt|ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false))
 Trace 'SEND' 'ONE_FROZEN_NATIVE_SEND_INVOKED'
 $watch=[Diagnostics.Stopwatch]::StartNew()
 $state=@{stable=0;x=0;y=0;sample_ms=-1;scroll_used=$false}
 $lastReason=''
 $polls=0
 $frozenLabel=[string]$plan.cases[1].button_label
 while($watch.ElapsedMilliseconds -lt 40000){
  $polls++
  $es=$w.FindAll([System.Windows.Automation.TreeScope]::Descendants,
      [System.Windows.Automation.Condition]::TrueCondition)
  $a=@($es|Where-Object{$_.Current.Name -eq 'Address and search bar' -and
      $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Edit'})
  $url=if($a.Count -eq 1){$a[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value}else{''}
  if($url -eq 'chatgpt.com' -and $watch.ElapsedMilliseconds -lt 12000){
    if($lastReason -ne 'WAIT_FOR_SAVED_CHAT_URL'){
      Trace 'POLL' 'WAIT_FOR_SAVED_CHAT_URL' @{url_matches=$false}
      $lastReason='WAIT_FOR_SAVED_CHAT_URL'
    }
    Start-Sleep -Milliseconds 300
    continue
  }
  $b=@($es|Where-Object{$_.Current.Name -eq $frozenLabel -and
      $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Button'})
  $buttons=@($es|Where-Object{$_.Current.Name -like 'Confirm fictional topic:*' -and
      $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Button'})
  $status=@($es|Where-Object{$_.Current.Name -eq 'Select a single fictional topic.' -and
      $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Text'})
  $heading=@($es|Where-Object{$_.Current.Name -eq 'Choose a fictional source topic' -and
      $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Text'})
  $obs=@{window_present=$true;url_matches=($url -match '^chatgpt.com/c/');
    foreground_matches=([StagePWindow]::GetForegroundWindow() -eq $h);
    five_choices=($buttons.Count -eq 5 -and $heading.Count -eq 1);
    one_merrow=($b.Count -eq 1 -and $b[0].Current.IsEnabled);
    ready_status=($status.Count -eq 1);merrow_offscreen=$true;
    scroll_supported=$false;centre_x=0;centre_y=0}
  if($b.Count -eq 1){
   $p=$b[0].Current.BoundingRectangle
   $obs.centre_x=[int]($p.Left+$p.Width/2)
   $obs.centre_y=[int]($p.Top+$p.Height/2)
   $obs.merrow_offscreen=[bool]$b[0].Current.IsOffscreen
   $scroll=$null
   $obs.scroll_supported=$b[0].TryGetCurrentPattern(
      [System.Windows.Automation.ScrollItemPattern]::Pattern,[ref]$scroll)
  }
  $next=Evaluate-MerrowObservation -Observation $obs -Prior $state -ElapsedMs ([int]$watch.ElapsedMilliseconds) -DeadlineMs 40000
  if($next.reason -ne $lastReason){
    Trace 'POLL' $next.reason @{window_present=$obs.window_present;url_matches=$obs.url_matches;
      foreground_matches=$obs.foreground_matches;five_choices=$obs.five_choices;
      one_merrow=$obs.one_merrow;ready_status=$obs.ready_status;
      merrow_offscreen=$obs.merrow_offscreen;scroll_supported=$obs.scroll_supported;
      centre_x=$obs.centre_x;centre_y=$obs.centre_y;stable_count=$next.stable}
    $lastReason=$next.reason
  }
  if($next.status -eq 'STOP'){throw ('Polling stopped: '+$next.reason)}
  if($next.reason -eq 'SCROLL_INTO_VIEW_ONCE_ALLOWED'){
    if($state.scroll_used){throw 'Second scroll blocked'}
    # Persist scroll decision *before* the single UIA action.
    Trace 'SCROLL' 'ONE_SCROLL_REQUESTED'
    $state.scroll_used=$true
    $scroll.ScrollIntoView()
    Trace 'SCROLL' 'ONE_SCROLL_COMPLETED'
  }elseif($next.status -eq 'READY'){
    $samePrompt=@($es|Where-Object{$_.Current.Name.Trim() -eq $prompt -and
       $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Text'})
    $mention=@($es|Where-Object{$_.Current.Name -eq 'LTM-RAG vNext Native Apps M' -and
       $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Hyperlink'})
    Require ($samePrompt.Count -eq 1 -and $mention.Count -ge 1) 'Saved native prompt/mention not uniquely verified'
    Require ($b.Count -eq 1 -and $b[0].Current.IsEnabled) 'Target button changed before invoke'
    $invoke=$b[0].GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
    $row=[ordered]@{stage='P';phase='about_to_invoke_once';topic_id='merrow_prism';
      chat_url=$url;window_handle=$h.ToInt64();synthetic_automated_action=$true;
      human_consent_attested=$false;one_invoke_intended=1;
      local_elapsed_ms=[int]$watch.ElapsedMilliseconds;stable_count=$next.stable;
      timestamp_utc=[DateTimeOffset]::UtcNow.ToString('o')}
    [IO.File]::WriteAllText($invokeMarker,($row|ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false))
    Trace 'INVOKE' 'PREINVOKE_MARKER_FLUSHED' @{stable_count=$next.stable;
       centre_x=$obs.centre_x;centre_y=$obs.centre_y}
    $invoke.Invoke()
    $invoked=$true
    $row.phase='one_uia_invoke_issued'
    [IO.File]::WriteAllText($invokeMarker,($row|ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false))
    Trace 'INVOKE' 'ONE_MERROW_UIA_INVOKE_ISSUED'
    break
  }else{$state=$next}
  Start-Sleep -Milliseconds 300
 }
 if(-not $invoked){Trace 'COMPLETE' 'NO_UIA_INVOKE_WITHIN_DEADLINE'}
 else{Trace 'COMPLETE' 'SYNTHETIC_INVOKE_SUBMITTED'}
 Write-Output ('P_CONTROLLER_DONE native_send='+$sent+' uia_invoke='+$invoked+' polls='+$polls)
}catch{
 try{Trace 'FAILURE' 'EXCEPTION_AFTER_OR_BEFORE_SEND' }catch{}
 Write-Output ('P_CONTROLLER_FAILED native_send='+$sent+' uia_invoke='+$invoked+' reason='+$_.Exception.Message)
 throw
}
