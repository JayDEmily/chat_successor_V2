"""Independent semantic review reconciliation over original fictional sources.

The reviewed judgements are authored after inspecting complete answers.
This checks evidence provenance, exact answer markers, frozen prompt identity
and tool source-scope conflicts, but does not automate semantic judgement.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

from summarise_native_decision_i import verify as verify_trace

ROOT=Path(__file__).resolve().parents[1]
FIXTURE=ROOT/"fixtures/synthetic_clean_g.json"
PLAN=ROOT/"NATIVE_DECISION_SUPPORT_I_20261119.json"
REVIEW=ROOT/"NATIVE_DECISION_SUPPORT_I_SEMANTIC_REVIEW_20261119.json"
REPORT=ROOT/"NATIVE_DECISION_SUPPORT_I_SEMANTIC_RESULTS_20261119.md"


def verify() -> tuple[dict,list[tuple[dict,dict,dict,bool]]]:
    trace,checked=verify_trace()
    if not trace["complete"]:
        raise ValueError("Cannot review incomplete or duplicate-risk native trial")
    plan=json.loads(PLAN.read_text(encoding="utf8"))
    review=json.loads(REVIEW.read_text(encoding="utf8"))
    fixture=json.loads(FIXTURE.read_text(encoding="utf8"))
    if (review.get("trial_id")!=plan["trial_id"]
        or review.get("schema_version")!=1
        or review["source_fixture_sha256"]!=hashlib.sha256(FIXTURE.read_bytes()).hexdigest()):
        raise ValueError("Review identity or original source hash mismatch")
    by_id={m["message_id"]:m for m in fixture["messages"]}
    if len(by_id)!=20:
        raise ValueError("Original 20 distinct messages unavailable")
    # Source edges and authorship independently inspected from original G bytes.
    for updated,original in (("g03","g01"),("g07","g05"),("g11","g09"),
                             ("g15","g13"),("g19","g17")):
        new,old=by_id[updated],by_id[original]
        if (new["supersedes"]["message_id"]!=original or
                new["author_role"]!="user" or old["author_role"]!="user" or
                new["branch_id"]!="main" or old["branch_id"]!="main" or
                new["conversation_id"]!=old["conversation_id"]):
            raise ValueError("Original correction edge or attribution broken")
    for m in ("g04","g08","g12","g16","g20"):
        if (by_id[m]["branch_id"]!="alternative"
                or by_id[m]["author_role"]!="assistant"
                or by_id[m]["attribution"]!="assistant_inference"):
            raise ValueError("Assistant-only alternative branch changed")
    for m in ("g05","g07"):
        if (by_id[m]["author_role"]!="user" or
                by_id[m]["attribution"]!="reported_recollection" or
                by_id[m]["reported_speaker"]!="Vela"):
            raise ValueError("Reported speaker conflated with original author")
    reviews=review.get("reviews")
    if not isinstance(reviews,list) or len(reviews)!=16:
        raise ValueError("Missing 16 complete independent review entries")
    if [r["id"] for r in reviews]!=[f"I{i:02d}" for i in range(1,17)]:
        raise ValueError("Changed independent review order or ID set")
    summary=Counter()
    expanded=[]
    for record,(case,row,tracepass,scopeok,_source_counts) in zip(reviews,checked):
        if record["id"]!=case["id"]:
            raise ValueError("Semantic review and native case identity diverged")
        verdict=record["verdict"]
        if not (verdict.startswith("PASS_") or verdict=="FAIL_UNSUPPORTED_REFERENT"):
            raise ValueError("Invalid semantic verdict")
        if len(record.get("finding",""))<40 or len(record.get("original_source_basis",""))<20:
            raise ValueError("Insufficient review rationale")
        ids=record.get("source_message_ids")
        if not isinstance(ids,list) or len(set(ids))!=len(ids) or any(i not in by_id for i in ids):
            raise ValueError("Unknown or duplicate supporting original source IDs")
        if any(required not in ids for required in case["source_ids"]):
            raise ValueError("Review omitted frozen required source message identity")
        # Markers support independently written human review, but cannot prove it.
        answer=row["answer_text"].casefold()
        markers=record.get("answer_markers")
        if not isinstance(markers,list) or len(markers)<2:
            raise ValueError("Not enough answer evidence markers")
        for marker in markers:
            if not isinstance(marker,str) or not marker.strip() or marker.casefold() not in answer:
                raise ValueError("Native answer lacks evidence marker "+
                                 case["id"]+": "+str(marker))
        if verdict=="FAIL_UNSUPPORTED_REFERENT":
            if scopeok or case["expected_status"]!="UNANCHORED":
                raise ValueError("Unsubstantiated fail-review mechanism")
            summary["semantic_fail"]+=1
        else:
            summary["semantic_pass"]+=1
        summary[verdict]+=1
        expanded.append((record,case,row,scopeok))
    if (summary["semantic_pass"],summary["semantic_fail"])!=(14,2):
        raise ValueError("Native I independent review verdict counts changed")
    if {r["id"] for r in reviews if r["verdict"]=="FAIL_UNSUPPORTED_REFERENT"}!={"I05","I15"}:
        raise ValueError("Known semantic failures not preserved")
    return {
        "trial_id":plan["trial_id"],"native_cases":len(reviews),
        "reviewed_sources":len(by_id),"original_fixture_sha256":review["source_fixture_sha256"],
        "source_scope_pass":trace["counts"]["source_scope_pass"],
        "source_scope_fail":trace["counts"]["source_scope_fail"],
        "trace_specified_pass":trace["counts"]["specified_trace_pass"],
        "trace_specified_fail":trace["counts"]["specified_trace_fail"],
        "verdicts":dict(summary),
    },expanded

def write_report(summary:dict, checked:list[tuple]) -> None:
    verdicts=summary["verdicts"]
    lines=[
        "# Native Decision-Support I — retrospective original-source semantic review",
        "",
        "**Verdict: 14/16 acceptable answers; 2/16 unsupported referent",
        "selection failures (I05/I15).** This separately reviews the",
        "complete saved ChatGPT answers against the original 20 made-up",
        "messages. Read-only validation confirmed every referenced message",
        "identity, correction edge, branch, source role and reported speaker.",
        "Marker checks only corroborate full-answer human semantic review.",
        "",
        "The separate native invocation check passed **12/12** specified",
        "required/avoided-tool cases with **14 successful I calls**, but",
        "the native source-packet scope checked **14/16** and failed",
        "**I05/I15**. Tool success is not semantic success.",
        "",
        "| Case | Source-content judgement | Original evidence messages | I source scope |",
        "|---|---|---|---|",
    ]
    for record,case,row,scope_ok in checked:
        verdict=record["verdict"]
        evidence=", ".join(record["source_message_ids"]) or "none"
        scope="PASS" if scope_ok else "**FAIL**"
        lines.append(f"| {case['id']} | {verdict} | {evidence} | {scope} |")
    lines.extend([
        "",
        "## Material native findings",
        "",
        "**I01 (first chat-empty Project turn):** The assistant actually",
        "called the new I resolver, received **zero source packets** and",
        "asked which record the user meant. The answer selected no",
        "narrative. This is one independently grounded clean-context pass.",
        "",
        "**I05:** For the referent-free prompt *Was the original version",
        "first or second?*, the model made one successful I call whose",
        "handler returned **12 original source packets**, although the",
        "registered unanchored question requires zero. The assistant",
        "answered 'First' and introduced the ORA-62 pier 4/pier 11",
        "example, despite the user not identifying ORA-62. The original",
        "ORA facts were accurate, but the referent selection was",
        "unsupported. Record **FAIL_UNSUPPORTED_REFERENT**.",
        "",
        "**I15:** For *Did she actually say it?*, the user gave no",
        "speaker or conversation identity. The I handler nevertheless",
        "returned **four packets**, and the assistant identified the",
        "Vela/TERN-91 narrative. Its statement that Vela's purported",
        "speech is only an unverified narrator recollection is accurate",
        "for g05/g07, but that does not establish which 'she' the user",
        "meant. Record **FAIL_UNSUPPORTED_REFERENT**.",
        "",
        "**I11:** The third underspecified follow-up returned zero",
        "source packets and asked for the intended record, like I01.",
        "Thus ambiguity behaviour was mixed, not consistently fixed.",
        "",
        "**I02–I04/I06–I08/I12–I14/I16:** The main source conclusions",
        "matched the original messages: user corrections remained",
        "distinct from assistant-only alternative-branch guesses;",
        "the original locker/optic remained distinct from the",
        "corrected one; the multi-topic comparison retained both",
        "correction sources; reported Vela speech was never treated",
        "as authenticated audio, and no missing serial/audio was",
        "fabricated.",
        "",
        "**I09–I10:** Technical questions about thermal expansion and",
        "hydraulic accumulators were answered without I resolver",
        "calls; semantic technical explanations were adequate.",
        "Accessibility text extraction may distort mathematical glyphs,",
        "so this review does not certify equation typography.",
        "",
        "## Root cause interpretation and next engineering boundary",
        "",
        "The I server validates the original 20-source archive and",
        "only returns source packets when **its received tool argument**",
        "contains an explicit narrative anchor. The frozen unanchored",
        "user prompts had no such anchors. Successful calls with 12",
        "or four packets therefore show a mismatch between the user",
        "question's referent and the arguments effectively evaluated",
        "by the tool. The actual tool arguments were not logged,",
        "so their exact wording and whether earlier same-Project chats",
        "caused the expansion are **unknown**. Do not claim the native",
        "model faithfully passed the current user text verbatim.",
        "",
        "This is a trust-boundary failure, not proof that H's original",
        "current-question local selector is broken. A model-authored",
        "tool question is not a host-attested user question. Simply",
        "asking the model to pass text verbatim, adding an extra",
        "fetch_source call or accepting source ranking cannot prove",
        "referent legitimacy. A separately registered mechanism",
        "would need a trusted binding to the actual user request,",
        "or a validated dialogue-context contract, plus native tests.",
        "",
        "## Causal and completeness limitations",
        "",
        "- I01 was first in a newly chat-empty Project whose Project-only",
        "  memory was explicitly selected at creation and verified",
        "  again in reopened Project settings. Later I02–I16 were",
        "  within the same Project and may share Project memory.",
        "  Immediate memory-mode propagation was not independently proved.",
        "- Every full answer was reviewed against an entirely fictional",
        "  original archive. Neither genuine memory reliability nor",
        "  external factual authenticity has been established.",
        "- The connected I plugin and private localhost/tunnel were",
        "  entirely separate from the original six-source and G",
        "  services. No native G score or source text was rewritten.",
        "- The 16 complete answers, private event IDs and prompt hashes",
        "  remain in ignored local ledgers; public Git reports contain",
        "  only reduced fictional case evidence and saved-chat links.",
        "",
    ])
    REPORT.write_text("\n".join(lines),encoding="utf8")


def main() -> None:
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=("status","write"))
    args=p.parse_args()
    summary,checked=verify()
    print(json.dumps(summary,sort_keys=True))
    if args.action=="write":
        write_report(summary,checked)
        print("NATIVE_I_SEMANTIC_REPORT_WRITTEN")


if __name__=="__main__":
    main()
