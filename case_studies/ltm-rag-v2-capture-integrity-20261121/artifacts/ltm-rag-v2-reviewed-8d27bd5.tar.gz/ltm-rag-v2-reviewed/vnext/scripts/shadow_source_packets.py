"""Synthetic-only read-only source-packet resolution for offline dense candidates.

Candidate similarity is never source authentication or proof of relevance.
Every packet must be retrieved through Archive.fetch from immutable SQLite.
"""
from __future__ import annotations

import hashlib
import math
from pathlib import Path
from typing import Any

from ltm_vnext.archive import Archive, _local_id


class PacketIntegrityError(ValueError):
    """A resolved SQLite packet does not match the registered synthetic evidence."""


class ShadowPacketResolver:
    def __init__(self, archive: Archive, fixture: dict):
        data=fixture.get("messages",[])
        if fixture.get("synthetic") is not True or not isinstance(data,list) or not data:
            raise PacketIntegrityError("Requires explicit synthetic-only fixture")
        if any(m.get("capture_method")!="synthetic_fixture" for m in data):
            raise PacketIntegrityError("Non-synthetic source not allowed")
        self.archive=archive
        self.records={m["message_id"]:m for m in data}
        if len(self.records)!=len(data):
            raise PacketIntegrityError("Duplicate source message identity")
        self.local_ids={}
        for message in data:
            local=_local_id(message["source_id"],message["message_id"],message["version_id"])
            if local in self.local_ids:
                raise PacketIntegrityError("Colliding local ID")
            self.local_ids[local]=message
        self.expected_children={}
        for message in data:
            previous=message.get("supersedes")
            if previous is not None:
                key=_local_id(message["source_id"],previous["message_id"],previous["version_id"])
                source=self.local_ids.get(key)
                if source is None:
                    raise PacketIntegrityError("Correction source absent")
                if (source["conversation_id"]!=message["conversation_id"]
                    or source["branch_id"]!=message["branch_id"]):
                    raise PacketIntegrityError("Correction crossed conversation/branch")
                self.expected_children.setdefault(key,[]).append(
                    _local_id(message["source_id"],message["message_id"],message["version_id"])
                )

    @staticmethod
    def text_hash(content: str) -> str:
        return hashlib.sha256(content.encode("utf8")).hexdigest()

    def verify_packet(self, packet: dict[str,Any], registered: dict[str,Any]) -> None:
        identity=_local_id(registered["source_id"],registered["message_id"],registered["version_id"])
        if packet.get("local_id")!=identity:
            raise PacketIntegrityError("Packet local ID mismatch")
        for key in (
            "source_id","message_id","version_id","conversation_id","branch_id",
            "position","author_role","reported_speaker","attribution",
            "capture_method","source_locator","exact_text",
        ):
            expected=registered.get(key)
            if packet.get(key)!=expected:
                raise PacketIntegrityError("Packet field mismatched: "+key)
        if packet.get("fidelity")!="synthetic_only":
            raise PacketIntegrityError("Source fidelity label is not synthetic")
        exact=registered["exact_text"]
        if packet.get("content_sha256")!=self.text_hash(exact):
            raise PacketIntegrityError("Original UTF-8 source SHA-256 mismatch")
        previous=registered.get("supersedes")
        prior_local=(_local_id(registered["source_id"],previous["message_id"],previous["version_id"])
                     if previous is not None else None)
        if packet.get("supersedes_local_id")!=prior_local:
            raise PacketIntegrityError("Supersession identity mismatch")
        actual_children=packet.get("corrected_by",[])
        if len(actual_children)!=len(set(actual_children)):
            raise PacketIntegrityError("Duplicate correction descendants")
        if set(actual_children)!=set(self.expected_children.get(identity,[])):
            raise PacketIntegrityError("Correction descendants mismatch")
        for adjacent in packet.get("neighbouring_dialogue",[]):
            local=adjacent["local_id"]
            other=self.local_ids.get(local)
            if other is None:
                raise PacketIntegrityError("Unknown adjacent source identity")
            if (
                other["source_id"]!=registered["source_id"]
                or other["conversation_id"]!=registered["conversation_id"]
                or other["branch_id"]!=registered["branch_id"]
            ):
                raise PacketIntegrityError("Cross-branch/source neighbour")
            for key in ("position","author_role","exact_text"):
                if adjacent.get(key)!=other[key]:
                    raise PacketIntegrityError("Adjacent source field mismatch: "+key)
            if adjacent.get("content_sha256")!=self.text_hash(other["exact_text"]):
                raise PacketIntegrityError("Adjacent source text/hash mismatch")

    def resolve(self, candidates: list[tuple[str,float]]) -> list[dict]:
        if not isinstance(candidates,list) or len(candidates)>8:
            raise ValueError("Maximum eight ranked source candidates")
        seen=set()
        result=[]
        for rank,(mid,score) in enumerate(candidates,start=1):
            if mid in seen:
                raise ValueError("Duplicate candidate source identity")
            seen.add(mid)
            expected=self.records.get(mid)
            if expected is None:
                raise PacketIntegrityError("Candidate outside registered synthetic archive")
            if type(score) not in (float,int) or not math.isfinite(score) or not -1.01<=score<=1.01:
                raise ValueError("Invalid cosine score")
            local=_local_id(expected["source_id"],expected["message_id"],expected["version_id"])
            packet=self.archive.fetch(local,neighbours=1)
            if packet is None:
                raise PacketIntegrityError("Registered source missing from SQLite")
            self.verify_packet(packet,expected)
            result.append({
                "rank":rank,
                "cosine_similarity":float(score),
                "candidate_relevance":"unverified_candidate",
                "source_integrity":"verified_against_synthetic_fixture_only",
                "source":packet,
            })
        return result
