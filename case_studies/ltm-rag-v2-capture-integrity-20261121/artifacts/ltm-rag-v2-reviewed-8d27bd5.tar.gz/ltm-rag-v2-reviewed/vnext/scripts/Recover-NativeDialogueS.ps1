# Stage S recovery only; NEVER sends or clicks a ChatGPT message.
[CmdletBinding()]
param([ValidateRange(1,5)][int]$Turn)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$root='\\wsl.localhost\Ubuntu\home\jds\ltm-rag-vnext-20261118\vnext'
$private=Join-Path $root '.local\native-s-dialogue'
$plan=Get-Content -Raw (Join-Path $root 'NATIVE_DIALOGUE_S_CASES_20261120.json')|ConvertFrom-Json
$case=$plan.case_messages[$Turn-1]
$windowInfo=Get-Content -Raw 'C:\Users\james\AppData\Local\Temp\ltm_s_dedicated_window_once.json'|ConvertFrom-Json
$pre=Join-Path $private ('send_once_'+$Turn.ToString('00')+'.json')
$captured=Join-Path $private ('captured_'+$Turn.ToString('00')+'.json')
if(-not (Test-Path $pre) -or (Test-Path $captured)){throw 'Recovery requires spent native send and missing capture'}
$receipt=Get-Content -Raw $pre|ConvertFrom-Json
if($receipt.phase -ne 'send_invoked' -or $receipt.turn -ne $Turn -or
 $receipt.native_window_handle -ne $windowInfo.native_window_handle -or $receipt.case_id -ne $case.id){
 throw 'Frozen native send-marker mismatch'
}
$check=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash(
 [Text.Encoding]::UTF8.GetBytes([string]$case.simulated_user_text))).Replace('-','').ToLowerInvariant()
if($check -ne $receipt.prompt_sha256){throw 'Frozen native user text hash mismatch'}
$rootEl=[Windows.Automation.AutomationElement]::RootElement
$win=@($rootEl.FindAll([Windows.Automation.TreeScope]::Children,[Windows.Automation.Condition]::TrueCondition)|
 Where-Object{$_.Current.ClassName -eq 'Chrome_WidgetWin_1' -and
  $_.Current.NativeWindowHandle -eq [int64]$windowInfo.native_window_handle})
if($win.Count -ne 1){throw 'Dedicated window missing'}
function Snapshot {
 $elements=$win[0].FindAll([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.Condition]::TrueCondition)
 $addr=@($elements|Where-Object{$_.Current.Name -eq 'Address and search bar' -and
  $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Edit'})
 if($addr.Count -ne 1){throw 'Dedicated browser URL not readable'}
 $url=$addr[0].GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern).Current.Value
 if($url -notmatch '^chatgpt\.com/c/[a-zA-Z0-9-]+$'){throw 'ChatGPT saved conversation URL missing'}
 $groups=@($elements|Where-Object{$_.Current.Name -eq 'Conversation' -and
  $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Group'})
 if($groups.Count -ne 1){throw 'Saved conversation group not uniquely accessible'}
 $texts=$groups[0].FindAll([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.Condition]::TrueCondition)
 $uCount=0;$aCount=0;$hasText=$false;$onAssistant=$false
 $bits=New-Object System.Collections.Generic.List[string]
 foreach($el in $texts){
  if($el.Current.ControlType.ProgrammaticName -ne 'ControlType.Text'){continue}
  $value=[string]$el.Current.Name
  if($value -eq 'You said:'){$uCount++;$onAssistant=$false;continue}
  if($value -eq 'ChatGPT said:'){$aCount++;$onAssistant=$true;$bits.Clear();continue}
  if($value -eq [string]$case.simulated_user_text){$hasText=$true}
  if($onAssistant -and -not [string]::IsNullOrWhiteSpace($value)){$bits.Add($value)}
 }
 $stops=@($elements|Where-Object{$_.Current.Name -eq 'Stop' -and
  $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Button'})
 return @{url=$url;u=$uCount;a=$aCount;hasPrompt=$hasText;
          text=($bits -join "\n").Trim();complete=($stops.Count -eq 0)}
}
$first=Snapshot
if($first.u -ne $Turn -or $first.a -ne $Turn -or
  -not $first.hasPrompt -or -not $first.complete -or
  $first.text.Length -lt 2 -or $first.text.Length -gt 6000){
 throw ('Native chat answer not yet recoverable; user='+$first.u+' assistant='+$first.a+
  ' prompt='+$first.hasPrompt+' complete='+$first.complete+' chars='+$first.text.Length)
}
if($Turn -gt 1){
 $prior=Get-Content -Raw (Join-Path $private ('captured_'+($Turn-1).ToString('00')+'.json'))|ConvertFrom-Json
 if($prior.chat_url -ne $first.url){throw 'Wrong native chat; no capture'}
}
Start-Sleep -Milliseconds 1600
$second=Snapshot
if($second.url -ne $first.url -or $second.u -ne $Turn -or
  $second.a -ne $Turn -or -not $second.complete -or
  $second.text -ne $first.text){throw 'Response unstable across two UIA reads'}
$observed=[DateTimeOffset]::UtcNow.ToString('o')
$row=[ordered]@{stage='S';turn=$Turn;case_id=$case.id;synthetic_only=$true;
 simulated_user_text=[string]$case.simulated_user_text;
 assistant_observed_text=[string]$second.text;assistant_generated_by='native_chatgpt';
 capture_method='native_windows_ui_automation';real_user_authorship_attested=$false;
 ui_send_at_utc=[string]$receipt.ui_send_at_utc;
 assistant_observed_complete_at_utc=$observed;
 chat_url=[string]$second.url;native_window_handle=[int64]$windowInfo.native_window_handle;
 assistant_capture_fidelity='UIA_rendered_text_observation_not_underlying_model_token_stream'}
[IO.File]::WriteAllText($captured,($row|ConvertTo-Json -Compress -Depth 8),[Text.UTF8Encoding]::new($false))
Write-Output ('S_NATIVE_RECOVERED turn='+$Turn+' assistant_chars='+$second.text.Length+' resends=0')
& wsl.exe -d Ubuntu -- bash -lc ('cd /home/jds/ltm-rag-vnext-20261118 && PYTHONPATH=vnext vnext/.venv/bin/python vnext/scripts/native_dialogue_s_bridge.py index --turn '+$Turn)
if($LASTEXITCODE -ne 0){throw 'Recovered source persisted, but Stage S indexing failed'}
Write-Output ('S_NATIVE_RECOVERY_AND_INDEX_PASS turn='+$Turn)
