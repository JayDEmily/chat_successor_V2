"""One-shot local Stage M Streamable HTTP client smoke, no ChatGPT."""
import anyio, json, os, socket, subprocess, sys, time
from pathlib import Path
from mcp import Client
from mcp.server.apps import APP_MIME_TYPE, EXTENSION_ID
from mcp.client import advertise

def wait_port(port,timeout=9):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        try:
            with socket.create_connection(("127.0.0.1",port),timeout=.4):
                return
        except OSError:
            time.sleep(.15)
    raise RuntimeError("Stage M loopback listener failed")

async def run_check():
    apps=advertise(EXTENSION_ID,{"mimeTypes":[APP_MIME_TYPE]})
    async with Client("http://127.0.0.1:8791/mcp",extensions=[apps]) as client:
        tools=await client.list_tools()
        print("SDK_LIST_TOOLS",len(tools.tools),[(t.name,t.meta) for t in tools.tools])
        resources=await client.list_resources()
        print("SDK_LIST_RESOURCES",len(resources.resources),[(str(x.uri),x.mime_type) for x in resources.resources])
        ui=await client.read_resource("ui://ltm-rag-vnext-m/selector.html")
        print("SDK_READ_RESOURCE",len(ui.contents),[x.mime_type for x in ui.contents])
        result=await client.call_tool("open_topic_selector_m",{})
        print("SDK_CALL_TOOL",json.dumps(result.structured_content,sort_keys=True))
        assert result.structured_content["status"]=="NO_SESSION_CONTEXT"
        assert result.structured_content["source_count"]==0
        synthetic_meta={"openai/session":"fiction-M-session-A",
                        "openai/subject":"fiction-M-owner-A"}
        opened=await client.call_tool("open_topic_selector_m",{},meta=synthetic_meta)
        assert not opened.is_error
        assert opened.structured_content["status"]=="AWAITING_CONFIRMATION"
        assert opened.structured_content["source_packets"]==[]
        private=opened.meta
        assert private and private["stage_m"]["challenge"]
        challenge=private["stage_m"]["challenge"]
        assert challenge not in str(opened.structured_content)
        assert challenge not in str(opened.content)
        denied=await client.call_tool("confirm_topic_m",{
            "challenge":challenge,"topic_id":"merrow_prism"},
            meta={"openai/session":"fiction-M-session-B",
                  "openai/subject":"fiction-M-owner-A"})
        assert denied.structured_content["status"]=="DENIED"
        accepted=await client.call_tool("confirm_topic_m",{
            "challenge":challenge,"topic_id":"merrow_prism"},meta=synthetic_meta)
        assert accepted.structured_content["status"]=="CONFIRMED"
        assert accepted.structured_content["source_count"]==0
        replay=await client.call_tool("confirm_topic_m",{
            "challenge":challenge,"topic_id":"merrow_prism"},meta=synthetic_meta)
        assert replay.structured_content["status"]=="DENIED"
        print("M_LOCAL_HTTP_SMOKE_PASS app_extension=true private_meta=true cross_session_denied=true replay_denied=true no_source_packets=true")

def main():
    root=Path(__file__).resolve().parents[1]
    cmd=[sys.executable,"-m","ltm_vnext.mcp_apps_m","--port","8791"]
    proc=subprocess.Popen(cmd,cwd=root.parent,stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,
        env={**os.environ,"PYTHONPATH":str(root)},text=True)
    try:
        wait_port(8791)
        anyio.run(run_check)
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=4)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=4)
    print("M_TEMPORARY_LISTENER_STOPPED",proc.poll() is not None)

if __name__=="__main__":
    main()
