# Stage S one native ChatGPT simulated-user send, authentic assistant UIA capture,
# then synchronous SQLite+OpenAI hosted indexing before any next send.
# Strictly one action per frozen turn, no replay of send after pre-send receipt.
[CmdletBinding()]
param([ValidateRange(1,5)][int]$Turn,[switch]$PreflightOnly)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class StageSFocus {
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
}
'@
$root='\\wsl.localhost\Ubuntu\home\jds\ltm-rag-vnext-20261118\vnext'
$private=Join-Path $root '.local\native-s-dialogue'
$cases=Get-Content -Raw (Join-Path $root 'NATIVE_DIALOGUE_S_CASES_20261120.json')|ConvertFrom-Json
if($cases.trial_id -ne 'ltm-vnext-S-native-synthetic-dialogue-20261120' -or
  $cases.case_messages.Count -ne 5 -or $cases.authorised_native_messages_max -ne 5){
 throw 'Frozen Stage S trial specification mismatch'
}
$marker='C:\Users\james\AppData\Local\Temp\ltm_s_dedicated_window_once.json'
if(-not (Test-Path $marker)){throw 'Dedicated empty S window not registered'}
$windowInfo=Get-Content -Raw $marker|ConvertFrom-Json
if($windowInfo.phase -ne 'dedicated_blank_chat_verified'){throw 'Stage S original window preflight mismatch'}
$handle=[IntPtr][Int64]$windowInfo.native_window_handle
$rootElement=[Windows.Automation.AutomationElement]::RootElement
$window=@($rootElement.FindAll([Windows.Automation.TreeScope]::Children,[Windows.Automation.Condition]::TrueCondition)|
 Where-Object {$_.Current.ClassName -eq 'Chrome_WidgetWin_1' -and $_.Current.NativeWindowHandle -eq $handle.ToInt64()})
if($window.Count -ne 1){throw 'Unique dedicated Stage S browser disappeared'}
$w=$window[0]
$case=$cases.case_messages[$Turn-1]
if($case.turn -ne $Turn -or $case.id -ne ('S-N'+$Turn.ToString('00'))){throw 'Frozen S turn identity mismatch'}
$prompt=[string]$case.simulated_user_text
$receiptPath=Join-Path $private ('captured_'+$Turn.ToString('00')+'.json')
$preSendPath=Join-Path $private ('send_once_'+$Turn.ToString('00')+'.json')
if((Test-Path $receiptPath) -or (Test-Path $preSendPath)){
 throw 'This frozen Stage S turn has already been sent or may be pending; refuse duplicate'
}
if($Turn -gt 1){
 $priorPath=Join-Path $private ('captured_'+($Turn-1).ToString('00')+'.json')
 if(-not (Test-Path $priorPath)){throw 'Prior native turn missing or incomplete'}
 $prior=Get-Content -Raw $priorPath|ConvertFrom-Json
 if($prior.turn -ne ($Turn-1)){throw 'Prior native turn mismatch'}
}
function Elements {
 return $w.FindAll([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.Condition]::TrueCondition)
}
function One([object]$items,[string]$name,[string]$typeName) {
 $found=@($items|Where-Object {$_.Current.Name -eq $name -and $_.Current.ControlType.ProgrammaticName -eq $typeName})
 if($found.Count -ne 1){throw ('Expected unique '+$name+' '+$typeName+', observed '+$found.Count)}
 return $found[0]
}
function Url([object]$es) {
 $addr=One $es 'Address and search bar' 'ControlType.Edit'
 return $addr.GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern).Current.Value
}
function Observation([object]$es){
 $groups=@($es|Where-Object {$_.Current.ControlType.ProgrammaticName -eq 'ControlType.Group' -and $_.Current.Name -eq 'Conversation'})
 if($groups.Count -ne 1){
  return @{ assistant_count=0;user_count=0;latest='';complete=$false }
 }
 $inside=$groups[0].FindAll([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.Condition]::TrueCondition)
 $active=$false
 $assistantCount=0
 $userCount=0
 $segment=New-Object System.Collections.Generic.List[string]
 foreach($el in $inside){
  if($el.Current.ControlType.ProgrammaticName -ne 'ControlType.Text'){continue}
  $name=[string]$el.Current.Name
  if($name -eq 'ChatGPT said:'){
    $assistantCount++
    $active=$true
    $segment.Clear()
    continue
  }
  if($name -eq 'You said:'){
    $userCount++
    $active=$false
    continue
  }
  # Global ChatGPT page controls are not assistant-origin words. Keep the
  # user's original reply separate from the browser/footer after it.
  if($active -and $name -in @('ChatGPT can make mistakes. Check important info.',
                             'Latest response','Ask ChatGPT')){
    $active=$false
    continue
  }
  if($active -and -not [string]::IsNullOrWhiteSpace($name)){
    if($name -notin @('ChatGPT said','ChatGPT','Copy','Read aloud',
                        'Good response','Bad response','More actions')){
      $segment.Add($name)
    }
  }
 }
 $stops=@($es|Where-Object {$_.Current.ControlType.ProgrammaticName -eq 'ControlType.Button' -and $_.Current.Name -eq 'Stop'})
 return @{assistant_count=$assistantCount;user_count=$userCount;
          latest=($segment -join "\n").Trim();
          complete=($stops.Count -eq 0)}
}
$all=Elements
$url=Url $all
if($Turn -eq 1){
 if($url -ne 'chatgpt.com' -and $url -ne 'https://chatgpt.com/'){
  throw 'First native turn must begin on an empty ChatGPT root'
 }
 $priorObservation=Observation $all
 if($priorObservation.assistant_count -ne 0 -or $priorObservation.user_count -ne 0){
  throw 'First-turn native conversation was not empty'
 }
}else{
 if($url -ne $prior.chat_url){throw 'Browser conversation URL changed between turns'}
 $priorObservation=Observation $all
 if($priorObservation.assistant_count -ne ($Turn-1)){
  throw ('Expected prior replies='+($Turn-1)+' observed='+$priorObservation.assistant_count)
 }
}
$edit=One $all 'Ask ChatGPT' 'ControlType.Edit'
$oldDraft=$edit.GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern).Current.Value
if($oldDraft.Trim() -ne '' -and $oldDraft.Trim() -ne 'Ask ChatGPT'){
 throw 'Nonempty draft in dedicated ChatGPT composer'
}
Write-Output ('S_UI_PREFLIGHT_OK turn='+$Turn+' previous_assistant_count='+$priorObservation.assistant_count+' no_send='+$PreflightOnly)
if($PreflightOnly){return}
if(-not [StageSFocus]::SetForegroundWindow($handle)){throw 'Could not focus isolated ChatGPT Chrome window'}
Start-Sleep -Milliseconds 160
if([StageSFocus]::GetForegroundWindow() -ne $handle){throw 'Isolated foreground window changed; no send'}
$edit.SetFocus()
$edit.GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern).SetValue($prompt)
Start-Sleep -Milliseconds 220
$all=Elements
$edit=One $all 'Ask ChatGPT' 'ControlType.Edit'
$draft=$edit.GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern).Current.Value
if($draft -ne $prompt){throw 'Native draft is not exactly the preregistered simulated-user message'}
if((Url $all) -ne $url){throw 'Browser URL changed before frozen send'}
$send=@($all|Where-Object {$_.Current.Name -eq 'Send' -and
  $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Button' -and $_.Current.IsEnabled})
if($send.Count -ne 1){throw 'Native send button not unique or enabled'}
$action=$send[0].GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)
$sendAt=[DateTimeOffset]::UtcNow.ToString('o')
$sha=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($prompt))).Replace('-','').ToLowerInvariant()
$pending=[ordered]@{stage='S';turn=$Turn;case_id=$case.id;
  phase='about_to_invoke_send';simulated_only=$true;
  ui_send_at_utc=$sendAt;prompt_sha256=$sha;
  native_window_handle=$handle.ToInt64()}
[IO.File]::WriteAllText($preSendPath,($pending|ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false))
$action.Invoke()
$pending.phase='send_invoked'
[IO.File]::WriteAllText($preSendPath,($pending|ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false))
Write-Output ('S_NATIVE_SENT turn='+$Turn+' marker_recorded=true')
$watch=[Diagnostics.Stopwatch]::StartNew()
$last=''
$stable=0
$answer=''
$urlAfter=''
while($watch.Elapsed.TotalSeconds -lt 120){
 Start-Sleep -Milliseconds 1200
 try {
  $es=Elements
  $nowUrl=Url $es
  $obs=Observation $es
 }catch{
  # Chrome's accessibility tree can transiently invalidate elements during
  # UI navigation/streaming. This recovery only re-reads; never sends again.
  Start-Sleep -Milliseconds 450
  continue
 }
 if($nowUrl -notmatch '^chatgpt\.com/c/[a-zA-Z0-9-]+$'){continue}
 if($Turn -gt 1 -and $nowUrl -ne $url){throw 'Chat changed during response; response not captured'}
 if(-not $obs.complete -or $obs.assistant_count -ne $Turn -or
    [string]::IsNullOrWhiteSpace($obs.latest)){
    $stable=0
    continue
 }
 if($obs.latest -eq $last){$stable++}else{$last=$obs.latest;$stable=0}
 if($stable -ge 2){$answer=$obs.latest;$urlAfter=$nowUrl;break}
}
if([string]::IsNullOrWhiteSpace($answer)){
 throw 'Native assistant text not provably complete; pending marker retained. Do not resend.'
}
if($answer.Length -gt 6000){throw 'Rendered assistant response unexpectedly large; no transcript claim'}
$received=[DateTimeOffset]::UtcNow.ToString('o')
$row=[ordered]@{stage='S';turn=$Turn;case_id=$case.id;synthetic_only=$true;
 simulated_user_text=$prompt;assistant_observed_text=$answer;
 assistant_generated_by='native_chatgpt';
 capture_method='native_windows_ui_automation';
 real_user_authorship_attested=$false;
 ui_send_at_utc=$sendAt;assistant_observed_complete_at_utc=$received;
 chat_url=$urlAfter;native_window_handle=$handle.ToInt64();
 assistant_capture_fidelity='UIA_rendered_text_observation_not_underlying_model_token_stream'}
[IO.File]::WriteAllText($receiptPath,($row|ConvertTo-Json -Depth 8 -Compress),[Text.UTF8Encoding]::new($false))
Write-Output ('S_NATIVE_CAPTURED turn='+$Turn+' assistant_chars='+$answer.Length+' stable_samples='+$stable+' chat_url_valid=true')
$wslargs=@('-d','Ubuntu','--','bash','-lc',('cd /home/jds/ltm-rag-vnext-20261118 && PYTHONPATH=vnext vnext/.venv/bin/python vnext/scripts/native_dialogue_s_bridge.py index --turn '+$Turn))
& wsl.exe @wslargs
if($LASTEXITCODE -ne 0){throw ('SQLite/vector incremental index failed; native capture preserved; code='+$LASTEXITCODE)}
Write-Output ('S_NATIVE_TURN_COMPLETE turn='+$Turn+' indexed=true')
