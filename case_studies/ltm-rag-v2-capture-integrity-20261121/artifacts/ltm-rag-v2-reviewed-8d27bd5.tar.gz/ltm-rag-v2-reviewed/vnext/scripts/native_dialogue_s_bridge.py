"""Stage S preregistered 5-turn native capture -> SQL -> hosted index.

All sensitive transcript and hosted identifiers stay Git-ignored. Only printed
summaries. No Responses / Chat Completions API inference calls.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
from ltm_vnext.native_dialogue_s import NativeSyntheticS, StageSFailure, _private_write

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
REGISTERED="a02192ef14c86242532e9ab22c61a64c590cecd1"
PARENT="24cd9f456e058b2789e0e8e20ad34d0761289906"
FROZEN=("NATIVE_DIALOGUE_S_PROTOCOL_20261120.md","NATIVE_DIALOGUE_S_CASES_20261120.json")


def git(*args):
    return subprocess.run(["git","-C",str(REPO),*args],
                          check=True,capture_output=True).stdout


def preregistered():
    if git("rev-list","--parents","-n","1",REGISTERED).decode().strip()!=REGISTERED+" "+PARENT:
        raise StageSFailure("Native Stage S registration parent drift")
    for filename in FROZEN:
        if (ROOT/filename).read_bytes()!=git("show",REGISTERED+":vnext/"+filename):
            raise StageSFailure("Frozen native Stage S bytes drift: "+filename)


def measure(pipeline:NativeSyntheticS,turn: int):
    plan=pipeline.plan
    cases=[c for c in plan["search_cases"] if c["after_turn"]==turn]
    if not cases:return
    results={"trial_id":"S","frozen":True,"queries":{}}
    if pipeline.ledger.exists():
        results=json.loads(pipeline.ledger.read_text(encoding="utf-8"))
        if results.get("trial_id")!="S" or "queries" not in results:
            raise StageSFailure("Private search ledger malformed")
    for case in cases:
        if case["id"] in results["queries"]:continue
        hits=pipeline.search(case["query"])
        ranks=[idx+1 for idx,h in enumerate(hits)
               if h["turn"]==case["expected_turn"]]
        rank=min(ranks) if ranks else None
        results["queries"][case["id"]]={
            "after_turn":turn,"target_rank":rank,
            "ranked_turns":[h["turn"] for h in hits],
            "top5_pass":rank is not None and rank<=case["within_top"],
        }
        _private_write(pipeline.ledger,results)
        print("S_HOSTED_QUERY",case["id"],
              "target_rank="+str(rank),"top5="+str(results["queries"][case["id"]]["top5_pass"]),
              flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("preflight","index","verify"))
    parser.add_argument("--turn",type=int)
    args=parser.parse_args()
    preregistered()
    pipeline=NativeSyntheticS()
    store_id=pipeline.store(allow_create=(args.action=="preflight"))
    if args.action=="preflight":
        result=pipeline.verify(upto=0)
        print("S_PRIVATE_STORE_PREFLIGHT_PASS store_isolated=true indexed_turns=0")
        return
    if args.action=="index":
        if args.turn not in (1,2,3,4,5):
            raise StageSFailure("One finite frozen turn required")
        resp=pipeline.index_turn(args.turn)
        verified=pipeline.verify(upto=args.turn)
        measure(pipeline,args.turn)
        print("S_TURN_INDEXED",args.turn,"records="+str(verified["sql_original_messages"]),
              "files="+str(verified["indexed_turns"]),flush=True)
        return
    ledger=json.loads(pipeline.ledger.read_text(encoding="utf-8"))
    if set(ledger["queries"])!={c["id"] for c in pipeline.plan["search_cases"]}:
        raise StageSFailure("Three frozen semantic queries not recorded")
    counts=pipeline.verify(upto=5)
    remote=pipeline.api.retrieve_store(store_id)
    if ((remote.get("file_counts") or {}).get("completed")!=5 or
        (remote.get("file_counts") or {}).get("total")!=5):
        raise StageSFailure("Unexpected remote hosted store file counts")
    print("S_NATIVE_READBACK_PASS",
          json.dumps({**counts,
                      "frozen_queries":len(ledger["queries"]),
                      "top5":sum(bool(r["top5_pass"]) for r in ledger["queries"].values())},
                     sort_keys=True))


if __name__=="__main__":
    try:main()
    except (StageSFailure,ValueError) as exc:
        print("S_NATIVE_HOLD:"+str(exc),file=sys.stderr)
        raise SystemExit(2)
