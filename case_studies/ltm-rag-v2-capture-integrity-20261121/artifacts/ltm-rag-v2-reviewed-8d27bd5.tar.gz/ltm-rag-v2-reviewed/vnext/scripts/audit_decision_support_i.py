"""Independent frozen I offline source and decision audit; no ChatGPT tests."""
from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
from collections import Counter
from pathlib import Path

from ltm_vnext.archive import Archive
from ltm_vnext.decision_support_i import SyntheticHistoryResolver

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
PINNED_COMMIT="bdc5dc7b6862531c5c0f29d56503e3fb5ee9876d"
PINNED_PARENT="d05bae31ded0ce17eb55c0b7b3cfdb2b5c1055e3"
PLAN_NAME="NATIVE_DECISION_SUPPORT_I_20261119.json"
PROTOCOL_NAME="NATIVE_DECISION_SUPPORT_I_PROTOCOL_20261119.md"
REPORT=ROOT/"NATIVE_DECISION_SUPPORT_I_OFFLINE_RESULTS_20261119.md"


def git(*args:str)->bytes:
    return subprocess.run(["git","-C",str(REPO),*args],check=True,
                          capture_output=True).stdout


def audit():
    parent=git("rev-list","--parents","-n","1",PINNED_COMMIT).decode().strip()
    if parent!=PINNED_COMMIT+" "+PINNED_PARENT:
        raise ValueError("Preregistered I Git commit parent mismatch")
    pinned={}
    for name in (PLAN_NAME,PROTOCOL_NAME):
        frozen=git("show",PINNED_COMMIT+":vnext/"+name)
        current=(ROOT/name).read_bytes()
        if frozen!=current:
            raise ValueError("Frozen Stage I file mutated: "+name)
        pinned[name]=hashlib.sha256(frozen).hexdigest()
    plan=json.loads((ROOT/PLAN_NAME).read_text(encoding="utf8"))
    fixture=ROOT/plan["fixture"]
    if hashlib.sha256(fixture.read_bytes()).hexdigest()!=plan["fixture_sha256"]:
        raise ValueError("Original frozen G fixture hash mismatch")
    data=json.loads(fixture.read_text(encoding="utf8"))
    orig={x["message_id"]:x for x in data["messages"]}
    assert len(orig)==20 and len(data["messages"])==20
    results=[]
    with tempfile.TemporaryDirectory() as td:
        db=Path(td)/"offline_i.sqlite"
        inserted=Archive.initialise(db).ingest_synthetic(fixture)
        if inserted["inserted"]!=20:
            raise ValueError("Fictional data seed mismatch")
        gate=SyntheticHistoryResolver(db,fixture,
                 ROOT/"REFERENT_GATE_H_MANIFEST_20261119.json")
        for case in plan["offline_cases"]:
            result=gate.resolve(case["question"])
            found=result["source_packets"]
            ids=[p["message_id"] for p in found]
            correct=(result["status"]==case["expected_status"] and
                     result["action"]==case["expected_action"] and
                     result["conversation_ids"]==case["expected_topics"] and
                     ids==case["expected_source_message_ids"])
            for packet in found:
                raw=orig[packet["message_id"]]
                expected_hash=hashlib.sha256(raw["exact_text"].encode("utf8")).hexdigest()
                if any((
                    packet["exact_text"]!=raw["exact_text"],
                    packet["content_sha256"]!=expected_hash,
                    packet["source_locator"]!=raw["source_locator"],
                    packet["branch_id"]!=raw["branch_id"],
                    packet["author_role"]!=raw["author_role"],
                    packet["reported_speaker"]!=raw.get("reported_speaker"),
                    packet["attribution"]!=raw["attribution"],
                    packet["conversation_id"]!=raw["conversation_id"],
                )):
                    raise ValueError("Original source text/provenance differed")
                for nb in packet["neighbouring_dialogue"]:
                    other=next(x for x in found if x["local_id"]==nb["local_id"])
                    if (other["branch_id"]!=packet["branch_id"] or
                        other["conversation_id"]!=packet["conversation_id"]):
                        raise ValueError("Cross-branch neighbour packet")
            if result["status"]=="UNANCHORED" and (found or result["source_count"]):
                raise ValueError("Ambiguous prompt leaked source packets")
            results.append({"id":case["id"],"kind":case["kind"],
                            "status":result["status"],"source_ids":ids,
                            "pass":correct})
    if plan["offline_case_count"]!=20 or plan["native_case_count"]!=16:
        raise ValueError("Frozen case counts not preserved")
    if [r["id"] for r in results]!=[f"I-O{i:02d}" for i in range(1,21)]:
        raise ValueError("Frozen sequential case identity mismatch")
    counts=Counter(x["status"] for x in results)
    passed=sum(x["pass"] for x in results)
    if passed!=len(results):
        raise ValueError("One or more frozen I offline case failed")
    return plan,pinned,counts,results


def main():
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=("status","write"))
    args=p.parse_args()
    plan,pinned,counts,rows=audit()
    print(json.dumps({
        "offline_cases":len(rows),
        "passed":sum(x["pass"] for x in rows),
        "native_cases_preregistered_not_run":plan["native_case_count"],
        "status_counts":dict(counts),
        "preimplementation_commit":PINNED_COMMIT,
        "pinned_frozen_sha256":pinned,
    },sort_keys=True))
    if args.action=="write":
        report=[
            "# Native Decision-Support I — independently audited OFFLINE result",
            "",
            "**Verdict: PASS_OFFLINE_I_ONLY.** All **20/20** preregistered",
            "synthetic decision/source cases passed. This is **not** a native",
            "ChatGPT trial, not a deployed connector and not a model-behaviour fix.",
            "",
            "## Frozen evidence and source identity",
            "",
            "- Both preregistered files were checked byte-for-byte against",
            f"  Git SHA {PINNED_COMMIT}; parent {PINNED_PARENT}.",
            "- Unmodified original G 20-message fictional fixture SHA-256:",
            f"  {plan['fixture_sha256']}.",
            "- Every source packet from all 20 cases independently matched",
            "  the fixture's exact Unicode source bytes, SHA-256, author, branch,",
            "  attributed speaker, locator and neighbouring-branch boundary.",
            "- UNANCHORED questions returned **zero source packets**, including",
            "  both previously failing G13/G14 queries.",
            "",
            "## Case classifications",
            "",
        ]
        for status,count in sorted(counts.items()):
            report.append(f"- {status}: {count}")
        report+=["","| Case | Type | Status | Full source message IDs |",
                 "|---|---|---|---|"]
        for row in rows:
            report.append("| "+row["id"]+" | "+row["kind"]+" | "+row["status"]+
                          " | "+(", ".join(row["source_ids"]) or "none")+" |")
        report+=["","## Transport and regression verification","",
                 "One-shot separate localhost MCP smoke must be recorded",
                 "independently: exactly one read-only resolve_history_reference",
                 "tool; ambiguous -> no packets; corrected source, two-narrative",
                 "comparison and reported-speech packet values exact. A separate",
                 "private audit contains successful tool events without prompt",
                 "or source text. This report does not inspect a native browser.",
                 "",
                 "New 17-unit tests included intentional corruption of SQLite",
                 "record count, original text/hash/locator, author, branch,",
                 "reported speaker and correction relationships. The complete",
                 "vNext regression is 118/118 core plus 40/40 shadow (command",
                 "results observed separately). The pre-existing Archive seed",
                 "helper's sqlite context-manager connections may emit ResourceWarning",
                 "on forced garbage collection; I's own read-only connections",
                 "are explicitly closed, without modifying the existing MCP.",
                 "",
                 "The existing six-source and G MCP interfaces were not changed.",
                 "A **separate** native I connector and clean Project must first",
                 "be operationally verified before any of the 16 registered",
                 "native questions can be sent or counted.",
                 ""]
        REPORT.write_text("\n".join(report),encoding="utf8")
        print("I_OFFLINE_EVIDENCE_REPORT_WRITTEN")


if __name__=="__main__":
    main()
