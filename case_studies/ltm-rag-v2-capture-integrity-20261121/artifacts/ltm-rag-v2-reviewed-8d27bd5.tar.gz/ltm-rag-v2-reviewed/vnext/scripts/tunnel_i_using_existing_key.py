"""Run the OpenAI tunnel client with the existing Ubuntu project key.

The key is read only at process launch and passed as CONTROL_PLANE_API_KEY.
No credential is copied to repository files or supplied on the command line.
The admin key is explicitly excluded from the tunnel process environment.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BINARY = ROOT / ".local" / "tooling" / "tunnel-client"
PROFILE_DIR = ROOT / ".local" / "profiles"
ENV_FILE = Path("/home/jds/.env")
PROFILE = "ltm-vnext-decision-i"
ALLOWED = {"doctor", "run"}


def project_key() -> str:
    if not ENV_FILE.is_file():
        raise ValueError("Expected Ubuntu project-key environment file is missing")
    matches = []
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("export "):
            line = line[7:].strip()
        name, sep, value = line.partition("=")
        if sep and name.strip() == "OPENAI_API_KEY":
            value = value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
                value = value[1:-1]
            matches.append(value)
    if len(matches) != 1 or not matches[0]:
        raise ValueError("Exactly one nonempty OPENAI_API_KEY entry required")
    return matches[0]


def main() -> None:
    if len(sys.argv) != 2 or sys.argv[1] not in ALLOWED:
        raise SystemExit("Usage: tunnel_using_existing_key.py doctor|run")
    if not BINARY.is_file() or not PROFILE_DIR.is_dir():
        raise SystemExit("Tunnel binary or profile is missing")
    try:
        key = project_key()
    except ValueError as exc:
        raise SystemExit(str(exc)) from None
    environment = os.environ.copy()
    environment.pop("OPENAI_ADMIN_KEY", None)
    environment.pop("OPENAI_API_KEY", None)
    environment["CONTROL_PLANE_API_KEY"] = key
    arguments = [
        str(BINARY),
        sys.argv[1],
        "--profile", PROFILE,
        "--profile-dir", str(PROFILE_DIR),
    ]
    if sys.argv[1] == "doctor":
        arguments.extend(["--json", "--explain"])
    os.execve(BINARY, arguments, environment)


if __name__ == "__main__":
    main()
