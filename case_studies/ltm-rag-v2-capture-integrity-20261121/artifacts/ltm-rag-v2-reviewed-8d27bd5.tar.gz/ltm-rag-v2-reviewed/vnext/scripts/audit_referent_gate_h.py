"""Read-only H audit against frozen Git preregistration, distinct from unit tests.

The manifest and cases are verified byte-for-byte against the preregistration
commit before evaluating the implemented shadow selector. A PASS is synthetic
offline protocol conformity, not native ChatGPT behaviour.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path

from ltm_vnext.referent_gate import ReferentGate

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
PREREG="2e1535e40d0a9770037d7c47a8e5ba780402d247"
PRE_PARENT="b68fd630b7c4f3c04322fe01a0f1385ede9967f9"
MANIFEST=ROOT/"REFERENT_GATE_H_MANIFEST_20261119.json"
CASES=ROOT/"REFERENT_GATE_H_CASES_20261119.json"
FIXTURE=ROOT/"fixtures/synthetic_clean_g.json"
REPORT=ROOT/"REFERENT_GATE_H_RESULTS_20261119.md"
LOCKED=("REFERENT_GATE_H_CASES_20261119.json",
        "REFERENT_GATE_H_MANIFEST_20261119.json",
        "REFERENT_GATE_H_PROTOCOL_20261119.md")


def git(*args: str) -> bytes:
    return subprocess.run(["git","-C",str(REPO),*args],check=True,
                          capture_output=True).stdout


def verify() -> tuple[dict,list[dict]]:
    parents=git("rev-list","--parents","-n","1",PREREG).decode().strip().split()
    if parents != [PREREG,PRE_PARENT]:
        raise ValueError("Preregistered commit SHA/parent mismatch")
    frozen={}
    for name in LOCKED:
        rel="vnext/"+name
        expected=git("show",f"{PREREG}:{rel}")
        current=(ROOT/name).read_bytes()
        if current != expected:
            raise ValueError("Locked preregistration file differs from pinned Git: "+name)
        frozen[name]=hashlib.sha256(expected).hexdigest()
    plan=json.loads(CASES.read_text(encoding="utf8"))
    manifest=json.loads(MANIFEST.read_text(encoding="utf8"))
    if (plan.get("schema_version") != 1 or plan.get("preregistered") is not True
            or plan.get("count") != 38 or len(plan.get("cases",[])) != 38
            or plan.get("trial_id") != manifest.get("evaluation")):
        raise ValueError("Frozen protocol/manifest case identity failure")
    if hashlib.sha256(FIXTURE.read_bytes()).hexdigest() != manifest["fixture_sha256"]:
        raise ValueError("Historical original fixture diverged from frozen SHA")
    gate=ReferentGate(MANIFEST,FIXTURE)
    rows=[]
    ids=set()
    counts=Counter()
    for case in plan["cases"]:
        cid=case["id"]
        if cid in ids:
            raise ValueError("Duplicate case ID")
        ids.add(cid)
        result=gate.decide(case["prompt"],case["candidate_conversations"])
        expect=case["expected"]
        correct=(result.status==expect["status"] and
                 list(result.conversation_ids)==expect["topics"])
        counts["cases"]+=1
        counts["pass"]+=int(correct)
        counts["fail"]+=int(not correct)
        counts["status_"+result.status]+=1
        counts["class_"+case["kind"]]+=1
        rows.append({"id":cid,"kind":case["kind"],
                     "expected_status":expect["status"],
                     "status":result.status,
                     "expected_topics":expect["topics"],
                     "topics":list(result.conversation_ids),
                     "result":"PASS" if correct else "FAIL",
                     "source_messages":[x.source_message_id for x in result.anchors]})
    if counts["cases"] != 38 or ids!={f"H{i:02d}" for i in range(1,39)}:
        raise ValueError("Case set not identical to preregistered 38 IDs")
    return {
        "preregistered_commit":PREREG,
        "preregistered_parent":PRE_PARENT,
        "frozen_sha256":frozen,
        "fixture_sha256":manifest["fixture_sha256"],
        "counts":dict(counts),
    }, rows

def write_report(state:dict, rows:list[dict]) -> None:
    counts=state["counts"]
    if counts.get("cases")!=38 or counts.get("fail")!=0:
        raise ValueError("Cannot publish all-pass report if any case failed")
    text=[
        "# Referent Gate H — frozen synthetic offline evaluation",
        "",
        f"**Result: {counts['pass']}/38 frozen cases PASS; 0 FAIL.**",
        "This is a conservative current-question narrative selector, **not a",
        "native ChatGPT behaviour improvement**. The original MCP/ChatGPT",
        "connectors were not changed or tested by this run.",
        "",
        "## Pre-registration integrity",
        "",
        "- Cases, source-manifest and protocol were frozen before code at Git",
        f"  commit {state['preregistered_commit']}, whose parent is",
        f"  {state['preregistered_parent']}.",
        "- All three preregistered files were compared byte-for-byte with",
        "  that exact local Git commit by a separate read-only Python auditor.",
        "- The original 20-message synthetic fixture SHA-256 was pinned to",
        f"  {state['fixture_sha256']}.",
        "- Each manifest anchor was validated in the original main-branch",
        "  user source message, not invented by retrieval or an assistant.",
        "",
        "## Decisions observed",
        "",
        f"- Explicit UNIQUE: {counts['status_UNIQUE']}.",
        f"- UNANCHORED: {counts['status_UNANCHORED']}, including both previously",
        "  failing G13/G14 prompts and candidate-rank traps.",
        f"- MULTIPLE: {counts['status_MULTIPLE']}; explicit comparison topics",
        "  remain represented as multiple, not silently collapsed.",
        f"- EVIDENCE_MISMATCH: {counts['status_EVIDENCE_MISMATCH']}; an explicit",
        "  topic was not replaced with a wrong retrieved candidate.",
        "",
        "| Case | Category | Registered | Observed | Result |",
        "|---|---|---|---|---|",
    ]
    for row in rows:
        text.append("| "+row["id"]+" | "+row["kind"]+" | "+
                    row["expected_status"]+" | "+row["status"]+" | "+
                    row["result"]+" |")
    text.extend([
        "",
        "## Governing distinction and limits",
        "",
        "A unique explicit topic identifies a **conversation to investigate**,",
        "not a verified answer, a source relevance judgement or an authentic",
        "spoken quotation. A user-reported recollection retains its original",
        "authorship even when its reported speaker is named.",
        "",
        "UNANCHORED means the question did not identify any of these five",
        "fictional conversations. For a separately established historical",
        "request, the consumer should clarify the referent; for a technical",
        "question not requiring memory, the consumer can answer normally.",
        "This selector deliberately **does not** classify history intent.",
        "",
        "Contextual follow-ups within an authenticated, single conversation",
        "are not yet supported. A ranking score or model-inferred synonym",
        "cannot override a missing current-question referent. The five-topic",
        "manifest is small, fixed and pre-known; performance does **not**",
        "generalise to unknown stories, translations or ordinary conversation.",
        "",
        "The original live six-record FTS5 tool and separate Trial G 20-record",
        "tool already deliver full source text and provenance on lookup.",
        "No additional fetch_source call is intrinsically necessary for",
        "that tool contract, but lack of fetch cannot be relabelled as",
        "two-tool compliance. Future native evaluation must separately",
        "test actual model use of this kind of decision support.",
        "",
        "No native test messages, new tunnel/client, public port, real data",
        "import, external inference API use, original evidence rewrite or",
        "operating-system startup change occurred in this offline stage.",
        "",
    ])
    REPORT.write_text("\n".join(text),encoding="utf8")


def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("status","write"))
    args=parser.parse_args()
    state,rows=verify()
    print(json.dumps(state,sort_keys=True))
    if args.action=="write":
        write_report(state,rows)
        print("REFERENT_H_EVIDENCE_REPORT_WRITTEN")


if __name__=="__main__":
    main()
