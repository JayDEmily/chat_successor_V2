"""Read-only independent audit of preregistered Stage O native test evidence.

Strictly no browser actions, sends, clicks, network calls, or raw identifiers
in public evidence. Fails closed on unexpected additional MCP events.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent
REG = "0a82ea6e22528d3494f7095b7112b2ef78f2e515"
PARENT = "25c543267c8a1f69ff3324cbc7fd12b4a89e58b3"
OFFLINE = "9f67a287f598964c03ae157fadc82d0da8ff64e4"
M_N_PREFIX_SHA = "f8980d0616468f3bcdf3c62f49765e87108aa89a19e77eabd4dadece90860fd6"
FROZEN = ("MCP_APPS_O_PROTOCOL_20261120.md", "MCP_APPS_O_CASES_20261120.json")
AUDIT = ROOT / ".local/trial-m-mcp-audit.jsonl"
TEMP = Path("/mnt/c/Users/james/AppData/Local/Temp")
SEND = TEMP / "ltm_o_n01_send_once.json"
CLICK = TEMP / "ltm_o_n02_automated_click_once.json"
REPORT = ROOT / "MCP_APPS_O_NATIVE_RESULTS_20261120.md"
ALLOWED = {"event_id", "timestamp_utc", "tool", "status",
           "session_present", "subject_present", "synthetic_only",
           "source_count", "original_user_text_attested"}


def git(*args: str) -> bytes:
    return subprocess.run(["git", "-C", str(REPO), *args],
                          check=True, stdout=subprocess.PIPE).stdout


def verify() -> dict:
    parent = git("rev-list", "--parents", "-n", "1", REG).decode().strip()
    if parent != REG + " " + PARENT:
        raise AssertionError("Stage O registration parent drift")
    digests = {}
    for name in FROZEN:
        content = (ROOT / name).read_bytes()
        if content != git("show", REG + ":vnext/" + name):
            raise AssertionError("Frozen O preregistration bytes changed: " + name)
        digests[name] = hashlib.sha256(content).hexdigest()

    frozen = json.loads((ROOT / FROZEN[1]).read_text())
    assert frozen["parent_checkpoint"] == PARENT
    assert frozen["trial_id"] == "ltm-vnext-o-native-viewport-stabilised-confirmation-20261120"
    assert frozen["previous_audit_line_count"] == 3
    assert frozen["previous_audit_sha256"] == M_N_PREFIX_SHA
    assert frozen["ttl_seconds"] == 60
    assert frozen["maximum_native_message_sends"] == 1
    assert frozen["maximum_automated_widget_clicks"] == 1
    assert len(frozen["cases"]) == 2
    assert [c["id"] for c in frozen["cases"]] == ["O-N01", "O-N02"]

    for path, key in [("ltm_vnext/mcp_apps_m.py", "m_source_sha256"),
                      ("ltm_vnext/mcp_apps_m_widget.html", "widget_sha256")]:
        body = (ROOT / path).read_bytes()
        if hashlib.sha256(body).hexdigest() != frozen[key]:
            raise AssertionError("Frozen M source SHA changed")
        if body != git("show", OFFLINE + ":vnext/" + path):
            raise AssertionError("Frozen M source differs from offline implementation")

    raw = AUDIT.read_bytes()
    lines = raw.splitlines(keepends=True)
    if len(lines) != 4:
        raise AssertionError(f"Unexpected native audit event count: {len(lines)}")
    if hashlib.sha256(b"".join(lines[:3])).hexdigest() != M_N_PREFIX_SHA:
        raise AssertionError("Prior M+N audit prefix changed")
    events = [json.loads(line) for line in lines]
    for event in events:
        if set(event) != ALLOWED:
            raise AssertionError("Native event schema not privacy-preserving")
        if not (event["session_present"] is True and
                event["subject_present"] is True and
                event["synthetic_only"] is True and
                event["original_user_text_attested"] is False and
                event["source_count"] == 0):
            raise AssertionError("Unexpected metadata, source or provenance status")
    if [(e["tool"], e["status"]) for e in events] != [
        ("open_topic_selector_m", "AWAITING_CONFIRMATION"),
        ("confirm_topic_m", "EXPIRED"),
        ("open_topic_selector_m", "AWAITING_CONFIRMATION"),
        ("open_topic_selector_m", "AWAITING_CONFIRMATION")
    ]:
        raise AssertionError("Native event history or order mismatches preregistered evidence")
    if not SEND.exists():
        raise AssertionError("No O-N01 one-send marker")
    if CLICK.exists():
        raise AssertionError("Unexpected O-N02 one-click marker")
    marker = json.loads(SEND.read_text(encoding="utf-8-sig"))
    prompt = frozen["cases"][0]["prompt"]
    digest = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
    if not (marker["stage"] == "O" and
            marker["phase"] == "one_send_click_issued" and
            marker["plugin_id"] == frozen["native_plugin_id"] and
            marker["prompt_sha256"] == digest and
            marker["intended_send_count"] == 1 and
            marker["full_message_includes_ui_plugin_mention"] is True):
        raise AssertionError("Frozen native one-send marker not verified")
    from datetime import datetime
    opening_time = datetime.fromisoformat(events[3]["timestamp_utc"])
    if opening_time.tzinfo is None:
        raise AssertionError("Opening timestamp missing timezone")
    return {
        "registration": REG, "parent": PARENT,
        "frozen_sha256": digests,
        "previous_three_events_sha256": M_N_PREFIX_SHA,
        "native_events_total": 4,
        "stage_o_native_openings": 1,
        "stage_o_native_callbacks": 0,
        "one_send_marker_valid": True,
        "one_click_marker_present": False,
        "frozen_prompt_sha256": digest,
        "plugin_id": frozen["native_plugin_id"],
        "native_opening_timestamp_utc": events[3]["timestamp_utc"],
        "native_opening_status": events[3]["status"],
        "source_packets": 0, "original_text_attested": False,
        "positive_confirmation_proven": False,
        "decision": "O_NATIVE_POSITIVE_NOT_PROVEN_NO_CALLBACK",
    }


def publish_report(d: dict) -> None:
    report = f"""# Stage O — native viewport recovery trial result

**20 November 2026 | Verdict: `O_NATIVE_POSITIVE_NOT_PROVEN_NO_CALLBACK`.**

## Pinned scope and reproducible evidence

- Preregistered, synthetic-only Stage O Git commit `{REG}` with exact direct parent `{PARENT}`.
- Frozen protocol SHA-256: `{d['frozen_sha256'][FROZEN[0]]}`; frozen case matrix SHA-256: `{d['frozen_sha256'][FROZEN[1]]}`. Both are byte-identical to the preregistration Git commit, with exactly two linked O cases.
- Existing Stage M server and HTML widget remain byte-identical to their pinned offline implementation; no server source modifications for Stage O.
- The original three Stage M/N audit events are preserved **byte for byte**, with SHA-256 `{M_N_PREFIX_SHA}`.
- Native plugin `{d['plugin_id']}`; no new plugin, tunnel or credential.

## Actual observed execution

- One Windows one-send marker identifies the exact frozen O prompt (SHA-256 `{d['frozen_prompt_sha256']}`), its native plugin binding, and a single send click issued.
- The fourth native MCP audit event, at **{d['native_opening_timestamp_utc']} UTC**, is one `open_topic_selector_m` request returning `AWAITING_CONFIRMATION`, with session/subject presence flags true, original user text not attested and **zero source packets**.
- **No Stage O `confirm_topic_m` callback was observed.** No O-N02 automated click marker exists. Consequently the positive native confirmation path was **not** demonstrated, irrespective of whether the widget rendered in the now-unavailable browser test window.
- At final review, the formerly dedicated browser window was no longer available for an independent Stage O UI readback. The precise reason for the missing click is **not proven** by the current durable record. Do not retroactively claim a successful, blocked, timed-out or user-authorised confirmation.
- The original 60-second challenge has expired. Do not resend O-N01 or click this old widget, change the TTL or alter the preregistration.

## Disposition and trust boundary

**Accept:** one new native tool opening; preserved earlier audit; zero source packets; enforced one-send evidence.

**Not established:** a completed automated Stage O selection, under-TTL callback, host filtering as a security boundary, authentic human consent, original user-message provenance, or repair of Stage I's I05/I15 unsupported referents. Stage K's historical deviation is unchanged.

A future positive-confirmation attempt requires a **separately preregistered** bounded trial with its own audit and one-send/one-click receipts; it must not be represented as Stage O's completion. No real conversation-history import, external inference, new credentials, OS autostart or legacy connector changes occurred.
"""
    REPORT.write_text(report, encoding="utf-8")
    print("O_NATIVE_REPORT_WRITTEN")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["status", "write"])
    args = parser.parse_args()
    out = verify()
    print(json.dumps(out, sort_keys=True))
    if args.action == "write":
        publish_report(out)


if __name__ == "__main__":
    main()
