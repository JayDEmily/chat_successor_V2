# Native MCP Apps UI read-only diagnostic and deterministic state evaluator.
# Synthetic-only. Never sends a ChatGPT message, clicks, changes focus or logs raw
# conversation strings/session/subject values.
[CmdletBinding()]
param(
  [ValidateSet('SelfTest','Inspect','Library')][string]$Mode='SelfTest',
  [Int64]$WindowHandle=0,
  [string]$ExpectedChatUrl='',
  [string]$PrivateTracePath=''
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

function New-TraceRecord {
 param([string]$Stage,[string]$Reason,[int]$ElapsedMs,[hashtable]$Flags=@{})
 $record=[ordered]@{
  utc=[DateTimeOffset]::UtcNow.ToString('o')
  synthetic_only=$true
  stage=$Stage
  reason=$Reason
  elapsed_ms=$ElapsedMs
 }
 foreach($key in ($Flags.Keys | Sort-Object)){
  if($key -notmatch '^(window_present|url_matches|foreground_matches|five_choices|one_merrow|ready_status|merrow_offscreen|in_safe_rect|scroll_supported|stable_count|centre_x|centre_y)$'){
   throw 'Unexpected trace field'
  }
  $record[$key]=$Flags[$key]
 }
 return $record
}

function Append-PrivateTrace {
 param([string]$Path,[System.Collections.IDictionary]$Record)
 if([string]::IsNullOrWhiteSpace($Path)){return}
 $full=[IO.Path]::GetFullPath($Path)
 $directory=[IO.Path]::GetDirectoryName($full)
 if(-not [IO.Directory]::Exists($directory)){throw 'Missing existing private trace directory'}
 # Require an ignored .local or Windows Temp path; never publish native traces.
 if(-not ($full -match '[\\/]\.local[\\/]' -or
           $full -match '(?i)[\\/]AppData[\\/]Local[\\/]Temp[\\/]')){
    throw 'Trace must remain in ignored private .local or Windows Temp'
 }
 $line=($Record|ConvertTo-Json -Depth 5 -Compress)+"`n"
 $bytes=[Text.Encoding]::UTF8.GetBytes($line)
 $stream=[IO.FileStream]::new($full,[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::Read)
 try{
  $stream.Write($bytes,0,$bytes.Length)
  $stream.Flush($true)
 }finally{$stream.Dispose()}
}

function Evaluate-MerrowObservation {
 param(
  [hashtable]$Observation,
  [hashtable]$Prior=@{stable=0;x=0;y=0;sample_ms=-1;scroll_used=$false},
  [int]$ElapsedMs=0,
  [int]$DeadlineMs=38000
 )
 # This function is deliberately pure: no UI interaction, focus or network.
 $required=@('window_present','url_matches','foreground_matches','five_choices','one_merrow',
             'ready_status','merrow_offscreen','scroll_supported','centre_x','centre_y')
 foreach($key in $required){if(-not $Observation.ContainsKey($key)){throw ('Missing observation '+$key)}}
 $result=@{status='WAIT';reason='PENDING';stable=0;x=0;y=0;sample_ms=-1;
           scroll_used=[bool]$Prior.scroll_used;safe_to_click=$false}
 if($ElapsedMs -ge $DeadlineMs){$result.status='STOP';$result.reason='LOCAL_DEADLINE';return $result}
 foreach($gate in @(
    @('window_present','WINDOW_ABSENT'),
    @('url_matches','URL_MISMATCH'),
    @('foreground_matches','FOREGROUND_MISMATCH')
  )){
  if(-not [bool]$Observation[$gate[0]]){
   $result.status='STOP';$result.reason=[string]$gate[1];return $result
  }
 }
 if(-not [bool]$Observation.five_choices -or
    -not [bool]$Observation.one_merrow -or
    -not [bool]$Observation.ready_status){
   $result.reason='WIDGET_NOT_VERIFIED';return $result
 }
 $x=[int]$Observation.centre_x;$y=[int]$Observation.centre_y
 $safe= -not [bool]$Observation.merrow_offscreen -and
        $x -ge 510 -and $x -le 1290 -and $y -ge 150 -and $y -le 1050
 if(-not $safe){
  if(-not [bool]$Prior.scroll_used -and [bool]$Observation.scroll_supported){
   $result.reason='SCROLL_INTO_VIEW_ONCE_ALLOWED'
  }else{
   $result.reason='OFFSCREEN_AFTER_RECOVERY_OR_SCROLL_UNAVAILABLE'
  }
  return $result
 }
 $result.x=$x;$result.y=$y;$result.sample_ms=$ElapsedMs
 if([int]$Prior.stable -gt 0 -and [math]::Abs($x-[int]$Prior.x) -le 3 -and
    [math]::Abs($y-[int]$Prior.y) -le 3 -and
    $ElapsedMs-[int]$Prior.sample_ms -ge 250){
  $result.stable=[int]$Prior.stable+1
 }else{$result.stable=1}
 if($result.stable -ge 2){
  $result.status='READY';$result.reason='STABLE_SAFE_TARGET';$result.safe_to_click=$true
 }else{$result.reason='WAIT_FOR_STABLE_SECOND_SAMPLE'}
 return $result
}

function Test-TraceDiagnostics {
 $n=0
 function Assert([bool]$Yes,[string]$Why){
  if(-not $Yes){throw ('Diagnostic self-test failed: '+$Why)}
 }
 $base=@{window_present=$true;url_matches=$true;foreground_matches=$true;
  five_choices=$true;one_merrow=$true;ready_status=$true;
  merrow_offscreen=$false;scroll_supported=$true;centre_x=804;centre_y=594}
 $zero=@{stable=0;x=0;y=0;sample_ms=-1;scroll_used=$false}
 $r=Evaluate-MerrowObservation $base $zero 1000
 Assert ($r.reason -eq 'WAIT_FOR_STABLE_SECOND_SAMPLE' -and -not $r.safe_to_click) 'first sample';$n++
 $r2=Evaluate-MerrowObservation $base $r 1350
 Assert ($r2.status -eq 'READY' -and $r2.safe_to_click -and $r2.stable -eq 2) 'stable second';$n++
 $r3=Evaluate-MerrowObservation $base $r 1100
 Assert (-not $r3.safe_to_click -and $r3.stable -eq 1) 'minimum sample interval';$n++
 $bad=$base.Clone();$bad.centre_y=120
 $r4=Evaluate-MerrowObservation $bad $zero 1000
 Assert ($r4.reason -eq 'SCROLL_INTO_VIEW_ONCE_ALLOWED' -and -not $r4.safe_to_click) 'offscreen recovery';$n++
 $spent=$zero.Clone();$spent.scroll_used=$true
 $r5=Evaluate-MerrowObservation $bad $spent 1100
 Assert ($r5.reason -eq 'OFFSCREEN_AFTER_RECOVERY_OR_SCROLL_UNAVAILABLE') 'one scroll max';$n++
 $bad=$base.Clone();$bad.url_matches=$false
 Assert ((Evaluate-MerrowObservation $bad $zero 1000).status -eq 'STOP') 'wrong URL';$n++
 $bad=$base.Clone();$bad.foreground_matches=$false
 Assert ((Evaluate-MerrowObservation $bad $zero 1000).reason -eq 'FOREGROUND_MISMATCH') 'foreground';$n++
 $bad=$base.Clone();$bad.five_choices=$false
 Assert ((Evaluate-MerrowObservation $bad $zero 1000).reason -eq 'WIDGET_NOT_VERIFIED') 'five choice gate';$n++
 $bad=$base.Clone();$bad.ready_status=$false
 Assert ((Evaluate-MerrowObservation $bad $zero 1000).reason -eq 'WIDGET_NOT_VERIFIED') 'ready status gate';$n++
 Assert ((Evaluate-MerrowObservation $base $zero 38000).reason -eq 'LOCAL_DEADLINE') 'deadline';$n++
 $bad=$base.Clone();$bad.merrow_offscreen=$true
 Assert ((Evaluate-MerrowObservation $bad $zero 1000).reason -eq 'SCROLL_INTO_VIEW_ONCE_ALLOWED') 'UIA offscreen flag';$n++
 $bad=$base.Clone();$bad.centre_x=1200
 Assert ((Evaluate-MerrowObservation $bad $r 1350).stable -eq 1) 'moving target resets stability';$n++
 try{Evaluate-MerrowObservation @{} $zero 1000 | Out-Null;throw 'Missing-field test unexpectedly passed'}catch{
  Assert ($_.Exception.Message -match 'Missing observation') 'fail closed missing input';$n++
 }
 $trace=New-TraceRecord 'OFFLINE_SELFTEST' 'NO_NATIVE_ACTION' 0 @{window_present=$false}
 Assert ($trace.synthetic_only -eq $true -and $trace.reason -eq 'NO_NATIVE_ACTION') 'safe trace schema';$n++
 $private=[IO.Path]::Combine([IO.Path]::GetTempPath(),'ltm-ui-diagnostic-'+[Guid]::NewGuid().ToString('N')+'.jsonl')
 try{
  Append-PrivateTrace $private $trace
  $actual=Get-Content -Raw -Path $private | ConvertFrom-Json
  Assert ($actual.synthetic_only -eq $true -and $actual.reason -eq 'NO_NATIVE_ACTION' -and $actual.window_present -eq $false) 'private trace flushed';$n++
 }finally{if(Test-Path $private){Remove-Item -LiteralPath $private -Force}}
 try{Append-PrivateTrace ([IO.Path]::Combine([IO.Path]::GetTempPath(),'..','not-private.jsonl')) $trace;throw 'Non-private path accepted'}catch{
  Assert ($_.Exception.Message -match 'Trace must remain') 'private log path enforced';$n++
 }
 Write-Output ('UI_DIAGNOSTIC_SELFTEST_PASS cases='+$n+' native_send_count=0 click_count=0')
}

function Inspect-ReadOnly {
 if($WindowHandle -le 0){throw 'Explicit target Chrome handle required'}
 if([string]::IsNullOrWhiteSpace($ExpectedChatUrl) -or
    $ExpectedChatUrl -notmatch '^chatgpt\.com/c/'){
  throw 'Explicit saved ChatGPT conversation URL required'
 }
 Add-Type -AssemblyName UIAutomationClient
 Add-Type -AssemblyName UIAutomationTypes
 Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class NativeAppsUiForegroundReader {
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
}
'@
 $root=[System.Windows.Automation.AutomationElement]::RootElement
 $target=@($root.FindAll([System.Windows.Automation.TreeScope]::Children,
    [System.Windows.Automation.Condition]::TrueCondition)|Where-Object{
      $_.Current.NativeWindowHandle -eq $WindowHandle -and
      $_.Current.ClassName -eq 'Chrome_WidgetWin_1'})
 if($target.Count -ne 1){
   $r=New-TraceRecord 'READ_ONLY_INSPECT' 'WINDOW_ABSENT' 0 @{window_present=$false}
   Append-PrivateTrace $PrivateTracePath $r
   Write-Output 'NATIVE_UI_INSPECT WINDOW_ABSENT no_send=true no_click=true'
   return
 }
 try{
  $es=$target[0].FindAll([System.Windows.Automation.TreeScope]::Descendants,
       [System.Windows.Automation.Condition]::TrueCondition)
  $a=@($es|Where-Object{$_.Current.Name -eq 'Address and search bar' -and
           $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Edit'})
  $url=if($a.Count -eq 1){$a[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value}else{''}
  $buttons=@($es|Where-Object{$_.Current.Name -like 'Confirm fictional topic:*' -and
              $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Button'})
  $merrow=@($buttons|Where-Object{$_.Current.Name -eq 'Confirm fictional topic: Merrow calibration log'})
  $ready=@($es|Where-Object{$_.Current.Name -eq 'Select a single fictional topic.' -and
            $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Text'})
  $flags=@{
   window_present=$true;url_matches=($url -eq $ExpectedChatUrl)
   foreground_matches=([NativeAppsUiForegroundReader]::GetForegroundWindow().ToInt64() -eq $WindowHandle)
   five_choices=($buttons.Count -eq 5);one_merrow=($merrow.Count -eq 1)
   ready_status=($ready.Count -eq 1);merrow_offscreen=$true
   scroll_supported=$false;centre_x=0;centre_y=0
  }
  if($merrow.Count -eq 1){
   $p=$merrow[0].Current.BoundingRectangle
   $flags.centre_x=[int]($p.Left+$p.Width/2)
   $flags.centre_y=[int]($p.Top+$p.Height/2)
   $flags.merrow_offscreen=[bool]$merrow[0].Current.IsOffscreen
   $pattern=$null
   $flags.scroll_supported=$merrow[0].TryGetCurrentPattern(
       [System.Windows.Automation.ScrollItemPattern]::Pattern,[ref]$pattern)
  }
  $result=Evaluate-MerrowObservation $flags
  $r=New-TraceRecord 'READ_ONLY_INSPECT' $result.reason 0 $flags
  Append-PrivateTrace $PrivateTracePath $r
  Write-Output ('NATIVE_UI_INSPECT '+$result.reason+' url_verified='+$flags.url_matches+
     ' five_choices='+$flags.five_choices+' click_count=0 send_count=0')
 }catch{
  $r=New-TraceRecord 'READ_ONLY_INSPECT' 'UI_AUTOMATION_EXCEPTION' 0 @{window_present=$true}
  Append-PrivateTrace $PrivateTracePath $r
  throw
 }
}

if($Mode -eq 'SelfTest'){Test-TraceDiagnostics}
elseif($Mode -eq 'Inspect'){Inspect-ReadOnly}
# Library mode defines reusable read-only evaluator and tracer; no side effects.
