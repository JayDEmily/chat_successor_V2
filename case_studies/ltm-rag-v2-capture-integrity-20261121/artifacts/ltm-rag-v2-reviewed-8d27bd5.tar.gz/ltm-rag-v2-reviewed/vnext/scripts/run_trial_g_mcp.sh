#!/usr/bin/env bash
set -euo pipefail
umask 077
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON="$ROOT/.venv/bin/python"
FIXTURE="$ROOT/fixtures/synthetic_clean_g.json"
DATABASE="$ROOT/.local/trial-g-synthetic.sqlite"
AUDIT="$ROOT/.local/trial-g-mcp-audit.jsonl"
PORT=8788
if [[ ! -x "$PYTHON" || ! -f "$FIXTURE" ]]; then
  echo "Trial G MCP dependencies or synthetic fixture missing" >&2
  exit 2
fi
mkdir -p "$ROOT/.local"
chmod 700 "$ROOT/.local"
export PYTHONPATH="$ROOT"
"$PYTHON" -m ltm_vnext.cli --db "$DATABASE" init >/dev/null
"$PYTHON" -m ltm_vnext.cli --db "$DATABASE" seed "$FIXTURE" >/dev/null
"$PYTHON" - "$DATABASE" <<'PY'
import sqlite3
import sys
with sqlite3.connect(f"file:{sys.argv[1]}?mode=ro", uri=True) as db:
    total = db.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
    correct = db.execute(
        "SELECT COUNT(*) FROM messages WHERE source_id='synthetic-clean-g' "
        "AND capture_method='synthetic_fixture'"
    ).fetchone()[0]
if total != 20 or correct != 20:
    raise SystemExit("Trial G DB not strictly isolated; refusing to start")
print("TRIAL_G_MCP_PRECHECK_PASS total=20 source=synthetic-clean-g loopback=127.0.0.1:8788")
PY
exec "$PYTHON" -m ltm_vnext.mcp_server --db "$DATABASE" --port "$PORT" --audit-log "$AUDIT"
