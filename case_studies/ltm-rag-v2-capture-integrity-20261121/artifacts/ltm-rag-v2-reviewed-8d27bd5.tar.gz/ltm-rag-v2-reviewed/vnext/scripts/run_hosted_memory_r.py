"""Run/read back Stage R hosted fictional chat index; no Responses/model calls."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import subprocess
import sys
from pathlib import Path

from ltm_vnext.hosted_memory_r import (
    STORE_NAME, HostedRFailure, OpenAIHttpR, SyntheticConversationR, project_key,
)

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
REGISTERED="97b5c691c81862e782d32978bf33e56b15517ba5"
PARENT="b9589cc5c7af7432c12e6e0450f3fc860872e029"
FROZEN=("HOSTED_MEMORY_R_PROTOCOL_20261120.md",
        "HOSTED_MEMORY_R_CASES_20261120.json",
        "fixtures/synthetic_diary_r_20261120.json")
LOCAL=ROOT/".local/hosted-memory-r"
CONFIG=LOCAL/"store.json"
STATE=LOCAL/"results.json"
DB=LOCAL/"synthetic_conversation.sqlite"
REPORT=ROOT/"HOSTED_MEMORY_R_RESULTS_20261120.md"
PLAN=ROOT/FROZEN[1]
FIXTURE=ROOT/FROZEN[2]


def atomic_private(path: Path, data: dict):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+".tmp")
    desc=os.open(temp,os.O_CREAT|os.O_WRONLY|os.O_TRUNC,0o600)
    with os.fdopen(desc,"w",encoding="utf-8") as handle:
        json.dump(data,handle,indent=2,sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp,path)
    os.chmod(path,0o600)


def git(*args: str) -> bytes:
    return subprocess.run(["git","-C",str(REPO),*args],check=True,
                          capture_output=True).stdout


def preregistered():
    parent=git("rev-list","--parents","-n","1",REGISTERED).decode().strip()
    if parent!=REGISTERED+" "+PARENT:
        raise HostedRFailure("Registered Git commit/parent mismatch")
    for name in FROZEN:
        if (ROOT/name).read_bytes()!=git("show",REGISTERED+":vnext/"+name):
            raise HostedRFailure("Frozen registration bytes have changed: "+name)
    plan=json.loads(PLAN.read_text(encoding="utf-8"))
    if (plan["trial_id"]!="ltm-rag-vnext-R-hosted-synthetic-conversation-20261120"
            or plan["baseline_git_parent"]!=PARENT
            or plan["turns"]!=12 or plan["messages"]!=24
            or plan["max_file_uploads"]!=12
            or plan["actual_chatgpt_messages"]!=0
            or plan["model_responses_generated"]!=0
            or len(plan["query_cases"])!=6
            or plan["store_name"]!=STORE_NAME
            or plan["expiration_days"]!=30
            or hashlib.sha256(FIXTURE.read_bytes()).hexdigest()!=plan["fixture_sha256"]):
        raise HostedRFailure("Frozen pilot registration contract mismatch")
    return plan


def init_store(api: OpenAIHttpR, plan: dict):
    if CONFIG.exists():
        private=json.loads(CONFIG.read_text(encoding="utf-8"))
        store_id=private.get("store_id")
    else:
        stores=api.stores()
        found=[x for x in stores if x.get("name")==STORE_NAME]
        if len(found)>1:
            raise HostedRFailure("Multiple similarly named stores; cannot choose safely")
        store=found[0] if found else api.create_store()
        store_id=store.get("id")
        if type(store_id) is not str or not store_id.startswith("vs_"):
            raise HostedRFailure("Created vector store missing identity")
        atomic_private(CONFIG,{"store_id":store_id,
                               "name":STORE_NAME,"synthetic_only":True,
                               "fixture_sha256":plan["fixture_sha256"]})
    if (private_data:=json.loads(CONFIG.read_text(encoding="utf-8"))).get("fixture_sha256")!=plan["fixture_sha256"]:
        raise HostedRFailure("Existing local vector store uses another fixture")
    if private_data["name"]!=STORE_NAME or private_data["synthetic_only"] is not True:
        raise HostedRFailure("Vector-store identity/scope mismatch")
    remote=api.retrieve_store(store_id)
    if remote.get("id")!=store_id or remote.get("name")!=STORE_NAME:
        raise HostedRFailure("Remote vector-store identity mismatch")
    meta=remote.get("metadata") or {}
    if meta.get("synthetic_only")!="true" or meta.get("scope")!="ltm-rag-vnext-r":
        raise HostedRFailure("Remote store not isolated for synthetic Stage R")
    expiration=remote.get("expires_after") or {}
    if (expiration.get("anchor")!="last_active_at"
            or expiration.get("days")!=30):
        raise HostedRFailure("Remote store expiry differs from fixed 30-day trial")
    return store_id,remote


def load_results():
    if not STATE.exists():
        return {"trial_id":"R","queries":{}}
    state=json.loads(STATE.read_text(encoding="utf-8"))
    if state.get("trial_id")!="R" or not isinstance(state.get("queries"),dict):
        raise HostedRFailure("Private query result ledger corrupted")
    return state


def measure(plan,pipeline,results,at_turn):
    for case in plan["query_cases"]:
        if case["after_turn"]!=at_turn or case["id"] in results["queries"]:
            continue
        hits=pipeline.search_candidates(case["query"],top=10)
        ranked_turns=[h["turn_index"] for h in hits]
        ranks=[i+1 for i,turn in enumerate(ranked_turns)
               if turn in case["expected_turns"]]
        rank=min(ranks) if ranks else None
        results["queries"][case["id"]]={
            "after_turn":at_turn,
            "query":case["query"],
            "expected_turns":case["expected_turns"],
            "target_rank":rank,
            "top5_pass":rank is not None and rank<=case["max_rank"],
            "returned_candidates":len(hits),
            "ranked_turns":ranked_turns,
            "scores":[h["score"] for h in hits],
        }
        atomic_private(STATE,results)
        print("HOSTED_SEARCH",case["id"],"target_rank="+str(rank),
              "top5="+str(results["queries"][case["id"]]["top5_pass"]),
              "candidates="+str(len(hits)),flush=True)


def verify_readback(api,store_id,pipeline,results,*,complete=False):
    source=pipeline.validate_all_local()
    remote=api.retrieve_store(store_id)
    for turn in source["indexed_turns"]:
        mapping=pipeline._get_mapping(turn)
        item=api.attachment(store_id,mapping["file_id"])
        if (item is None or item.get("status")!="completed"
                or mapping["completed"]!=1):
            raise HostedRFailure("Readback found incomplete hosted file attachment")
        required_attrs=pipeline.payload(turn)[2]
        attrs=item.get("attributes") or {}
        for field,value in required_attrs.items():
            if attrs.get(field)!=value:
                raise HostedRFailure("Remote file metadata/source identity drift")
    if complete:
        if (source["indexed_turns"]!=list(range(1,13))
                or source["original_messages"]!=24
                or len(results["queries"])!=6):
            raise HostedRFailure("Final pilot count or staged searches incomplete")
        counters=remote.get("file_counts") or {}
        if counters.get("completed",0)!=12 or counters.get("total",0)!=12:
            raise HostedRFailure("Remote vector store file counts not exactly 12")
    return {"original_messages":source["original_messages"],
            "indexed_turns":len(source["indexed_turns"]),
            "hosted_completed":(remote.get("file_counts") or {}).get("completed"),
            "remote_store_readback":True}


def report(plan,counts,results):
    lines=[
      "# Stage R — OpenAI-hosted fictional conversation-memory integration",
      "",
      "**Pilot uses synthetic scripted exchanges only. No real ChatGPT dialogue was captured or generated.**",
      "",
      f"- Preregistration: `{REGISTERED}`, direct parent `{PARENT}`; all three frozen Git blobs and fixture SHA-256 independently verified before implementation.",
      "- One isolated OpenAI Vector Store in the newly created API project; 30-day last-active expiry. Store/file identifiers and user-provided API key are not published; project key is read only from owner-only Ubuntu `.env`.",
      "- Each of 12 fictional consecutive exchanges was uploaded as one immutable text file after appending its user and scripted assistant messages separately to SQLite: **24 original source messages, 12 indexed files**.",
      "- All exact source texts, content hashes, stable message/version IDs, distinct author roles, correction links, source locators and branch identities are resolved from local SQLite, never from the hosted search snippet.",
      "- Hosted result file IDs must match the private SQLite mapping; unknown IDs, tampering or unexpected source roles fail closed. Search results are *candidates*, not endorsed answers, actual user-message attestation or relevance probabilities.",
      "",
      "## Frozen semantic-search measurements",
      "",
      "| Case | Indexed turns at query | Expected source turn(s) | First matching rank | Top-five |",
      "|---|---:|---|---:|---|",
    ]
    success=0
    for case in plan["query_cases"]:
        row=results["queries"][case["id"]]
        success+=int(row["top5_pass"])
        lines.append("| "+case["id"]+" | "+str(row["after_turn"])+" | "+
            ", ".join(map(str,row["expected_turns"]))+" | "+
            (str(row["target_rank"]) if row["target_rank"] is not None else "MISS")+" | "+
            ("PASS" if row["top5_pass"] else "MISS")+" |")
    lines.extend([
      "",
      f"**Frozen search-quality top-five result: {success}/6.** Unsuccessful matches, if any, are not redefined or re-queried to improve the score.",
      f"**Remote/store readback:** {counts['indexed_turns']} completed indexed turns, {counts['original_messages']} intact SQLite records, {counts['hosted_completed']} hosted completed files; read-only verification PASS.",
      "",
      "## Scope and technical limitations",
      "",
      "- OpenAI Vector Stores handled automated chunking, embedding and indexing; the internal embedding dimensions/model are **not asserted** to be `text-embedding-3-large`. No explicit Embeddings API request was made.",
      "- A fixed scripted fixture is not ChatGPT's real generative output. No ChatGPT native UI send, conversation export, on-turn capture hook, production archive or GPT model inference was used.",
      "- This validates file-ID mapping and candidate retrieval, not longitudinal memory relevance on real people, referent disambiguation, complete capture from native ChatGPT or authenticated owner consent.",
      "- Existing original/G/I/K/M/P services, tunnels, keys and native six-event audit were left unchanged. Hosted files remain isolated synthetic records subject to the 30-day last-active expiration.",
      "",
    ])
    REPORT.write_text("\n".join(lines),encoding="utf-8")
    return success


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("preflight","run","verify"))
    args=parser.parse_args()
    plan=preregistered()
    api=OpenAIHttpR(project_key())
    if args.action=="preflight":
        found=[s for s in api.stores() if s.get("name")==STORE_NAME]
        print("REGISTERED_GIT_READBACK=PASS")
        print("PROJECT_KEY_STORE_LIST_READ_ONLY=PASS")
        print("MATCHING_EXISTING_STORES="+str(len(found)))
        return
    store_id,remote=init_store(api,plan)
    LOCAL.mkdir(parents=True,exist_ok=True)
    os.chmod(LOCAL,0o700)
    pipe=SyntheticConversationR(DB,FIXTURE,api,store_id)
    os.chmod(DB,0o600)
    ledger=load_results()
    if args.action=="run":
        for turn in range(1,13):
            response=pipe.index_turn(turn)
            print("INDEX_TURN",turn,"complete="+str(response["indexed"]),flush=True)
            if turn in (8,12):
                state=pipe.validate_all_local()
                if state["indexed_turns"]!=list(range(1,turn+1)):
                    raise HostedRFailure("Indexed turn prefix incomplete")
                measure(plan,pipe,ledger,turn)
    counts=verify_readback(api,store_id,pipe,ledger,complete=True)
    if args.action=="run":
        quality=report(plan,counts,ledger)
        print("HOSTED_R_FINAL",json.dumps({**counts,"frozen_search_top5_hits":quality,
             "frozen_search_cases":6,"scripted_not_model_generated":True,
             "no_native_chatgpt_messages":True},sort_keys=True))
    else:
        print("HOSTED_R_READONLY_VERIFY",json.dumps(counts,sort_keys=True))


if __name__=="__main__":
    try:
        main()
    except HostedRFailure as err:
        print("HOSTED_R_FAIL_CLOSED:",str(err),file=sys.stderr)
        raise SystemExit(2)
