# Stage T read-only reconciliation of actual native ChatGPT-rendered text.
# No sends, clicks, model tool invocation or change to frozen Stage S captures.
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$root='\\wsl.localhost\Ubuntu\home\jds\ltm-rag-vnext-20261118\vnext'
$sp=Join-Path $root '.local\native-s-dialogue'
$tp=Join-Path $root '.local\native-t-dialogue'
if(-not (Test-Path $tp)){[IO.Directory]::CreateDirectory($tp)|Out-Null}
$manifest=Get-Content -Raw -Encoding UTF8 (Join-Path $root 'NATIVE_DIALOGUE_S_CASES_20261120.json')|ConvertFrom-Json
$prior=@()
for($n=1;$n -le 5;$n++){
 $path=Join-Path $sp ('captured_'+$n.ToString('00')+'.json')
 if(-not (Test-Path $path)){throw 'Missing previous captured source'}
 $prior+=([IO.File]::ReadAllText($path,[Text.Encoding]::UTF8)|ConvertFrom-Json)
}
$winfo=Get-Content -Raw 'C:\Users\james\AppData\Local\Temp\ltm_s_dedicated_window_once.json'|ConvertFrom-Json
$rootEl=[Windows.Automation.AutomationElement]::RootElement
$wins=@($rootEl.FindAll([Windows.Automation.TreeScope]::Children,[Windows.Automation.Condition]::TrueCondition)|
 Where-Object {$_.Current.ClassName -eq 'Chrome_WidgetWin_1' -and
  $_.Current.NativeWindowHandle -eq [int64]$winfo.native_window_handle})
if($wins.Count -ne 1){throw 'Frozen native S window missing'}
$all=$wins[0].FindAll([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.Condition]::TrueCondition)
$address=@($all|Where-Object{$_.Current.Name -eq 'Address and search bar' -and
  $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Edit'})
if($address.Count -ne 1){throw 'Native URL not readable'}
$url=$address[0].GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern).Current.Value
if($url -ne $prior[0].chat_url){throw 'Native chat URL changed'}
$groups=@($all|Where-Object{$_.Current.Name -eq 'Conversation' -and
  $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Group'})
if($groups.Count -ne 1){throw 'Native conversation group not unique'}
$texts=$groups[0].FindAll([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.Condition]::TrueCondition)
$msgs=New-Object System.Collections.Generic.List[object]
$role=''
$parts=New-Object System.Collections.Generic.List[string]
$footer=@('ChatGPT can make mistakes. Check important info.','Latest response','Ask ChatGPT')
foreach($el in $texts){
 if($el.Current.ControlType.ProgrammaticName -ne 'ControlType.Text'){continue}
 $v=[string]$el.Current.Name
 if($v -eq 'You said:' -or $v -eq 'ChatGPT said:'){
  if($role -ne ''){$msgs.Add([ordered]@{role=$role;text=($parts -join [Environment]::NewLine).Trim()})}
  $role=if($v -eq 'You said:'){'user'}else{'assistant'}
  $parts.Clear()
  continue
 }
 if($v -in $footer){continue}
 if($role -ne '' -and -not [string]::IsNullOrWhiteSpace($v)){$parts.Add($v)}
}
if($role -ne ''){$msgs.Add([ordered]@{role=$role;text=($parts -join [Environment]::NewLine).Trim()})}
if($msgs.Count -ne 10){throw ('Expected ten actual UI message units, got '+$msgs.Count)}
$footerSuffix='\nChatGPT can make mistakes. Check important info.\nLatest response\nAsk ChatGPT'
$out=New-Object System.Collections.Generic.List[object]
for($n=1;$n -le 5;$n++){
 $u=$msgs[$n*2-2];$a=$msgs[$n*2-1];$priorRow=$prior[$n-1]
 $spec=$manifest.case_messages[$n-1]
 if($u.role -ne 'user' -or $a.role -ne 'assistant'){throw ('UI role order changed at '+$n)}
 if($u.text -ne $spec.simulated_user_text -or
    $priorRow.simulated_user_text -ne $spec.simulated_user_text){
   throw ('Original simulated user text drift at '+$n)
 }
 $raw=[string]$priorRow.assistant_observed_text
 if(-not $raw.EndsWith($footerSuffix)){throw ('Unexpected raw capture suffix at '+$n)}
 $clean=$raw.Substring(0,$raw.Length-$footerSuffix.Length)
 if($a.text -ne $clean){throw ('Live native UI does not equal raw response prefix at '+$n)}
 $rawPath=Join-Path $sp ('captured_'+$n.ToString('00')+'.json')
 $sha=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([IO.File]::ReadAllBytes($rawPath))).Replace('-','').ToLowerInvariant()
 $out.Add([ordered]@{turn=$n;case_id=$spec.id;synthetic_only=$true;
  simulated_user_text=[string]$u.text;
  assistant_verified_rendered_text=[string]$a.text;
  assistant_generated_by='native_chatgpt';
  exact_UIA_rendered_text_verified=$true;
  ui_send_at_utc=[string]$priorRow.ui_send_at_utc;
  first_observed_complete_at_utc=[string]$priorRow.assistant_observed_complete_at_utc;
  original_raw_capture_sha256=$sha;
  native_ui_readback_at_utc=[DateTimeOffset]::UtcNow.ToString('o');
  chat_url=[string]$url;
  real_user_authorship_attested=$false})
 Write-Output ('T_UI_VERIFIED turn='+$n+' assistant_chars='+$a.text.Length+' discarded_footer_chars='+$footerSuffix.Length)
}
$record=[ordered]@{trial_id='T';synthetic_only=$true;schema_version=1;
  methodology='native_ChatGPT_UIA_read_only_same_conversation_exact_rendered_text';
  original_capture_preserved=$true;turns=$out.ToArray()}
$path=Join-Path $tp 'verified_transcript.json'
if(Test-Path $path){throw 'Native T verified transcript already written; no overwrite'}
[IO.File]::WriteAllText($path,($record|ConvertTo-Json -Depth 9),[Text.UTF8Encoding]::new($false))
Write-Output 'T_UI_VERIFIED_TRANSCRIPT_FILE_CREATED turns=5 original_user_messages=5 real_model_replies=5 no_native_sends=true'
