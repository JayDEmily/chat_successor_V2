"""Cross-check complete native F trace with separately authored semantic review.

This validates IDs, source membership and observed answer markers, not the
semantic truth of manually assessed verdicts.
"""
from __future__ import annotations
import argparse
import json
from collections import Counter
from pathlib import Path
from scripts.summarise_native_trial_f import analyse, load_lines, PLAN, LEDGER, AUDIT

ROOT=Path(__file__).resolve().parents[1]
REVIEW=ROOT/"NATIVE_TRIAL_F_SEMANTIC_REVIEW_20261118.json"
FIXTURE=ROOT/"fixtures/synthetic_conversations.json"
REPORT=ROOT/"NATIVE_TRIAL_F_SEMANTIC_RESULTS.md"
VERDICTS={
    "CONSISTENT_WITH_FIXTURE":"source-consistent main conclusion",
    "CONSISTENT_MAIN_CLAIM_QUOTE_FORMAT_DRIFT":"source-consistent claim, quotation-mark drift",
    "CONSISTENT_WITH_FIXTURE_NO_LOOKUP":"source-consistent conclusion without MCP lookup",
    "FAIL_UNJUSTIFIED_UNIQUE_REFERENT":"unjustified unique referent",
    "ADEQUATE_TECHNICAL_EXPLANATION":"adequate unrelated explanation",
}

def verify(plan, records, events, review, fixture):
    trace=analyse(plan, records, events)
    if not trace["complete"] or trace["pending_send_marker_exists"]:
        raise ValueError("Incomplete native trial F")
    messages=fixture["messages"]
    if not fixture.get("synthetic") or len(messages)!=6:
        raise ValueError("Original fixture mismatch")
    by_id={m["message_id"]:m for m in messages}
    if len(by_id)!=6:
        raise ValueError("Duplicate fixture ID")
    grades=review.get("reviewed_cases")
    if review.get("review_id")!="native-f-source-grounding-20261118" or len(grades)!=16:
        raise ValueError("Incomplete independent review")
    if len({x["id"] for x in grades})!=16:
        raise ValueError("Duplicate grade ID")
    out=[]
    for task, record, grade in zip(plan["cases"], records, grades):
        if not(task["id"]==record["id"]==grade["id"]):
            raise ValueError("Plan, result or grade ordering differs")
        verdict=grade["verdict"]
        if verdict not in VERDICTS:
            raise ValueError("Unknown semantic grade")
        answer=record.get("answer_excerpt","")
        if len(answer)<25 or len(answer)>=2500:
            raise ValueError("Absent or possibly clipped answer excerpt: "+task["id"])
        absent=[marker for marker in grade["required_answer_markers"]
                if marker.casefold() not in answer.casefold()]
        if absent:
            raise ValueError(f"Review markers not visible for {task['id']}: {absent}")
        if any(mid not in by_id for mid in grade["source_ids"]):
            raise ValueError("Unknown original source ID in review")
        if task["kind"]=="ambiguous" and verdict!="FAIL_UNJUSTIFIED_UNIQUE_REFERENT":
            raise ValueError("Unexpected ambiguity verdict")
        if task["kind"]=="unrelated" and verdict!="ADEQUATE_TECHNICAL_EXPLANATION":
            raise ValueError("Unexpected unrelated verdict")
        if task["kind"] in ("missing","contradiction") and verdict in (
                "FAIL_UNJUSTIFIED_UNIQUE_REFERENT","ADEQUATE_TECHNICAL_EXPLANATION"):
            raise ValueError("Incorrect historical verdict class")
        out.append({"id":task["id"],"kind":task["kind"],
                    "verdict":verdict,"lookup":record["lookup_count"],
                    "fetch":record["fetch_count"],"sources":grade["source_ids"]})
    return out,trace

def write_report(rows,trace):
    lines=[
        "# Native ChatGPT Trial F — independent source/content review",
        "",
        "All 16 registered synthetic-only cases were sent exactly once, and every",
        "saved answer and successful local MCP event was reconciled independently.",
        "This retrospective manual-style review was checked against source IDs",
        "in the original six-message fictional fixture and observed answer markers.",
        "Marker matching alone is NOT automatic proof of semantic correctness.",
        "",
        "| Case class | N | Semantic review | Audited new lookups |",
        "|---|---:|---|---:|",
        "| Missing historical details | 4 | 4/4 main conclusions consistent; M04 quote typography drift | 3/4 |",
        "| Contradictory source claims | 4 | 4/4 main conclusions consistent | 2/4 |",
        "| Ambiguous references | 4 | 4/4 unjustified unique referent | 1/4 (optional) |",
        "| Unrelated explanations | 4 | 4/4 technically adequate | 0/4 expected |",
        "",
        "| Case | Assessed answer quality | Lookup | Fetch | Supporting fictional messages |",
        "|---|---|---:|---:|---|",
    ]
    for r in rows:
        lines.append("| "+r["id"]+" | "+VERDICTS[r["verdict"]]+" | "+
                     str(r["lookup"])+" | "+str(r["fetch"])+" | "+
                     (", ".join(r["sources"]) or "not applicable")+" |")
    lines.extend([
        "",
        "## Findings and constraints",
        "",
        "Only 5 of 8 history-dependent cases made an audited external MCP lookup.",
        "Source-consistent wording with no MCP event cannot be attributed to",
        "a live archive retrieval. There were 6 successful lookups and 4 source",
        "fetches across all 16 cases.",
        "",
        "M04 correctly rejected the claim of authenticated audio but had no",
        "successful lookup; its correction quotation also changed punctuation",
        "relative to the exact archived wording.",
        "",
        "Every ambiguous prompt chose the notebook as its unique referent even",
        "though the text of the question did not identify it. One such response",
        "searched the archive; retrieval did not establish the chosen referent.",
        "",
        "Fresh conversations were all within one existing ChatGPT Project, so",
        "cross-chat Project memory could have contributed. We cannot identify",
        "whether it did in any specific case; these are not blank-context",
        "causal retrieval tests. See PROJECT_MEMORY_CONFOUND_20261118.md.",
        "",
        "Four unrelated technical questions produced no audited MCP lookups.",
        "This small functional sample does not establish population reliability.",
        "Original answer excerpts and event records stay in Git-ignored .local.",
        "No genuine user chat archive was imported and the live MCP was unaltered.",
        "",
    ])
    REPORT.write_text("\n".join(lines),encoding="utf8")

def main():
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=("status","write"))
    action=p.parse_args().action
    plan=json.loads(PLAN.read_text(encoding="utf8"))
    review=json.loads(REVIEW.read_text(encoding="utf8"))
    fixture=json.loads(FIXTURE.read_text(encoding="utf8"))
    rows,trace=verify(plan,load_lines(LEDGER),load_lines(AUDIT),review,fixture)
    print(json.dumps({"reviewed_cases":len(rows),"verdicts":dict(Counter(r["verdict"] for r in rows)),
                      "lookups":trace["counts"]["lookup_calls"],
                      "fetches":trace["counts"]["fetch_calls"]},sort_keys=True))
    if action=="write":
        write_report(rows,trace)
        print("SEMANTIC_REPORT_WRITTEN")

if __name__=="__main__":
    main()
