"""Synthetic-only shadow test: CPU ONNX embeddings versus frozen FTS5 Holdout C."""
from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
from collections import Counter
from pathlib import Path

import numpy as np
from ltm_vnext.archive import Archive
from scripts.run_holdout_c import FIXTURE, PROBES, validate, file_sha256

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / ".local" / "shadow-models"
REPORT = ROOT / "SHADOW_EMBEDDING_RESULTS.md"
MODEL = "BAAI/bge-small-en-v1.5"
METHODS = ("DENSE_RAW", "DENSE_CHAIN", "HYBRID_RRF")
TOP_N = 8
RRF_K = 60


def normalized(embeddings) -> np.ndarray:
    data = np.asarray(list(embeddings), dtype=np.float32)
    if data.ndim != 2:
        raise ValueError("Expected a matrix of embeddings")
    norms = np.linalg.norm(data, axis=1, keepdims=True)
    if np.any(norms == 0):
        raise ValueError("A zero embedding norm was produced")
    return data / norms


def order_by_score(ids: list[str], scores: np.ndarray) -> list[str]:
    if len(ids) != len(scores):
        raise ValueError("Vector/matrix size mismatch")
    return [ids[i] for i in sorted(range(len(ids)), key=lambda i: (-float(scores[i]), i))]


def correction_chain_texts(messages: list[dict]) -> list[str]:
    by_key = {(m["source_id"], m["message_id"], m["version_id"]): m for m in messages}
    if len(by_key) != len(messages):
        raise ValueError("Duplicate source/message/version key")
    result = []
    for current in messages:
        text = current["exact_text"]
        prior = current.get("supersedes")
        if prior:
            key = (current["source_id"], prior["message_id"], prior["version_id"])
            old = by_key.get(key)
            if old is None:
                raise ValueError("Broken supersedes reference")
            if old["conversation_id"] != current["conversation_id"] or old["branch_id"] != current["branch_id"]:
                raise ValueError("Cross-branch correction reference")
            text = ("Corrected statement: " + text +
                    "\nSuperseded prior statement (same branch): " + old["exact_text"])
        result.append(text)
    return result


def reciprocal_rank_fusion(dense: list[str], lexical: list[str], k: int = RRF_K) -> list[str]:
    if k <= 0 or len(set(dense)) != len(dense) or len(set(lexical)) != len(lexical):
        raise ValueError("Invalid ranks")
    dr = {mid: idx + 1 for idx, mid in enumerate(dense)}
    lr = {mid: idx + 1 for idx, mid in enumerate(lexical)}
    return sorted(set(dr) | set(lr), key=lambda mid: (
        -(1 / (k + dr[mid]) if mid in dr else 0)
        -(1 / (k + lr[mid]) if mid in lr else 0),
        dr.get(mid, len(dr) + 1), mid,
    ))


def evaluate(model, fixture: dict, config: dict) -> list[dict]:
    validate(fixture, config)
    messages = fixture["messages"]
    ids = [m["message_id"] for m in messages]
    text_raw = [m["exact_text"] for m in messages]
    text_chain = correction_chain_texts(messages)
    queries = [probe["query"] for probe in config["probes"]]
    raw = normalized(model.embed(text_raw, batch_size=16))
    chain = normalized(model.embed(text_chain, batch_size=16))
    qvec = normalized(model.embed(queries, batch_size=16))
    results = []
    with tempfile.TemporaryDirectory(prefix="ltm-shadow-holdout-c-") as directory:
        archive = Archive.initialise(Path(directory) / "shadow.sqlite")
        loaded = archive.ingest_synthetic(FIXTURE)
        if loaded != {"inserted": 26, "total": 26}:
            raise ValueError("Wrong synthetic record count")
        for n, probe in enumerate(config["probes"]):
            raw_order = order_by_score(ids, raw @ qvec[n])
            chain_order = order_by_score(ids, chain @ qvec[n])
            base_order = [hit["message_id"] for hit in archive.lookup(probe["query"], limit=20)["hits"]]
            rrf_order = reciprocal_rank_fusion(chain_order, base_order)
            result = {"probe": probe["id"], "kind": probe["kind"],
                      "target": probe["expected_message_id"]}
            for label, ranking in (
                ("FTS5", base_order), ("DENSE_RAW", raw_order),
                ("DENSE_CHAIN", chain_order), ("HYBRID_RRF", rrf_order),
            ):
                top = ranking[:TOP_N]
                rank = top.index(result["target"]) + 1 if result["target"] in top else None
                result[label] = {"rank": rank, "first": top[0] if top else None,
                                 "hit": rank is not None, "top1": rank == 1}
            results.append(result)
    return results


def model_manifest() -> list[dict]:
    files = []
    for item in sorted(CACHE.rglob("*")):
        if not item.is_file():
            continue
        # Hugging Face snapshots contain symlinks to content-addressed blobs.
        # Follow only links that stay within the ignored model-cache directory.
        if not item.resolve().is_relative_to(CACHE.resolve()):
            raise ValueError("Model cache link resolves outside isolated cache")
        if item.suffix.lower() in (".onnx", ".json", ".txt") and item.stat().st_size < 150_000_000:
            files.append({"name": str(item.relative_to(CACHE)), "bytes": item.stat().st_size,
                          "sha256": hashlib.sha256(item.read_bytes()).hexdigest()})
    return files


def describe(rows: list[dict], mode: str) -> dict:
    subset = [r for r in rows if r["kind"] == mode]
    return {method: {
        "recall8": sum(r[method]["hit"] for r in subset),
        "rank1": sum(r[method]["top1"] for r in subset),
        "misses": [r["probe"] for r in subset if not r[method]["hit"]],
    } for method in ("FTS5",) + METHODS}


def write_report(rows: list[dict]) -> None:
    e = describe(rows, "explicit")
    i = describe(rows, "implicit")
    lines = [
        "# Shadow embedding experiment: frozen synthetic Holdout C",
        "",
        "The method was registered in SHADOW_EMBEDDING_EXPERIMENT_20261118.md",
        "before running the local model. Holdout C was already inspected in a prior",
        "FTS5 baseline, therefore these results are EXPLORATORY, not independent validation.",
        "",
        "Model: BAAI/bge-small-en-v1.5 (FastEmbed 0.9.1 / ONNXRuntime 1.32.0, CPU 2 threads).",
        "No external model inference calls; model cache and dependencies are Git-ignored.",
        "Fixture SHA-256: " + file_sha256(FIXTURE),
        "Probe SHA-256: " + file_sha256(PROBES),
        "",
        "| Method | Explicit recall@8 | Explicit first | Implicit recall@8 | Implicit first |",
        "|---|---:|---:|---:|---:|",
    ]
    for method in ("FTS5",) + METHODS:
        lines.append("| " + method + " | " + str(e[method]["recall8"]) + "/8 | " +
                     str(e[method]["rank1"]) + "/8 | " +
                     str(i[method]["recall8"]) + "/8 | " + str(i[method]["rank1"]) + "/8 |")
    lines += ["", "| Probe | Target | FTS5 rank | Raw rank | Chain rank | Hybrid rank |",
              "|---|---|---:|---:|---:|---:|"]
    fmt = lambda r: str(r["rank"]) if r["rank"] is not None else "MISS"
    for row in rows:
        lines.append("| " + row["probe"] + " | " + row["target"] + " | " +
                     " | ".join(fmt(row[x]) for x in ("FTS5",) + METHODS) + " |")
    lines += ["", "## Local model file SHA-256 manifest", "", "| File | Bytes | SHA-256 |",
              "|---|---:|---|"]
    for f in model_manifest():
        lines.append("| " + f["name"] + " | " + str(f["bytes"]) + " | " + f["sha256"] + " |")
    lines += [
        "", "## Boundaries", "",
        "Each method ranks distinct original message identities; no branch or corrected",
        "source was rewritten. Dense chain text uses only the record's own same-branch",
        "superseded original and is for candidate scoring, not source evidence.",
        "The frozen registered corrected message ID alone constitutes a hit.",
        "These scores do not establish ChatGPT automatic invocation, source-text",
        "quotation accuracy, robust selectivity, privacy, or generalisation.",
        "The live six-message SQLite MCP archive and its tunnel were not changed.",
        "A new unseen holdout is necessary before choosing a method for live integration.",
        "",
    ]
    REPORT.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("status", "write"))
    action = parser.parse_args().action
    from fastembed import TextEmbedding
    model = TextEmbedding(model_name=MODEL, cache_dir=str(CACHE), threads=2,
                          providers=["CPUExecutionProvider"], cuda=False)
    fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
    probes = json.loads(PROBES.read_text(encoding="utf-8"))
    rows = evaluate(model, fixture, probes)
    print(json.dumps({mode: describe(rows, mode) for mode in ("explicit", "implicit")}, sort_keys=True))
    if action == "write":
        write_report(rows)
        print("SHADOW_EMBEDDING_REPORT_WRITTEN")


if __name__ == "__main__":
    main()
