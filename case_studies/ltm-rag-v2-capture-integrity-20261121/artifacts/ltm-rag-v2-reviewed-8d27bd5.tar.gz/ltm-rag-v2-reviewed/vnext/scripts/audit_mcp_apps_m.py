"""Independent Stage M preregistration + offline UI/selector audit.

Never touches native ChatGPT, network services, live connectors or source DB.
"""
from __future__ import annotations
import argparse
import asyncio
import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path
from ltm_vnext.mcp_apps_m import (
    SelectorM, create_server, TOOL_OPEN, TOOL_CONFIRM, RESOURCE, TOPICS, WIDGET
)

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
REGISTERED="2c24a4ebabb5a8be8ec4d3ecabc5cedc73a69193"
PARENT="3703f8b9dd633d0ddcc05d6bdae3e4d28a0ba81c"
FROZEN=("MCP_APPS_M_PROTOCOL_20261120.md","MCP_APPS_M_CASES_20261120.json")
PLAN=ROOT/FROZEN[1]
REPORT=ROOT/"MCP_APPS_M_OFFLINE_RESULTS_20261120.md"


def git(*args):
    return subprocess.run(["git","-C",str(REPO),*args],
                          check=True,capture_output=True).stdout


def audit():
    if git("rev-list","--parents","-n","1",REGISTERED).decode().strip() != REGISTERED+" "+PARENT:
        raise ValueError("Stage M registration parent mismatch")
    hashes={}
    for file in FROZEN:
        local=(ROOT/file).read_bytes()
        if local!=git("show",REGISTERED+":vnext/"+file):
            raise ValueError("Preregistered Stage M byte drift: "+file)
        hashes[file]=hashlib.sha256(local).hexdigest()
    data=json.loads(PLAN.read_text(encoding="utf8"))
    fixture=ROOT/"fixtures/synthetic_clean_g.json"
    if (data.get("cases_count")!=16 or len(data.get("cases",[]))!=16
        or not data.get("registered_before_implementation")
        or not data.get("synthetic_only")
        or hashlib.sha256(fixture.read_bytes()).hexdigest()!=data["fixture_sha256"]
        or data.get("ttl_seconds")!=60 or data.get("tool_names")!=[TOOL_OPEN,TOOL_CONFIRM]
        or data.get("resource_uri")!=RESOURCE or data.get("topic_ids")!=list(TOPICS)):
        raise ValueError("Stage M shape/fixture mismatch")

    tools=asyncio.run(create_server().list_tools())
    resources=asyncio.run(create_server().list_resources())
    got={tool.name:tool.meta["ui"] for tool in tools}
    if (len(tools)!=2 or set(got)!={TOOL_OPEN,TOOL_CONFIRM}
        or got[TOOL_OPEN]!={"resourceUri":RESOURCE,"visibility":["model","app"]}
        or got[TOOL_CONFIRM]!={"resourceUri":RESOURCE,"visibility":["app"]}
        or len(resources)!=1 or str(resources[0].uri)!=RESOURCE
        or resources[0].mime_type!=data["resource_mime"]):
        raise ValueError("SDK descriptor/resource not as frozen")
    html=WIDGET.read_text(encoding="utf8")
    for literal in ("ui/initialize","ui/notifications/initialized","tools/call",
                    "confirm_topic_m","event.source!==host","challenge", "topic.id"):
        if literal not in html:
            raise ValueError("Missing actual bridge/UX token: "+literal)
    for forbidden in ("fetch(","XMLHttpRequest","http://","https://",
                      "<iframe","localStorage","sessionStorage"):
        if forbidden in html:
            raise ValueError("Forbidden widget network or storage token: "+forbidden)
    meta={"openai/session":"synthetic-chat-1","openai/subject":"synthetic-owner-1"}
    token="simulated-private-token-0123456789ABCDEFGH"
    results=Counter()
    for i,case in enumerate(data["cases"],1):
        if case["id"]!=f"M{i:02d}":
            raise ValueError("Non-frozen order")
        if case["kind"]=="descriptor":
            observed="TWO_TOOLS_CORRECT_VISIBILITY"
        elif case["kind"]=="resource":
            observed="ONE_MCP_APPS_HTML_RESOURCE"
        else:
            now=[100.0]
            state=SelectorM(clock=lambda:now[0],token_factory=lambda:token)
            public,private=state.begin(meta)
            if (public["source_count"]!=0 or public["source_packets"]!=[]
                or public["original_user_text_attested"]
                or token in json.dumps(public) or private["stage_m"]["challenge"]!=token):
                raise ValueError("Initial tool leaks challenge/source")
            kind=case["kind"]
            if kind in ("open_only","model_only"):
                if kind=="model_only" and case["claimed"] not in TOPICS:
                    raise ValueError("Bad fixed model-only case")
                observed="AWAITING_CONFIRMATION_NO_SOURCES"
            elif kind=="overlap":
                later,hidden=state.begin(meta)
                if hidden or later["status"]!="ACTIVE_FLOW_ALREADY_EXISTS":
                    raise ValueError("Overlap accepted")
                observed="SECOND_ACTIVE_FLOW_REJECTED"
            elif kind=="cross_chat":
                observed=("WRONG_SESSION_DENIED" if state.confirm(
                    {"openai/session":"synthetic-chat-2","openai/subject":"synthetic-owner-1"},
                    token,case["selected"])["status"]=="DENIED" else "UNEXPECTED")
            else:
                now[0]+=case.get("advance_seconds",0)
                context=dict(meta)
                if case.get("context")=="wrong_session":
                    context["openai/session"]="synthetic-chat-2"
                elif case.get("context")=="wrong_subject":
                    context["openai/subject"]="synthetic-owner-2"
                choice=case["selected"]
                challenge=token if case["token"]=="valid" else (
                    None if case["token"]=="missing" else "fabricated-private-token-123456789123")
                out=state.confirm(context,challenge,choice)
                if out["source_count"]!=0 or out["source_packets"]!=[]:
                    raise ValueError("Source data leaked in Stage M")
                if kind=="replay":
                    second=state.confirm(context,challenge,choice)
                    observed="FIRST_ONLY" if (out["status"]=="CONFIRMED" and
                                              second["status"]=="DENIED") else "UNEXPECTED"
                else:
                    observed=out["status"]
        if observed!=case["expected"]:
            raise ValueError(f"{case['id']}: got {observed}, expected {case['expected']}")
        results[observed]+=1
    return {"registration":REGISTERED,"parent":PARENT,"hashes":hashes,
            "expected":16,"passed":16,"outcomes":dict(results),
            "html_bytes":len(WIDGET.read_bytes()),"tools":2,"resources":1,
            "native_messages":0,"human_consent_attested":False}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=("status","write"))
    a=p.parse_args()
    result=audit()
    print(json.dumps(result,sort_keys=True))
    if a.action=="write":
        lines=[
            "# Stage M — independent preregistered MCP Apps offline audit",
            "",
            "**16/16 frozen offline cases PASS; no native ChatGPT or human click.**",
            "",
            f"- Frozen registration commit: `{REGISTERED}`; exact parent `{PARENT}`.",
            f"- Protocol SHA-256 `{result['hashes'][FROZEN[0]]}`.",
            f"- Case matrix SHA-256 `{result['hashes'][FROZEN[1]]}`.",
            "- Preregistered blobs compared byte-for-byte against Git before scoring.",
            "- Original synthetic 20-message fixture SHA-256 checked; no source DB read in Stage M handler.",
            "- MCP Python SDK 2.3.0 reports exactly two tools and one HTML resource.",
            "- Model/app opening tool and app-only confirmation descriptor visibility checked.",
            "- Resource MIME `text/html;profile=mcp-app`; UI bridge wiring and no external network/storage use inspected.",
            f"- Frozen case outcomes: `{json.dumps(result['outcomes'],sort_keys=True)}`.",
            "- The server always returns zero source packets, even after simulated confirmation.",
            "- Private one-use challenge is never included in model-visible structured/text output.",
            "- Client-supplied session and subject values are used for ephemeral **correlation only**, not authentication.",
            "",
            "**Decision: PASS_M_OFFLINE_UI_TRANSPORT_ONLY.** This test does not prove host-side tool filtering,",
            "a visible native ChatGPT widget, real user click or consent, authenticated current-message",
            "content, or a Stage I remedy. Any native observation must be reported separately.",
            ""
        ]
        REPORT.write_text("\n".join(lines),encoding="utf8")
        print("M_OFFLINE_REPORT_WRITTEN")

if __name__=="__main__":
    main()
