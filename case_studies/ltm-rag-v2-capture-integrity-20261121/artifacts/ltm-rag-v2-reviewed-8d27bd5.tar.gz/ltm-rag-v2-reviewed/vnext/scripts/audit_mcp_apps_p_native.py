"""Independent Stage P native one-send/one-Invoke positive transport audit.

Read-only. No native sends/clicks, archives or external inference.
Raw user message identifiers, session/subject values and challenge never enter
the published report.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
import uuid
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
REG="340fe6e27277f9e3295ec0995eb4cb80b5119422"
PARENT="7ae7e4d504745a26116d451d8ddf05b89cbb31be"
PREVIOUS_SHA="a50e5fe66543b155d25841585007ace06c9bd0881d44ad50c44957f7a10c5aba"
FROZEN=("MCP_APPS_P_PROTOCOL_20261120.md","MCP_APPS_P_CASES_20261120.json")
AUDIT=ROOT/".local/trial-m-mcp-audit.jsonl"
TRACE=ROOT/".local/trial-p-native-controller-trace.jsonl"
UI=ROOT/".local/trial-p-native-ui-proof.json"
TEMP=Path("/mnt/c/Users/james/AppData/Local/Temp")
SEND=TEMP/"ltm_p_n01_send_once.json"
INVOKE=TEMP/"ltm_p_n02_invoke_once.json"
REPORT=ROOT/"MCP_APPS_P_NATIVE_RESULTS_20261120.md"
EXPECTED_EVENT_KEYS={"event_id","timestamp_utc","tool","status","session_present",
 "subject_present","synthetic_only","source_count","original_user_text_attested"}
TRACE_KEYS={"utc","synthetic_only","stage","reason","elapsed_ms",
 "window_present","url_matches","foreground_matches","five_choices",
 "one_merrow","ready_status","merrow_offscreen","in_safe_rect",
 "scroll_supported","stable_count","centre_x","centre_y"}


def git(*args):
    return subprocess.run(["git","-C",str(REPO),*args],check=True,
                          capture_output=True).stdout


def run_audit():
    if git("rev-list","--parents","-n","1",REG).decode().strip()!=REG+" "+PARENT:
        raise RuntimeError("Stage P registration parent mismatch")
    frozen_hashes={}
    for name in FROZEN:
        local=(ROOT/name).read_bytes()
        if local!=git("show",REG+":vnext/"+name):
            raise RuntimeError("Frozen Stage P preregistration drift "+name)
        frozen_hashes[name]=hashlib.sha256(local).hexdigest()
    plan=json.loads((ROOT/FROZEN[1]).read_text(encoding="utf-8"))
    if (plan["registered_before_implementation"] is not True or
        plan["synthetic_only"] is not True or
        plan["parent_checkpoint"]!=PARENT or
        plan["old_audit_lines"]!=4 or
        plan["old_audit_sha256"]!=PREVIOUS_SHA or
        plan["native_messages_max"]!=1 or plan["automated_invokes_max"]!=1 or
        plan["ttl_seconds"]!=60 or len(plan["cases"])!=2 or
        [c["id"] for c in plan["cases"]]!=["P-N01","P-N02"]):
        raise RuntimeError("Frozen Stage P shape mismatch")
    for filename,key in [("ltm_vnext/mcp_apps_m.py","m_source_sha256"),
                         ("ltm_vnext/mcp_apps_m_widget.html","widget_sha256"),
                         ("scripts/NativeAppsUiDiagnostics.ps1","diagnostics_sha256")]:
        if hashlib.sha256((ROOT/filename).read_bytes()).hexdigest()!=plan[key]:
            raise RuntimeError("Pinned implementation changed: "+filename)
    raw=AUDIT.read_bytes()
    lines=raw.splitlines(keepends=True)
    if len(lines)!=6 or hashlib.sha256(b"".join(lines[:4])).hexdigest()!=PREVIOUS_SHA:
        raise RuntimeError("Historical audit prefix or expected native event count differs")
    events=[json.loads(x) for x in lines]
    for event in events:
        if set(event)!=EXPECTED_EVENT_KEYS:
            raise RuntimeError("Unexpected audit event schema")
        uuid.UUID(event["event_id"])
        if (event["session_present"] is not True or
            event["subject_present"] is not True or
            event["synthetic_only"] is not True or
            event["source_count"]!=0 or
            event["original_user_text_attested"] is not False):
            raise RuntimeError("Unexpected native audit source/attestation flags")
    if [(x["tool"],x["status"]) for x in events]!=[
        ("open_topic_selector_m","AWAITING_CONFIRMATION"),
        ("confirm_topic_m","EXPIRED"),
        ("open_topic_selector_m","AWAITING_CONFIRMATION"),
        ("open_topic_selector_m","AWAITING_CONFIRMATION"),
        ("open_topic_selector_m","AWAITING_CONFIRMATION"),
        ("confirm_topic_m","CONFIRMED")
    ]:
        raise RuntimeError("Wrong cumulative native tool/status sequence")
    start=datetime.fromisoformat(events[4]["timestamp_utc"])
    end=datetime.fromisoformat(events[5]["timestamp_utc"])
    if start.tzinfo is None or end.tzinfo is None:
        raise RuntimeError("Naive audit timestamp")
    elapsed_ms=round((end-start).total_seconds()*1000)
    if not 0<elapsed_ms<plan["ttl_seconds"]*1000:
        raise RuntimeError("P callback was not strictly inside frozen TTL")
    if not SEND.exists() or not INVOKE.exists() or not UI.exists() or not TRACE.exists():
        raise RuntimeError("Required original private proof missing")
    send=json.loads(SEND.read_text(encoding="utf-8-sig"))
    invoke=json.loads(INVOKE.read_text(encoding="utf-8-sig"))
    proof=json.loads(UI.read_text(encoding="utf-8"))
    digest=hashlib.sha256(plan["cases"][0]["prompt"].encode("utf-8")).hexdigest()
    if (send["stage"]!="P" or send["phase"]!="one_send_invoked" or
        send["intended_send_count"]!=1 or send["prompt_sha256"]!=digest or
        send["plugin_id"]!=plan["native_plugin_id"] or
        send["ui_added_plugin_mention"] is not True):
        raise RuntimeError("One-send marker mismatch")
    if (invoke["stage"]!="P" or invoke["phase"]!="one_uia_invoke_issued" or
        invoke["one_invoke_intended"]!=1 or
        invoke["topic_id"]!="merrow_prism" or
        invoke["synthetic_automated_action"] is not True or
        invoke["human_consent_attested"] is not False or
        invoke["stable_count"]<2 or
        invoke["local_elapsed_ms"]>=plan["local_deadline_seconds"]*1000 or
        send["window_handle"]!=invoke["window_handle"]):
        raise RuntimeError("Single synthetic Invoke marker mismatch")
    if (proof["stage"]!="P" or proof["plugin_id"]!=plan["native_plugin_id"] or
        proof["private_saved_chat_url"]!=invoke["chat_url"] or
        proof["exact_prompt_visible"] is not True or
        proof["frozen_prompt_sha256"]!=digest or
        proof["separate_plugin_mention_visible"] is not True or
        proof["widget_button_count"]!=5 or proof["widget_buttons_disabled"]!=5 or
        proof["confirmed_status_visible"] is not True or
        proof["send_marker_verified"] is not True or
        proof["invoke_marker_verified"] is not True or
        proof["human_consent_attested"] is not False or
        proof["original_user_text_attested"] is not False or
        proof["source_packets"]!=0):
        raise RuntimeError("Independent saved ChatGPT UI proof mismatch")
    trace=[json.loads(x) for x in TRACE.read_text(encoding="utf-8").splitlines()]
    if len(trace)<9:
        raise RuntimeError("Missing flushed post-send telemetry")
    for row in trace:
        if not set(row).issubset(TRACE_KEYS) or row["synthetic_only"] is not True:
            raise RuntimeError("Private trace schema unexpected")
    route=[(x["stage"],x["reason"]) for x in trace]
    required=[
      ("PREFLIGHT","VERIFIED_DEDICATED_PLUGIN_COMPOSER"),
      ("SEND","PRESEND_MARKER_FLUSHED"),
      ("SEND","ONE_FROZEN_NATIVE_SEND_INVOKED"),
      ("POLL","STABLE_SAFE_TARGET"),
      ("INVOKE","PREINVOKE_MARKER_FLUSHED"),
      ("INVOKE","ONE_MERROW_UIA_INVOKE_ISSUED"),
      ("COMPLETE","SYNTHETIC_INVOKE_SUBMITTED"),
    ]
    positions=[route.index(x) for x in required]
    if positions!=sorted(positions):
        raise RuntimeError("Native trace stages out of order")
    if route.count(("INVOKE","ONE_MERROW_UIA_INVOKE_ISSUED"))!=1:
        raise RuntimeError("One-and-only-one automated invocation not verified")
    if route.count(("SCROLL","ONE_SCROLL_REQUESTED"))>1:
        raise RuntimeError("Excess scroll attempts")
    return {
      "registered_commit":REG,"registration_parent":PARENT,
      "frozen_hashes":frozen_hashes,"old_audit_prefix_sha256":PREVIOUS_SHA,
      "total_audit_events":len(events),"stage_p_native_events":2,
      "native_send_count":1,"automated_uia_invoke_count":1,
      "frozen_prompt_sha256":digest,"controller_trace_records":len(trace),
      "scroll_attempts":route.count(("SCROLL","ONE_SCROLL_REQUESTED")),
      "server_event_elapsed_milliseconds":elapsed_ms,
      "server_ttl_milliseconds":plan["ttl_seconds"]*1000,
      "saved_widget_confirmed":True,"source_packets_released":0,
      "human_consent_attested":False,"original_user_message_attested":False,
      "decision":"PASS_P_NATIVE_ACCEPTED_UI_TRANSPORT_ONLY",
    }


def write_report(result):
    lines=[
      "# Stage P — native MCP Apps positive UIAutomation confirmation",
      "",
      "**PASS_P_NATIVE_ACCEPTED_UI_TRANSPORT_ONLY** — one native ChatGPT message, one synthetic automated InvokePattern activation, confirmed app-only callback before the frozen TTL. This is **not human consent or authenticated user-message ingress**.",
      "",
      "## Pinned registration and source",
      "",
      f"- Preregistered at `{REG}`, exact direct parent `{PARENT}`; frozen protocol and two-case matrix were independently GitHub-read-back before implementation.",
      f"- Frozen protocol SHA-256: `{result['frozen_hashes'][FROZEN[0]]}`.",
      f"- Frozen case matrix SHA-256: `{result['frozen_hashes'][FROZEN[1]]}`.",
      "- Original Stage M Python handler, HTML widget and post-Stage O diagnostic helper all retained their preregistered SHA-256 values; no MCP server, host connector or fixture edits.",
      f"- Prior four M/N/O audit events preserved **byte-for-byte** with SHA-256 `{PREVIOUS_SHA}`. The private cumulative audit contains exactly six events.",
      "",
      "## Actual native outcome",
      "",
      f"- One native ChatGPT message from an isolated, newly created Chrome window, with the exact frozen request text SHA-256 `{result['frozen_prompt_sha256']}` and a separate UI-added plugin mention. The marker records one Send invocation; no duplicate send.",
      "- One new `open_topic_selector_m` event: `AWAITING_CONFIRMATION`, client session and subject present, no source packets or original text attestation.",
      "- The embedded MCP Apps widget displayed **five fictional topics**. The controller verified two stable positions of the exact Merrow button, performed **one** UIA `ScrollIntoView` recovery, and called its `InvokePattern.Invoke()` **once**, with a private pre-invoke marker.",
      f"- One new `confirm_topic_m` app-only callback: **`CONFIRMED`**, server event interval **{result['server_event_elapsed_milliseconds']/1000:.3f} seconds**, strictly less than frozen **60 seconds**.",
      "- Independent native browser UI readback verified the frozen request and separate plugin mention, five buttons disabled after selection, and visible status **'Fictional topic selected. No sources or user messages were retrieved.'**",
      f"- Private controller trace has **{result['controller_trace_records']} flushed records**, including the send, widget readiness, scroll recovery, stable positioning, pre-invoke and completed invocation; no raw conversation text, challenge or session/subject value appears in the published evidence.",
      "- Every cumulative native MCP audit record, including both new P events, reports `source_count=0`, `original_user_text_attested=false`, and synthetic-only provenance.",
      "",
      "## Interpretation and limits",
      "",
      "**Established:** The real ChatGPT web host rendered the fictional MCP Apps UI, and an automated UIA invocation delivered an app-only callback which the existing server accepted within its unchanged short TTL. The original source data boundary remained closed.",
      "",
      "**Not established:** Actual human consent or identity; a trusted record of the original user's typed words; that host app-only tool visibility is an enforceable security boundary against an untrusted client; any source-selection or retrieval relevance for real history; Stage I's I05/I15 semantic referents.",
      "",
      "Stage P's one-send/one-invoke budget is exhausted. No further P native prompts/clicks are permitted. Original/G/I/K services and past M/N/O judgments remain unchanged. Do not connect the offline shadow to genuine messages or claim a production implementation based solely on this synthetic result.",
      "",
    ]
    REPORT.write_text("\n".join(lines),encoding="utf-8")
    print("P_NATIVE_REPORT_WRITTEN")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=["status","write"])
    args=parser.parse_args()
    result=run_audit()
    print(json.dumps(result,sort_keys=True))
    if args.action=="write": write_report(result)


if __name__=="__main__":
    main()
