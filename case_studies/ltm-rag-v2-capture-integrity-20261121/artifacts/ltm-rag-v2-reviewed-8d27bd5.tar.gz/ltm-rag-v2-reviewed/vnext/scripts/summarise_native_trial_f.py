"""Independent read-only verification of native Trial F runner ledger.

Semantic conclusions are deliberately NOT automatically derived from keyword
presence or tool-call counts. Separate source-backed review is required.
"""
from __future__ import annotations
import argparse
import json
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PLAN=ROOT/"NATIVE_TRIAL_F_20261118.json"
LEDGER=ROOT/".local/native-trial-f-results.jsonl"
AUDIT=ROOT/".local/mcp-tool-audit.jsonl"
PENDING=ROOT/".local/native-trial-f-pending.json"
REPORT=ROOT/"NATIVE_TRIAL_F_TRACE_RESULTS.md"
PROJECT="g-p-6afd1c455970819197ab1bdad8acf53d"

def load_lines(path:Path) -> list[dict]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]

def analyse(plan:dict,results:list[dict],events:list[dict]) -> dict:
    cases=plan["cases"]
    if plan.get("trial_id")!="ltm-vnext-native-grounding-f-20261118" or len(cases)!=16:
        raise ValueError("Wrong frozen Trial F plan")
    if len(results)>16:
        raise ValueError("Too many observed responses")
    event_by_id={event["event_id"]:event for event in events}
    if len(event_by_id)!=len(events):
        raise ValueError("Duplicate event identity in MCP audit")
    consumed=set()
    urls=set()
    counts=Counter()
    for i,row in enumerate(results):
        test=cases[i]
        if row.get("id")!=test["id"] or row.get("kind")!=test["kind"] or row.get("ordinal")!=i+1:
            raise ValueError("Out-of-order Trial F record")
        url=row.get("chat_url","")
        if (not url.startswith("chatgpt.com/g/"+PROJECT+"/c/") and
            not url.startswith("chatgpt.com/g/"+PROJECT+"-ltm-rag-vnext-synthetic-trial/c/")):
            raise ValueError("Incorrect ChatGPT Project conversation URL")
        if url in urls:
            raise ValueError("Duplicate ChatGPT conversation URL")
        urls.add(url)
        start=datetime.fromisoformat(row["sent_at_utc"])
        end=datetime.fromisoformat(row["observed_at_utc"])
        if end<start:
            raise ValueError("Nonmonotone native test timing")
        actual=Counter()
        local_events=row["added_event_ids"]
        if len(local_events)!=len(set(local_events)):
            raise ValueError("Duplicated audit evidence within case")
        for eid in local_events:
            if eid not in event_by_id or eid in consumed:
                raise ValueError("Duplicate/unavailable MCP audit event")
            consumed.add(eid)
            ev=event_by_id[eid]
            actual[ev["tool"]]+=1
            event_time=datetime.fromisoformat(ev["timestamp_utc"].replace("Z","+00:00"))
            if not (start-timedelta(seconds=3) <= event_time <= end+timedelta(seconds=3)):
                raise ValueError("MCP event outside native case time window")
        if actual["lookup_evidence"]!=row["lookup_count"] or actual["fetch_source"]!=row["fetch_count"]:
            raise ValueError("MCP tool count/type conflict")
        if len(local_events)!=row["lookup_count"]+row["fetch_count"]:
            raise ValueError("Extra unknown tool event")
        expected=test["lookup_expected"]
        actual_pass=(bool(row.get("completed")) and
                     ((row["lookup_count"]>0) if expected else row["lookup_count"]==0)
                     if expected is not None else None)
        if actual_pass!=row.get("trace_pass"):
            raise ValueError("Runner trace score mismatch")
        if row.get("semantic_review")!="PENDING":
            raise ValueError("Semantic outcome not independently assessed")
        counts[test["kind"]]+=1
        counts[test["kind"]+"_lookup"]+=int(row["lookup_count"]>0)
        counts[test["kind"]+"_trace_pass"]+=int(actual_pass is True)
        counts[test["kind"]+"_completed"]+=int(row["completed"])
        counts["lookup_calls"]+=row["lookup_count"]
        counts["fetch_calls"]+=row["fetch_count"]
    return {"cases":len(results),"complete":len(results)==16,
            "pending_send_marker_exists":PENDING.is_file(),"counts":counts}

def write_report(plan:dict,rows:list[dict],summary:dict):
    if not summary["complete"] or summary["pending_send_marker_exists"]:
        raise ValueError("Cannot publish full Trial F trace until all 16 cases are resolved")
    counts=summary["counts"]
    lines=[
        "# Native ChatGPT Trial F — verified tool traces (semantic review separate)",
        "",
        "All 16 questions were registered and committed before execution at 98a7017.",
        "The tested connected plugin still uses the unchanged six-message fictional",
        "SQLite FTS5 catalogue. Each question was submitted once into its own verified",
        "fresh ChatGPT Project conversation, with no selected-tool chip.",
        "",
        "## Observed successful MCP lookup/fetch trace",
        "",
        "| Category | Cases | Completed | With a lookup | Required/avoided trace PASS |",
        "|---|---:|---:|---:|---:|",
    ]
    for group in ("missing","contradiction","ambiguous","unrelated"):
        n=counts[group]
        primary=(str(counts[group+"_trace_pass"])+"/"+str(n)
                 if group!="ambiguous" else "not specified")
        lines.append("| "+group+" | "+str(n)+" | "+str(counts[group+"_completed"])+
                     " | "+str(counts[group+"_lookup"])+" | "+primary+" |")
    lines += [
        "",
        "Successful, locally audited MCP calls: "+str(counts["lookup_calls"])+
        " lookups; "+str(counts["fetch_calls"])+" source fetches.",
        "These figures do not count outbound attempts that failed before reaching the local handler.",
        "",
        "| Case | Category | Expected lookup | Actual lookup | Fetch | Trace check | ChatGPT Project answer |",
        "|---|---|---|---:|---:|---|---|",
    ]
    for test,row in zip(plan["cases"],rows):
        expected="optional" if test["lookup_expected"] is None else ("yes" if test["lookup_expected"] else "no")
        check=("not specified" if row["trace_pass"] is None
               else "PASS" if row["trace_pass"] else "FAIL")
        lines.append("| "+row["id"]+" | "+row["kind"]+" | "+expected+" | "+
                     str(row["lookup_count"])+" | "+str(row["fetch_count"])+
                     " | "+check+" | [Read](https://"+row["chat_url"]+") |")
    lines += [
        "",
        "## Independent semantic evidence boundary",
        "",
        "Tool trace alone does NOT establish a correct or source-faithful answer. This",
        "document deliberately leaves the semantic verdict unassigned until every",
        "saved response is compared with the exact original synthetic fixture.",
        "A case without lookup may still give a plausible answer but does not prove",
        "that its archive was checked. A reported human recollection is not an",
        "authenticated recording. An answer about a missing detail must not",
        "fabricate an original quote, serial number or authenticated timestamp.",
        "",
        "Original answer excerpts and per-event IDs are retained only under the",
        "Git-ignored local Trial F ledger. No personal history was imported or",
        "pushed to GitHub; no native backend was modified in this test.",
        "",
    ]
    REPORT.write_text("\n".join(lines),encoding="utf8")

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("status","write"))
    action=parser.parse_args().action
    plan=json.loads(PLAN.read_text(encoding="utf8"))
    results=load_lines(LEDGER)
    summary=analyse(plan,results,load_lines(AUDIT))
    print(json.dumps({"cases":summary["cases"],"complete":summary["complete"],
                      "pending_send_marker_exists":summary["pending_send_marker_exists"],
                      "counts":dict(summary["counts"])},sort_keys=True))
    if action=="write":
        write_report(plan,results,summary)
        print("NATIVE_F_TRACE_REPORT_WRITTEN")

if __name__=="__main__":
    main()
