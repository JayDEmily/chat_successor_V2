"""Calibrate a raw-dense abstention gate using only prior corpora C/D.

This script must NOT read Holdout E. Its output is committed before E testing.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scripts.run_shadow_embeddings import CACHE, MODEL, normalized, order_by_score

ROOT=Path(__file__).resolve().parents[1]
CAL=ROOT/"RELEVANCE_CALIBRATION_20261118.json"
OUT=ROOT/"RELEVANCE_GATE_T_20261118.json"
REPORT=ROOT/"RELEVANCE_GATE_CALIBRATION_20261118.md"
CORPORA=(
    ("C",ROOT/"fixtures/synthetic_holdout_c.json",ROOT/"HOLDOUT_C_PROBES_20261118.json"),
    ("D",ROOT/"fixtures/synthetic_holdout_d.json",ROOT/"HOLDOUT_D_PROBES_20261118.json"),
)

def checksum(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def calculate(model, cfg: dict) -> dict:
    if cfg.get("trial_id")!="ltm-vnext-shadow-relevance-calibration-20261118" or not cfg.get("synthetic_only"):
        raise ValueError("Invalid calibration scope")
    negatives=cfg["negative_queries"]
    if len(negatives)!=24 or len({n["id"] for n in negatives})!=24:
        raise ValueError("Negative calibration count/identity")
    all_neg=[]
    all_pos=[]
    checks={}
    for label,fixture_path,probe_path in CORPORA:
        fixture=json.loads(fixture_path.read_text(encoding="utf8"))
        probes=json.loads(probe_path.read_text(encoding="utf8"))["probes"]
        data=fixture["messages"]
        if not fixture["synthetic"] or any(m["capture_method"]!="synthetic_fixture" for m in data):
            raise ValueError("Non-synthetic calibration input")
        negative=[n for n in negatives if n["corpus"]==label]
        if len(negative)!=12:
            raise ValueError("Calibration class imbalance")
        ids=[m["message_id"] for m in data]
        doc=normalized(model.embed([m["exact_text"] for m in data],batch_size=16))
        questions=normalized(model.embed([x["query"] for x in negative+probes],batch_size=16))
        scores=questions@doc.T
        checks[label]={"fixture_sha256":checksum(fixture_path),"probes_sha256":checksum(probe_path)}
        for i,query in enumerate(negative):
            ranking=order_by_score(ids,scores[i])
            all_neg.append({"id":query["id"],"corpus":label,"top_source":ranking[0],
                            "top1_cosine":float(scores[i].max())})
        for i,probe in enumerate(probes,start=len(negative)):
            ranking=order_by_score(ids,scores[i])
            target=probe["expected_message_id"]
            all_pos.append({"id":probe["id"],"corpus":label,"target":target,
                            "rank8":ranking[:8].index(target)+1 if target in ranking[:8] else None,
                            "top_source":ranking[0],"top1_cosine":float(scores[i].max())})
    if len(all_pos)!=48:
        raise ValueError("Wrong number of registered positive questions")
    maxneg=np.float32(max(x["top1_cosine"] for x in all_neg))
    cutoff=np.nextafter(maxneg,np.float32(np.inf))
    if not np.isfinite(cutoff):
        raise ValueError("Nonfinite threshold")
    for record in all_neg+all_pos:
        record["accepted"]=record["top1_cosine"]>=float(cutoff)
    if any(x["accepted"] for x in all_neg):
        raise ValueError("Negative calibration not rejected")
    return {
        "schema_version":1,"gate_id":"raw-dense-cd-calibration-20261118",
        "method":"raw BGE-small exact_text cosine threshold",
        "threshold_float32":float(cutoff),"max_negative_float32":float(maxneg),
        "rule":"nextafter(max negative top1 across 24 C/D questions,+infinity) float32",
        "model":MODEL,"calibration_sha256":checksum(CAL),
        "corpus_sha256":checks,"positive_total":48,"negative_total":24,
        "positive_accepted":sum(x["accepted"] for x in all_pos),
        "positive_accepted_correct8":sum(x["accepted"] and x["rank8"] is not None for x in all_pos),
        "negative_accepted":sum(x["accepted"] for x in all_neg),
        "negative_records":all_neg,"positive_records":all_pos,
        "e_holdout_not_accessed":True,
    }

def document(result: dict) -> str:
    lines=[
        "# Raw dense relevance gate: calibration only",
        "",
        "The fixed protocol and new Holdout E were committed BEFORE calibration.",
        "This script reads only Holdouts C/D and the registered negative calibration queries.",
        "The resulting threshold is now frozen before any test on E.",
        "",
        "Model: "+result["model"]+" (local CPU ONNX inference)",
        "Gate rule: "+result["rule"],
        "Threshold float32: "+format(result["threshold_float32"],".9f"),
        "Maximum negative top1 float32: "+format(result["max_negative_float32"],".9f"),
        "Calibration config SHA-256: "+result["calibration_sha256"],
        "Negative accepted: "+str(result["negative_accepted"])+"/24 (zero by construction)",
        "Positive accepted: "+str(result["positive_accepted"])+"/48",
        "Positive accepted and target in top8: "+str(result["positive_accepted_correct8"])+"/48",
        "",
        "| Calibration negative | Corpus | Top source | Top cosine | Outcome |",
        "|---|---|---|---:|---|",
    ]
    for n in result["negative_records"]:
        lines.append("| "+n["id"]+" | "+n["corpus"]+" | "+n["top_source"]+" | "+format(n["top1_cosine"],".6f")+" | REJECT |")
    lines += [
        "", "## Evidential limit", "",
        "This threshold has ZERO independent validation yet. Its zero false-positive",
        "rate on the 24 calibration negatives is mechanically guaranteed.",
        "It may reject genuine source questions. Holdout E must now be scored",
        "without modifying or recalibrating the threshold.",
        "",
    ]
    return "\n".join(lines)

def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("status","write"))
    action=parser.parse_args().action
    from fastembed import TextEmbedding
    model=TextEmbedding(model_name=MODEL,cache_dir=str(CACHE),threads=2,
                        providers=["CPUExecutionProvider"],cuda=False)
    result=calculate(model,json.loads(CAL.read_text(encoding="utf8")))
    print(json.dumps({k:v for k,v in result.items() if k not in ("negative_records","positive_records")},sort_keys=True))
    if action=="write":
        OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf8")
        REPORT.write_text(document(result),encoding="utf8")
        print("CALIBRATION_GATE_RECORDED")

if __name__=="__main__":
    main()
