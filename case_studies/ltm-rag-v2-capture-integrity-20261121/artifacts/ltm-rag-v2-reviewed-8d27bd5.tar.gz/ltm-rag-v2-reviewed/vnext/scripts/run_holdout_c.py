"""Evaluate frozen holdout C against the existing exact-source SQLite FTS5 lookup.

Uses a disposable, isolated, explicitly synthetic SQLite catalogue.
Does not contact OpenAI, alter the live MCP DB, or modify the registered probes.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import tempfile
from collections import Counter
from pathlib import Path

from ltm_vnext.archive import Archive

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "fixtures/synthetic_holdout_c.json"
PROBES = ROOT / "HOLDOUT_C_PROBES_20261118.json"
REPORT = ROOT / "HOLDOUT_C_BASELINE_RESULTS.md"


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate(fixture: dict, config: dict) -> None:
    if config["trial_id"] != "ltm-vnext-synthetic-holdout-c-20261118":
        raise ValueError("Unexpected holdout trial identity")
    if not config.get("registered_before_execution"):
        raise ValueError("Pre-registration marker missing")
    messages = fixture["messages"]
    if fixture.get("synthetic") is not True or len(messages) != 26:
        raise ValueError("Expected 26 entirely synthetic messages")
    if len(config["probes"]) != 16:
        raise ValueError("Expected 16 frozen retrieval probes")
    by_id = {m["message_id"]: m for m in messages}
    if len(by_id) != 26:
        raise ValueError("Duplicate message identifier")
    sources = {m["source_id"] for m in messages}
    if sources != {"synthetic-holdout-c"}:
        raise ValueError("Holdout source namespace changed")
    if any(m["capture_method"] != "synthetic_fixture" for m in messages):
        raise ValueError("Non-synthetic content forbidden")
    expected_ids = {f"c{n:02d}" for n in (3, 7, 10, 13, 17, 20, 23, 26)}
    if {p["expected_message_id"] for p in config["probes"]} != expected_ids:
        raise ValueError("Unexpected target correction identities")
    seen = set()
    for i, probe in enumerate(config["probes"]):
        if probe["id"] in seen:
            raise ValueError("Duplicate probe")
        seen.add(probe["id"])
        if probe["kind"] not in ("explicit", "implicit") or probe["limit"] != 8:
            raise ValueError("Invalid frozen probe kind or candidate limit")
        if probe["id"] != ("E" if i % 2 == 0 else "I") + f"{i // 2 + 1:02d}":
            raise ValueError("Probe order changed")
        target = by_id[probe["expected_message_id"]]
        if target.get("supersedes") is None:
            raise ValueError("Target is not a correction")


def run(fixture: dict, config: dict) -> list[dict]:
    validate(fixture, config)
    with tempfile.TemporaryDirectory(prefix="ltm-vnext-holdout-c-") as directory:
        archive = Archive.initialise(Path(directory) / "holdout.sqlite")
        inserted = archive.ingest_synthetic(FIXTURE)
        if inserted != {"inserted": 26, "total": 26}:
            raise ValueError("Fixture ingest did not preserve the expected record set")
        rows = []
        for probe in config["probes"]:
            packet = archive.lookup(probe["query"], limit=probe["limit"])
            ids = [hit["message_id"] for hit in packet["hits"]]
            rank = ids.index(probe["expected_message_id"]) + 1 if probe["expected_message_id"] in ids else None
            rows.append({
                "id": probe["id"],
                "kind": probe["kind"],
                "expected_message_id": probe["expected_message_id"],
                "candidate_count": len(ids),
                "rank": rank,
                "top_id": ids[0] if ids else None,
                "recall_at_8": rank is not None,
                "top1": rank == 1,
            })
        return rows


def make_report(rows: list[dict]) -> str:
    counts = Counter()
    for row in rows:
        k = row["kind"]
        counts[k] += 1
        counts[k + "_recall8"] += int(row["recall_at_8"])
        counts[k + "_top1"] += int(row["top1"])
        counts[k + "_zero_candidates"] += int(row["candidate_count"] == 0)
    lines = [
        "# Holdout C — frozen, offline lexical retrieval baseline",
        "",
        "Pre-registered before execution in HOLDOUT_C_PROBES_20261118.json. "
        "The original six-message live MCP catalogue was not changed.",
        "",
        f"Fixture SHA-256: {file_sha256(FIXTURE)}",
        f"Probe SHA-256: {file_sha256(PROBES)}",
        "",
        "| Probe group | Registered-source recall@8 | Target at rank 1 | Empty results |",
        "|---|---:|---:|---:|",
    ]
    for k in ("explicit", "implicit"):
        lines.append(
            f"| {k} | {counts[k + '_recall8']}/{counts[k]} | "
            f"{counts[k + '_top1']}/{counts[k]} | "
            f"{counts[k + '_zero_candidates']}/{counts[k]} |"
        )
    lines.extend([
        "",
        "| Probe | Group | Expected record | Actual rank | Candidate count | First result |",
        "|---|---|---|---:|---:|---|",
    ])
    for row in rows:
        lines.append(
            f"| {row['id']} | {row['kind']} | {row['expected_message_id']} | "
            f"{row['rank'] if row['rank'] is not None else 'MISS'} | "
            f"{row['candidate_count']} | {row['top_id'] or 'none'} |"
        )
    lines.extend([
        "",
        "## Limits and next decision",
        "",
        "This evaluates **SQLite FTS5 candidate retrieval only**, using a disposable database, "
        "eight novel fictional stories and 26 source messages. It does **not** measure "
        "ChatGPT's decision to invoke memory, OpenAI model accuracy, personal-history fidelity "
        "or production performance.",
        "",
        "An explicit-query hit is not proof the correct citation or historical interpretation "
        "will be used. Implicit misses may indicate a lexical/semantic vocabulary gap or "
        "ranking failure. Do not retrospectively change the frozen probes. "
        "If the implicit shortfall is material, evaluate a separate hybrid/semantic "
        "candidate retrieval method against this same corpus before integrating it with "
        "the native MCP service.",
        "",
        "No model API calls, real ChatGPT export imports, or changes to the live six-fixture "
        "archive/tunnel were made.",
        "",
    ])
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("status", "write"))
    args = parser.parse_args()
    fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
    config = json.loads(PROBES.read_text(encoding="utf-8"))
    rows = run(fixture, config)
    counts = Counter()
    for row in rows:
        counts[row["kind"] + "_total"] += 1
        counts[row["kind"] + "_hits"] += int(row["recall_at_8"])
        counts[row["kind"] + "_top1"] += int(row["top1"])
    print(json.dumps(dict(counts), sort_keys=True))
    if args.action == "write":
        REPORT.write_text(make_report(rows), encoding="utf-8")
        print("HOLDOUT_C_BASELINE_REPORT_WRITTEN")


if __name__ == "__main__":
    main()
