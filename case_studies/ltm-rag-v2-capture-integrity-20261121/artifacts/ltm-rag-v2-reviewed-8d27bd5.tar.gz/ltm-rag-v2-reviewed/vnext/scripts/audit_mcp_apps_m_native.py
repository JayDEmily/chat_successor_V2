"""Independently reconcile native Stage M audit with frozen plan and private UI receipt.

No network calls, ChatGPT messages, tool invocations, archive reads or secret output.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
import uuid
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
REG="2c24a4ebabb5a8be8ec4d3ecabc5cedc73a69193"
REG_PARENT="3703f8b9dd633d0ddcc05d6bdae3e4d28a0ba81c"
OFFLINE="9f67a287f598964c03ae157fadc82d0da8ff64e4"
FROZEN=("MCP_APPS_M_PROTOCOL_20261120.md","MCP_APPS_M_CASES_20261120.json")
AUDIT=ROOT/".local/trial-m-mcp-audit.jsonl"
UI=ROOT/".local/trial-m-native-ui-proof.json"
REPORT=ROOT/"MCP_APPS_M_NATIVE_RESULTS_20261120.md"
NATIVE_PLUGIN="plugin_asdk_app_6affaf818f3481919433489e25b52471"
TUNNEL="tunnel_6affa48f70b0819187bbe06449bf2750"
ALLOWED_EVENT_KEYS={
 "event_id","timestamp_utc","tool","status","session_present",
 "subject_present","synthetic_only","source_count","original_user_text_attested"
}


def git(*args):
    return subprocess.run(["git","-C",str(REPO),*args],capture_output=True,check=True).stdout


def audit():
    parent=git("rev-list","--parents","-n","1",REG).decode().strip()
    if parent!=REG+" "+REG_PARENT:
        raise RuntimeError("Stage M registration parent mismatch")
    frozen_sha={}
    for name in FROZEN:
        raw=(ROOT/name).read_bytes()
        if raw!=git("show",REG+":vnext/"+name):
            raise RuntimeError("Preregistered bytes changed: "+name)
        frozen_sha[name]=hashlib.sha256(raw).hexdigest()
    if (ROOT/"ltm_vnext/mcp_apps_m.py").read_bytes()!=git(
            "show",OFFLINE+":vnext/ltm_vnext/mcp_apps_m.py"):
        raise RuntimeError("Native handler drifted after offline release")
    plan=json.loads((ROOT/FROZEN[1]).read_text(encoding="utf-8"))
    native=plan["native_probe"]
    prompt=native["prompt"]
    digest=hashlib.sha256(prompt.encode("utf-8")).hexdigest()
    if (plan["cases_count"]!=16 or len(plan["cases"])!=16 or
        plan["ttl_seconds"]!=60 or native["id"]!="M-N01" or
        native["maximum_native_chat_sends"]!=1 or
        native["optional_automated_app_clicks"]!=1 or
        native["click_topic_id"]!="merrow_prism"):
        raise RuntimeError("Frozen native probe shape drifted")
    if not AUDIT.exists() or not UI.exists():
        raise RuntimeError("Private native audit or UI evidence absent")
    rows=[json.loads(line) for line in AUDIT.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(rows)!=2:
        raise RuntimeError(f"Unexpected native MCP event count: {len(rows)}")
    tools=["open_topic_selector_m","confirm_topic_m"]
    statuses=["AWAITING_CONFIRMATION","EXPIRED"]
    timestamps=[]
    for i,row in enumerate(rows):
        if set(row)!=ALLOWED_EVENT_KEYS:
            raise RuntimeError("Privacy-guarded audit schema drift")
        if (row["tool"]!=tools[i] or row["status"]!=statuses[i] or
            row["source_count"]!=0 or row["original_user_text_attested"] is not False or
            row["synthetic_only"] is not True or
            row["session_present"] is not True or row["subject_present"] is not True):
            raise RuntimeError("Native tool status/boundary mismatch")
        uuid.UUID(row["event_id"])
        t=datetime.fromisoformat(row["timestamp_utc"])
        if t.tzinfo is None:
            raise RuntimeError("Missing event timestamp timezone")
        timestamps.append(t)
    elapsed_ms=round((timestamps[1]-timestamps[0]).total_seconds()*1000)
    if elapsed_ms < plan["ttl_seconds"]*1000:
        raise RuntimeError("EXPIRED result contradicted timestamp/TTL")
    proof=json.loads(UI.read_text(encoding="utf-8"))
    if (proof["schema_version"]!=1 or proof["synthetic_only"] is not True or
        proof["native_plugin_id"]!=NATIVE_PLUGIN or
        proof["frozen_prompt_sha256"]!=digest or
        proof["frozen_prompt_exact_text_visible"] is not True or
        proof["native_plugin_mention_visible"] is not True or
        proof["separate_ui_mention_visible"] is not True or
        proof["rendered_topic_button_count"]!=5 or
        len(proof["rendered_topic_buttons"])!=5 or
        "Confirm fictional topic: Merrow calibration log" not in proof["rendered_topic_buttons"] or
        proof["expired_ui_status_visible"] is not True or
        proof["send_once_marker_valid"] is not True or
        proof["automated_click_once_marker_valid"] is not True or
        proof["human_consent_attested"] is not False or
        proof["original_user_text_attested"] is not False or
        not proof["private_saved_chat_url"].startswith("chatgpt.com/c/")):
        raise RuntimeError("Native UI and one-send evidence mismatch")
    if digest!="b5fc29f6ce6547d4772d69f4e3202c7e37443f05463f809ed1f1775527ff47e6":
        raise RuntimeError("Frozen native prompt hash mismatch")
    return {
        "registered_commit":REG,"registration_parent":REG_PARENT,
        "offline_implementation":OFFLINE,"frozen_sha256":frozen_sha,
        "native_plugin":NATIVE_PLUGIN,"tunnel":TUNNEL,
        "native_prompt_sha256":digest,"user_send_clicks":1,"automated_widget_clicks":1,
        "observed_native_mcp_tool_calls":2,
        "tool_statuses":statuses,"elapsed_milliseconds":elapsed_ms,
        "frozen_ttl_milliseconds":plan["ttl_seconds"]*1000,
        "topic_buttons":5,"native_widget_rendered":True,
        "app_only_callback_delivered":True,"confirmation_accepted":False,
        "human_consent_attested":False,"original_user_text_attested":False,
        "source_packets_released":0,"raw_metadata_exported":False
    }


def write_report(out):
    ms=out["elapsed_milliseconds"]
    rows=[
        "# Stage M — native ChatGPT MCP Apps observation",
        "",
        "**Outcome: NATIVE_M_UI_AND_APP_CALLBACK_TRANSPORT_OBSERVED; EXPIRED CONFIRMATION; NO TRUSTED USER ATTESTATION.**",
        "",
        "## Reconciliation and lineage",
        "",
        f"- Frozen pre-implementation registration `{REG}`, direct parent `{REG_PARENT}`.",
        f"- Frozen protocol SHA-256 `{out['frozen_sha256'][FROZEN[0]]}` and cases SHA-256 `{out['frozen_sha256'][FROZEN[1]]}`, verified byte-for-byte against preregistered Git blobs.",
        f"- Stage M native-handler source remains byte-identical to offline implementation commit `{OFFLINE}`.",
        f"- Dedicated tunnel: `{TUNNEL}`. Native ChatGPT custom MCP plugin: `{NATIVE_PLUGIN}`, personally private.",
        "- The earlier portable/desktop plugin package is a separate registration, not the native ChatGPT web plugin.",
        f"- Frozen user-request text SHA-256: `{out['native_prompt_sha256']}`.",
        "- Exactly one native message send and one automated synthetic widget click, checked against one-send markers.",
        "- The saved ChatGPT message shows the frozen text verbatim **after** a separate UI-added plugin mention; therefore **the complete displayed message is not a byte-identical stand-alone frozen prompt**.",
        "",
        "## Native server and UI evidence",
        "",
        "- **M-N01:** one native `open_topic_selector_m` event. `AWAITING_CONFIRMATION`, session and subject supplied, zero source packets, no original-user-text attestation.",
        "- The saved native ChatGPT conversation rendered the actual embedded MCP Apps HTML with all five preregistered fictional topic controls and the initial 'Select a single fictional topic.' status.",
        "- **M-N02:** exactly one automated click on the **Merrow calibration log** widget button. The `confirm_topic_m` **app-only** tool reached the server as a second native MCP event.",
        f"- Time between native tool events: **{ms/1000:.3f} seconds**; frozen TTL **60 seconds**. Confirmation returned `EXPIRED`, not `CONFIRMED`. The actual native widget visibly updated to `Confirmation not accepted: EXPIRED`.",
        "- Both private-audit records report session and subject presence, synthetic-only status, no source packets and no original text attestation. No raw session/subject values, token, user-message content, chat URL or raw event IDs are included in this published report.",
        "- Because the handler returns `EXPIRED` only on a **matching existing scoped flow**, that outcome supports process-local equality of the two **client-supplied** session/subject correlation scopes; it does not authenticate the client or user.",
        "- The assistant's initial textual reply indicating no topic was selected preceded the automated widget click; it must not be treated as evidence about the later `EXPIRED` tool event.",
        "",
        "## Decision and strict limits",
        "",
        "**ACCEPT native opening-tool delivery, embedded-widget rendering, widget-to-MCP app-only callback delivery, source-exclusion and timeout enforcement.**",
        "",
        "**DO NOT claim a successful confirmed choice or genuine human consent.** The confirm event expired after the 60-second window while the UI was being inspected, so the positive live-confirmation path has **not** been exercised. The UI-added plugin mention changes the complete displayed message compared with the frozen stand-alone prompt; record this as a native prompt presentation deviation, not a clean exact-message attestation.",
        "",
        "The app-only descriptor is a host-side presentation filter, **not** a server-enforced identity or authorisation boundary. Client-provided `openai/session` and subject still cannot prove the original current user message or speaker. Stage I remains 14/16 with I05/I15 unsupported referents; Stage K retains its earlier four-call deviation.",
        "",
        "**No additional Stage M native sends or clicks.** Any live accepted-confirmation test requires a *new*, separately preregistered time-bounded stage, using the existing M-only connector. No real conversation history, external inference, production imports, new API keys, OS autostart or original/G/I/K connector changes were made.",
        "",
    ]
    REPORT.write_text("\n".join(rows),encoding="utf-8")
    print("M_NATIVE_REPORT_WRITTEN")


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=["status","write"])
    args=p.parse_args()
    out=audit()
    print(json.dumps(out,sort_keys=True))
    if args.action=="write":
        write_report(out)

if __name__=="__main__":
    main()
