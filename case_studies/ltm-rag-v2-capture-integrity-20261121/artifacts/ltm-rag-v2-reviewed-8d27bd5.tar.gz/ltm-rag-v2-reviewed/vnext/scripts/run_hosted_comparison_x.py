"""Run the preregistered normal-chat comparison on the existing private listener."""

import hashlib
import json
from pathlib import Path

from ltm_vnext.hosted_mcp_u import CallQuotaU, create_server
from ltm_vnext.hosted_mcp_w import W_AUDIT, HostedMemoryGatewayW, check_registration, git
from ltm_vnext.verified_dialogue_t import NativeVerifiedT

ROOT = Path(__file__).resolve().parents[1]
REGISTRATION = "a6eeb042cf272c245478713836df83da55e57399"
X_CASES = "NATIVE_HOSTED_X_CASES_20261120.json"
X_PROTOCOL = "NATIVE_HOSTED_X_PROTOCOL_20261120.md"
X_AUDIT = ROOT / ".local/trial-x-hosted-mcp-audit.jsonl"


def main():
    for filename in (X_CASES, X_PROTOCOL):
        frozen = git("show", f"{REGISTRATION}:vnext/{filename}")
        if (ROOT / filename).read_bytes() != frozen:
            raise RuntimeError(f"Frozen Stage X registration changed: {filename}")
    plan = json.loads((ROOT / X_CASES).read_bytes())
    parent = git("rev-parse", f"{REGISTRATION}^").decode().strip()
    if parent != plan["stage_w_implementation"]:
        raise RuntimeError("Stage X parent does not match the W baseline")
    if hashlib.sha256(W_AUDIT.read_bytes()).hexdigest() != plan["stage_w_audit_sha256"]:
        raise RuntimeError("Completed Stage W audit changed")
    source = ROOT / ".local/native-t-dialogue/dialogue_s.sqlite"
    if hashlib.sha256(source.read_bytes()).hexdigest() != plan["stage_t_sqlite_sha256"]:
        raise RuntimeError("Canonical Stage T SQLite bytes changed")

    check_registration()
    gateway = HostedMemoryGatewayW(
        pipeline=NativeVerifiedT(),
        quota=CallQuotaU(X_AUDIT, limit=plan["max_server_calls"], stage="X"),
    )
    create_server(gateway).run(
        transport="streamable-http",
        host="127.0.0.1",
        port=8792,
        json_response=True,
        stateless_http=True,
    )


if __name__ == "__main__":
    main()
