"""One-shot loopback HTTP MCP smoke test. Terminates its subprocess."""
from __future__ import annotations

import asyncio
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from mcp import Client
from ltm_vnext.archive import Archive

ROOT = Path(__file__).resolve().parents[1]


async def exercise(url: str) -> None:
    async with Client(url) as client:
        tools = (await client.list_tools()).tools
        assert {x.name for x in tools} == {"lookup_evidence", "fetch_source"}
        assert all(x.annotations.read_only_hint for x in tools)
        result = await client.call_tool(
            "lookup_evidence", {"query": "blue notebook"}
        )
        assert not result.is_error, result
        content = result.structured_content
        assert content and content["synthetic_only"]
        assert content["hits"]
        hit = next(x for x in content["hits"] if x["message_id"] == "m1")
        assert hit["author_role"] == "user"
        assert hit["reported_speaker"] == "Mira"
        source = await client.call_tool(
            "fetch_source", {"local_id": hit["local_id"]}
        )
        assert not source.is_error
        assert source.structured_content["exact_text"] == hit["exact_text"]
        print("HTTP_MCP_SMOKE: PASS, tools=2, synthetic_lookup=true, source_fetch=exact")


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        database = Path(td) / "synthetic.sqlite"
        audit_log = Path(td) / "tool-calls.jsonl"
        Archive.initialise(database).ingest_synthetic(
            ROOT / "fixtures" / "synthetic_conversations.json"
        )
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        env = dict(os.environ)
        env["PYTHONPATH"] = str(ROOT)
        process = subprocess.Popen(
            [sys.executable, "-m", "ltm_vnext.mcp_server",
             "--db", str(database), "--port", str(port),
             "--audit-log", str(audit_log)],
            env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            text=True,
        )
        try:
            deadline = time.monotonic() + 8
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise RuntimeError("MCP server exited before listener was ready")
                try:
                    with socket.create_connection(("127.0.0.1", port), timeout=0.3):
                        break
                except OSError:
                    time.sleep(0.1)
            else:
                raise TimeoutError("MCP loopback listener was not ready")
            asyncio.run(exercise(f"http://127.0.0.1:{port}/mcp"))
            events = [json.loads(line) for line in audit_log.read_text().splitlines()]
            assert [e["tool"] for e in events] == ["lookup_evidence", "fetch_source"]
            assert all(e["outcome"] == "ok" for e in events)
            assert all("query" not in e and "exact_text" not in e for e in events)
            print("HTTP_MCP_AUDIT: PASS, 2 content-minimised invocation events")
        finally:
            process.terminate()
            try:
                _, error = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                _, error = process.communicate(timeout=5)
            if process.returncode not in (0, -15):
                print(error[-1000:], file=sys.stderr)


if __name__ == "__main__":
    main()
