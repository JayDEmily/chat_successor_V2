"""Independent Stage J preregistered 26-case shadow auditor (NO native calls)."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import tempfile
from collections import Counter
from pathlib import Path

from ltm_vnext.archive import Archive
from ltm_vnext.decision_support_i import SyntheticHistoryResolver
from ltm_vnext.trusted_turn_j import BoundTurnGateway

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent
REGISTRATION = "0628a238a6f2bf80323cc9c58bfa53f6a670e059"
REGISTRATION_PARENT = "d83695fb4a10944311eaa7bd9c7a919521abc5de"
PROTOCOL = "TRUSTED_TURN_J_PROTOCOL_20261119.md"
PLAN = "TRUSTED_TURN_J_CASES_20261119.json"
REPORT = ROOT / "TRUSTED_TURN_J_OFFLINE_RESULTS_20261119.md"


def _git(*args: str) -> bytes:
    return subprocess.run(["git", "-C", str(REPO), *args],
                          capture_output=True,check=True).stdout


def audit():
    actual_parent=_git("rev-list","--parents","-n","1",REGISTRATION).decode().strip()
    if actual_parent != REGISTRATION+" "+REGISTRATION_PARENT:
        raise ValueError("Pinned J preregistration parent mismatch")
    frozen={}
    for name in (PROTOCOL,PLAN):
        committed=_git("show",REGISTRATION+":vnext/"+name)
        local=(ROOT/name).read_bytes()
        if committed!=local:
            raise ValueError("J frozen plan changed after preregistration: "+name)
        frozen[name]=hashlib.sha256(local).hexdigest()
    plan=json.loads((ROOT/PLAN).read_text(encoding="utf8"))
    if (plan.get("trial_id")!="ltm-rag-vnext-J-conditional-trusted-turn-20261119"
        or plan.get("offline_only") is not True
        or plan.get("registered_before_implementation") is not True
        or plan.get("synthetic_only") is not True
        or plan.get("cases_count")!=26 or len(plan.get("cases",[]))!=26):
        raise ValueError("Incorrect J preregistration identity/count")
    fixture=ROOT/plan["fixture"]
    fixture_data=fixture.read_bytes()
    if hashlib.sha256(fixture_data).hexdigest()!=plan["fixture_sha256"]:
        raise ValueError("Original G fixture content hash mismatch")
    originals=json.loads(fixture_data)["messages"]
    source_map={m["message_id"]:m for m in originals}
    if len(originals)!=20 or len(source_map)!=20:
        raise ValueError("Not exactly 20 distinct original fictional sources")
    results=[]
    with tempfile.TemporaryDirectory() as tmp:
        db=Path(tmp)/"shadow-j.sqlite"
        inserted=Archive.initialise(db).ingest_synthetic(fixture)
        if inserted["inserted"]!=20:
            raise ValueError("Synthetic archive seed missing messages")
        resolver=SyntheticHistoryResolver(
            db,fixture,ROOT/"REFERENT_GATE_H_MANIFEST_20261119.json")
        for index,case in enumerate(plan["cases"],1):
            if case["id"]!=f"J{index:02d}":
                raise ValueError("J case order changed")
            registry=BoundTurnGateway(resolver)
            if case["registered"]:
                registry.register_trusted_turn(
                    case["registration_context"],case["trusted_question"])
            response=registry.resolve_tool_call(
                case["model_question"],case["call_context"])
            ids=[packet["message_id"] for packet in response["source_packets"]]
            fields_valid=(
                response["status"]==case["expected_status"]
                and response["conversation_ids"]==case["expected_topics"]
                and ids==case["expected_original_message_ids"]
                and response["source_count"]==len(ids)
                and response["trust_boundary"]=="OWNER_INGRESS_SIMULATED_NOT_NATIVE_CHATGPT"
                and response["synthetic_only"] is True
            )
            if not fields_valid:
                raise ValueError("Case outcome disagrees with registered expectation: "+case["id"])
            for packet in response["source_packets"]:
                original=source_map[packet["message_id"]]
                for key in ("exact_text","author_role","attribution","branch_id",
                            "source_locator","conversation_id","reported_speaker"):
                    if packet.get(key)!=original.get(key):
                        raise ValueError(
                            f"Original {key} mismatch in {case['id']}:{packet['message_id']}")
                if packet["content_sha256"]!=hashlib.sha256(
                        original["exact_text"].encode("utf8")).hexdigest():
                    raise ValueError("Original source content hash mismatch")
            if response["status"] not in ("UNIQUE","MULTIPLE") and ids:
                raise ValueError("Denied/unanchored call disclosed original content")
            results.append({"id":case["id"],"class":case["type"],
                            "status":response["status"],
                            "source_message_ids":ids,"pass":True})
    counts=Counter(item["status"] for item in results)
    if counts!={"UNANCHORED":5,"MODEL_ARGUMENT_MISMATCH":9,
                "UNIQUE":5,"MULTIPLE":2,"NO_BOUND_TURN":5}:
        raise ValueError("J registered outcome distribution diverged")
    return {
        "registered_commit":REGISTRATION,
        "registered_parent":REGISTRATION_PARENT,
        "preregistered_sha256":frozen,
        "fixture_sha256":plan["fixture_sha256"],
        "cases":len(results),"pass":sum(x["pass"] for x in results),
        "status_counts":dict(sorted(counts.items())),
        "native_chatgpt_cases_executed":0,
    },results

def write_report(summary,rows):
    counts=summary["status_counts"]
    lines=[
        "# Stage J — independent shadow trusted-turn-binding audit",
        "",
        "**Result: 26/26 preregistered cases PASS.** The conditional",
        "in-process owner-ingress fixture prevents model-augmented",
        "historical referent arguments from releasing fictional sources.",
        "This is **NOT** proof that a native ChatGPT MCP can receive a",
        "host-authenticated current user message.",
        "",
        "## Frozen inputs and provenance",
        "",
        f"- Registration commit: `{summary['registered_commit']}`, exact parent",
        f"  `{summary['registered_parent']}`.",
        "- Both preregistered documents were independently compared byte-for-byte",
        "  against their committed Git blobs before case results were accepted.",
        f"- 20-message fictional original fixture SHA-256: `{summary['fixture_sha256']}`.",
        "- Every returned source packet matched original UTF-8 text, SHA-256,",
        "  locator, author, branch, reported speaker and source identity.",
        "- No live MCP transport, tunnel, connected plugin, native ChatGPT",
        "  message or external inference endpoint was used.",
        "",
        "## Frozen case outcomes",
        "",
        "| Outcome | Count |",
        "|---|---:|",
    ]
    for status,n in sorted(counts.items()):
        lines.append(f"| {status} | {n} |")
    lines.extend(["","| Frozen case | Class | Result | Original source IDs |",
                  "|---|---|---|---|"])
    for row in rows:
        ids=", ".join(row["source_message_ids"]) or "none"
        lines.append(f"| {row['id']} | {row['class']} | {row['status']} | {ids} |")
    lines.extend([
        "",
        "## Security interpretation",
        "",
        "1. I05/I15 could not be promoted through a model-injected ORA-62",
        "   or Vela name. Exact model-question mismatch produced no source",
        "   packet, as did a missing/wrong out-of-band session/turn context.",
        "2. A trusted, exact original user message did permit ordinary",
        "   source lookup (when it explicitly named its topic). Source",
        "   authorship and correction semantics remained those of the",
        "   original I resolver.",
        "3. The owner-registration method in this proof is an in-process",
        "   harness operation **not exposed as an MCP tool**. The test",
        "   assumes the caller already holds genuinely authenticated",
        "   user input. The Python method's existence is not an",
        "   authentication scheme and the test does not supply one.",
        "4. The documented `_meta['openai/session']` is an anonymised",
        "   **conversation** identifier for correlation, not a copy",
        "   of the user's prompt, a per-turn authentication token,",
        "   or by itself an access-control credential.",
        "5. If the native ChatGPT host cannot send original user text",
        "   independently of model-authored arguments, this gateway",
        "   cannot be securely connected without a separate owned",
        "   front end, a documented host interface or an explicit",
        "   user-side confirmation mechanism. Neither has been",
        "   verified in native ChatGPT by this experiment.",
        "",
        "## Official source links, reviewed 19 November 2026",
        "",
        "- MCP model-selected arguments: https://developers.openai.com/plugins/concepts/mcp-server",
        "- ChatGPT-supplied metadata (session/subject): https://developers.openai.com/plugins/reference",
        "- Server auth, elicitation and annotations: https://developers.openai.com/plugins/build/mcp-server",
        "- Remote MCP does not automatically receive conversation: https://developers.openai.com/api/docs/guides/realtime-mcp",
        "- Owning application can supply `role=user` item: https://developers.openai.com/api/docs/guides/migrate-to-responses",
        "- Application guardrails: https://developers.openai.com/api/docs/guides/agents/guardrails-approvals",
        "- Don't pull full conversation as workaround: https://developers.openai.com/plugins/guides/security-privacy",
        "",
        "**Decision: PASS_SHADOW_TRUSTED_INGRESS_CONDITIONAL_ONLY.**",
        "**Native message authentication remains unverified.**",
        "",
    ])
    # ` escaped in script source represents literal code quote and is safe.
    REPORT.write_text("\n".join(lines),encoding="utf8")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("status","write"))
    args=parser.parse_args()
    summary,rows=audit()
    print(json.dumps(summary,sort_keys=True))
    if args.action=="write":
        write_report(summary,rows)
        print("J_INDEPENDENT_OFFLINE_RESULT_WRITTEN")


if __name__=="__main__":
    main()
