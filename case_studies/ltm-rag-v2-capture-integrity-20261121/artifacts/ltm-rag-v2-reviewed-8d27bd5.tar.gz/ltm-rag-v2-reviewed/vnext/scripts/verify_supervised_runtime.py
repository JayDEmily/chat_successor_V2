"""Verify live synthetic child secret-name boundaries without exposing values."""
from __future__ import annotations

import argparse
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOCAL = ROOT / ".local"


def check_child(name: str, pid: int, expects_control_key: bool) -> None:
    proc = Path("/proc") / str(pid)
    argv = (proc / "cmdline").read_bytes()
    entries = (proc / "environ").read_bytes().split(b"\0")
    names = {item.split(b"=", 1)[0] for item in entries if b"=" in item}
    if str(ROOT).encode("utf-8") not in argv:
        raise RuntimeError(f"{name} process does not match the synthetic vNext root")
    for forbidden in (b"OPENAI_ADMIN_KEY", b"OPENAI_API_KEY"):
        if forbidden in names:
            raise RuntimeError(f"{name} contains forbidden key name {forbidden.decode()}")
    present = b"CONTROL_PLANE_API_KEY" in names
    if present != expects_control_key:
        raise RuntimeError(f"{name} control-plane environment boundary mismatch")
    print(f"PROCESS_ENV_BOUNDARY_PASS service={name} pid={pid} control_key_present={present}")


def check_logs() -> None:
    for filename in (
        "mcp-tool-audit.jsonl",
        "reliability-trial-b-results.jsonl",
        "synthetic-supervisor-events.jsonl",
        "synthetic-mcp-child.log",
        "synthetic-tunnel-child.log",
    ):
        path = LOCAL / filename
        if not path.is_file():
            raise RuntimeError(f"Missing expected private file: {filename}")
        mode = path.stat().st_mode & 0o777
        if mode != 0o600:
            raise RuntimeError(f"Expected mode 0600: {filename} has {oct(mode)}")
        print(f"LOG_PERMISSION_PASS name={filename} mode=0600")
    for filename in ("synthetic-mcp-child.log", "synthetic-tunnel-child.log"):
        content = (LOCAL / filename).read_text(encoding="utf-8", errors="replace")
        for forbidden in ("OPENAI_ADMIN_KEY=", "OPENAI_API_KEY=", "CONTROL_PLANE_API_KEY=", "sk-proj-"):
            if forbidden in content:
                raise RuntimeError(f"Potential credential literal in {filename}")
        print(f"CHILD_LOG_LITERAL_SCAN_PASS name={filename}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mcp-pid", type=int, required=True)
    parser.add_argument("--tunnel-pid", type=int, required=True)
    args = parser.parse_args()
    if args.mcp_pid <= 1 or args.tunnel_pid <= 1 or args.mcp_pid == args.tunnel_pid:
        raise ValueError("Expected two distinct positive child PIDs")
    check_child("mcp", args.mcp_pid, expects_control_key=False)
    check_child("tunnel", args.tunnel_pid, expects_control_key=True)
    check_logs()
    print("SYNTHETIC_RUNTIME_SAFETY_PASS")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, ValueError, OSError) as exc:
        raise SystemExit("SYNTHETIC_RUNTIME_SAFETY_FAIL " + str(exc)) from None
