"""Independent read-only audit: verified native UI source, SQL and hosted T index.

No new ChatGPT sends, hosted searches, uploads or model inference. No raw
ChatGPT texts, IDs, signed in chat URLs or credentials in stdout.
"""
from __future__ import annotations
import hashlib
import json
import sqlite3
import stat
import subprocess
from datetime import datetime,timezone
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request,urlopen

from ltm_vnext.archive import Archive
from ltm_vnext.hosted_memory_r import project_key

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
TREG="da3232c5c999255b551ae876f3b1d169a277f1db"
TPARENT="a02192ef14c86242532e9ab22c61a64c590cecd1"
FROZEN=("NATIVE_DIALOGUE_T_PROTOCOL_20261120.md","NATIVE_DIALOGUE_T_CASES_20261120.json")
S=ROOT/".local/native-s-dialogue"
T=ROOT/".local/native-t-dialogue"
M=ROOT/".local/trial-m-mcp-audit.jsonl"
M_SHA="65aee8025541240eac6fde67d0b47bcc870c3b02f99e3c68b53f90ed90cb769a"
T_NAME="LTM-RAG vNext — Verified Native Dialogue T"
SRC="synthetic-native-dialogue-t"
CONV="fictional_native_dialogue_t"


def git(*args):
    return subprocess.run(["git","-C",str(REPO),*args],
                          check=True,capture_output=True).stdout


def get(key,uri):
    request=Request("https://api.openai.com/v1"+uri,method="GET",
                    headers={"Authorization":"Bearer "+key,"Accept":"application/json"})
    try:
        with urlopen(request,timeout=30) as reply:
            obj=json.load(reply)
    except HTTPError as exc:
        raise RuntimeError("Independent hosted readback HTTP "+str(exc.code)) from None
    if not isinstance(obj,dict):raise RuntimeError("Malformed hosted response")
    return obj


def assert_utc(value):
    if type(value) is not str:
        raise RuntimeError("Missing timestamp")
    date=datetime.fromisoformat(value.replace("Z","+00:00"))
    if date.utcoffset() is None:
        raise RuntimeError("Timestamp without explicit offset")
    return date.astimezone(timezone.utc)


def audit():
    if git("rev-list","--parents","-n","1",TREG).decode().strip()!=TREG+" "+TPARENT:
        raise RuntimeError("Frozen independent Stage T preregistration parent changed")
    for item in FROZEN:
        if (ROOT/item).read_bytes()!=git("show",TREG+":vnext/"+item):
            raise RuntimeError("Frozen T preregistration bytes altered")
    plan=json.loads((ROOT/FROZEN[1]).read_text(encoding="utf-8"))
    original=json.loads((ROOT/"NATIVE_DIALOGUE_S_CASES_20261120.json").read_text(encoding="utf-8"))
    if (plan["trial_id"]!="ltm-vnext-T-verified-native-dialogue-salvage-20261120" or
        plan["additional_native_sends_allowed"]!=0 or
        plan["original_native_sends"]!=5 or plan["hosted_file_uploads_max"]!=5 or
        len(plan["query_cases"])!=3):
        raise RuntimeError("Frozen verified T scope mismatch")
    if stat.S_IMODE(T.stat().st_mode)!=0o700:
        raise RuntimeError("Verified T private directory not owner-only")
    required=("verified_transcript.json","store.json","dialogue_s.sqlite",
              "frozen_query_results.json")
    for item in required:
        file=T/item
        if not file.is_file() or stat.S_IMODE(file.stat().st_mode)!=0o600:
            raise RuntimeError("Unprotected or missing T private file")
    verified_bytes=(T/"verified_transcript.json").read_bytes()
    if hashlib.sha256(verified_bytes).hexdigest()!=plan["verified_private_transcript_sha256"]:
        raise RuntimeError("Verified independent UI transcript bytes altered")
    verified=json.loads(verified_bytes)
    if len(verified["turns"])!=5 or verified["original_capture_preserved"] is not True:
        raise RuntimeError("Verified live UI transcript shape differs")
    if len(list(S.glob("send_once_*.json")))!=5 or len(list(S.glob("captured_*.json")))!=5:
        raise RuntimeError("Unexpected original native sends or UIA raw captures")
    for i,entry in enumerate(verified["turns"],1):
        raw_file=S/f"captured_{i:02d}.json"
        if hashlib.sha256(raw_file.read_bytes()).hexdigest()!=plan["raw_private_capture_sha256"][i-1]:
            raise RuntimeError("Stage S raw evidence changed after reconstruction")
        orig=json.loads(raw_file.read_text(encoding="utf-8"))
        before=json.loads((S/f"send_once_{i:02d}.json").read_text(encoding="utf-8"))
        expected=original["case_messages"][i-1]["simulated_user_text"]
        footer=r"\nChatGPT can make mistakes. Check important info.\nLatest response\nAsk ChatGPT"
        if (entry["turn"]!=i or entry["simulated_user_text"]!=expected or
            orig["simulated_user_text"]!=expected or
            orig["assistant_observed_text"]!=entry["assistant_verified_rendered_text"]+footer or
            entry["exact_UIA_rendered_text_verified"] is not True or
            before["phase"]!="send_invoked" or before["turn"]!=i or
            entry["real_user_authorship_attested"] is not False):
            raise RuntimeError("Verified UI original source fidelity/author role drift")
        assert_utc(entry["ui_send_at_utc"])
        assert_utc(entry["first_observed_complete_at_utc"])
        assert_utc(entry["native_ui_readback_at_utc"])
    with sqlite3.connect("file:"+str(T/"dialogue_s.sqlite")+"?mode=ro",uri=True) as sql:
        sql.row_factory=sqlite3.Row
        rows=sql.execute("SELECT * FROM messages ORDER BY position").fetchall()
        mapping=sql.execute("SELECT * FROM native_s_files ORDER BY turn_index").fetchall()
    if len(rows)!=10 or len(mapping)!=5:
        raise RuntimeError("T canonical ten sources / five mappings not found")
    ids=set()
    for i in range(1,6):
        user,assistant=rows[(i-1)*2:i*2]
        proof=verified["turns"][i-1]
        for row,role,suffix,text in (
            (user,"user","u",proof["simulated_user_text"]),
            (assistant,"assistant","a",proof["assistant_verified_rendered_text"]),
        ):
            if (row["message_id"]!=f"t{i:02d}{suffix}" or
                row["position"]!=(i*2-1 if role=="user" else i*2) or
                row["author_role"]!=role or
                row["source_id"]!=SRC or
                row["conversation_id"]!=CONV or
                row["branch_id"]!="main" or
                row["capture_method"]!="synthetic_native_ui" or
                row["fidelity"]!="synthetic_only" or
                row["exact_text"]!=text or
                row["content_sha256"]!=hashlib.sha256(text.encode("utf-8")).hexdigest() or
                row["source_locator"]!=f"synthetic-native-ui://stage-t/turn-{i:02d}/{role}"):
                raise RuntimeError("T original SQLite message/provenance mismatch")
            if row["local_id"] in ids:
                raise RuntimeError("Duplicate canonical message identity")
            ids.add(row["local_id"])
            assert_utc(row["ingested_at_utc"])
            if role=="user":
                if row["message_sent_at_source"]!=proof["ui_send_at_utc"]:
                    raise RuntimeError("Controller UI send timestamp source altered")
                assert_utc(row["message_sent_at_utc"])
            elif row["message_sent_at_source"] is not None or row["message_sent_at_utc"] is not None:
                raise RuntimeError("False model server-send timestamp")
        row=mapping[i-1]
        if (row["turn_index"]!=i or row["completed"]!=1 or
            row["user_local_id"]!=user["local_id"] or
            row["assistant_local_id"]!=assistant["local_id"] or
            row["assistant_observed_at_utc"]!=proof["first_observed_complete_at_utc"] or
            row["chat_url"]!=proof["chat_url"]):
            raise RuntimeError("Hosted T file/source or observed time mapping changed")
        lines=[
            "WHOLLY FICTIONAL NATIVE CHATGPT TEST. NOT A REAL USER DIARY.",
            "The assistant reply was independently reread from ChatGPT UIA;",
            "it excludes a verified Chrome UI footer added by a failed first capture.",
            f"Conversation: {CONV}",
            f"Turn: {i:02d}",
            f"SIMULATED USER [t{i:02d}u]: {user['exact_text']}",
            f"NATIVE CHATGPT ASSISTANT [t{i:02d}a]: {assistant['exact_text']}",
            "",
        ]
        contents="\n".join(lines).encode("utf-8")
        digest=hashlib.sha256(contents).hexdigest()
        if (row["payload_sha256"]!=digest or
            row["filename"]!=f"fictional_native_t_turn_{i:02d}_{digest[:16]}.txt" or
            "ChatGPT can make mistakes." in assistant["exact_text"]):
            raise RuntimeError("T uploaded clean source payload/hash drift")
    ledger=json.loads((T/"frozen_query_results.json").read_text(encoding="utf-8"))
    if ledger.get("trial_id")!="T" or set(ledger["queries"])!={case["id"] for case in plan["query_cases"]}:
        raise RuntimeError("Frozen T provider query ledger incomplete/extra")
    ranks={}
    for case in plan["query_cases"]:
        rec=ledger["queries"][case["id"]]
        ranked=rec["ranked_turns"]
        expected=[j+1 for j,turn in enumerate(ranked) if turn==case["expected_turn"]]
        rank=min(expected) if expected else None
        if (rec["after_turn"]!=case["after_turn"] or
            rec["target_rank"]!=rank or
            rec["top5_pass"]!=(rank is not None and rank<=case["max_rank"]) or
            any(type(x) is not int or x<1 or x>case["after_turn"] for x in ranked) or
            len(ranked)!=len(set(ranked))):
            raise RuntimeError("Frozen T hosted query rank/turn identity mismatch")
        ranks[case["id"]]=rank
    cfg=json.loads((T/"store.json").read_text(encoding="utf-8"))
    if cfg["name"]!=T_NAME or cfg["synthetic_only"] is not True:
        raise RuntimeError("T private hosted store binding mismatch")
    key=project_key()
    store=cfg["store_id"]
    remote=get(key,"/vector_stores/"+quote(store,safe=""))
    if (remote.get("id")!=store or remote.get("name")!=T_NAME or
        (remote.get("metadata") or {}).get("synthetic_only")!="true" or
        (remote.get("metadata") or {}).get("scope")!="ltm-rag-vnext-t" or
        (remote.get("expires_after") or {}).get("days")!=30 or
        (remote.get("file_counts") or {}).get("completed")!=5 or
        (remote.get("file_counts") or {}).get("total")!=5):
        raise RuntimeError("T hosted store identity/count/retention failed")
    for i,row in enumerate(mapping,1):
        file=get(key,"/vector_stores/"+quote(store,safe="")+
                 "/files/"+quote(row["file_id"],safe=""))
        attrs=file.get("attributes") or {}
        if (file.get("status")!="completed" or
            attrs.get("synthetic_only") is not True or
            attrs.get("conversation_id")!=CONV or
            attrs.get("turn_index")!=i or
            attrs.get("payload_sha256")!=row["payload_sha256"]):
            raise RuntimeError("Remote T verified file content association changed")
    if hashlib.sha256(M.read_bytes()).hexdigest()!=M_SHA:
        raise RuntimeError("Historical M/N/O/P six native events changed")
    scfg=json.loads((S/"store.json").read_text(encoding="utf-8"))
    source_store=get(key,"/vector_stores/"+quote(scfg["store_id"],safe=""))
    if ((source_store.get("file_counts") or {}).get("completed")!=5 or
        (source_store.get("file_counts") or {}).get("total")!=5):
        raise RuntimeError("Original S forensic hosted file count mutated")
    return {
        "verdict":"PASS_T_EXACT_NATIVE_UI_RENDERED_SOURCE_SQL_HOSTED",
        "pre_registered":True,"actual_native_chatgpt_replies":5,
        "original_simulated_owner_sends":5,"additional_native_sends":0,
        "clean_sql_original_message_count":10,
        "utc_ingestion_timestamps":10,
        "simulated_user_controller_send_timestamps":5,
        "unattested_original_assistant_send_timestamps":5,
        "clean_hosted_completed_files":5,
        "frozen_hosted_query_ranks":ranks,
        "original_contaminated_S_files_preserved":5,
        "original_sends_preserved":5,
        "historical_mcp_audit_unchanged":True,
        "real_user_chat_history_imported":False,
        "native_cross_chat_auto_retrieval_proven":False,
    }


if __name__=="__main__":
    print(json.dumps(audit(),sort_keys=True))
