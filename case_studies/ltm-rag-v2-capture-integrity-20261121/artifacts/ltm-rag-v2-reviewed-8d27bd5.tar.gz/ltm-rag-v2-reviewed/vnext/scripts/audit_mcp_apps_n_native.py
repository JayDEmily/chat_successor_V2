"""Independent Stage N preregistration, one-send and no-click native audit.

Read-only: no ChatGPT sends, no UI interaction, no real data. Private identifiers
are never written to the published results report.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
import uuid
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent
REG = "75f4d64b5616cacbbb648069be60320f0d88c4e7"
PARENT = "ec90ed9188b7090140ae20a0be83fe7b31e19241"
FROZEN = ("MCP_APPS_N_PROTOCOL_20261120.md","MCP_APPS_N_CASES_20261120.json")
M_OFFLINE = "9f67a287f598964c03ae157fadc82d0da8ff64e4"
M_PREFIX_SHA256 = "3697904ca3f7b744cb87e0b9f6a23628716d2375ee72a6396978972b16c0c19b"
AUDIT = ROOT / ".local/trial-m-mcp-audit.jsonl"
UI = ROOT / ".local/trial-n-native-ui-proof.json"
SEND = Path("/mnt/c/Users/james/AppData/Local/Temp/ltm_n_n01_send_once.json")
CLICK = Path("/mnt/c/Users/james/AppData/Local/Temp/ltm_n_n02_automated_click_once.json")
REPORT = ROOT / "MCP_APPS_N_NATIVE_RESULTS_20261120.md"
SCHEMA = {"event_id","timestamp_utc","tool","status","session_present",
          "subject_present","synthetic_only","source_count","original_user_text_attested"}


def git(*args: str) -> bytes:
    return subprocess.run(["git","-C",str(REPO),*args],check=True,capture_output=True).stdout


def audit():
    ancestry=git("rev-list","--parents","-n","1",REG).decode().strip()
    if ancestry != REG+" "+PARENT:
        raise RuntimeError("Stage N preregistration direct parent mismatch")
    hashes={}
    for name in FROZEN:
        content=(ROOT/name).read_bytes()
        if content != git("show",REG+":vnext/"+name):
            raise RuntimeError("Frozen N registration bytes drift: "+name)
        hashes[name]=hashlib.sha256(content).hexdigest()
    cases=json.loads((ROOT/FROZEN[1]).read_text(encoding="utf-8"))
    if (cases["registered_before_execution"] is not True or
        cases["synthetic_only"] is not True or len(cases["cases"])!=2 or
        [x["id"] for x in cases["cases"]]!=["N-N01","N-N02"] or
        cases["previous_m_audit_baseline_exact_events"]!=2 or
        cases["maximum_native_message_sends"]!=1 or
        cases["maximum_automated_widget_clicks"]!=1 or
        cases["ttl_seconds"]!=60):
        raise RuntimeError("Frozen N matrix count/scope drift")
    if (ROOT/"ltm_vnext/mcp_apps_m.py").read_bytes()!=git(
        "show",M_OFFLINE+":vnext/ltm_vnext/mcp_apps_m.py"):
        raise RuntimeError("Stage M native source changed after frozen N registration")
    if (ROOT/"ltm_vnext/mcp_apps_m_widget.html").read_bytes()!=git(
        "show",M_OFFLINE+":vnext/ltm_vnext/mcp_apps_m_widget.html"):
        raise RuntimeError("Stage M widget source changed")
    raw=AUDIT.read_bytes()
    lines=raw.splitlines(keepends=True)
    if len(lines)!=3:
        raise RuntimeError("Native audit count not exactly 3; investigate unexpected calls")
    if hashlib.sha256(b"".join(lines[:2])).hexdigest()!=M_PREFIX_SHA256:
        raise RuntimeError("Stage M original two-event audit prefix changed")
    rows=[json.loads(line) for line in lines]
    for row in rows:
        if (set(row)!=SCHEMA or row["source_count"]!=0 or
            row["session_present"] is not True or row["subject_present"] is not True or
            row["synthetic_only"] is not True or
            row["original_user_text_attested"] is not False):
            raise RuntimeError("Native audit envelope/privacy/source boundary changed")
        uuid.UUID(row["event_id"])
        if datetime.fromisoformat(row["timestamp_utc"]).tzinfo is None:
            raise RuntimeError("Audit event not timezone aware")
    if ([r["tool"] for r in rows]!=["open_topic_selector_m",
                                  "confirm_topic_m","open_topic_selector_m"] or
        [r["status"] for r in rows]!=["AWAITING_CONFIRMATION",
                                    "EXPIRED","AWAITING_CONFIRMATION"]):
        raise RuntimeError("Unexpected N native event tool/status sequence")
    if not SEND.exists() or CLICK.exists():
        raise RuntimeError("Native N Windows send or click guard mismatch")
    marker=json.loads(SEND.read_text(encoding="utf-8-sig"))
    frozen_prompt=cases["cases"][0]["prompt"]
    digest=hashlib.sha256(frozen_prompt.encode("utf-8")).hexdigest()
    if (marker["stage"]!="N" or marker["phase"]!="one_send_click_issued" or
        marker["plugin_id"]!=cases["stage_m_native_plugin_id"] or
        marker["prompt_sha256"]!=digest or marker["intended_send_count"]!=1 or
        marker["full_message_includes_ui_plugin_mention"] is not True):
        raise RuntimeError("Exact frozen N one-send marker unverified")
    evidence=json.loads(UI.read_text(encoding="utf-8"))
    if (evidence["stage"]!="N" or evidence["native_plugin_id"]!=cases["stage_m_native_plugin_id"] or
        evidence["prompt_sha256"]!=digest or
        evidence["native_send_marker_verified"] is not True or
        evidence["five_fictional_controls_visible_in_ui_automation"] is not True or
        evidence["initial_unselected_status_visible_in_ui_automation"] is not True or
        evidence["frozen_prompt_visible"] is not True or
        evidence["native_plugin_mention_visible"] is not True or
        evidence["controller_error_observed"]!="Widget button outside safe viewport" or
        evidence["click_marker_exists"] is not False or
        evidence["result"]!="N_NATIVE_WIDGET_RENDERED_CONTROLLER_VIEWPORT_GUARD_ABORTED_NO_CLICK" or
        evidence["elapsed_seconds_since_open_at_later_readback"]<=60 or
        evidence["human_consent_attested"] is not False or
        evidence["original_user_text_attested"] is not False):
        raise RuntimeError("Frozen N saved UI or later readback mismatch")
    return {
        "registration":REG,"parent":PARENT,"case_count":2,"frozen_hashes":hashes,
        "stage_m_prefix_sha256":M_PREFIX_SHA256,
        "native_stage_n_opening_events":1,"native_stage_n_confirmation_events":0,
        "one_send_marker":True,"one_automated_click_marker":False,
        "widget_rendered_with_five_fictional_buttons":True,
        "controller_failed_safe_viewport_test":True,
        "later_ui_button_inside_safe_viewport":evidence["merrow_within_frozen_safe_viewport_at_later_readback"],
        "later_readback_after_ttl":True,
        "native_source_packets_returned":0,
        "native_consent_attested":False,
        "original_text_attested":False,
        "positive_confirmation_proven":False,
        "decision":"NATIVE_N_UI_NOT_VERIFIED"
    }


def write_report(out):
    rows=[
      "# Stage N — single guarded native under-TTL confirmation probe",
      "",
      "**Verdict: `NATIVE_N_UI_NOT_VERIFIED` (the frozen click was withheld after a transient viewport guard failure); positive confirmation NOT established.**",
      "",
      "## Preregistration and invariants",
      "",
      f"- Frozen N registration Git commit `{REG}`, direct parent `{PARENT}`, byte-for-byte verified before result classification.",
      f"- Frozen protocol SHA-256 `{out['frozen_hashes'][FROZEN[0]]}`; matrix SHA-256 `{out['frozen_hashes'][FROZEN[1]]}`; exactly two cases N-N01 and N-N02.",
      "- Original Stage M Python server and widget byte-identical to pinned offline implementation; existing M tunnel/native plugin reused, without new key, plugin or listener change.",
      f"- First two Stage M audit event bytes preserved with original SHA-256 `{M_PREFIX_SHA256}`; Stage N added exactly **one** new event, not a replacement.",
      "",
      "## Actual Stage N observations",
      "",
      "- **N-N01: one frozen native prompt sent.** Windows one-send receipt verifies exact frozen request SHA-256 and plugin selection; the saved ChatGPT conversation independently displays the frozen text with a separate UI-added plugin mention.",
      "- Third native MCP audit event: one `open_topic_selector_m`, `AWAITING_CONFIRMATION`, session and subject presence flags true, original text un-attested and **0 source packets**.",
      "- Native embedded widget rendered all five fictional topic buttons and the initial unselected status.",
      "- **N-N02: no click.** The one-send/one-click controller stopped after reporting `Widget button outside safe viewport` rather than clicking unverified coordinates. The automated click marker is absent; the audit contains **no new `confirm_topic_m` event**.",
      "- A separate later UI readback found the Merrow button in the expected viewport (centre x=804, y=594), but that later readback was **after** the frozen 60-second TTL. It does **not** prove the button was in the viewport when the controller aborted. The temporal viewport discrepancy is unresolved.",
      "- No authenticated click, no successful positive confirmation, no human consent, no original-user-question provenance, and no source-data release.",
      "",
      "## Decision and stop rule",
      "",
      "Do not re-send N-N01 and do not click the expired N widget. The N native test did **not** satisfy the positive-confirmation acceptance predicate. It demonstrated correct fail-closed automation on uncertain UI geometry; that is not proof of successful UI selection.",
      "",
      "The same synthetic-only trust boundary applies: host-side app-only tool filtering and client-supplied session/subject correlation are **not** server-side authorisation or exact original user-message attestation. Stage I remains 14/16; Stage K's earlier four-call discrepancy remains.",
      "",
      "If a new positive native test is warranted, pre-register it separately and improve the controller's deterministic viewport recovery/settling before the next single send. Do not alter frozen N expectations or reuse its send marker.",
      "",
    ]
    REPORT.write_text("\n".join(rows),encoding="utf-8")
    print("N_NATIVE_REPORT_WRITTEN")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("status","write"))
    args=parser.parse_args()
    result=audit()
    print(json.dumps(result,sort_keys=True))
    if args.action=="write": write_report(result)

if __name__=="__main__":
    main()
