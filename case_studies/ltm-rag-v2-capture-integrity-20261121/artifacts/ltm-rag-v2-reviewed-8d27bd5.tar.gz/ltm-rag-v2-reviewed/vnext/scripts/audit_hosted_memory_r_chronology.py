"""Independent read-only Stage R ledger, source chronology and mapping audit.

No external API requests, inference, personal data, new files, or resends.
The separate run_hosted_memory_r.py verify checks hosted API file status.
"""
from __future__ import annotations
import hashlib
import json
import sqlite3
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from ltm_vnext.archive import Archive

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
REGISTERED="97b5c691c81862e782d32978bf33e56b15517ba5"
PARENT="b9589cc5c7af7432c12e6e0450f3fc860872e029"
R=ROOT/"fixtures/synthetic_diary_r_20261120.json"
DB=ROOT/".local/hosted-memory-r/synthetic_conversation.sqlite"
STATE=ROOT/".local/hosted-memory-r/results.json"
PLAN=ROOT/"HOSTED_MEMORY_R_CASES_20261120.json"
AUDIT=ROOT/".local/trial-m-mcp-audit.jsonl"


def git(*args):
    return subprocess.run(["git","-C",str(REPO),*args],
                          capture_output=True,check=True).stdout


def run():
    if git("rev-list","--parents","-n","1",REGISTERED).decode().strip()!=REGISTERED+" "+PARENT:
        raise RuntimeError("Frozen hosted R registration parent changed")
    for name in ("HOSTED_MEMORY_R_PROTOCOL_20261120.md",
                 "HOSTED_MEMORY_R_CASES_20261120.json",
                 "fixtures/synthetic_diary_r_20261120.json"):
        raw=(ROOT/name).read_bytes()
        if raw!=git("show",REGISTERED+":vnext/"+name):
            raise RuntimeError("Frozen registration byte drift: "+name)
    plan=json.loads(PLAN.read_text())
    original=json.loads(R.read_text())
    if (len(original["messages"])!=24 or
        plan["fixture_sha256"]!=hashlib.sha256(R.read_bytes()).hexdigest()):
        raise RuntimeError("Synthetic source fixture changed")
    sources={Archive._validate(x)["local_id"]:Archive._validate(x)
             for x in original["messages"]}
    if len(sources)!=24:
        raise RuntimeError("Duplicate original message identities")
    evidence=json.loads(STATE.read_text())
    queries=evidence.get("queries",{})
    if set(queries)!={r["id"] for r in plan["query_cases"]}:
        raise RuntimeError("Fewer or extra frozen hosted search responses")
    for case in plan["query_cases"]:
        row=queries[case["id"]]
        rank=row.get("target_rank")
        turns=row.get("ranked_turns")
        matches=[i+1 for i,turn in enumerate(turns) if turn in case["expected_turns"]]
        exact=min(matches) if matches else None
        if (row.get("query")!=case["query"] or
            row.get("after_turn")!=case["after_turn"] or
            row.get("expected_turns")!=case["expected_turns"] or
            rank!=exact or row.get("top5_pass")!=(rank is not None and rank<=5)):
            raise RuntimeError("Frozen hosted result/target rank mismatch: "+case["id"])
    with sqlite3.connect("file:"+str(DB)+"?mode=ro",uri=True) as c:
        c.row_factory=sqlite3.Row
        rows=c.execute("SELECT * FROM messages ORDER BY row_id").fetchall()
        maps=c.execute("SELECT * FROM hosted_r_files ORDER BY turn_index").fetchall()
        if len(rows)!=24 or len(maps)!=12:
            raise RuntimeError("SQLite source count/indexed turn count mismatch")
        by_id={row["local_id"]:row for row in rows}
        if set(by_id)!=set(sources):
            raise RuntimeError("Source identities changed")
        for row in rows:
            for key,value in sources[row["local_id"]].items():
                if row[key]!=value:
                    raise RuntimeError("Changed source bytes/provenance: "+key)
            if row["message_sent_at_source"] is not None or row["message_sent_at_utc"] is not None:
                raise RuntimeError("Frozen scripted R falsely claims original send time")
            ingest=row["ingested_at_utc"]
            if type(ingest) is not str or not ingest.endswith("Z"):
                raise RuntimeError("Missing UTC first-ingestion time")
            parsed=datetime.fromisoformat(ingest.replace("Z","+00:00"))
            if parsed.utcoffset()!=timezone.utc.utcoffset(None):
                raise RuntimeError("UTC ingestion instant invalid")
        expected_positions=list(range(1,25))
        if [row["position"] for row in sorted(rows,key=lambda z:z["position"])]!=expected_positions:
            raise RuntimeError("Canonical conversation order corrupted")
        for idx in range(12):
            turn=idx+1
            mapping=maps[idx]
            user,assistant=original["messages"][2*idx:2*idx+2]
            expected_ids=(Archive._validate(user)["local_id"], Archive._validate(assistant)["local_id"])
            if (mapping["turn_index"]!=turn or mapping["completed"]!=1 or
                (mapping["user_local_id"],mapping["assistant_local_id"])!=expected_ids or
                by_id[expected_ids[0]]["author_role"]!="user" or
                by_id[expected_ids[1]]["author_role"]!="assistant"):
                raise RuntimeError("Hosted mapping/role/turn sequence mismatch")
    if not AUDIT.is_file() or len(AUDIT.read_bytes().splitlines())!=6:
        raise RuntimeError("Historical native Stage P event count changed")
    return {"read_only":True,"registered_commit":REGISTERED,
            "synthetic_source_records":24,"utc_ingestion_timestamps":24,
            "source_authored_timestamps_known":0,"indexed_hosted_files":12,
            "frozen_search_cases":6,
            "top_five_hits":sum(bool(q["top5_pass"]) for q in queries.values()),
            "top_one_hits":sum(q["target_rank"]==1 for q in queries.values()),
            "native_events_unchanged":6,
            "decision":"PASS_R_SQLITE_CHRONOLOGY_AND_HOSTED_MAPPING_READBACK"}


if __name__=="__main__":
    print(json.dumps(run(),sort_keys=True))
