#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON="$ROOT/.venv/bin/python"
FIXTURE="$ROOT/fixtures/synthetic_conversations.json"
DATABASE="$ROOT/.local/synthetic-trial.sqlite"
AUDIT="$ROOT/.local/mcp-tool-audit.jsonl"

if [[ ! -x "$PYTHON" ]]; then
  echo "MCP virtualenv missing; install requirements-mcp.txt first" >&2
  exit 2
fi
mkdir -p "$ROOT/.local"
chmod 700 "$ROOT/.local"
export PYTHONPATH="$ROOT"
"$PYTHON" -m ltm_vnext.cli --db "$DATABASE" init
"$PYTHON" -m ltm_vnext.cli --db "$DATABASE" seed "$FIXTURE"
printf 'Synthetic MCP on 127.0.0.1:8787, audit %s\n' "$AUDIT"
exec "$PYTHON" -m ltm_vnext.mcp_server --db "$DATABASE" --port 8787 --audit-log "$AUDIT"
