# Stage S read-only native visual transcript reconciliation, no UI actions.
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$root='\\wsl.localhost\Ubuntu\home\jds\ltm-rag-vnext-20261118\vnext'
$private=Join-Path $root '.local\native-s-dialogue'
$wininfo=Get-Content -Raw 'C:\Users\james\AppData\Local\Temp\ltm_s_dedicated_window_once.json'|ConvertFrom-Json
$repo=Get-Content -Raw (Join-Path $root 'NATIVE_DIALOGUE_S_CASES_20261120.json')|ConvertFrom-Json
$prior=@()
for($i=1;$i -le 5;$i++){
 $path=Join-Path $private ('captured_'+$i.ToString('00')+'.json')
 if(-not (Test-Path $path)){throw 'Missing one native capture'}
 $prior+=Get-Content -Raw $path|ConvertFrom-Json
}
if(@($prior|Select-Object -ExpandProperty chat_url -Unique).Count -ne 1){throw 'Native chat URL changed'}
$rootEl=[Windows.Automation.AutomationElement]::RootElement
$win=@($rootEl.FindAll([Windows.Automation.TreeScope]::Children,[Windows.Automation.Condition]::TrueCondition)|
 Where-Object{$_.Current.ClassName -eq 'Chrome_WidgetWin_1' -and
  $_.Current.NativeWindowHandle -eq [int64]$wininfo.native_window_handle})
if($win.Count -ne 1){throw 'Stage S dedicated window absent'}
$es=$win[0].FindAll([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.Condition]::TrueCondition)
$addr=@($es|Where-Object {$_.Current.Name -eq 'Address and search bar' -and
 $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Edit'})
if($addr.Count -ne 1){throw 'Native address ambiguous'}
$url=$addr[0].GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern).Current.Value
if($url -ne $prior[0].chat_url){throw 'Wrong native conversation URL'}
$groups=@($es|Where-Object {$_.Current.Name -eq 'Conversation' -and
 $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Group'})
if($groups.Count -ne 1){throw 'Native conversation group absent'}
$els=$groups[0].FindAll([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.Condition]::TrueCondition)
$records=New-Object System.Collections.Generic.List[object]
$role=''
$parts=New-Object System.Collections.Generic.List[string]
foreach($el in $els){
 if($el.Current.ControlType.ProgrammaticName -ne 'ControlType.Text'){continue}
 $val=[string]$el.Current.Name
 if($val -eq 'You said:' -or $val -eq 'ChatGPT said:'){
  if($role -ne ''){$records.Add([ordered]@{role=$role;text=($parts -join "\n").Trim()})}
  $role=if($val -eq 'You said:'){'user'}else{'assistant'}
  $parts.Clear()
 }elseif($role -ne '' -and -not [string]::IsNullOrWhiteSpace($val)){$parts.Add($val)}
}
if($role -ne ''){$records.Add([ordered]@{role=$role;text=($parts -join "\n").Trim()})}
if($records.Count -ne 10){throw ('Native UI has wrong message node count '+$records.Count)}
for($i=0;$i -lt 5;$i++){
 $user=$records[2*$i]
 $assistant=$records[2*$i+1]
 if($user.role -ne 'user' -or $assistant.role -ne 'assistant'){throw 'Native alternating authorship changed'}
 if($user.text -ne $prior[$i].simulated_user_text){throw ('Native user source mismatch at turn '+($i+1))}
 if($assistant.text -ne $prior[$i].assistant_observed_text){throw ('Native assistant rendered source mismatch at turn '+($i+1))}
}
$stops=@($es|Where-Object{$_.Current.Name -eq 'Stop' -and
 $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Button'})
if($stops.Count){throw 'UI generation remains active'}
Write-Output 'S_NATIVE_UI_READBACK_PASS five_simulated_user_messages=true five_actual_assistant_outputs=true all_original_text_exact=true no_send=true no_click=true'
