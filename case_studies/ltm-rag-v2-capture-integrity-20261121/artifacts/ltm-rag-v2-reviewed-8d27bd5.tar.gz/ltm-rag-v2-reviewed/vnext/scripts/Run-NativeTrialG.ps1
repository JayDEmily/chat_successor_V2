# Trial G clean-context; isolated ChatGPT Project and separate read-only tunnel.
# Never send to other projects and never duplicate an unresolved pending send.
param(
    [ValidateRange(0,15)][int]$Start = 0,
    [ValidateRange(1,16)][int]$Count = 1
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

$root = '\\wsl.localhost\Ubuntu\home\jds\ltm-rag-vnext-20261118\vnext'
$planPath = Join-Path $root 'NATIVE_TRIAL_G_20261119.json'
$auditPath = Join-Path $root '.local\trial-g-mcp-audit.jsonl'
$resultPath = Join-Path $root '.local\native-trial-g-results.jsonl'
$pendingPath = Join-Path $root '.local\native-trial-g-pending.json'
$windowTitle = 'ChatGPT - LTM-RAG vNext Trial G Clean Context - Google Chrome'
$projectSlug = 'g-p-6afd806ca9348191accae58eea37c74c-ltm-rag-vnext-trial-g-clean-context'
$projectId = 'g-p-6afd806ca9348191accae58eea37c74c'
$projectName = 'LTM-RAG vNext Trial G Clean Context'
$plan = Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json
if ($plan.cases.Count -ne 16 -or $plan.trial_id -ne 'ltm-vnext-native-trial-g-cleancontext-20261119') {
    throw 'Locked test plan does not match expected trial'
}
if ($Start + $Count -gt 16) { throw 'Requested cases exceed locked plan' }
if (Test-Path -LiteralPath $pendingPath) { throw 'PREVIOUS_PENDING_SEND: inspect before any further automated send' }

$previous = @()
if (Test-Path -LiteralPath $resultPath) {
    $previous = @(Get-Content -LiteralPath $resultPath | Where-Object { $_.Trim() -ne '' } | ForEach-Object { $_ | ConvertFrom-Json })
}
if ($previous.Count -ne $Start) {
    throw "Ledger count $($previous.Count) differs from requested Start $Start"
}
$desktop = [System.Windows.Automation.AutomationElement]::RootElement
$topWindows = $desktop.FindAll([System.Windows.Automation.TreeScope]::Children, [System.Windows.Automation.Condition]::TrueCondition)
$handleFile = Join-Path $root '.local\trial-g-window-handle.txt'
if (-not (Test-Path -LiteralPath $handleFile)) { throw 'TRIAL_G_WINDOW_HANDLE_FILE_MISSING' }
$registeredHandle = [int](Get-Content -LiteralPath $handleFile -Raw)
$projectWindows = @($topWindows | Where-Object {
    $_.Current.NativeWindowHandle -eq $registeredHandle -and $_.Current.ClassName -eq 'Chrome_WidgetWin_1'
})
if ($projectWindows.Count -ne 1) { throw "Expected one isolated synthetic Project Chrome window, found $($projectWindows.Count)" }
$window = $projectWindows[0]
$elementsBefore = $window.FindAll([System.Windows.Automation.TreeScope]::Descendants, [System.Windows.Automation.Condition]::TrueCondition)
$addressEditors = @($elementsBefore | Where-Object {
    $_.Current.Name -eq 'Address and search bar' -and
    $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Edit'
})
if ($addressEditors.Count -ne 1) { throw 'Isolated test window has no unique address bar' }
$initialAddress = $addressEditors[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
if ($initialAddress -notlike "chatgpt.com/g/$projectSlug/*" -and
    $initialAddress -notlike "chatgpt.com/g/$projectId/*") {
    throw "Wrong Project location: $initialAddress"
}
Write-Output "ISOLATED_PROJECT_WINDOW_VERIFIED handle=$($window.Current.NativeWindowHandle) url=$initialAddress"

function Get-Elements {
    return ,$window.FindAll([System.Windows.Automation.TreeScope]::Descendants, [System.Windows.Automation.Condition]::TrueCondition)
}
function Select-Elements([object]$items,[string]$name,[string]$typeName) {
    return @($items | Where-Object { $_.Current.Name -eq $name -and $_.Current.ControlType.ProgrammaticName -eq $typeName })
}
function Require-One([object]$items,[string]$name,[string]$typeName) {
    $found = @(Select-Elements $items $name $typeName)
    if ($found.Count -ne 1) {
        throw "Expected one $typeName '$name', found $($found.Count)"
    }
    return $found[0]
}
function Audit-Events {
    if (-not (Test-Path -LiteralPath $auditPath)) { throw "Audit log missing" }
    return @(Get-Content -LiteralPath $auditPath |
        Where-Object { $_.Trim() -ne '' } |
        ForEach-Object { $_ | ConvertFrom-Json })
}
function Chat-URL {
    $all = Get-Elements
    $a = Require-One $all 'Address and search bar' 'ControlType.Edit'
    return $a.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
}
function Get-ConversationText([object]$items) {
    $conv = @($items | Where-Object { $_.Current.ControlType.ProgrammaticName -eq 'ControlType.Group' -and $_.Current.Name -eq 'Conversation' })
    if ($conv.Count -ne 1) { return '' }
    $desc = $conv[0].FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition)
    $pastAssistant = $false
    $bits = New-Object System.Collections.Generic.List[string]
    foreach ($el in $desc) {
        if ($el.Current.ControlType.ProgrammaticName -ne 'ControlType.Text') { continue }
        $name = $el.Current.Name
        if ($name -eq 'ChatGPT said:') { $pastAssistant = $true; continue }
        if ($pastAssistant -and -not [string]::IsNullOrWhiteSpace($name)) { $bits.Add($name) }
    }
    return ($bits -join ' ')
}
function Append-Result([object]$item) {
    $json = ConvertTo-Json -InputObject $item -Compress -Depth 8
    [System.IO.File]::AppendAllText($resultPath, $json + [Environment]::NewLine, [System.Text.Encoding]::UTF8)
}

for ($i=$Start; $i -lt ($Start+$Count); $i++) {
    if ($i -eq 0) {
        $beforeFirst=Get-Elements
        $empty=@($beforeFirst|Where-Object{ $_.Current.Name -eq 'No chats' -and $_.Current.ControlType.ProgrammaticName -eq 'ControlType.ListItem' })
        if ($empty.Count -ne 1) { throw 'G01_REQUIRES_EMPTY_PROJECT' }
        Write-Output 'G01_EMPTY_PROJECT_CONFIRMED'
    }
    $test = $plan.cases[$i]
    $stamp = [DateTimeOffset]::UtcNow.ToString('o')
    $beforeEvents = @(Audit-Events)
    $beforeIds = @{}
    foreach ($ev in $beforeEvents) { $beforeIds[$ev.event_id] = $true }
    $all = Get-Elements
    $editor = $null
    $existing = @(Select-Elements $all "New chat in $projectName" 'ControlType.Edit')
    if ($existing.Count -eq 1) {
        $existingValue = $existing[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
        if ($existingValue -eq $test.prompt) {
            $editor = $existing[0]
            Write-Output "RESUMING_OWN_UNSENT_DRAFT $($test.id)"
        } elseif ($existingValue.Trim() -ne '' -and $existingValue.Trim() -ne "New chat in $projectName") {
            throw 'UNRELATED_PROJECT_DRAFT: will not overwrite'
        }
    }
    if ($null -eq $editor) {
        $newChat = Require-One $all "New chat in $projectName" 'ControlType.Button'
        $newChat.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
        for($retry=0;$retry -lt 20;$retry++){
            Start-Sleep -Milliseconds 650
            $all = Get-Elements
            $editors = @(Select-Elements $all "New chat in $projectName" 'ControlType.Edit')
            if($editors.Count -eq 1){$editor=$editors[0];break}
        }
    }
    if ($null -eq $editor) { throw "NO_PROJECT_EDITOR before send $($test.id)" }
    $current = $editor.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value.Trim()
    if ($current -ne '' -and $current -ne "New chat in $projectName" -and $current -ne $test.prompt) {
        throw "NONEMPTY_PROJECT_DRAFT: refusing overwrite for $($test.id)"
    }
    $editor.SetFocus()
    $editor.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue($test.prompt)
    $all = Get-Elements
    $editor = Require-One $all "New chat in $projectName" 'ControlType.Edit'
    $confirmed = $editor.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
    if ($confirmed -ne $test.prompt) {
        Start-Sleep -Milliseconds 500
        $confirmed = $editor.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
    }
    if ($confirmed -ne $test.prompt) { throw "DRAFT_MISMATCH: $($test.id), no send" }
    $chips = @(Select-Elements $all 'LTM-RAG vNext Clean G' 'ControlType.Text')
    if ($chips.Count -ne 0) { throw "EXPLICIT_PLUGIN_CHIP: $($test.id), no send" }
    $send = $null
    for ($readyTry=0;$readyTry -lt 12;$readyTry++) {
        $all = Get-Elements
        $ready = @(Select-Elements $all 'Send' 'ControlType.Button')
        if ($ready.Count -eq 1 -and $ready[0].Current.IsEnabled) {
            $send=$ready[0]; break
        }
        Start-Sleep -Milliseconds 400
    }
    if ($null -eq $send) { throw "SEND_NOT_READY: $($test.id), no send" }

    $addressBeforeSend = Chat-URL
    if ($addressBeforeSend -notlike "chatgpt.com/g/$projectSlug/*" -and
        $addressBeforeSend -notlike "chatgpt.com/g/$projectId/*") {
        throw "PROJECT_NAVIGATION_CHANGED: refusing send of $($test.id)"
    }
    $hasher=[System.Security.Cryptography.SHA256]::Create()
    try { $hashBytes=$hasher.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($test.prompt)) }
    finally { $hasher.Dispose() }
    $promptHash=([BitConverter]::ToString($hashBytes)).Replace('-','').ToLowerInvariant()
    $pending = [ordered]@{case_id=$test.id; ordinal=($i+1); written_at_utc=$stamp;
       state='about_to_send'; prompt_sha256=$promptHash; audit_before=$beforeEvents.Count; project_id=$projectId}
    [System.IO.File]::WriteAllText($pendingPath,(ConvertTo-Json $pending -Compress),[System.Text.Encoding]::UTF8)
    $send.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
    Write-Output "SENT $($i+1)/16 $($test.id) $($test.kind)"
    $sentClock = [DateTimeOffset]::UtcNow

    $done = $false
    $responseText = ''
    $url = ''
    $stable = 0
    $lastText = ''
    for($poll=0;$poll -lt 75;$poll++) {
        if (([DateTimeOffset]::UtcNow - $sentClock).TotalSeconds -ge 120) {
            throw "RESPONSE_TIMEOUT_PRESERVE_PENDING: $($test.id), no navigation or retry"
        }
        Start-Sleep -Seconds 2
        $all = Get-Elements
        $stopBtns = @(Select-Elements $all 'Stop' 'ControlType.Button')
        $said = @(Select-Elements $all 'ChatGPT said:' 'ControlType.Text')
        $address = @(Select-Elements $all 'Address and search bar' 'ControlType.Edit')
        if ($address.Count -eq 1) {
            $url = $address[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
        }
        if ($said.Count -lt 1 -or $stopBtns.Count -gt 0 -or $url -notmatch [regex]::Escape($projectId) -or $url -notmatch '/c/[a-z0-9-]+') {
            $stable = 0
            continue
        }
        $responseText = Get-ConversationText $all
        if ([string]::IsNullOrWhiteSpace($responseText)) { continue }
        if ($lastText -eq $responseText) { $stable++ } else { $stable = 0 }
        $lastText = $responseText
        if ($stable -ge 1) { $done = $true; break }
    }

    if (-not $done) {
        throw "RESPONSE_INCOMPLETE_PRESERVE_PENDING: $($test.id), no navigation or retry"
    }
    $afterEvents = @(Audit-Events)
    $added = @($afterEvents | Where-Object { -not $beforeIds.ContainsKey($_.event_id) })
    $lookups = @($added | Where-Object { $_.tool -eq 'lookup_evidence' })
    $fetches = @($added | Where-Object { $_.tool -eq 'fetch_source' })
    $initiation = $lookups.Count -gt 0
    $expectedLookup = $test.lookup_expected
    $tracePass = $null
    if ($null -ne $expectedLookup) {
        $tracePass = if ($expectedLookup) { $done -and $initiation } else { $done -and -not $initiation }
    }
    $record = [ordered]@{ prompt_sha256=$promptHash;
        id=$test.id; kind=$test.kind; ordinal=($i+1);
        sent_at_utc=$stamp; observed_at_utc=[DateTimeOffset]::UtcNow.ToString('o');
        completed=$done; chat_url=$url;
        lookup_count=$lookups.Count; fetch_count=$fetches.Count;
        added_event_ids=@($added|ForEach-Object{$_.event_id});
        expected_lookup=$expectedLookup; trace_pass=$tracePass;
        semantic_review='PENDING'; review_concepts=@($test.review_concepts);
        answer_text=$responseText;
        ambiguity_note=if($done){''}else{'Timed out or could not verify isolated Project response'}
    }
    Append-Result $record
    Remove-Item -LiteralPath $pendingPath -Force
    Write-Output "RESULT $($test.id) complete=$done lookup=$($lookups.Count) fetch=$($fetches.Count) trace=$tracePass semantic=PENDING events=$($added.Count)"
}
Write-Output "TRIAL_SEGMENT_COMPLETE count=$Count start=$Start"
