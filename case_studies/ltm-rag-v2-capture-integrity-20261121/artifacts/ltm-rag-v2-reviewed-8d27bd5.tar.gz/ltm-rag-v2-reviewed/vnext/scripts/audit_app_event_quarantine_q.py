"""Independent Stage Q Git provenance, synthetic fixture and 21-case audit.

No native tool invocation, web access, plugin activity or real source data.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
REG="bf46933c18862392d200f8aa8a1e5d81ac57be9d"
PARENT="4768bf6c79dc72528c3eddf630a3cf3f08152816"
FROZEN=("MCP_APPS_Q_PROTOCOL_20261120.md",
        "MCP_APPS_Q_CASES_20261120.json")
ORIGINAL=ROOT/"fixtures/synthetic_clean_g.json"
AUDIT=ROOT/".local/trial-m-mcp-audit.jsonl"
RESULT=ROOT/"MCP_APPS_Q_OFFLINE_RESULTS_20261120.md"
IMPL=ROOT/"ltm_vnext/app_event_quarantine_q.py"
CASE_TEST=ROOT/"tests/test_app_event_quarantine_q.py"


def git(*args):
    return subprocess.run(["git","-C",str(REPO),*args],
                          capture_output=True,check=True).stdout


def run():
    if git("rev-list","--parents","-n","1",REG).decode().strip()!=REG+" "+PARENT:
        raise RuntimeError("Stage Q Git preregistration direct parent mismatch")
    hashes={}
    for name in FROZEN:
        body=(ROOT/name).read_bytes()
        if body!=git("show",REG+":vnext/"+name):
            raise RuntimeError("Frozen Stage Q file bytes drift: "+name)
        hashes[name]=hashlib.sha256(body).hexdigest()
    plan=json.loads((ROOT/FROZEN[1]).read_text(encoding="utf-8"))
    if (plan["trial_id"]!="ltm-vnext-q-app-event-quarantine-source-scope-20261120" or
        plan["parent"]!=PARENT or
        plan["synthetic_only"] is not True or
        plan["registered_before_implementation"] is not True or
        plan["native_sends"]!=0 or plan["native_clicks"]!=0 or
        plan["source_release_from_native_app_event"] is not False or
        plan["case_count"]!=21 or len(plan["cases"])!=21 or
        [c["id"] for c in plan["cases"]]!=[f"Q{i:02d}" for i in range(1,22)]):
        raise RuntimeError("Stage Q frozen case order/scope changed")
    original=json.loads(ORIGINAL.read_text(encoding="utf-8"))
    if (hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()!=plan["fixture_sha256"] or
        original["synthetic"] is not True or
        len(original["messages"])!=20):
        raise RuntimeError("Original synthetic source fixture changed")
    # The quarantine module is deliberately not permitted to reach the source
    # archive/owner gateway; this is a narrow static dependency check, NOT
    # an arbitrary-Python sandbox or production security mechanism.
    tree=ast.parse(IMPL.read_text(encoding="utf-8"))
    imports=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Import):
            imports.extend(alias.name for alias in node.names)
        if isinstance(node,ast.ImportFrom) and node.module:
            imports.append(node.module)
    if set(imports)!={"__future__","collections.abc","typing"}:
        raise RuntimeError("Q quarantine unexpectedly imports a source/network/owner dependency")
    from ltm_vnext.app_event_quarantine_q import AppEventQuarantineQ
    if not all(hasattr(AppEventQuarantineQ,method) for method in
               ("observe_app_result","model_source_attempt")):
        raise RuntimeError("Quarantine public interface missing")
    if any(hasattr(AppEventQuarantineQ,method) for method in (
        "confirm_from_owner_ui","resolve_tool_call","register_trusted_turn")):
        raise RuntimeError("Source or trusted owner operation exposed on quarantine")
    suite=unittest.defaultTestLoader.discover(
        start_dir=str(ROOT/"tests"), pattern="test_app_event_quarantine_q.py",
        top_level_dir=str(ROOT/"tests"))
    if suite.countTestCases()!=21:
        raise RuntimeError("Frozen Q test discovery count not 21")
    stream=io.StringIO()
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    if (not result.wasSuccessful() or result.testsRun!=21 or
        result.skipped or result.expectedFailures or result.unexpectedSuccesses):
        raise RuntimeError("Stage Q failed/skip/unknown case:\n"+stream.getvalue())
    mentioned=re.findall(r"test_(q\d{2}) ",stream.getvalue())
    if mentioned != [f"q{i:02d}" for i in range(1,22)]:
        raise RuntimeError("Frozen Q named test identities mismatch")
    # The existing Stage L 20-case evidence is re-audited independently; the
    # simulated owner callback is intentionally not imported into Q code.
    check=subprocess.run(
        [sys.executable,str(ROOT/"scripts/audit_clarification_l.py"),"status"],
        env={**os.environ,"PYTHONPATH":str(ROOT)},
        cwd=REPO, capture_output=True,text=True,check=True)
    l_result=json.loads(check.stdout.strip().splitlines()[-1])
    if l_result["passed"]!=20 or l_result["originals_validated"]!=20:
        raise RuntimeError("Original L simulated owner scope audit regressed")
    # Preserve native events. No new Q native test/sends/clicks are authorised.
    if not AUDIT.exists():
        raise RuntimeError("Existing private native audit unavailable")
    raw=AUDIT.read_bytes()
    events=[json.loads(row) for row in raw.splitlines()]
    want=[("open_topic_selector_m","AWAITING_CONFIRMATION"),
          ("confirm_topic_m","EXPIRED"),
          ("open_topic_selector_m","AWAITING_CONFIRMATION"),
          ("open_topic_selector_m","AWAITING_CONFIRMATION"),
          ("open_topic_selector_m","AWAITING_CONFIRMATION"),
          ("confirm_topic_m","CONFIRMED")]
    if (len(events)!=6 or
        [(x["tool"],x["status"]) for x in events]!=want or
        any(x["source_count"]!=0 or x["synthetic_only"] is not True or
            x["original_user_text_attested"] is not False for x in events)):
        raise RuntimeError("Original native M/N/O/P audit unexpectedly changed")
    return {
      "registration":REG,"parent":PARENT,
      "frozen_hashes":hashes,"original_source_messages":20,
      "frozen_cases":21,"passed":result.testsRun,
      "l_original_offline_cases_reaudited":l_result["passed"],
      "native_audit_count_unchanged":6,
      "native_audit_sha256":hashlib.sha256(raw).hexdigest(),
      "native_messages_sent_by_q":0,"source_packets_from_native_result":0,
      "quarantine_has_no_source_or_owner_gateway_imports":True,
      "outcome":"PASS_Q_APP_EVENT_QUARANTINED_AND_OFFLINE_OWNER_SCOPE_SEPARATED",
    }


def write_report(result):
    lines=[
     "# Stage Q — native app event quarantine / offline source-scope separation",
     "",
     "**PASS_Q_APP_EVENT_QUARANTINED_AND_OFFLINE_OWNER_SCOPE_SEPARATED — 21/21 frozen Q cases PASS; no native calls, no packet release from native event.**",
     "",
     "## Immutable evidence and tests",
     "",
     f"- Preregistration Git commit `{REG}`, direct parent `{PARENT}`; both protocol and case matrix byte-identical to frozen Git blobs.",
     f"- Frozen protocol SHA-256 `{result['frozen_hashes'][FROZEN[0]]}`.",
     f"- Frozen matrix SHA-256 `{result['frozen_hashes'][FROZEN[1]]}`.",
     f"- `{result['frozen_cases']}/21` dynamically named, strictly ordered cases independently discovered and run; zero skips, failures or expected-failure substitutions.",
     "- Original 20-message fictional fixture SHA-256 and manifest topic identity verified; separate Stage L audit rerun **20/20**, including packet contents, authorship/correction links and one-shot owner scope.",
     f"- Historical native M/N/O/P audit still **six** events, SHA-256 `{result['native_audit_sha256']}`, with zero source packets and no original-user-text attestation. Stage Q sent **zero** native ChatGPT messages/clicks.",
     "",
     "## Narrow implementation and outcomes",
     "",
     "- `ltm_vnext/app_event_quarantine_q.py` has no resolver, owner gateway, archive or network dependency. Its public API only accepts the precise Stage M public structured event envelope or rejects it; no source-return or owner-confirmation port is present. This is static/functional evidence, **not a Python security sandbox**.",
     "- Q01–Q05: five valid-looking fictional `CONFIRMED` responses are explicitly **`QUARANTINED_APP_EVENT`** with `owner_authorised=false`, empty packets and no promoted selected topic.",
     "- Q06–Q12: malformed or forged events rejected: model-supplied topic, false human/original-message attestation, nonzero count, fabricated packet, missing flag and unknown topic.",
     "- Q13–Q15: `DENIED`, `EXPIRED` and `AWAITING_CONFIRMATION` remain non-confirmed with no source.",
     "- Q16: model-origin arguments cannot access any sources through quarantine.",
     "- Q17–Q21: a **separate** Stage L simulated owner-controlled gateway, explicitly outside quarantine, retains its existing single-topic, one-shot replay, canonical multi-topic and I05/I15 original-question limitations. It can release original fictional packets only on its own assumed owner confirmation.",
     "",
     "## Admission boundary",
     "",
     "**Stage P confirmed app-only callback transport, not authenticated user approval.** Neither client-supplied session/subject nor `InvokePattern` attests a real person's approval or the original user's current words. Quarantine must never be wired into a source-release API. Source packets may become available only through a future independently authenticated owner ingress tested in a separate environment. The Stage L comparator's grant is simulated and is not such authentication.",
     "",
     "The Stage I I05/I15 referent failures remain unresolved; Stage K's previously recorded call-count deviation remains. Existing M source, tunnel, plugin and all previous native quotas unchanged; no real histories, external inference, credentials, production changes or OS autostart.",
     "",
    ]
    RESULT.write_text("\n".join(lines),encoding="utf-8")
    print("Q_OFFLINE_RESULT_WRITTEN")


def main():
    arg=argparse.ArgumentParser()
    arg.add_argument("action",choices=["status","write"])
    a=arg.parse_args()
    result=run()
    print(json.dumps(result,sort_keys=True))
    if a.action=="write": write_report(result)


if __name__=="__main__":
    main()
