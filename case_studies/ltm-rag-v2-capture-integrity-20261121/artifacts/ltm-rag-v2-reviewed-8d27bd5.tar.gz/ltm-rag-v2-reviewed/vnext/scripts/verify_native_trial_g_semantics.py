"""Validate the separate human-style source-fidelity review of native Trial G.

Keyword tests verify that recorded assessments refer to observable answer text;
they are NOT substitutes for the source/attribution reasoning in the review.
"""
from __future__ import annotations
import argparse
import json
from collections import Counter
from pathlib import Path
from scripts.summarise_native_trial_g import verify, ROOT, load

REVIEW=ROOT/"NATIVE_TRIAL_G_SEMANTIC_REVIEW_20261119.json"
FIXTURE=ROOT/"fixtures/synthetic_clean_g.json"
REPORT=ROOT/"NATIVE_TRIAL_G_SEMANTIC_RESULTS.md"
GOOD={"PASS_SOURCE_FIDELITY","PASS_ABSTENTION","PASS_UNRELATED"}
BAD={"FAIL_UNSUPPORTED_REFERENT"}
ALLOWED=GOOD|BAD

def examine():
    summary,checked=verify()
    if not summary["complete"] or len(checked)!=16:
        raise ValueError("Cannot adjudicate incomplete G trial")
    review=json.loads(REVIEW.read_text(encoding="utf8"))
    fixture=json.loads(FIXTURE.read_text(encoding="utf8"))
    if review.get("review_id")!="native-g-independent-fixture-review-20261119":
        raise ValueError("Review identity mismatch")
    grades=review["reviewed_cases"]
    messages={m["message_id"]:m for m in fixture["messages"]}
    if len(grades)!=16 or len({x["id"] for x in grades})!=16:
        raise ValueError("Review case IDs missing/duplicated")
    output=[]
    for (case,row,trace),grade in zip(checked,grades):
        cid=case["id"]
        if grade["id"]!=cid or grade["verdict"] not in ALLOWED:
            raise ValueError("Review/ledger ID or verdict mismatch: "+cid)
        for srcid in grade["source_ids"]:
            if srcid not in messages:
                raise ValueError("Unknown original source: "+srcid)
        for marker in grade["required_answer_markers"]:
            if marker.casefold() not in row["answer_text"].casefold():
                raise ValueError("Review marker not observable "+cid+": "+marker)
        verdict=grade["verdict"]
        if case["kind"]=="ambiguous" and verdict!="FAIL_UNSUPPORTED_REFERENT":
            raise ValueError("Ambiguous question review inconsistency")
        if case["kind"]=="unrelated" and (
            verdict!="PASS_UNRELATED" or row["lookup_count"]!=0 or row["fetch_count"]!=0):
            raise ValueError("Unrelated selectivity or answer review inconsistency")
        if case["kind"]=="alternative_requested":
            claimed=grade["source_ids"][0]
            if messages[claimed]["branch_id"]!="alternative" or messages[claimed]["author_role"]!="assistant":
                raise ValueError("Alternative-branch authorship conflated")
        if case["kind"]=="reported_speech":
            source_recollections=[s for s in grade["source_ids"] if s in ("g05","g07")]
            if not source_recollections or any(messages[s]["attribution"]!="reported_recollection" for s in source_recollections):
                raise ValueError("Recollection attribution failure")
        if not grade.get("assessment"):
            raise ValueError("Unexplained semantic result")
        output.append((case,row,trace,grade))
    return summary,output

def write_report(summary,reviewed):
    counts=Counter(grade["verdict"] for _,_,_,grade in reviewed)
    lines=[
        "# Trial G — retrospective original-source semantic review","",
        "This review separately inspected all 16 saved native answers against the",
        "original 20-record fictional G archive, its authorship, branch IDs,",
        "correction edges and reported-speech source labels. A separate script",
        "validated source-ID membership, review markers, complete records and",
        "the entire local successful MCP event ledger. Marker checks alone",
        "are not a proof of semantic correctness.","",
        f"**14/16** semantically acceptable responses; **2/16** unsupported",
        "referent selection failures (G13/G14).",
        f"Source-dependent G01–G12: **12/12** acceptable main conclusions and",
        "**12/12** with successful G lookup initiation.",
        f"Unrelated G15–G16: **2/2** technically adequate without G lookup.",
        f"Recorded successful calls: **{summary['counts']['lookup_calls']} lookups**,",
        f"**{summary['counts']['fetch_calls']} separate fetch_source calls**.","",
        "| Case | Source/content judgement | Lookup | Supporting fictional source IDs |",
        "|---|---|---:|---|",
    ]
    for case,row,_,grade in reviewed:
        lines.append(f"| {case['id']} | {grade['verdict']} | {row['lookup_count']} "
                     f"| {', '.join(grade['source_ids']) or 'none'} |")
    lines.extend([
        "","## Specific findings and limitations","",
        "**G01 first clean turn:** The answer selected locker 9 and the cobalt",
        "optic, attributed it to main-branch user correction g03, included its",
        "stable fixture locator and distinguished it from superseded g01.",
        "The server's separate source-byte/hash smoke test passed. Native G01",
        "had one successful source lookup but no separate source fetch.",
        "G01's saved result predates the runner prompt-hash enhancement; the",
        "first Send was preceded by frozen-prompt UI verification.","",
        "**Correction/branch authenticity:** G02–G08 preserved the original,",
        "corrected and alternative-branch identities. The alternative pier 7",
        "and red cabinet statements were correctly identified as assistant",
        "speculation rather than user corrections.","",
        "**Reported speech:** G09 reproduced both Vela recollections consistent",
        "with g05/g07. G10 correctly refused to infer authenticated audio",
        "from user-reported recollection and the assistant's archive description.",
        "G11/G12 invented neither a SOVA serial number nor a Vela audio file.","",
        "**Ambiguous referents:** G13 and G14 confidently assumed the Merrow",
        "narrative, although neither question identified a narrative.",
        "Both made a successful lookup, but a retrieval result cannot establish",
        "which narrative the user meant. This is a semantic FAIL, not a",
        "missed tool-call failure.","",
        "**Causal and completeness limits:** Only G01 ran in a previously",
        "chat-empty Project. G02–G16 may use prior conversations within",
        "that same Project even though its settings were read back as",
        "Project-only. All native history-needed cases did invoke the new",
        "source lookup, but no native G case invoked the separate fetch_source",
        "tool. Successful lookup responses can contain source text and",
        "metadata; absence of an explicit fetch should not be disguised.",
        "These 16 synthetic cases do not establish population reliability.",
        "No real conversation history, original MCP configuration, or",
        "Windows/Ubuntu automatic startup was changed.","",
        "The local complete answer ledger and tool audit remain Git-ignored.",
        "Saved Project conversations are linked in NATIVE_TRIAL_G_TRACE_RESULTS.md.",
        "",
    ])
    REPORT.write_text("\n".join(lines),encoding="utf8")

def main():
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=("status","write"))
    action=p.parse_args().action
    summary,reviewed=examine()
    grades=Counter(grade["verdict"] for _,_,_,grade in reviewed)
    print(json.dumps({"reviewed_cases":len(reviewed),"verdicts":dict(grades),
                      "lookups":summary["counts"]["lookup_calls"],
                      "fetches":summary["counts"]["fetch_calls"]},sort_keys=True))
    if action=="write":
        write_report(summary,reviewed)
        print("TRIAL_G_SEMANTIC_REPORT_WRITTEN")

if __name__=="__main__":
    main()
