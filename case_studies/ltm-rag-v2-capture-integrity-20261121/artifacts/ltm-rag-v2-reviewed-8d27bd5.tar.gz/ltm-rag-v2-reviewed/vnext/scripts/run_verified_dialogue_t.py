"""Stage T read-only verified native source -> clean SQL + OpenAI Vector Store.

Stage S original five native sends and five index files remain unchanged.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

from ltm_vnext.native_dialogue_s import StageSFailure, _private_write
from ltm_vnext.verified_dialogue_t import (
 NativeVerifiedT, T_PLAN, PRIVATE_T
)

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
REGISTERED="da3232c5c999255b551ae876f3b1d169a277f1db"
PARENT="a02192ef14c86242532e9ab22c61a64c590cecd1"
FROZEN=("NATIVE_DIALOGUE_T_PROTOCOL_20261120.md","NATIVE_DIALOGUE_T_CASES_20261120.json")
QUERIES=PRIVATE_T/"frozen_query_results.json"


def git(*args):
    return subprocess.run(["git","-C",str(REPO),*args],capture_output=True,check=True).stdout


def registered():
    if git("rev-list","--parents","-n","1",REGISTERED).decode().strip()!=REGISTERED+" "+PARENT:
        raise StageSFailure("Git T registration parent changed")
    for name in FROZEN:
        if (ROOT/name).read_bytes()!=git("show",REGISTERED+":vnext/"+name):
            raise StageSFailure("Frozen Stage T protocol/matrix changed "+name)
    if not PRIVATE_T.joinpath("verified_transcript.json").exists():
        raise StageSFailure("Independently UI-verified private transcript missing")
    plan=json.loads(T_PLAN.read_text(encoding="utf-8"))
    if (hashlib.sha256(PRIVATE_T.joinpath("verified_transcript.json").read_bytes()).hexdigest()
            !=plan["verified_private_transcript_sha256"]):
        raise StageSFailure("Private verified original UI transcript hash changed")
    if plan["additional_native_sends_allowed"]!=0:
        raise StageSFailure("Stage T must forbid extra native sends")
    original=ROOT/".local/native-s-dialogue"
    if (len(list(original.glob("send_once_*.json")))!=5 or
        len(list(original.glob("captured_*.json")))!=5):
        raise StageSFailure("Original five send-once actions/captures are not exactly five")
    for index in range(1,6):
        raw=original/f"captured_{index:02d}.json"
        if hashlib.sha256(raw.read_bytes()).hexdigest()!=plan["raw_private_capture_sha256"][index-1]:
            raise StageSFailure("Original Stage S raw capture bytes changed")
    os.chmod(PRIVATE_T,0o700)
    os.chmod(PRIVATE_T/"verified_transcript.json",0o600)
    return plan


def measured_index(pipeline:NativeVerifiedT,plan:dict,after_turn:int):
    source={"trial_id":"T","queries":{}}
    if QUERIES.exists():
        source=json.loads(QUERIES.read_text(encoding="utf-8"))
    if source.get("trial_id")!="T" or not isinstance(source.get("queries"),dict):
        raise StageSFailure("Private T query ledger changed")
    for case in plan["query_cases"]:
        if case["after_turn"]!=after_turn or case["id"] in source["queries"]:
            continue
        hits=pipeline.search(case["query"],top=10)
        ranked=[row["turn"] for row in hits]
        matches=[i+1 for i,turn in enumerate(ranked)
                 if turn==case["expected_turn"]]
        rank=min(matches) if matches else None
        source["queries"][case["id"]]={
            "after_turn":after_turn,"target_rank":rank,
            "ranked_turns":ranked,
            "top5_pass":rank is not None and rank<=case["max_rank"],
        }
        _private_write(QUERIES,source)
        print("T_HOSTED_QUERY",case["id"],"target_rank="+str(rank),
              "top5="+str(source["queries"][case["id"]]["top5_pass"]),flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("preflight","run","verify"))
    args=parser.parse_args()
    plan=registered()
    pipeline=NativeVerifiedT()
    store=pipeline.store(allow_create=args.action=="preflight")
    if args.action=="preflight":
        print("T_FROZEN_SOURCE_PREFLIGHT_PASS zero_new_native_sends=true store_isolated=true")
        return
    if args.action=="run":
        for turn in range(1,6):
            result=pipeline.index_turn(turn)
            verified=pipeline.verify(upto=turn)
            print("T_VERIFIED_PAIR_INDEXED turn="+str(turn),
                  "sql_records="+str(verified["sql_original_messages"]),flush=True)
            if turn in (3,5):measured_index(pipeline,plan,turn)
    checked=pipeline.verify(upto=5)
    queries=json.loads(QUERIES.read_text(encoding="utf-8"))["queries"]
    if set(queries)!={c["id"] for c in plan["query_cases"]}:
        raise StageSFailure("Frozen three query results missing")
    remote=pipeline.api.retrieve_store(store)
    counts=remote.get("file_counts") or {}
    if counts.get("completed")!=5 or counts.get("total")!=5:
        raise StageSFailure("Expected exactly five completed hosted clean files")
    report={**checked,"hosted_file_count":5,
            "frozen_queries_measured":len(queries),
            "frozen_rank_one":sum(row["target_rank"]==1 for row in queries.values()),
            "frozen_top5":sum(bool(row["top5_pass"]) for row in queries.values()),
            "new_native_sends":0,"original_raw_stage_s_untouched":True}
    print("T_FINAL_READBACK",json.dumps(report,sort_keys=True))


if __name__=="__main__":
    try:main()
    except (StageSFailure,ValueError) as err:
        print("T_FAILURE_HOLD:"+str(err),file=sys.stderr)
        raise SystemExit(2)
