"""Independent frozen Stage K metadata audit. Synthetic-only; never calls native ChatGPT."""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path

from ltm_vnext.metadata_probe_k import MetadataProbeK

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
REGISTERED="8b6ae970a8e5cdb36e0beb6882ad0ddcfa84a436"
PARENT="660434d352b735d5886476b7738263d193dce996"
PLAN="MCP_METADATA_K_CASES_20261119.json"
PROTOCOL="MCP_METADATA_K_PROTOCOL_20261119.md"
REPORT=ROOT/"MCP_METADATA_K_OFFLINE_RESULTS_20261119.md"


def git(*args):
    return subprocess.run(["git","-C",str(REPO),*args],check=True,capture_output=True).stdout


def audit():
    parents=git("rev-list","--parents","-n","1",REGISTERED).decode().strip()
    if parents!=REGISTERED+" "+PARENT:
        raise ValueError("Registration does not have exact registered parent")
    hashes={}
    for name in (PLAN,PROTOCOL):
        local=(ROOT/name).read_bytes()
        if local!=git("show",REGISTERED+":vnext/"+name):
            raise ValueError("Frozen K source bytes changed: "+name)
        hashes[name]=hashlib.sha256(local).hexdigest()
    plan=json.loads((ROOT/PLAN).read_text(encoding="utf8"))
    if plan.get("trial_id")!="ltm-vnext-K-mcp-metadata-presence-20261119":
        raise ValueError("Wrong trial ID")
    if not plan.get("registered_before_implementation") or not plan.get("synthetic_only"):
        raise ValueError("Not frozen or not synthetic")
    if plan.get("expected_case_count")!=10 or len(plan.get("offline_cases",[]))!=10:
        raise ValueError("K case count changed")
    if len(plan.get("native_probes",[]))!=3:
        raise ValueError("K native observation shape changed")
    probe=MetadataProbeK(ephemeral_key=bytes.fromhex("f1"*32))
    observed={}
    outcome_counts=Counter()
    for n,case in enumerate(plan["offline_cases"],1):
        if case["id"]!=f"K{n:02d}":
            raise ValueError("K case ID/order changed")
        public,private=probe.inspect(
            case.get("meta"), tool_arguments=case.get("tool_args"))
        expected=(case["expected_session"],case["expected_subject"],
                  case["expected_usable"])
        actual=(public["session_present"],public["subject_present"],
                public["usable_session_and_subject"])
        if actual!=expected:
            raise ValueError("K frozen metadata result mismatch: "+case["id"])
        if public["native_user_text_attested"] is not False or public["raw_metadata_disclosed"] is not False:
            raise ValueError("Unsupported auth/disclosure claim")
        if "compare_to" in case:
            previous=observed[case["compare_to"]]
            checks=(private["session_fingerprint"]==previous["session_fingerprint"],
                    private["subject_fingerprint"]==previous["subject_fingerprint"])
            if checks!=(case["expected_session_equal"],case["expected_subject_equal"]):
                raise ValueError("K correlation comparison mismatch")
        full=json.dumps(public,sort_keys=True)
        for value in ("fiction-session-A","fiction-user-A","fiction-session-B",
                      "fiction-user-B","Neverland","fabricated"):
            if value in full:
                raise ValueError("Raw private ID or client supplied text exposed")
        observed[case["id"]]=private
        outcome_counts["present_both" if public["usable_session_and_subject"] else "not_present_both"]+=1
    return {"registered_commit":REGISTERED,"registered_parent":PARENT,
            "frozen_sha256":hashes,"cases":10,"passed":10,
            "observed_status":dict(outcome_counts),
            "native_chatgpt_cases_executed":0,
            "native_metadata_attestation":"NOT_ESTABLISHED"}


def write_report(result):
    rows=[
        "# Stage K — independent preregistered metadata adapter audit",
        "",
        "**10/10 frozen cases PASS. 0 native ChatGPT calls executed in this local audit.**",
        "",
        "## Reproducibility",
        "",
        f"- Registered Git commit: `{result['registered_commit']}`; exact parent `{result['registered_parent']}`.",
        "- The frozen protocol and 10-case plan were compared byte-for-byte",
        "  with the remote-registered Git content before running any case.",
        f"- Local outcomes: {result['observed_status']}.",
        "- Two different synthetic session IDs produce distinct process-keyed",
        "  fingerprints; repeated same-session calls produce the same fingerprint",
        "  within the same process. A different process key changes fingerprints.",
        "- Model-supplied fake metadata in tool arguments never counts as MCP",
        "  request metadata. No raw ID, prompt, location or credential is logged",
        "  or returned by the standalone probe.",
        "",
        "## Hard interpretation boundary",
        "",
        "The MCP request `_meta` fields are **client-supplied** and are",
        "not an independently authenticated copy of the original user text.",
        "A local SDK client can simulate this metadata and must not be mistaken",
        "for proof of native ChatGPT delivery. Even if ChatGPT genuinely delivers",
        "an anonymised `openai/session`, a per-turn user-message binding is",
        "still absent. Capability advertisement is not a completed human",
        "clarification interaction. The SDK's `ctx._input_params` is an",
        "implementation detail; no production dependency is approved.",
        "",
        "**Decision: ACCEPT_K_OFFLINE_METADATA_ADAPTER_ONLY pending verified native connection.**",
        "",
    ]
    REPORT.write_text("\n".join(rows),encoding="utf8")


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=("status","write"))
    args=p.parse_args()
    result=audit()
    print(json.dumps(result,sort_keys=True))
    if args.action=="write":
        write_report(result)
        print("K_OFFLINE_REPORT_WRITTEN")

if __name__=="__main__":
    main()
