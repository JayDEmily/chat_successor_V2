"""Bounded, no-new-key admin operations for one isolated synthetic U tunnel.

Creation is single-attempt and refuses ambiguous pre-existing names. No secret
appears in argv, returned logs or repository files.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BINARY = ROOT / ".local/tooling/tunnel-client"
ENV_FILE = Path("/home/jds/.env")
RECEIPT = ROOT / ".local/trial-u-tunnel-receipt.json"
ORG = "org-BTw54pQ0XEDOzp89gClJhtJs"
NAME = "LTM-RAG-vNext-Hosted-U-20261120"
DESC = "Synthetic-only Stage U hosted semantic SQLite read-only tool loopback 8792"


def read_key(name: str) -> str:
    found = []
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("export "):
            line = line[7:].strip()
        field, sep, value = line.partition("=")
        if sep and field.strip() == name:
            value = value.strip()
            if len(value) > 1 and value[0] == value[-1] and value[0] in ("'", '"'):
                value = value[1:-1]
            found.append(value)
    if len(found) != 1 or not found[0]:
        raise RuntimeError(f"Expected exactly one nonempty {name} in existing Ubuntu environment")
    return found[0]


def call(*args: str) -> dict:
    env = os.environ.copy()
    for name in ("OPENAI_API_KEY", "CONTROL_PLANE_API_KEY", "OPENAI_ADMIN_KEY"):
        env.pop(name, None)
    env["OPENAI_ADMIN_KEY"] = read_key("OPENAI_ADMIN_KEY")
    cp = subprocess.run(
        [str(BINARY), "admin", "tunnels", *args, "--json"],
        env=env, text=True, capture_output=True, timeout=50,
    )
    if cp.returncode != 0:
        # Avoid accidental inclusion of secrets in diagnostic echo. Only the exit
        # status is shown; raw details are not printed.
        raise RuntimeError(f"Tunnel admin action failed (exit={cp.returncode}); no automatic retry")
    try:
        return json.loads(cp.stdout)
    except ValueError as exc:
        raise RuntimeError("Tunnel admin returned invalid JSON; inspect before any retry") from exc


def walk(obj):
    if isinstance(obj, dict):
        if isinstance(obj.get("id"), str) and obj["id"].startswith("tunnel_"):
            yield obj
        for val in obj.values():
            yield from walk(val)
    elif isinstance(obj, list):
        for val in obj:
            yield from walk(val)


def tunnels() -> list[dict]:
    response = call("list", "--organization-id", ORG)
    unique = {}
    for entry in walk(response):
        unique[entry["id"]] = entry
    return list(unique.values())


def status() -> None:
    entries = tunnels()
    selected = [e for e in entries if e.get("name") == NAME]
    print(json.dumps({
        "scope": "organization_only",
        "organization": ORG,
        "matching_tunnel_count": len(selected),
        "matching_tunnel_ids": [e["id"] for e in selected],
        "local_receipt_exists": RECEIPT.is_file(),
    }, sort_keys=True))


def create() -> None:
    if RECEIPT.exists():
        raise RuntimeError("U tunnel receipt already exists; refusing duplicate create")
    if [t for t in tunnels() if t.get("name") == NAME]:
        raise RuntimeError("Remote U tunnel name already exists; inspect before adoption")
    creation = call(
        "create", "--name", NAME, "--description", DESC,
        "--organization-id", ORG
    )
    created = [x for x in walk(creation) if x.get("name") == NAME]
    if len(created) != 1:
        raise RuntimeError("Tunnel may have been created but response identity is ambiguous; DO NOT retry")
    tunnel_id = created[0]["id"]
    RECEIPT.parent.mkdir(parents=True, exist_ok=True)
    payload = {"id": tunnel_id, "name": NAME, "organization": ORG,
               "purpose": "isolated synthetic Stage U hosted search original SQLite read-only private loopback MCP",
               "create_response_observed": True, "remote_readback_verified": False}
    temporary = RECEIPT.with_suffix(".tmp")
    fd = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, RECEIPT)
    print(json.dumps({"created_tunnel_id": tunnel_id, "local_receipt": "written",
                      "remote_readback_verified": False}, sort_keys=True))


def verify() -> None:
    receipt = json.loads(RECEIPT.read_text(encoding="utf-8"))
    observed = call("get", receipt["id"])
    matching = [x for x in walk(observed) if x["id"] == receipt["id"]]
    if len(matching) != 1 or matching[0].get("name") != NAME:
        raise RuntimeError("Remote tunnel identity/name does not match local receipt")
    matching_organization = ORG in json.dumps(matching[0], sort_keys=True)
    # Explicitly report organisation visibility separately from ID/name match.
    receipt["remote_readback_verified"] = True
    receipt["org_visible_in_get"] = matching_organization
    RECEIPT.write_text(json.dumps(receipt, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(RECEIPT, 0o600)
    print(json.dumps({"tunnel_id": receipt["id"], "name_confirmed": True,
                      "organization_visible_in_response": matching_organization,
                      "remote_readback_verified": True}, sort_keys=True))


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in ("list", "create", "verify"):
        raise SystemExit("Usage: trial_m_tunnel_admin.py list|create|verify")
    if not BINARY.is_file() or not ENV_FILE.is_file():
        raise SystemExit("Existing tunnel binary or Ubuntu private .env not available")
    try:
        {"list": status, "create": create, "verify": verify}[sys.argv[1]]()
    except Exception as exc:
        print(f"TRIAL_U_TUNNEL_ADMIN_ERROR {exc}", file=sys.stderr)
        raise SystemExit(2) from None
