"""Read-only audit and summary of the pre-registered synthetic native trial."""
from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PLAN = ROOT / "RELIABILITY_TRIAL_B_20261118.json"
RESULTS = ROOT / ".local" / "reliability-trial-b-results.jsonl"
AUDIT = ROOT / ".local" / "mcp-tool-audit.jsonl"
REPORT = ROOT / "RELIABILITY_TRIAL_B_RESULTS.md"
PROJECT = "g-p-6afd1c455970819197ab1bdad8acf53d-ltm-rag-vnext-synthetic-trial"


def wilson(success: int, count: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if success < 0 or count < 0 or success > count:
        raise ValueError("Invalid binomial count")
    if count == 0:
        return (0.0, 1.0)
    p = success / count
    z2 = z * z
    middle = (p + z2 / (2 * count)) / (1 + z2 / count)
    half = z * math.sqrt(p * (1 - p) / count + z2 / (4 * count * count)) / (1 + z2 / count)
    return max(0.0, middle - half), min(1.0, middle + half)


def json_lines(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def analyse(plan: dict, results: list[dict], audit: list[dict]) -> dict:
    cases = plan["cases"]
    if len(cases) != 20 or len(results) > 20:
        raise ValueError("Unexpected case count")
    audit_by_id = {ev["event_id"]: ev for ev in audit}
    if len(audit_by_id) != len(audit):
        raise ValueError("Duplicate event IDs in local MCP audit log")
    attributed = set()
    urls = set()
    counts = Counter()
    rows = []
    for i, result in enumerate(results):
        test = cases[i]
        ident = test["id"]
        if result.get("id") != ident or result.get("kind") != test["kind"] or result.get("ordinal") != i + 1:
            raise ValueError(f"Wrong case ID/type/ordinal at index {i}")
        url = result.get("chat_url", "")
        if not url.startswith("chatgpt.com/g/" + PROJECT + "/c/") or url in urls:
            raise ValueError(f"Missing, non-Project or duplicate chat URL for {ident}")
        urls.add(url)
        event_ids = result.get("added_event_ids", [])
        if len(event_ids) != len(set(event_ids)) or len(event_ids) != result["lookup_count"] + result["fetch_count"]:
            raise ValueError(f"Event-count mismatch for {ident}")
        event_tools = Counter()
        for event in event_ids:
            if event not in audit_by_id or event in attributed:
                raise ValueError(f"Missing/duplicate local audit event {event}")
            attributed.add(event)
            event_tools[audit_by_id[event]["tool"]] += 1
        if event_tools["lookup_evidence"] != result["lookup_count"] or event_tools["fetch_source"] != result["fetch_count"]:
            raise ValueError(f"Audit tool types contradict runner counts for {ident}")
        is_history = test["kind"] == "history"
        primary = bool(result["completed"]) and (
            result["lookup_count"] > 0 if is_history else result["lookup_count"] == 0
        )
        content = primary and (
            not is_history
            or (result["fetch_count"] > 0 and set(test["expected_terms"]).issubset(result["matched_terms"]))
        )
        if primary != result["initiation_or_selectivity_pass"] or content != result["content_pass"]:
            raise ValueError(f"Scoring contradiction for {ident}")
        counts[test["kind"]] += 1
        counts[test["kind"] + "_primary"] += int(primary)
        counts[test["kind"] + "_content"] += int(content)
        counts["lookup"] += result["lookup_count"]
        counts["fetch"] += result["fetch_count"]
        rows.append((test, result, primary, content))
    return {"complete": len(results) == 20, "counts": counts, "rows": rows}


def write_report(summary: dict) -> None:
    if not summary["complete"]:
        raise ValueError("No final report until all 20 cases were executed")
    c = summary["counts"]
    init = c["history_primary"] / c["history"]
    unnecessary_count = c["unrelated"] - c["unrelated_primary"]
    unnecessary = unnecessary_count / c["unrelated"]
    ip = wilson(c["history_primary"], c["history"])
    un = wilson(unnecessary_count, c["unrelated"])
    fmt = lambda n: f"{n:.1%}"
    out = [
        "# LTM-RAG vNext: pre-registered native trial B results",
        "",
        "All 20 cases are from the fixed input in RELIABILITY_TRIAL_B_20261118.json,",
        "committed before the first question was sent. No completed case was excluded.",
        "",
        f"History-needed retrieval initiated: {c['history_primary']}/{c['history']} ({fmt(init)}), "
        f"two-sided Wilson 95% interval {fmt(ip[0])}–{fmt(ip[1])}.",
        f"Unnecessary retrieval on unrelated controls: {unnecessary_count}/{c['unrelated']} ({fmt(unnecessary)}), "
        f"two-sided Wilson 95% interval {fmt(un[0])}–{fmt(un[1])}.",
        f"End-to-end content/source checks: {c['history_content']}/{c['history']} history cases.",
        f"Actual local MCP calls: {c['lookup']} successful lookups, {c['fetch']} successful source fetches.",
        "",
        "Astra's proposed future population thresholds are ≥90% necessary initiation and ≤10%",
        "unnecessary retrieval. This small synthetic dataset does NOT establish those population bounds.",
        "",
        "| Case | Class | Lookup | Fetch | Primary | Content | Native ChatGPT Project chat |",
        "|---|---|---:|---:|---|---|---|",
    ]
    for test, result, primary, content in summary["rows"]:
        out.append(
            f"| {test['id']} | {test['kind']} | {result['lookup_count']} | {result['fetch_count']} | "
            f"{'PASS' if primary else 'FAIL'} | {'PASS' if content else 'FAIL'} | "
            f"[View](https://{result['chat_url']}) |"
        )
    out.extend([
        "",
        "## Evidence boundaries",
        "",
        "- The private trial ledger and content-minimised invocation audit are held locally under vnext/.local;",
        "  they were not committed or uploaded.",
        "- Each case was submitted in a distinct saved chat inside the synthetic-only ChatGPT Project,",
        "  with no selected plugin chip or explicit instruction to call the plugin.",
        "- Local audit entries establish successful MCP handler calls, not the absence of every failed attempt.",
        "- The automated content check requires the registered answer terms and a source fetch;",
        "  it does not replace a full independent human semantic review.",
        "- Results use six invented fixture messages, not actual personal conversations.",
        "- Boot persistence, host shutdown and other projects are outside this trial.",
        "",
    ])
    REPORT.write_text("\n".join(out), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("status", "write"))
    action = parser.parse_args().action
    plan = json.loads(PLAN.read_text(encoding="utf-8"))
    summary = analyse(plan, json_lines(RESULTS), json_lines(AUDIT))
    c = summary["counts"]
    print(json.dumps({
        "complete": summary["complete"],
        "count": len(summary["rows"]),
        "history_completed": c["history"],
        "history_initiated": c["history_primary"],
        "history_content": c["history_content"],
        "unrelated_completed": c["unrelated"],
        "unrelated_no_lookup": c["unrelated_primary"],
        "new_lookups": c["lookup"],
        "new_fetches": c["fetch"],
    }, sort_keys=True))
    if action == "write":
        write_report(summary)
        print("REPORT_WRITTEN")


if __name__ == "__main__":
    main()
