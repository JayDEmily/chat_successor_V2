"""Disposable HTTP MCP verification of pre-registered clean-Project Trial G sources.

Never changes the live six-message MCP, original tunnel or any real chat data.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from mcp import Client
from ltm_vnext.archive import Archive, _local_id

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "fixtures/synthetic_clean_g.json"
PLAN = ROOT / "NATIVE_TRIAL_G_20261119.json"


def check_fixture() -> dict:
    fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
    plan = json.loads(PLAN.read_text(encoding="utf-8"))
    records = fixture["messages"]
    if not fixture.get("synthetic") or len(records) != 20:
        raise ValueError("Only registered twenty-message synthetic fixture permitted")
    if plan["trial_id"] != "ltm-vnext-native-trial-g-cleancontext-20261119":
        raise ValueError("Trial identity mismatch")
    if plan["case_count"] != 16 or len(plan["cases"]) != 16:
        raise ValueError("G trial questions mismatch")
    if plan["cases"][0]["id"] != plan["first_turn_clean_case"] != "G01":
        raise ValueError("First-turn clean probe identity mismatch")
    ids = {x["message_id"]: x for x in records}
    if len(ids) != len(records):
        raise ValueError("Duplicate message ID")
    if {x["source_id"] for x in records} != {"synthetic-clean-g"}:
        raise ValueError("Wrong source namespace")
    if any(x["capture_method"] != "synthetic_fixture" for x in records):
        raise ValueError("Real content prohibited")
    if any(x["author_role"] != "user" for x in records if x.get("supersedes")):
        raise ValueError("Corrections must be original user statements")
    for x in records:
        if x.get("supersedes"):
            prior = ids.get(x["supersedes"]["message_id"])
            if prior is None or prior["conversation_id"] != x["conversation_id"] or prior["branch_id"] != x["branch_id"]:
                raise ValueError("Correction target crossed conversation/branch")
        if x["branch_id"] == "alternative" and x["author_role"] != "assistant":
            raise ValueError("Alternative branches must be assistant-authored in G")
    for case in plan["cases"]:
        if any(mid not in ids for mid in case["source_ids"]):
            raise ValueError("Unregistered expected source ID")
    return fixture


async def exercise(url: str) -> None:
    async with Client(url) as client:
        tools = (await client.list_tools()).tools
        if {t.name for t in tools} != {"lookup_evidence", "fetch_source"}:
            raise AssertionError("G source server has the wrong tools")
        if not all(t.annotations.read_only_hint for t in tools):
            raise AssertionError("G tools are not declared readonly")
        search = await client.call_tool("lookup_evidence", {"query": "Merrow ULN-4827 locker"})
        if search.is_error:
            raise AssertionError("G source lookup failed")
        packet = search.structured_content
        hits = packet["hits"]
        target = next((h for h in hits if h["message_id"] == "g03"), None)
        if target is None:
            raise AssertionError("G corrected g03 not returned")
        if target["branch_id"] != "main" or target["author_role"] != "user":
            raise AssertionError("G correction lost user/branch identity")
        if target["exact_text"] != "Correction to my Merrow log: the ULN-4827 prism token was secured in locker 9 beside the cobalt optic.":
            raise AssertionError("G exact correction text corrupted")
        source = await client.call_tool("fetch_source", {"local_id": target["local_id"], "neighbours": 1})
        if source.is_error:
            raise AssertionError("G fetch tool failed")
        original = source.structured_content
        for field in ("source_id", "message_id", "version_id", "branch_id", "exact_text", "content_sha256", "source_locator"):
            if original[field] != target[field]:
                raise AssertionError("Mismatch between G source lookup and fetch: " + field)
        if original["content_sha256"] != hashlib.sha256(original["exact_text"].encode("utf-8")).hexdigest():
            raise AssertionError("G SHA256 mismatch")
        if original.get("supersedes_local_id") is None:
            raise AssertionError("G correction lost supersession link")
        if any(n["local_id"] == _local_id("synthetic-clean-g", "g04", "1") for n in original["neighbouring_dialogue"]):
            raise AssertionError("Alternative-branch neighbour leaked")
        print("TRIAL_G_HTTP_SMOKE_PASS: two read-only tools, corrected user g03, SHA256, branch and source fetch")


def main() -> None:
    check_fixture()
    with tempfile.TemporaryDirectory(prefix="ltm-clean-g-http-") as td:
        path = Path(td)
        db = path / "clean-g.sqlite"
        audit = path / "calls.jsonl"
        inserted = Archive.initialise(db).ingest_synthetic(FIXTURE)
        if inserted != {"inserted": 20, "total": 20}:
            raise AssertionError("G source ingest count mismatch")
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        env = dict(os.environ, PYTHONPATH=str(ROOT))
        proc = subprocess.Popen(
            [sys.executable, "-m", "ltm_vnext.mcp_server",
             "--db", str(db), "--port", str(port), "--audit-log", str(audit)],
            env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True
        )
        try:
            deadline = time.monotonic() + 12
            while time.monotonic() < deadline:
                if proc.poll() is not None:
                    raise RuntimeError("G MCP server exited before ready")
                try:
                    with socket.create_connection(("127.0.0.1", port), timeout=0.25):
                        break
                except OSError:
                    time.sleep(0.1)
            else:
                raise TimeoutError("G MCP server not listening on disposable port")
            asyncio.run(exercise(f"http://127.0.0.1:{port}/mcp"))
            events = [json.loads(line) for line in audit.read_text(encoding="utf-8").splitlines()]
            if [e["tool"] for e in events] != ["lookup_evidence", "fetch_source"]:
                raise AssertionError("G audit tool sequence mismatch")
            if any(e["outcome"] != "ok" or "exact_text" in e or "query" in e for e in events):
                raise AssertionError("G audit exposed source text or failed")
            print("TRIAL_G_AUDIT_PASS: two content-minimised tool events; disposable DB and listener")
        finally:
            proc.terminate()
            try:
                proc.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate(timeout=5)


if __name__ == "__main__":
    main()
