"""Native I trace auditor: independently reconcile frozen case plan, private ledger, MCP event IDs.

This verifies tool invocations and packet counts, NOT answer fidelity. The
semantic review is a separately documented judgement over original source text.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PLAN = ROOT/"NATIVE_DECISION_SUPPORT_I_20261119.json"
FIXTURE = ROOT/"fixtures/synthetic_clean_g.json"
LEDGER = ROOT/".local/native-trial-i-results.jsonl"
AUDIT = ROOT/".local/trial-i-mcp-audit.jsonl"
PENDING = ROOT/".local/native-trial-i-pending.json"
REPORT = ROOT/"NATIVE_DECISION_SUPPORT_I_TRACE_RESULTS_20261119.md"
PROJECT_ID = "g-p-6afe74761d848191830dc78a328d29c1"


def jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(
        encoding="utf-8-sig").splitlines() if line.strip()]


def verify() -> tuple[dict,list[tuple[dict,dict,bool|None]]]:
    plan=json.loads(PLAN.read_text(encoding="utf8"))
    if (plan.get("trial_id")!="ltm-vnext-native-decision-support-I-20261119"
            or not plan.get("registered_before_implementation")
            or len(plan.get("native_cases",[]))!=16):
        raise ValueError("I native plan identity mismatch")
    original=FIXTURE.read_bytes()
    if hashlib.sha256(original).hexdigest()!=plan["fixture_sha256"]:
        raise ValueError("Original clean G fixture SHA-256 mismatch")
    archive=json.loads(original.decode("utf8"))
    original_rows=archive["messages"]
    if not archive["synthetic"] or len(original_rows)!=20:
        raise ValueError("Invalid original G source archive")
    if {m["message_id"] for m in original_rows}!={f"g{i:02d}" for i in range(1,21)}:
        raise ValueError("Original source identifiers differ")
    rows=jsonl(LEDGER)
    events=jsonl(AUDIT)
    if len(rows)>16:
        raise ValueError("More than 16 native I case responses")
    indexed={x["event_id"]:x for x in events}
    if len(indexed)!=len(events):
        raise ValueError("Duplicate I native audit event ID")
    consumed=set()
    urls=set()
    counts=Counter()
    checked=[]
    for i,row in enumerate(rows):
        case=plan["native_cases"][i]
        if (row.get("id"),row.get("kind"),row.get("ordinal")) != (
                case["id"],case["kind"],i+1):
            raise ValueError("Native case order/identity diverged")
        expected_hash=hashlib.sha256(case["prompt"].encode("utf8")).hexdigest()
        if row.get("prompt_sha256")!=expected_hash:
            raise ValueError("Sent native prompt hash differs: "+case["id"])
        url=row.get("chat_url","")
        if not url.startswith("chatgpt.com/g/"+PROJECT_ID) or "/c/" not in url or url in urls:
            raise ValueError("Wrong or duplicate saved ChatGPT Project chat")
        urls.add(url)
        start=datetime.fromisoformat(row["sent_at_utc"])
        end=datetime.fromisoformat(row["observed_at_utc"])
        if end<start or not row.get("completed"):
            raise ValueError("Incomplete or reversed observation")
        ids=row["added_event_ids"]
        if len(set(ids))!=len(ids):
            raise ValueError("Duplicate audit IDs attributed to a native response")
        calls=[]
        source_scope_ok=True
        for eid in ids:
            if eid not in indexed or eid in consumed:
                raise ValueError("Missing/reused tool event: "+eid)
            consumed.add(eid)
            event=indexed[eid]
            if event.get("tool")!="resolve_history_reference" or event.get("outcome")!="ok":
                raise ValueError("Unexpected/unsuccessful tool event")
            if event.get("synthetic_only") is not True:
                raise ValueError("Non-synthetic event in I audit")
            when=datetime.fromisoformat(event["timestamp_utc"])
            if not start-timedelta(seconds=3)<=when<=end+timedelta(seconds=3):
                raise ValueError("Audited I call outside case interval")
            expected_sources = (0 if case["expected_status"]=="UNANCHORED"
                                else 4 if case["expected_status"]=="UNIQUE"
                                else 8 if case["expected_status"]=="MULTIPLE"
                                else None)
            if event["result_count"]!=expected_sources:
                source_scope_ok=False
            calls.append(event)
        n=len(calls)
        if (n!=row.get("lookup_count") or row.get("fetch_count")!=0 or
                row.get("expected_lookup")!=case["resolve_expected"]):
            raise ValueError("Event count/expectation conflict")
        expected=case["resolve_expected"]
        trace=(n>0 if expected else n==0) if expected is not None else None
        if trace!=row.get("trace_pass"):
            raise ValueError("Trace scorer differs from independently audited event count")
        if not row.get("semantic_review")=="PENDING" or len(row.get("answer_text",""))<12:
            raise ValueError("Missing answer or prematurely scored content")
        counts["source_scope_pass"]+=int(source_scope_ok)
        counts["source_scope_fail"]+=int(not source_scope_ok)
        counts["completed"]+=1
        counts["resolve_calls"]+=n
        counts["with_tool"]+=int(n>0)
        counts["specified_trace_pass"]+=int(trace is True)
        counts["specified_trace_fail"]+=int(trace is False)
        counts["optional_trace"]+=int(trace is None)
        counts[case["kind"]]+=1
        checked.append((case,row,trace,source_scope_ok,[ev["result_count"] for ev in calls]))
    complete=len(rows)==16 and not PENDING.exists()
    if complete and len(consumed)!=len(events):
        raise ValueError("Unattributed separate I audit calls during frozen native run")
    return {
        "executed":len(rows),"complete":complete,"pending":PENDING.exists(),
        "audited_events":len(events),"counts":dict(counts),
    },checked

def write(summary,checked):
    if not summary["complete"]:
        raise ValueError("Cannot publish complete native I trace with missing/pending sends")
    c=summary["counts"]
    lines=[
        "# Native Decision-Support I — independently verified ChatGPT tool trace",
        "",
        "Separate Stage I test of a single synthetic-only source-resolution",
        "tool, in a newly created Project with Project-only memory selected.",
        "",
        f"Executed **{c['completed']}/16** registered cases in unique saved chats;",
        f"**{c['resolve_calls']}** successful read-only I resolver calls.",
        f"Specified invocation/selectivity: **{c['specified_trace_pass']} PASS**,",
        f"**{c['specified_trace_fail']} FAIL**;",
        f"optional-invocation ambiguity cases: **{c['optional_trace']}**.",
        "",
        "| Case | Class | Registered invocation | Observed calls | Source packets | Source-scope | Trace | Chat |",
        "|---|---|---|---:|---|---|---|---|",
    ]
    for case,row,trace,scope_ok,source_counts in checked:
        expectation=("optional" if case["resolve_expected"] is None
                     else "required" if case["resolve_expected"] else "must avoid")
        verdict=("optional" if trace is None else "PASS" if trace else "FAIL")
        lines.append(f"| {case['id']} | {case['kind']} | {expectation} | "
                     f"{row['lookup_count']} | {source_counts} | "+
                     f"{'PASS' if scope_ok else 'FAIL'} | {verdict} | "+
                     f"[Saved native answer](https://{row['chat_url']}) |")
    lines.extend([
        "",
        f"Source-packet scope: **{c['source_scope_pass']} PASS**,",
        f"**{c['source_scope_fail']} FAIL** against registered original-topic requirement.",
        "",
        "The two scope failures are I05 (12 packets for an unanchored question)",
        "and I15 (four packets for another unanchored question).",
        "They are recorded as FAIL; successful tool transport is not semantic compliance.",
        "",
        "## Inspection and uncertainty",
        "",
        "- The independent auditor checked all 16 SHA-256 prompt hashes",
        "  against the pre-registered questions, exact saved Project ID,",
        "  distinct chat URLs, event-ID ownership, order and timestamps,",
        "  source packet counts implied by explicit narrative anchors and",
        "  handler status. It verified no pending duplicate-risk send.",
        "- A successful resolver call is evidence that the native assistant",
        "  accessed the correct isolated I tool, not itself that its",
        "  answer correctly used original source text. Semantic source",
        "  fidelity, correction/authorship and ambiguity verdicts are",
        "  independently recorded, not manufactured from tool invocation.",
        "- I01 was the very first message in the newly chat-empty Project;",
        "  I02–I16 may use other chats within this Project. Creation as",
        "  Project-only was verified in a reopened settings modal; whether",
        "  memory settings propagated instantaneously cannot be proved.",
        "- All questions and evidence were fictional. Full answer text,",
        "  private local per-case ledger and tool audit stay Git-ignored.",
        "  Historical G outcomes remain unchanged; absence of separate",
        "  fetch_source calls is expected because the versioned I contract",
        "  includes exact original message packets within one resolver call.",
        "- Original 8787 and G 8788 MCP tools were not intentionally",
        "  modified; any independent audit activity on those tools",
        "  must be evaluated separately rather than silently assumed zero.",
        "",
    ])
    REPORT.write_text("\n".join(lines),encoding="utf8")


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=("status","write"))
    args=p.parse_args()
    s,rows=verify()
    print(json.dumps(s,sort_keys=True))
    if args.action=="write":
        write(s,rows)
        print("NATIVE_I_TRACE_REPORT_WRITTEN")


if __name__=="__main__":
    main()
