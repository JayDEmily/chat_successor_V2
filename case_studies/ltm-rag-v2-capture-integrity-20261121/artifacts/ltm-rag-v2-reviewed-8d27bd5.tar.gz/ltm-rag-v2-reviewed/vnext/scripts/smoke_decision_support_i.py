"""One-shot read-only I MCP transport smoke; private random localhost port only."""
from __future__ import annotations

import asyncio
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from mcp import Client
from ltm_vnext.archive import Archive

ROOT=Path(__file__).resolve().parents[1]


async def verify_transport(port: int) -> None:
    async with Client(f"http://127.0.0.1:{port}/mcp") as client:
        tools=(await client.list_tools()).tools
        assert [t.name for t in tools]==["resolve_history_reference"],tools
        assert all(t.annotations.read_only_hint for t in tools)
        async def ask(question):
            result=await client.call_tool("resolve_history_reference",
                                          {"question":question})
            assert not result.is_error,result
            return result.structured_content
        ambiguous=await ask("Where did it end up in that earlier fictional record?")
        assert ambiguous["status"]=="UNANCHORED",ambiguous
        assert ambiguous["action"]=="CLARIFY_IF_HISTORY_REQUEST"
        assert ambiguous["source_packets"]==[]
        corrected=await ask("What was the corrected ULN-4827 locker?")
        assert corrected["status"]=="UNIQUE"
        assert [p["message_id"] for p in corrected["source_packets"]]==[
            "g01","g02","g03","g04"]
        assert corrected["source_packets"][2]["exact_text"].endswith(
            "locker 9 beside the cobalt optic.")
        multiple=await ask("Compare Merrow and SOVA-88 corrections")
        assert multiple["status"]=="MULTIPLE"
        assert len(multiple["source_packets"])==8
        speech=await ask("What did Vela say about TERN-91?")
        first=next(r for r in speech["source_packets"]
                   if r["message_id"]=="g05")
        assert first["author_role"]=="user"
        assert first["reported_speaker"]=="Vela"
        assert first["attribution"]=="reported_recollection"
        print("I_HTTP_MCP_SMOKE_PASS one_readonly_tool=true "
              "unanchored_source_packets=0 corrected_exact=true "
              "two_narratives=8 reported_speech_label=preserved")


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        td=Path(tmp)
        db=td/"synthetic.sqlite"
        audit=td/"events.jsonl"
        Archive.initialise(db).ingest_synthetic(
            ROOT/"fixtures"/"synthetic_clean_g.json")
        with socket.socket() as sock:
            sock.bind(("127.0.0.1",0))
            port=sock.getsockname()[1]
        env=dict(os.environ)
        env["PYTHONPATH"]=str(ROOT)
        p=subprocess.Popen([
            sys.executable,"-m","ltm_vnext.decision_support_i",
            "--db",str(db),"--fixture",str(ROOT/"fixtures"/"synthetic_clean_g.json"),
            "--manifest",str(ROOT/"REFERENT_GATE_H_MANIFEST_20261119.json"),
            "--port",str(port),"--audit-log",str(audit),
        ],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
        try:
            for _ in range(100):
                if p.poll() is not None:
                    raise RuntimeError("I MCP process quit before listener")
                try:
                    with socket.create_connection(("127.0.0.1",port),timeout=.2):
                        break
                except OSError:
                    time.sleep(.1)
            else:
                raise TimeoutError("I MCP never listened on loopback")
            asyncio.run(verify_transport(port))
            calls=[json.loads(line) for line in audit.read_text().splitlines()]
            assert len(calls)==4,len(calls)
            assert [c["result_count"] for c in calls]==[0,4,8,4],calls
            assert all(c["tool"]=="resolve_history_reference"
                       and c["outcome"]=="ok"
                       and c["synthetic_only"]
                       and "question" not in c
                       and "source" not in c for c in calls)
            print("I_MCP_AUDIT_PASS events=4 source_counts=0,4,8,4 "
                  "no_question_or_source_logged=true")
        finally:
            p.terminate()
            try:
                _,err=p.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill()
                _,err=p.communicate(timeout=5)
            if p.returncode not in (0,-15):
                print(err[-1000:],file=sys.stderr)


if __name__=="__main__":
    main()
