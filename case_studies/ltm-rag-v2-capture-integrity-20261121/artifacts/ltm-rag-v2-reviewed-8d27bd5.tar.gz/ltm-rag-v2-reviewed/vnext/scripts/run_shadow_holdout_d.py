"""Independent pre-registered synthetic holdout D test, same shadow algorithms as C."""
from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
from collections import Counter
from pathlib import Path

import numpy as np
from ltm_vnext.archive import Archive
from scripts.run_shadow_embeddings import (
    CACHE, MODEL, TOP_N, correction_chain_texts, normalized,
    order_by_score, reciprocal_rank_fusion,
)

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "fixtures/synthetic_holdout_d.json"
PROBES = ROOT / "HOLDOUT_D_PROBES_20261118.json"
OUTPUT = ROOT / "SHADOW_HOLDOUT_D_RESULTS.md"
GROUPS = ("explicit", "implicit", "original", "alternative")
METHODS = ("FTS5", "DENSE_RAW", "DENSE_CHAIN", "HYBRID_RRF")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate(fixture: dict, plan: dict) -> None:
    if fixture.get("synthetic") is not True or len(fixture.get("messages", [])) != 40:
        raise ValueError("Expected all 40 synthetic fixture records")
    if plan.get("trial_id") != "ltm-vnext-independent-synthetic-holdout-d-20261118":
        raise ValueError("Unrecognised trial identity")
    if not plan.get("registered_before_execution") or plan.get("top_k") != 8:
        raise ValueError("Registered trial metadata missing")
    if len(plan.get("probes", [])) != 32:
        raise ValueError("Expected 32 preregistered probes")
    by_id = {m["message_id"]: m for m in fixture["messages"]}
    if len(by_id) != 40:
        raise ValueError("Duplicate message identity")
    if {m["source_id"] for m in fixture["messages"]} != {"synthetic-holdout-d"}:
        raise ValueError("Unexpected source")
    if {m["capture_method"] for m in fixture["messages"]} != {"synthetic_fixture"}:
        raise ValueError("Non-synthetic message")
    if len([m for m in fixture["messages"] if "supersedes" in m]) != 12:
        raise ValueError("Expected twelve corrected sources")
    counts = Counter()
    for query in plan["probes"]:
        if query.get("limit") != 8 or query["expected_message_id"] not in by_id:
            raise ValueError("Invalid target or limit")
        counts[query["kind"]] += 1
        target = by_id[query["expected_message_id"]]
        if query["kind"] in ("explicit", "implicit") and not target.get("supersedes"):
            raise ValueError("Corrected query has non-correction target")
        if query["kind"] == "original" and (target.get("supersedes") or target["position"] != 1):
            raise ValueError("Original query target is not original")
        if query["kind"] == "alternative" and target["branch_id"] != "alternative":
            raise ValueError("Alternative query target wrong branch")
    if dict(counts) != {"explicit":12, "implicit":12, "original":4, "alternative":4}:
        raise ValueError("Wrong preregistered group sizes")
    if len({p["id"] for p in plan["probes"]}) != 32:
        raise ValueError("Duplicate probe IDs")


def evaluate(model, fixture: dict, plan: dict) -> list[dict]:
    validate(fixture, plan)
    messages = fixture["messages"]
    ids = [m["message_id"] for m in messages]
    raw = normalized(model.embed([m["exact_text"] for m in messages], batch_size=16))
    chain = normalized(model.embed(correction_chain_texts(messages), batch_size=16))
    questions = normalized(model.embed([p["query"] for p in plan["probes"]], batch_size=16))
    rows = []
    with tempfile.TemporaryDirectory(prefix="ltm-holdout-d-") as dirname:
        archive = Archive.initialise(Path(dirname) / "fresh.sqlite")
        output = archive.ingest_synthetic(FIXTURE)
        if output != {"inserted": 40, "total": 40}:
            raise ValueError("Holdout D ingest failed")
        for idx, probe in enumerate(plan["probes"]):
            lexical = [m["message_id"] for m in archive.lookup(probe["query"],limit=20)["hits"]]
            dense = order_by_score(ids, raw @ questions[idx])
            dense_chain = order_by_score(ids, chain @ questions[idx])
            hybrid = reciprocal_rank_fusion(dense_chain, lexical)
            ranks = {}
            for key, ranking in zip(METHODS, (lexical, dense, dense_chain, hybrid)):
                top8 = ranking[:TOP_N]
                target = probe["expected_message_id"]
                rank = top8.index(target) + 1 if target in top8 else None
                ranks[key] = {
                    "rank":rank,
                    "hit":rank is not None,
                    "top1":rank == 1,
                    "first":top8[0] if top8 else None,
                }
            rows.append({"id":probe["id"],"kind":probe["kind"],
                         "target":probe["expected_message_id"],"ranking":ranks})
    return rows


def aggregate(rows: list[dict]) -> dict:
    summary = {}
    for group in GROUPS:
        subset = [r for r in rows if r["kind"] == group]
        summary[group] = {
            method: {
                "recall8":sum(r["ranking"][method]["hit"] for r in subset),
                "top1":sum(r["ranking"][method]["top1"] for r in subset),
                "misses":[r["id"] for r in subset if not r["ranking"][method]["hit"]],
            }
            for method in METHODS
        }
    return summary


def write_report(rows: list[dict]) -> None:
    summaries=aggregate(rows)
    out=[
        "# Independent synthetic Holdout D — offline source candidate rankings",
        "",
        "Data/questions fixed before embedding execution: HOLDOUT_D_PROTOCOL_20261118.md.",
        "New fictional 40-record corpus; 32 questions (12 explicit, 12 implicit,",
        "4 original and 4 alternative-branch). Registered target ID alone counts as a hit.",
        "C had been inspected before D was designed; D is new but still handcrafted.",
        "",
        "All algorithms were fixed in SHADOW_EMBEDDING_EXPERIMENT_20261118.md",
        "before evaluation on C and D. Model: BAAI/bge-small-en-v1.5",
        "(FastEmbed 0.9.1, ONNX Runtime 1.32.0, CPU two threads).",
        "No remote inference API or live service changes.",
        "",
        "Fixture SHA-256: " + sha256_file(FIXTURE),
        "Probe SHA-256: " + sha256_file(PROBES),
        "",
        "| Question type | Method | Source recall@8 | Correct source ranked first |",
        "|---|---|---:|---:|",
    ]
    for group in GROUPS:
        n=sum(r["kind"] == group for r in rows)
        for method in METHODS:
            x=summaries[group][method]
            out.append("| "+group+" | "+method+" | "+str(x["recall8"])+"/"+str(n)+" | "+
                       str(x["top1"])+"/"+str(n)+" |")
    out += ["", "| Probe | Group | Expected | FTS5 | Dense raw | Dense chain | Hybrid |",
            "|---|---|---|---:|---:|---:|---:|"]
    for row in rows:
        fmt=lambda m: str(row["ranking"][m]["rank"]) if row["ranking"][m]["rank"] else "MISS"
        out.append("| "+row["id"]+" | "+row["kind"]+" | "+row["target"]+" | "+
                   " | ".join(fmt(m) for m in METHODS)+" |")
    out += [
        "", "## Interpretation boundary",
        "",
        "These are source-candidate rankings, not generated answers or conversational",
        "memory initiation. An incorrect original or alternative branch ID is counted",
        "as failure even if the result text is topically similar.",
        "The test is small and handwritten, not a random sample of genuine history.",
        "All text stays synthetic, with isolated temporary SQLite and local CPU",
        "embeddings; source versioning and SHA-256 remain in authoritative SQLite.",
        "No candidate method is promoted to the live MCP search by this experiment.",
        "",
    ]
    OUTPUT.write_text("\n".join(out),encoding="utf-8")


def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("status","write"))
    action=parser.parse_args().action
    from fastembed import TextEmbedding
    model=TextEmbedding(model_name=MODEL,cache_dir=str(CACHE),threads=2,
                        providers=["CPUExecutionProvider"],cuda=False)
    fixture=json.loads(FIXTURE.read_text(encoding="utf-8"))
    plan=json.loads(PROBES.read_text(encoding="utf-8"))
    rows=evaluate(model,fixture,plan)
    print(json.dumps(aggregate(rows),sort_keys=True))
    if action=="write":
        write_report(rows)
        print("HOLDOUT_D_REPORT_WRITTEN")


if __name__=="__main__":
    main()
