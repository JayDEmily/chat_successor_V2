"""Retrospective exact-span audit of the completed synthetic Trial B.

No alteration to original pre-registered scoring, local audit ledger, or MCP server.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "fixtures/synthetic_conversations.json"
PLAN = ROOT / "RELIABILITY_TRIAL_B_20261118.json"
LEDGER = ROOT / ".local/reliability-trial-b-results.jsonl"
REPORT = ROOT / "TRIAL_B_QUOTE_FIDELITY_AUDIT.md"

# Post-hoc manually identified quoted spans. "full" is the complete recorded
# exact_text. "speech" is a directly quoted inner utterance within the source.
TARGETS = {
    "H01": (("m3", "full"),),
    "H02": (("m4", "full"),),
    "H03": (("m1", "full"),),
    "H04": (("m5", "full"),),
    "H05": (("m5", "full"), ("m6", "full")),
    "H06": (("m4", "full"),),
    "H07": (("m1", "speech"), ("m3", "speech")),
    "H08": (("m5", "full"),),
    "H09": (("m2", "full"),),
    "H10": (("m3", "full"), ("m4", "full")),
}


def quote_fold(s: str) -> str:
    """Collapse quotation-mark variants ONLY; preserve all other characters."""
    return s.translate(str.maketrans({"\u201c": '"', "\u201d": '"', "\u2018": '"', "\u2019": '"'}))


def source_span(message: dict, mode: str) -> str:
    text = message["exact_text"]
    if mode == "full":
        return text
    if mode == "speech":
        match = re.search(r"\u201c[^\u201d]+\u201d", text)
        if not match:
            raise ValueError("Source lacks Unicode-quoted direct speech")
        return match.group(0)
    raise ValueError("Invalid source-span mode")


def compare_span(expected: str, observed: str) -> str:
    if expected in observed:
        return "exact"
    if quote_fold(expected) in quote_fold(observed):
        return "punctuation_only"
    return "not_observed"


def audit(fixture: dict, plan: dict, results: list[dict]) -> list[dict]:
    messages = {m["message_id"]: m for m in fixture["messages"]}
    cases = plan["cases"]
    if len(cases) != 20 or len(results) != 20:
        raise ValueError("Requires complete 20-case original trial")
    if [c["id"] for c in cases] != [r["id"] for r in results]:
        raise ValueError("Original pre-registered order mismatched")
    history = [c for c in cases if c["kind"] == "history"]
    if set(TARGETS) != {c["id"] for c in history}:
        raise ValueError("Post-hoc source span review is incomplete")
    rows = []
    by_result = {r["id"]: r for r in results}
    for case in history:
        answer = by_result[case["id"]]["answer_excerpt"]
        if not by_result[case["id"]]["completed"] or len(answer) >= 1200:
            raise ValueError("Incomplete or possibly truncated response: " + case["id"])
        targets = []
        for mid, mode in TARGETS[case["id"]]:
            if mid not in case["expected_message_ids"]:
                raise ValueError("Quoted source not in registered expected message list")
            span = source_span(messages[mid], mode)
            targets.append({
                "message_id": mid, "mode": mode,
                "status": compare_span(span, answer),
                "source_sha256": hashlib.sha256(span.encode("utf-8")).hexdigest(),
            })
        rows.append({
            "id": case["id"], "targets": targets,
            "all_exact": all(t["status"] == "exact" for t in targets),
            "fetch": by_result[case["id"]]["fetch_count"],
        })
    return rows


def format_report(rows: list[dict]) -> str:
    spans = [t for r in rows for t in r["targets"]]
    counts = {x: sum(t["status"] == x for t in spans) for x in
              ("exact", "punctuation_only", "not_observed")}
    out = [
        "# Trial B — retrospective source-quotation fidelity audit",
        "",
        "This analysis was performed AFTER the fixed 20-case native trial. Its selected "
        "quoted spans and exactness criterion do not replace or rescore the original "
        "pre-registered initiation, fetch or answer-marker results.",
        "",
        f"Exact Unicode quoted spans: **{counts['exact']}/{len(spans)}**.",
        f"Quotation-mark-only differences: **{counts['punctuation_only']}/{len(spans)}**.",
        f"Other absent expected spans: **{counts['not_observed']}/{len(spans)}**.",
        f"Cases with all selected spans exact: **{sum(r['all_exact'] for r in rows)}/{len(rows)}**.",
        "",
        "| Case | Source spans | Byte-identical | Unicode quote drift | Source fetches |",
        "|---|---|---|---|---:|",
    ]
    for row in rows:
        labels = ", ".join(t["message_id"] + ":" + t["mode"] for t in row["targets"])
        exact = ", ".join(t["message_id"] for t in row["targets"] if t["status"] == "exact") or "none"
        drift = ", ".join(t["message_id"] for t in row["targets"] if t["status"] == "punctuation_only") or "none"
        out.append(f"| {row['id']} | {labels} | {exact} | {drift} | {row['fetch']} |")
    out += [
        "",
        "## Relevant distinctions",
        "",
        "- **H03:** the answer introduced a passage as exact archived wording but substituted "
        "single Unicode curly quotation marks for the original double curly quotation marks "
        "surrounding Mira's reported words. The factual location and authorship need not be wrong.",
        "- **H10:** the answer similarly labelled the complete correction exact but changed "
        "the original inner double quotation marks to single curly marks. A separate source-fetch "
        "call was also absent. The initial lookup itself supplied full original source text.",
        "- **H07:** the answer quoted only the inner spoken sentences, not the narrator's full "
        "message, so the audit checks those verbatim spans rather than falsely require full records.",
        "",
        "The Unicode mark difference is a byte-level discrepancy, not proof of semantic misinformation. "
        "Other claims still need human contextual review; exact matching of selected spans is not "
        "a complete hallucination or provenance audit.",
        "",
        "All inspected excerpts were shorter than the recorder's 1200-character clipping limit. "
        "All source records are fictional. The private per-case answer ledger remains local in the "
        "Git-ignored .local directory and was not published. No original Trial B score was changed.",
        "",
    ]
    return "\n".join(out)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("action", choices=("status", "write"))
    action = p.parse_args().action
    fixture = json.loads(SOURCE.read_text(encoding="utf-8"))
    plan = json.loads(PLAN.read_text(encoding="utf-8"))
    results = [json.loads(line) for line in LEDGER.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    rows = audit(fixture, plan, results)
    statuses = [t["status"] for r in rows for t in r["targets"]]
    print(json.dumps({
        "cases": len(rows), "quote_spans": len(statuses),
        "full_case_matches": sum(r["all_exact"] for r in rows),
        "exact_spans": statuses.count("exact"),
        "quote_mark_only_drift": statuses.count("punctuation_only"),
        "not_observed": statuses.count("not_observed"),
        "drift_cases": [r["id"] for r in rows if not r["all_exact"]],
    }, sort_keys=True))
    if action == "write":
        REPORT.write_text(format_report(rows), encoding="utf-8")
        print("RETROSPECTIVE_QUOTE_AUDIT_WRITTEN")


if __name__ == "__main__":
    main()
