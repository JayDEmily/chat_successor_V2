"""Serve a registered automatic-recall trial through the existing private tunnel."""

import argparse
import hashlib
import json
from pathlib import Path

from ltm_vnext.hosted_mcp_u import CallQuotaU, create_server
from ltm_vnext.hosted_mcp_w import (
    HostedMemoryGatewayW, check_registration, git, validate_native_recall, validate_semantic_w,
)
from ltm_vnext.verified_dialogue_t import NativeVerifiedT

ROOT = Path(__file__).resolve().parents[1]
REGISTRATION = "3da1c26e2ce82d6714da131f5ffc44ead08428ab"
CASE_FILE = "NATIVE_RECALL_ROUTING_CASES_20261120.json"
AUDIT = ROOT / ".local/trial-y-hosted-mcp-audit.jsonl"
LONG_FORM_REGISTRATION = "f56bcd9c843cef8092eaebd74dc535bb44e4efee"
LONG_FORM_CASE_FILE = "NATIVE_RECALL_LONG_FORM_CASES_20261121.json"
LONG_FORM_AUDIT = ROOT / ".local/trial-long-form-hosted-mcp-audit.jsonl"
RETRY_REGISTRATION = "c842b1cdcc170518307d01cf4707c3a325293c43"
RETRY_CASE_FILE = "NATIVE_RECALL_LONG_FORM_RETRY_CASES_20261121.json"
RETRY_AUDIT = ROOT / ".local/trial-long-form-retry-hosted-mcp-audit.jsonl"
HISTORY_REGISTRATION = "040cdcc6cee9e228e5302ecce6ed90ec378fce76"
HISTORY_CASE_FILE = "NATIVE_LONG_HISTORY_CASES_20261121.json"
HISTORY_AUDIT = ROOT / ".local/trial-long-history-hosted-mcp-audit.jsonl"


class UnavailableArchive:
    """Keep the same tool reachable without exposing archive search during the baseline."""

    def search(self, query, *, top):
        return []


def registered_call_limit(
    registration: str, case_file: str, snapshot: Path, snapshot_hash_key: str
) -> int:
    cases = (ROOT / case_file).read_bytes()
    if cases != git("show", f"{registration}:vnext/{case_file}"):
        raise RuntimeError("Frozen recall cases changed")
    plan = json.loads(cases)
    parent = git("rev-parse", f"{registration}^").decode().strip()
    if parent != plan["baseline_commit"]:
        raise RuntimeError("Recall baseline changed")

    source = ROOT / ".local/native-t-dialogue/dialogue_s.sqlite"
    if hashlib.sha256(snapshot.read_bytes()).hexdigest() != plan[snapshot_hash_key]:
        raise RuntimeError("Prior recall audit snapshot changed")
    if hashlib.sha256(source.read_bytes()).hexdigest() != plan["stage_t_sqlite_sha256"]:
        raise RuntimeError("Canonical fictional source changed")
    return plan["max_mcp_calls"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--trial", choices=("routing", "long-form", "long-form-retry", "long-history"),
        default="routing",
    )
    parser.add_argument("--archive-unavailable", action="store_true")
    args = parser.parse_args()
    if args.archive_unavailable and args.trial != "long-history":
        parser.error("--archive-unavailable is only for the matched long-history baseline")
    repaired = args.trial in {"long-form-retry", "long-history"}
    if args.trial == "long-history":
        limit = registered_call_limit(
            HISTORY_REGISTRATION,
            HISTORY_CASE_FILE,
            ROOT / ".local/native-long-form-retry/trial_long_form_retry_audit_at_completion.jsonl",
            "prior_long_form_retry_audit_sha256",
        )
        plan = json.loads((ROOT / HISTORY_CASE_FILE).read_bytes())
        fixture = plan["fixture"]
        generated = (ROOT.parent / fixture["generator"]).read_bytes()
        if hashlib.sha256(generated).hexdigest() != fixture["generator_sha256"]:
            raise RuntimeError("Long-history fixture changed")
        audit, stage = HISTORY_AUDIT, "long-history"
    elif args.trial == "long-form-retry":
        limit = registered_call_limit(
            RETRY_REGISTRATION,
            RETRY_CASE_FILE,
            ROOT / ".local/native-long-form/trial_long_form_audit_at_completion.jsonl",
            "prior_long_form_audit_sha256",
        )
        audit, stage = RETRY_AUDIT, "long-form-retry"
    elif args.trial == "long-form":
        limit = registered_call_limit(
            LONG_FORM_REGISTRATION,
            LONG_FORM_CASE_FILE,
            ROOT / ".local/native-z/trial_z_audit_at_completion.jsonl",
            "prior_provenance_audit_sha256",
        )
        audit, stage = LONG_FORM_AUDIT, "long-form"
    else:
        limit = registered_call_limit(
            REGISTRATION,
            CASE_FILE,
            ROOT / ".local/native-x/trial_x_audit_at_completion.jsonl",
            "stage_x_audit_sha256",
        )
        audit, stage = AUDIT, "Y"

    if args.trial != "routing" and (type(limit) is not int or limit != 5):
        raise RuntimeError("Long-form recall must have a five-attempt backend limit")
    check_registration()
    gateway = HostedMemoryGatewayW(
        pipeline=UnavailableArchive() if args.archive_unavailable else NativeVerifiedT(),
        quota=CallQuotaU(audit, limit=limit, stage=stage),
        validator=validate_native_recall if repaired else validate_semantic_w,
    )
    create_server(gateway, default_limit=5 if repaired else 3).run(
        transport="streamable-http",
        host="127.0.0.1",
        port=8792,
        json_response=True,
        stateless_http=True,
    )


if __name__ == "__main__":
    main()
