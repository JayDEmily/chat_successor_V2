# Next native evidence gate — clean-context retrieval and ambiguity

**Status:** DESIGN_ONLY; not executed or accepted. The complete Trial F remains the audited baseline and cannot be rescored.

## Deficiency this gate addresses

The pre-registered Trial F used a new conversation for each test inside an **existing ChatGPT Project**. OpenAI's current [Projects documentation](https://help.openai.com/en/articles/10169521-projects-in-chatgpt) confirms Project memory may draw on earlier chats within that Project. As a result, correct answers without new MCP calls cannot establish retrieval from the local archive. Four vague questions also selected a notebook referent despite insufficient text identifying the intended record.

## Proposed independently observable control

1. Use a **new, empty Project set to project-only memory**, not merely a new chat in the existing Project. Verify the selected memory mode and absence of previous project chats before testing; do not alter the user's existing Projects or account-level memory settings.
2. Use a **new synthetic-only fixture with distinctive opaque facts** that have never appeared in ChatGPT project files, prior prompts or any previous test answers. All originals, corrections and alternative-branch assertions remain separately attributed. Register exact source IDs, SHA-256 hashes and expectations in Git **before** first model access to that fixture.
3. Expose only that new fixture through a **separate, private, read-only test MCP/tunnel** if the already-connected plugin cannot isolate catalogues without changing the current production-like synthetic service. Do not reconfigure or overwrite the current six-message MCP or its tunnel. Reuse the already authorised secret only through the existing in-memory key-mapping mechanism and never print it. Any new account-level tunnel creation or workspace change must be separately scoped and auditable.
4. Submit source-needed prompts and unrelated/ambiguous controls in pre-registered order. Record native Project chat IDs, actual MCP audit event IDs, time windows, exact response text, and source fetches, with a duplicate-safe pending-send marker. Separate **invocation**, **correct source identity**, **faithful quotation**, **authorship/branch/correction provenance**, **referent disambiguation** and **no-source abstention**.
5. Include deliberately vague prompts without conversational referents. A clear user-facing clarification or explicit uncertainty is expected; arbitrary selection of a particular source is an ambiguity failure even when its archived facts happen to be correct.
6. Treat an eventual lack of tool calls as an observed failure of the registered trace, not proof that the model never attempted an unavailable remote call. Preserve timeout, generation-stall and Project-memory controls; never retry an unresolved Send without independently inspecting its saved conversation.

## Advancement rule

Do not deploy shadow dense retrieval, introduce real conversation imports, or claim population-level reliability based on Trial B/F or the small offline C/D/E tests. Only a source-faithful, isolated **native** test with the correct context boundary can reduce the current causal uncertainty. Define a realistic sample size and acceptance criteria before execution; mere exact-source packet integrity is already proven offline and must not be conflated with relevance.

No new Project, plugin, tunnel, archive or account setting is created by this design record.
