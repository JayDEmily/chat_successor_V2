# Synthetic shadow source-packet fidelity boundary — verified

**Verdict: ACCEPT_SHADOW_SOURCE_INTEGRITY_ONLY.**

The read-only `ShadowPacketResolver` and standalone `audit_shadow_source_packets_e.py` passed the fixed Holdout E synthetic source-integrity trial. This does not approve a native ChatGPT search replacement, real conversation ingestion or any external inference API.

## Exact verification

- **34 registered fictional records** in an ephemeral SQLite archive, with 58 pre-registered synthetic questions from Holdout E.
- Raw dense BGE-small locally ranked every source message by cosine similarity, then passed the top **8 stable message IDs** to `ShadowPacketResolver`. No expected source IDs, source labels, query classes or hand-written synonyms were used for ranking.
- **464/464 source packets** resolved from the **existing read-only `Archive.fetch` method**, without modifying source text. The registered target was present among top eight on **30/30** positive questions.
- Each source packet was checked against the original synthetic fixture for stable source/message/version identity, exact UTF-8 text SHA-256, source locator, author role, reported speaker, attribution, conversation and branch, correction predecessor and correction descendants, and exact text/hash/branch identity of neighbouring dialogue.
- **40/40 isolated shadow tests** passed, including fault injection for corrupted source text, hash, locator, branch, reported speaker, supersession identity, correction descendants and a malicious injected cross-branch neighbour. Duplicate/unknown source IDs, non-finite scores, more than eight results, and a non-synthetic fixture are rejected.
- The same synthetic archive used for source evidence was separate from the **live** six-message native MCP archive. No native tool calls or paid inference were initiated by this packet test.
- One observed local run: 58 queries, 464 source packets and all checks completed in approximately **0.981 seconds**, excluding any unrelated operations. This is not a production latency guarantee.

## What passing means

**Accepted:** the bounded shadow implementation correctly resolves and checks the source bytes and provenance of these invented records under both normal and deliberately corrupted conditions. The resolver uses a `candidate_relevance=unverified_candidate` marker and `source_integrity=verified_against_synthetic_fixture_only` marker for every result; it never conflates cosine similarity with verified source relevance.

**Not accepted:** relevance and abstention quality, native ChatGPT tool invocation/selectivity, a production embedding model, fidelity/authenticity of genuine human speech, or a permission to import personal conversation data. The 28 generic/ambiguous questions collectively produced **224 fully valid source packets** even though no unique record was relevant by test design. Therefore byte-exact retrieval alone cannot solve no-source detection.

## Strongest supported next engineering direction

Keep **original SQLite FTS5 live**, maintain raw dense + packet resolver **offline/shadow only**, and design a separately registered native end-to-end contract proving that the assistant uses candidates **only** for clearly history-dependent questions and either disambiguates multiple plausible records or reports insufficient evidence.

In future work, candidate retrieval should be scoped to source identities and exact readonly SQLite packets. A query-intent/relevance decision must be independently validated; do not install the rejected cosine threshold, and do not treat a verified packet as a verified proposition.

The stage is complete without modifying Windows startup, the connected native ChatGPT plugin, real conversation history, or the supplementary OpenAI inference gateway.
