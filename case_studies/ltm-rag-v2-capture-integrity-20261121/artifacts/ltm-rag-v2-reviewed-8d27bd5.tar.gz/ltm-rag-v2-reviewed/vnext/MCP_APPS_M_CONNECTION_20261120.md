# Stage M — isolated private tunnel/plugin connection and native-readiness reconciliation

**20 November 2026 (AEDT) | Synthetic-only; no Stage M native send.**

**Disposition: PRIVATE_PLUGIN_REGISTERED_AND_TUNNEL_READY; NATIVE_M_N01_N02_NOT_RUN_TOOL_NOT_VERIFIED.** This report follows the [pre-registered protocol](MCP_APPS_M_PROTOCOL_20261120.md) and [16 fixed cases](MCP_APPS_M_CASES_20261120.json), at registration commit `2c24a4ebabb5a8be8ec4d3ecabc5cedc73a69193`. The Stage M [offline implementation](MCP_APPS_M_OFFLINE_RESULTS_20261120.md) was committed as `9f67a287f598964c03ae157fadc82d0da8ff64e4` before any M connection work.

## Verified M-specific transport and registry state

- New dedicated tunnel ID `tunnel_6affa48f70b0819187bbe06449bf2750`, name `LTM-RAG-vNext-Apps-M-20261120`. The M admin launcher checked **zero** same-name tunnels before the **single creation**; then exact ID/name/organisation independent control-plane readback and a list with exactly **one** matching tunnel both passed. The receipt remains ignored, under `vnext/.local/trial-m-tunnel-receipt.json`.
- An isolated `ltm-vnext-apps-m` private tunnel profile points **only** to `http://127.0.0.1:8791/mcp` and uses the pre-existing owner-authorised control-plane credential from Ubuntu's private environment; no new key was created, disclosed or committed. The profile lives under ignored `vnext/.local/profiles/`; no original/G/I/K profile changed.
- New Python MCP Apps server started only on loopback `127.0.0.1:8791` (WSL PID observed: 9975). The standalone tunnel doctor returned `ok` after the listener started, including target access and OAuth-not-advertised handling. The new private tunnel listener (WSL PID observed: 10048) returned `ready` at the discovered ephemeral health port 35573. Original/G/I/K retained their separate listeners at 8787/8788/8789/8790 and their four discovered tunnel health ports 43999/32953/46159/35501 each independently returned `ready`. Ports/PIDs are observations, not durable identifiers across restarts.
- One **new private USER-scoped ChatGPT plugin**, with discoverability PRIVATE and no public listing: `plugins_6affa5ab43fc81918f735d54ea8e9425`, version 0.1.0, release `pluginrel_6affa5ace64881919f2d4fc4a3f60bd9`. Plugin Creator returned **created** once, and separate registry metadata and all four generated manifest file contents were independently read back. The plugin's private `mcp.json` and compatibility `.mcp.json` both bind exactly `tunnel_6affa48f70b0819187bbe06449bf2750` with streamable HTTP, no plugin-packaged credentials. Registry link: https://example.invalid/private-chatgpt-evidence
- Prior Stage K private plugin `plugin_asdk_app_6aff77ff8dd48191b31949e4f23531d4` and all other existing plugins remain untouched.

## Native browser verification: no case executed

- Inspected only the identified James-profile Chrome Plugins directory window (Win32 handle 788352) and an earlier, isolated synthetic K test Chrome window (handle 5441354), without closing or controlling unrelated Chrome/project windows. The dedicated K window was moved by a **single verified global New chat action** from an already saved K conversation to a fresh, unsent `chatgpt.com` composer. The Windows navigation marker is `%LOCALAPPDATA%\Temp\ltm_m_newchat_nav_marker.json`. Prior saved K chat messages were not modified or resent.
- In the fresh chat, the `Add files and more` plugin picker displayed other available apps, but the Stage M plugin/tool was **not positively identified**. A "Type to search plugins" label appeared below the initially visible viewport; scrolling moved it to the bottom, but a targeted click did not yield a verifiable editable search input and the popover closed. The Personal Plugins directory likewise did not expose a uniquely attributed Stage M entry in the inspected UI; a direct-navigation attempt did not yield an independently verified Stage M detail page. These UI limitations **do not prove** the plugin is unavailable to every ChatGPT client.
- **No frozen M-N01 prompt was sent and no M-N02 automated widget click occurred.** There was no connected Stage M tool invocation to observe, and the private `vnext/.local/trial-m-mcp-audit.jsonl` file was absent on final check: **zero native M server call events observed**. No native case is retrospectively claimed completed from a tunnel health poll, plugin creation, or local SDK client smoke.
- Stage M client-side app-only visibility remains a descriptor/SDK fact, **not** proven host filtering or server-side authenticated access. The Stage K original-message provenance limitation and Stage I's 14/16 native verdict are unchanged.

## Acceptance and next bounded action

**ACCEPT: M private tunnel ready; private plugin created and exact tunnel-binding registry readback; M offline 16/16 and local full Streamable HTTP smoke passed.**

**NOT ESTABLISHED: ChatGPT's native exposure of Stage M's opening tool; embedded widget rendering; app-only tool filtering in ChatGPT; any actual human action; authenticated user's exact current message.**

**Status: `NATIVE_M_N01_N02_NOT_RUN_TOOL_NOT_VERIFIED`.** Before any subsequent native send, verify this distinct private plugin in a newly loaded eligible ChatGPT session, retain frozen one-send and one-automated-click limits, recheck the ignored M audit baseline, and use a uniquely identified, isolated browser window. Do not reuse the unsupported K native send ledger or infer user consent. No real history, production deployment, external inference, OS autostart, source SQLite integration or legacy connector repointing was performed.


## Subsequent verified native evidence — 20 November 2026

The `NOT_RUN_TOOL_NOT_VERIFIED` status above is a **historical checkpoint**, not the current Stage M state. A separate native ChatGPT custom-MCP connection (`plugin_asdk_app_6affaf818f3481919433489e25b52471`) was later created using the existing M tunnel, then verified in a fresh native ChatGPT conversation. Exactly one model-visible opening event and one automated app-only callback were observed; the latter returned `EXPIRED` after 262.618 s against TTL 60 s. The embedded UI and app-only callback transport worked, but **no accepted confirmation** or human consent was established. See [subsequent complete native results](MCP_APPS_M_NATIVE_RESULTS_20261120.md). No Stage M native resends or clicks remain authorised under the frozen protocol.
