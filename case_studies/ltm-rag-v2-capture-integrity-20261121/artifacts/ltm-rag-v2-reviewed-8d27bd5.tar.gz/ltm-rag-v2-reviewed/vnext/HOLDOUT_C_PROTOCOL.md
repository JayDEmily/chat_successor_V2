# Holdout C — pre-registered lexical retrieval stress test

**Frozen before testing:** 18 November 2026 AEDT. This is a distinct **offline** retrieval evaluation, not another live ChatGPT initiation test.

## Corpus and intent

- `fixtures/synthetic_holdout_c.json`: **26 wholly invented messages** across eight independent fictional narratives (observatory, ferry, laboratory, gallery, gardening, documents, bike and survey map).
- Preserves user/assistant authorship, separate reported speakers, eight main-branch corrections linked to original records, and two alternative branches. No genuine personal conversation or physical-world claim is incorporated.
- The existing six-message online synthetic Project is **untouched**. This corpus will be loaded into a separate temporary SQLite database for offline evaluation only; neither the live MCP server nor its tunnel is changed.

## Locked probes and metrics

- `HOLDOUT_C_PROBES_20261118.json` defines **16 ordered retrieval probes**: eight `explicit` prompts naming distinctive stored terms and eight `implicit` prompts using paraphrases and circumlocutions.
- Each probe registers a single expected corrected message ID and the same candidate limit **8** before any execution. All cases are retained even if they miss.
- Primary outcome is **recall@8 of the registered corrected source message**, reported separately for explicit and implicit prompts. A match only by another source on the same subject is **not** a registered-source hit. Rank of the registered target is retained.
- Also record any empty candidate set and whether the first-ranked hit is the registered target. These auxiliary metrics are descriptive, not substituted for recall@8.
- No changes to the queries, fixture or registered expected IDs after baseline inspection. If a scoring error is found, record and repair transparently in a separate commit while preserving the original baseline.
- This test measures only the current **SQLite FTS5 OR-token lexical retrieval layer**. It **does not** measure when native ChatGPT decides to search, source quotation fidelity, synthesis accuracy, semantic embedding quality, real data capture or OpenAI model usage.

## Decision boundary

A measured implicit-query miss would justify considering a more capable retrieval method or bounded query rewriting, but **not** automatic deployment of an embedding model or a background researcher. The smallest evidence-backed implementation should be evaluated against this frozen baseline separately, retaining the SQLite archive as the canonical exact-source store.

The native service and private tunnel remain on the six-message original fixture; no data is copied between them and the offline holdout database. All reported outcomes must distinguish the already completed 20-case native test from this new, offline probe.
