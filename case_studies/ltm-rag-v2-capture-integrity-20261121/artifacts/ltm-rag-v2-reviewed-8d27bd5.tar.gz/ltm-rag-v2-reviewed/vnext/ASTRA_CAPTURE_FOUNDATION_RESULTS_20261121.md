# Astra capture foundation - implementation checkpoint

**21 November 2026**
**Baseline:** `269bf99504244301fb790b49dc908beb9a545603` (verbatim Astra import)
**Frozen protocol:** `ASTRA_CAPTURE_FOUNDATION_PROTOCOL_20261121.md`, preregistered at `fc0db8d4c35a34f6327855c2fac8e1c6eefa6c90`
**Scope:** isolated local synthetic source receipts only, no new normal-Chat sends or remote API calls.

## Implementation

- `ltm_vnext/capture_foundation_v.py`: separate synthetic-only SQLite receipt ledger; exact text hash, immutable author/branch/version/position and separate event timestamps. Source ingestion and index-outbox insertion are atomic; a replay preserves first ingestion. SQLite file mode is 0600.
- Directly observed synthetic receipts begin as `SOURCE_OBSERVED`. A separately supplied synthetic readback can confirm the same bytes and record its external evidence reference; there is no real-owner attestation or passive native capture route.
- Indexing has `PENDING`, `IN_FLIGHT` and `SEARCHABLE` states. Once reserved, uncertain uploads cannot silently be repeated. An explicit synthetic remote-absence reconciliation can requeue the item; recorded reconciliation references do not themselves prove live provider state.
- Per-conversation/branch coverage records explicit `GAP_UNKNOWN` positions independently of observed source; there is no automatic completeness claim. Corrected originals and alternative branches remain separate. Model reconstructions go into a separate, non-indexed table.
- The snapshot path checks both stored original-text hashes and outbox payload hashes before releasing the local synthetic records.

## Evidence

- Pre-change Ubuntu project core suite: **245/245 passed**.
- New targeted synthetic tests: **18/18 passed**, covering CF01-CF11 and additional readback-integrity tests.
- Original Astra review-tool tests: **31/31 passed**.
- Full regression suite: run and publish its result at final checkpoint.
- Shadow suite could not run in the vNext virtual environment because NumPy is absent (three module-import errors); this is **not a passing shadow result**. Its previous independent 40/40 pass is historical, not a substitute for a current rerun.

## Explicit limitations / next boundary

**`CAPTURE_ROUTE_NOT_ESTABLISHED`** for passive capture of ordinary ChatGPT conversations. This local synthetic implementation does not capture real turns, identify an authenticated owner, serve a model-callable plugin or index remotely. The prescribed live 12-turn experiment remains `NOT_RUN`; only its local 12-turn outage/replay simulation has passed. No personal source, frozen S/T trial, original/G/I/K/M plugin, tunnel, credential, startup task or production service was altered.

Next: establish a supported, authorised, genuinely passive source capture route and independently retained source inventory before running the live 12-turn native experiment. The source capture ledger can be used as a local synthetic test harness but does not itself satisfy that external prerequisite.
