# Native ChatGPT Project history confound — evidence qualification

**Discovered 18 November 2026 during Native Trial F.** The original pre-registered test inputs and source-call counts have **not** been revised.

## Verified OpenAI product mechanism

OpenAI's current official [Projects in ChatGPT documentation](https://help.openai.com/en/articles/10169521-projects-in-chatgpt), section **Memory in projects**, states that project chats can use other conversations in the same Project as context. This is true for **both default Project memory and project-only memory**. For Plus/Pro, previous chats in the Project may be prioritised when answering new Project queries. See also the [Memory in ChatGPT explanation](https://help.openai.com/en/articles/8590148-memory-in-chatgpt).

Therefore, a **new conversation within an existing Project does not guarantee that earlier Project answers are inaccessible** to the model. We previously used “fresh Project chat” in the experimental protocol to isolate immediate conversational turns. That isolation is real at the conversation URL level, but **does not imply isolation from Project memory**.

The exact Project memory setting and whether cross-chat context actually contributed to any particular response were **not independently observed**; neither can be inferred simply because the answer contains the fictional source.

## Impact on native evidence interpretation

1. The local MCP audit still confirms **actual successful tool calls** (and their exact event IDs) for turns which used the connected plugin; these are not erased by Project memory.
2. A response that is correct about synthetic source text **without a new MCP event** might have used general model reasoning, prior Project chat content, other available memory context or another mechanism. **Do not assign a unique cause** without evidence.
3. The Trial B and F “fresh conversation per case” method should not be called a **fully independent blank-memory experiment** or evidence that the external MCP supplied every remembered fact.
4. Native F provides direct instances: M04 and C02 produced substantively source-consistent answers despite **zero successful local tool calls**. C04 likewise distinguished reported speech from authenticated audio without an MCP event. These answers must **not** be counted as verified external archive reads.
5. The previously published Trial B counts (10/10 initiated on history questions, 0/10 unnecessary on unrelated controls) are still correct **observed successful-call counts**. Any stronger causal statement that native ChatGPT *needed* the external archive for those answers is **not established** by these trials.

## Next experimental control

Register and execute a *separate* test where the relevant fictional source has **not already appeared in the target conversation/Project memory**, with a verified empty context boundary and a direct audit of external MCP calls. Assess whether a temporary unpersonalised chat can access the installed plugin before assuming it will work; do not change account-wide memory settings or delete past chats to simulate isolation. The existing six-message test corpus is now extensively repeated in this Project, so reusing its facts cannot prove clean-room retrieval.

The current Native F plan continues unchanged as a **within-Project functional test** with per-turn tool traces, not a clean-room causality test. No account setting, ChatGPT memory, plugin or connected project was modified by this research.
