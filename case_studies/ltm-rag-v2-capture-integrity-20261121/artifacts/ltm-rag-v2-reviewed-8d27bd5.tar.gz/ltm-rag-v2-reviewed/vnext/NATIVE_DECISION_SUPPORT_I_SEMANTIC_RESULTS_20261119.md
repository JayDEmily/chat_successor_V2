# Native Decision-Support I — retrospective original-source semantic review

**Verdict: 14/16 acceptable answers; 2/16 unsupported referent
selection failures (I05/I15).** This separately reviews the
complete saved ChatGPT answers against the original 20 made-up
messages. Read-only validation confirmed every referenced message
identity, correction edge, branch, source role and reported speaker.
Marker checks only corroborate full-answer human semantic review.

The separate native invocation check passed **12/12** specified
required/avoided-tool cases with **14 successful I calls**, but
the native source-packet scope checked **14/16** and failed
**I05/I15**. Tool success is not semantic success.

| Case | Source-content judgement | Original evidence messages | I source scope |
|---|---|---|---|
| I01 | PASS_CLARIFICATION | none | PASS |
| I02 | PASS_SOURCE_FIDELITY | g03, g01 | PASS |
| I03 | PASS_SOURCE_FIDELITY | g11, g09 | PASS |
| I04 | PASS_BRANCH_FIDELITY | g16, g15, g13 | PASS |
| I05 | FAIL_UNSUPPORTED_REFERENT | g13, g15 | **FAIL** |
| I06 | PASS_MULTI_SOURCE | g03, g19 | PASS |
| I07 | PASS_REPORTED_SPEECH | g05, g06, g07 | PASS |
| I08 | PASS_MISSING_FACT_ABSTENTION | g17, g19 | PASS |
| I09 | PASS_UNRELATED | none | PASS |
| I10 | PASS_UNRELATED | none | PASS |
| I11 | PASS_CLARIFICATION | none | PASS |
| I12 | PASS_ORIGINAL_VERSION | g01 | PASS |
| I13 | PASS_BRANCH_FIDELITY | g12, g11, g09 | PASS |
| I14 | PASS_SOURCE_FIDELITY | g19, g17 | PASS |
| I15 | FAIL_UNSUPPORTED_REFERENT | g05, g07 | **FAIL** |
| I16 | PASS_MISSING_FACT_ABSTENTION | g05, g06, g07 | PASS |

## Material native findings

**I01 (first chat-empty Project turn):** The assistant actually
called the new I resolver, received **zero source packets** and
asked which record the user meant. The answer selected no
narrative. This is one independently grounded clean-context pass.

**I05:** For the referent-free prompt *Was the original version
first or second?*, the model made one successful I call whose
handler returned **12 original source packets**, although the
registered unanchored question requires zero. The assistant
answered 'First' and introduced the ORA-62 pier 4/pier 11
example, despite the user not identifying ORA-62. The original
ORA facts were accurate, but the referent selection was
unsupported. Record **FAIL_UNSUPPORTED_REFERENT**.

**I15:** For *Did she actually say it?*, the user gave no
speaker or conversation identity. The I handler nevertheless
returned **four packets**, and the assistant identified the
Vela/TERN-91 narrative. Its statement that Vela's purported
speech is only an unverified narrator recollection is accurate
for g05/g07, but that does not establish which 'she' the user
meant. Record **FAIL_UNSUPPORTED_REFERENT**.

**I11:** The third underspecified follow-up returned zero
source packets and asked for the intended record, like I01.
Thus ambiguity behaviour was mixed, not consistently fixed.

**I02–I04/I06–I08/I12–I14/I16:** The main source conclusions
matched the original messages: user corrections remained
distinct from assistant-only alternative-branch guesses;
the original locker/optic remained distinct from the
corrected one; the multi-topic comparison retained both
correction sources; reported Vela speech was never treated
as authenticated audio, and no missing serial/audio was
fabricated.

**I09–I10:** Technical questions about thermal expansion and
hydraulic accumulators were answered without I resolver
calls; semantic technical explanations were adequate.
Accessibility text extraction may distort mathematical glyphs,
so this review does not certify equation typography.

## Root cause interpretation and next engineering boundary

The I server validates the original 20-source archive and
only returns source packets when **its received tool argument**
contains an explicit narrative anchor. The frozen unanchored
user prompts had no such anchors. Successful calls with 12
or four packets therefore show a mismatch between the user
question's referent and the arguments effectively evaluated
by the tool. The actual tool arguments were not logged,
so their exact wording and whether earlier same-Project chats
caused the expansion are **unknown**. Do not claim the native
model faithfully passed the current user text verbatim.

This is a trust-boundary failure, not proof that H's original
current-question local selector is broken. A model-authored
tool question is not a host-attested user question. Simply
asking the model to pass text verbatim, adding an extra
fetch_source call or accepting source ranking cannot prove
referent legitimacy. A separately registered mechanism
would need a trusted binding to the actual user request,
or a validated dialogue-context contract, plus native tests.

## Causal and completeness limitations

- I01 was first in a newly chat-empty Project whose Project-only
  memory was explicitly selected at creation and verified
  again in reopened Project settings. Later I02–I16 were
  within the same Project and may share Project memory.
  Immediate memory-mode propagation was not independently proved.
- Every full answer was reviewed against an entirely fictional
  original archive. Neither genuine memory reliability nor
  external factual authenticity has been established.
- The connected I plugin and private localhost/tunnel were
  entirely separate from the original six-source and G
  services. No native G score or source text was rewritten.
- The 16 complete answers, private event IDs and prompt hashes
  remain in ignored local ledgers; public Git reports contain
  only reduced fictional case evidence and saved-chat links.
