# Post-restart direct ChatGPT plugin invocation — 18 November 2026

**Status: PASS for explicit plugin lookup + fetch via the existing ChatGPT connection.** This test occurred after the Ubuntu restart and after the original 16-case native Trial F was complete.

## Independent path tested

Using the already connected `LTM-RAG vNext Synthetic Recall` plugin from this ChatGPT session, the assistant explicitly called `lookup_evidence` with query `yellow gate bicycle`, limit 3. The returned structured result contained two hits from the unchanged six-message fictional fixture, including:

- `source_id=synthetic-v1`, `message_id=m5`, `local_id=8debcfe6de4e88b9eb08fd9be616572a`
- `source_locator=fixture://garden/m5`; `author_role=user`; `branch_id=main`; `capture_method=synthetic_fixture`
- Exact original: **The blue bicycle was parked beside a yellow gate.**
- `content_sha256=f239c5e2b9e61ce67c1ffb2af46e1106c703b4827f68bca31f7f2e41365a80ca`.

A second explicit `fetch_source` call for that stable local ID returned the **same exact text, source locator, author, branch and content SHA-256**, and one neighbouring fictional assistant message.

Readback from the local Git-ignored MCP audit confirmed successful handler events:

- `lookup_evidence`: event `8ebafe02-43ff-435e-ac31-ad9d53d8933f`, timestamp **2026-11-18T10:30:28.662Z**, result_count=2, synthetic_only=true.
- `fetch_source`: event `72637497-9551-4b18-a62d-628de3b0ffbe`, timestamp **2026-11-18T10:30:37.487Z**, result_count=1, synthetic_only=true.

## Exact evidential boundary

This demonstrates the **ChatGPT connected-plugin → existing tunnel → restored local SQLite MCP → ChatGPT result** path for two explicitly requested read-only tool calls. It is stronger evidence than local loopback or tunnel health alone.

It is **not** evidence of *unprompted* memory invocation, accurate source selection on an ambiguous query, native context isolation, reliability over multiple turns, real historical capture, or authenticated real-world facts. Do not add these two post-restart events to the earlier Trial F counts, which remain exactly 16 cases, 6 lookups, 4 fetches.

No additional account credential, tunnel, source fixture or Project was created. The existing live MCP remains synthetic-only; Windows/Ubuntu automatic startup remains unmodified.
