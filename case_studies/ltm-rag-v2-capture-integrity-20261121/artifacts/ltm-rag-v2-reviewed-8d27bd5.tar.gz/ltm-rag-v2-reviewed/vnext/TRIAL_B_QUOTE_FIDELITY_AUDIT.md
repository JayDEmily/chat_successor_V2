# Trial B — retrospective source-quotation fidelity audit

This analysis was performed AFTER the fixed 20-case native trial. Its selected quoted spans and exactness criterion do not replace or rescore the original pre-registered initiation, fetch or answer-marker results.

Exact Unicode quoted spans: **11/13**.
Quotation-mark-only differences: **2/13**.
Other absent expected spans: **0/13**.
Cases with all selected spans exact: **8/10**.

| Case | Source spans | Byte-identical | Unicode quote drift | Source fetches |
|---|---|---|---|---:|
| H01 | m3:full | m3 | none | 1 |
| H02 | m4:full | m4 | none | 1 |
| H03 | m1:full | none | m1 | 1 |
| H04 | m5:full | m5 | none | 1 |
| H05 | m5:full, m6:full | m5, m6 | none | 1 |
| H06 | m4:full | m4 | none | 1 |
| H07 | m1:speech, m3:speech | m1, m3 | none | 1 |
| H08 | m5:full | m5 | none | 1 |
| H09 | m2:full | m2 | none | 1 |
| H10 | m3:full, m4:full | m4 | m3 | 0 |

## Relevant distinctions

- **H03:** the answer introduced a passage as exact archived wording but substituted single Unicode curly quotation marks for the original double curly quotation marks surrounding Mira's reported words. The factual location and authorship need not be wrong.
- **H10:** the answer similarly labelled the complete correction exact but changed the original inner double quotation marks to single curly marks. A separate source-fetch call was also absent. The initial lookup itself supplied full original source text.
- **H07:** the answer quoted only the inner spoken sentences, not the narrator's full message, so the audit checks those verbatim spans rather than falsely require full records.

The Unicode mark difference is a byte-level discrepancy, not proof of semantic misinformation. Other claims still need human contextual review; exact matching of selected spans is not a complete hallucination or provenance audit.

All inspected excerpts were shorter than the recorder's 1200-character clipping limit. All source records are fictional. The private per-case answer ledger remains local in the Git-ignored .local directory and was not published. No original Trial B score was changed.
