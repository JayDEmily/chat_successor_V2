# Holdout C — frozen, offline lexical retrieval baseline

Pre-registered before execution in HOLDOUT_C_PROBES_20261118.json. The original six-message live MCP catalogue was not changed.

Fixture SHA-256: 9bd02d60c7f8f49c71a9d4483b96868f5e7be3b5a556415563f9c7c23382b966
Probe SHA-256: 1171de1a3be92a7a3a59d6b5f25164fe06517b8ddf87ca7c9971cf1f2318d6c2

| Probe group | Registered-source recall@8 | Target at rank 1 | Empty results |
|---|---:|---:|---:|
| explicit | 8/8 | 4/8 | 0/8 |
| implicit | 6/8 | 1/8 | 0/8 |

| Probe | Group | Expected record | Actual rank | Candidate count | First result |
|---|---|---|---:|---:|---|
| E01 | explicit | c03 | 2 | 8 | c02 |
| I01 | implicit | c03 | 7 | 8 | c23 |
| E02 | explicit | c07 | 1 | 8 | c07 |
| I02 | implicit | c07 | 2 | 8 | c08 |
| E03 | explicit | c10 | 2 | 8 | c08 |
| I03 | implicit | c10 | MISS | 8 | c08 |
| E04 | explicit | c13 | 2 | 8 | c11 |
| I04 | implicit | c13 | 3 | 8 | c22 |
| E05 | explicit | c17 | 1 | 8 | c17 |
| I05 | implicit | c17 | 5 | 8 | c22 |
| E06 | explicit | c20 | 1 | 8 | c20 |
| I06 | implicit | c20 | MISS | 8 | c08 |
| E07 | explicit | c23 | 2 | 8 | c21 |
| I07 | implicit | c23 | 1 | 8 | c23 |
| E08 | explicit | c26 | 1 | 8 | c26 |
| I08 | implicit | c26 | 7 | 8 | c22 |

## Limits and next decision

This evaluates **SQLite FTS5 candidate retrieval only**, using a disposable database, eight novel fictional stories and 26 source messages. It does **not** measure ChatGPT's decision to invoke memory, OpenAI model accuracy, personal-history fidelity or production performance.

An explicit-query hit is not proof the correct citation or historical interpretation will be used. Implicit misses may indicate a lexical/semantic vocabulary gap or ranking failure. Do not retrospectively change the frozen probes. If the implicit shortfall is material, evaluate a separate hybrid/semantic candidate retrieval method against this same corpus before integrating it with the native MCP service.

No model API calls, real ChatGPT export imports, or changes to the live six-fixture archive/tunnel were made.
