# LTM-RAG vNext — post-shutdown recovery checkpoint (18 November 2026)

## Verified external state after owner powered the computer back on

- The owner reported that the Windows computer was turned off and subsequently powered on. This establishes only the **owner's report**, not verified WSL or application startup.
- Remote Desktop Commander `list_devices` returned **DESKTOP-I188O30: Offline**, last seen approximately one hour earlier. A direct remote process command failed with **"No Desktop Commander device is currently online"**.
- The connected native ChatGPT plugin `LTM-RAG vNext Synthetic Recall` was directly queried with `lookup_evidence(query="blue notebook", limit=1)`. The platform returned **"Tunnel-client has not been seen for 300 seconds. Ensure tunnel-client is running and connected."** No source text was returned.
- GitHub `fetch_file` successfully read the branch's `PROGRESS.md`, interrupted-trial report, supervisor report and guarded runner. The last independently verified full commit before this recovery note was `bf6f6f8eb10a9919f3bda2de6d814d7e6e2e000e`.
- The official Desktop Commander support documentation explicitly states Remote **does not restart automatically after a computer restart**; on Windows, run the saved Remote shortcut or its existing setup command again. See https://desktopcommander.app/help/troubleshooting/remote-cant-find-computer and https://desktopcommander.app/help/devices/connect-computer.

**Evidence boundary:** Neither the Windows session, Ubuntu filesystem, MCP process, tunnel daemon nor archived test ledgers could be inspected after the shutdown. The observed tunnel/disconnected state is verified; the exact local cause and any survived process state are not.

## Required recovery sequencing — not yet executed

1. **Reconnect the same registered Remote Desktop Commander device**, rather than pairing a new one. The machine operator should open the existing Windows **Desktop Commander Remote** shortcut (if present) or launch the previously installed Remote command. Keep the terminal open and obtain `Device ready`. Avoid changing GitHub credentials, API keys or account linkages. Source: Desktop Commander official guide above.
2. When the device reports **Online**, first inspect `wsl.exe -d Ubuntu -- whoami`, `git -C /home/jds/ltm-rag-vnext-20261118 status -sb`, `git ... rev-parse HEAD` and the remote branch SHA. Ensure the correct user is `jds`, correct branch is `work/ltm-rag-vnext-synthetic-20261118` and no unrelated changes are overwritten.
3. **Read actual local test evidence before any new ChatGPT message**. Check `vnext/.local/reliability-trial-b-results.jsonl` line count, its final `H10` record, and whether `vnext/.local/reliability-trial-b-pending.json` exists. Expect 19 completed records based on the previous observation, but after shutdown this must be verified. Do not reconstruct or fabricate missing events. Inspect audit JSONL, preserving its 0600 permissions.
4. Inspect the dedicated supervisor and child PIDs, the MCP loopback port `127.0.0.1:8787`, and **the exact dedicated profile** `ltm-vnext-synthetic` before taking action. Historical PIDs `163464` and `163607` cannot be treated as live after a shutdown.
5. If both synthetic services are absent and no conflicting process is detected, run `python3 /home/jds/ltm-rag-vnext-20261118/vnext/scripts/supervise_synthetic_services.py preflight`, then `python3 /home/jds/ltm-rag-vnext-20261118/vnext/scripts/supervise_synthetic_services.py run` from an explicitly managed, persistent remote terminal. The supervisor is an **interactive user-space parent** and does **not** automatically start after Windows/WSL boot. Do not start a second copy if either service is already running. Do not read or print the project/admin key values.
6. Independently verify both children via process identities, **real MCP source lookup and fetch**, tunnel `readyz`, and a subsequent successful OpenAI control-plane `last_success`. Only then test native ChatGPT invocation. Local `doctor` alone is insufficient.
7. **Resume only N10**, the twentieth pre-registered synthetic control, and only from a verified, truly isolated new Chrome/ChatGPT Project composer. Prior attempt stopped because a draft for another engineering project appeared in the target browser. Do not overwrite, clear, submit or otherwise act on that unrelated draft. Record the new conversation ID, exact single send, result and fresh audit event count. If isolation cannot be demonstrated, leave trial **19/20 INCOMPLETE**.
8. Re-run the independent result analyser and 36+ unit tests. Preserve `H10` as **lookup PASS / source fetch FAIL** even if the answer looked correct. Report Wilson confidence intervals separately; a 20-case synthetic sample cannot establish production population reliability.
9. Re-examine the **post-reboot service persistence gap** separately from child-exit recovery. Any Windows startup task, WSL user service or new always-on cloud instance is a separate implementation and verification boundary. No persistence mechanism has been installed.

## No action claimed

This note was prepared and committed **using GitHub directly, while Remote Desktop Commander was offline**. It is a recovery protocol, not evidence that any local process was restarted, any unexecuted test was sent, or any new Windows startup configuration was installed.

The private legacy AWS implementation, API Access gateway, real conversation imports and external inference endpoints remain outside this recovery scope.

## Executed follow-up — Remote Desktop Commander online

At the owner's subsequent confirmation, **DESKTOP-I188O30** returned Online. A direct WSL command established Ubuntu user `jds`, the correct clean work branch, local HEAD `bf6f6f8...`, and the expected GitHub remote branch `5b4da5d...`. A clean `git pull --ff-only` advanced local HEAD to that remote SHA without discarding changes.

The preserved local ledger had **19** entries ending in the original H10 (lookup=1, fetch=0, content_pass=false), with **no pending-send marker**. The two dedicated synthetic processes were absent. Synthetic fixture preflight passed.

A single `supervise_synthetic_services.py run` command started local MCP child **PID 809** and tunnel child **PID 816**. The official tunnel doctor returned `result=ok`, the loopback two-tool source lookup/fetch smoke passed, and `GET /health?details=true` (2026-11-18T06:54:10Z) reported `ready=true`, `control-plane.status=ok`, `state=polling`, successful poll at 2026-11-18T06:53:55Z and **zero consecutive failures**. A real native connected plugin `lookup_evidence` call returned the garden fixture, establishing restoration beyond local listener status. Both APIs used the already authorised project-key mapping; no extra credential was created.

**Browser isolation:** Windows UI Automation enumerated separate Chrome windows for the user's unrelated NVIDIA and performance tasks. The worker opened a **new Chrome window** directly in `LTM-RAG vNext Synthetic Trial` (handle 330542 at this observation, not a persistent identifier), verified its ChatGPT account and empty Project composer, then adapted the guarded runner to resolve a unique Project window by title and address rather than using a stale hard-coded handle. Before sending, the runner refused on a benign canonical URL redirect and preserved its own N10 draft. The runner was updated to accept both the slugged and canonical URL forms of the **same verified Project ID**. No unrelated draft was touched.

Only the registered **N10** was sent after verifying the isolated Project URL and exact draft. The final saved [N10 ChatGPT Project conversation](https://example.invalid/private-chatgpt-evidence) answered the train-bogie engineering question and made **zero** `lookup_evidence` or `fetch_source` calls. The ledger now has **20 entries**, no pending marker. Independent analyser: `complete=true`, necessary lookup **10/10**, strict fetch/registered content **9/10**, unrelated no-lookup **10/10**. **H10 remains failed on the frozen strict criterion.** Unit tests **36/36 PASS** and supervised live HTTP smoke PASS.

The complete report is [RELIABILITY_TRIAL_B_RESULTS.md](RELIABILITY_TRIAL_B_RESULTS.md); historical 19-case [partial evidence](RELIABILITY_TRIAL_B_PARTIAL_20261118.md) is retained. The case does not establish the proposed 90%/10% population targets: two-sided Wilson 95% bounds remain **72.2%–100%** for necessary initiation and **0%–27.8%** for unnecessary lookups.

**Remaining operational boundary:** User-space supervisor and tunnel do **not** automatically resume after Windows/WSL restart. This follow-up relied on Remote Desktop Commander reconnecting and explicitly starting the supervisor. No user logon task, system service or reboot persistence mechanism was installed. Live PIDs are evidence at one instant, not permanent state.
