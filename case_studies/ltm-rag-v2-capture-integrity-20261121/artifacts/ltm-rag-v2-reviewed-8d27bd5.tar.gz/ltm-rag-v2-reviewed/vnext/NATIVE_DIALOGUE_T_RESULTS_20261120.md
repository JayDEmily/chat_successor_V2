# Stage T — independently verified real ChatGPT replies, clean SQL and hosted index

**20 November 2026 | PASS_T_EXACT_NATIVE_UI_RENDERED_SOURCE_SQL_HOSTED.**

## Result

The original **five** Stage S ChatGPT messages and their **five** actual ChatGPT model responses were independently reread from the same native signed-in conversation. Each simulated user text matched its frozen preregistration. Each model response's exact **UI-rendered** text matched the preserved raw capture with precisely the Chrome global footer removed. No model-generated answer was invented, paraphrased, replayed, or sourced from API inference.

A new synthetic-only **clean** SQLite + OpenAI Vector Store index was built from those five verified pairs. Every original S raw receipt, S five-file hosted store, prompt and send-once marker remains unmodified. **No further native ChatGPT messages were sent.**

| Predicate | Verified value |
|---|---|
| Actual native ChatGPT model replies reread independently | **5/5** |
| Simulated user messages | **5/5** |
| Clean canonical SQLite messages | **10/10** |
| UTC first-ingestion timestamps | **10/10** |
| User UI send-action timestamps preserved | **5/5** |
| Assistant original server-send timestamps | Unknown (NULL; 5/5 correctly unclaimed) |
| Assistant response-completion observation stamps | **5/5**, held separately |
| Hosted clean source files, completed and independently read back | **5/5** |
| Frozen semantic top-five queries | **3/3** |
| Frozen semantic target rank-one results | **3/3** |
| Additional native ChatGPT sends in T | **0** |
| Historical Stage M/N/O/P six-event audit | Unchanged |
| Original contaminated S hosted files | **5 preserved** |

## Independent source/hosting audit

- Preregistration: `da3232c5c999255b551ae876f3b1d169a277f1db`, direct parent `a02192ef14c86242532e9ab22c61a64c590cecd1`. Both frozen T files independently read back from GitHub before hosted indexing.
- Independent private read-only UI source digest: `09caa5c43521c9d115f24f2e476f933676c17715c5ee8d833ab64ca3307bbb50` (no actual transcript bytes/chat URL committed). Five individual original S capture hashes also preregistered.
- `scripts/audit_verified_dialogue_t.py` independently reassembled **all** canonical SQLite message authors, exact UTF-8 text, content SHA-256, source identifiers, chronological positions, per-role timestamp provenance, indexed-file bytes/digests and private original receipt identity. No source/role/timestamp field was silently rewritten. Unknown/mismatched source candidates are rejected by the pipeline.
- The same audit used read-only OpenAI Files/Vector Stores APIs to verify the **distinct** 30-day-expiring T store, exactly five completed file attachments, all source attributes, and the original five S attachments still present. No model inference, hosted query replay, upload or ChatGPT UI action in the audit.
- Three newly measured hosted searches, frozen before T indexing, each recovered its expected fictional source turn at **rank 1**. A rank is a candidate-retrieval result, not a probability or proof that facts are true.
- The original Stage S source-index fidelity result is explicitly **PARTIAL**, not upgraded by T's subsequent success.

## Regression and authority

Synthetic-only core regression **221/221** and isolated shadow **40/40**. Six focused Stage T fake-provider tests, eight Stage S fake-provider tests, immutable original hashes, timestamp source preservation and idempotent local mapping tests passed. Existing Stage P/UI synthetic tunnels and GitHub source remain isolated. No real account conversation content or personally authored source records were imported.

**What is not yet implemented:** an always-on capture hook for *every* future native ChatGPT user message, and automatic retrieval from this hosted store by a *different* ChatGPT conversation. The five-message synthetic trial was driven by bounded desktop automation and manually scoped hosted search. A separate native cross-chat invocation and authenticated provenance design would be required before claiming full continuous memory. The UIA rendered text (plain sentences) is separately evidenced; it is not a cryptographic copy of the model token stream.

**Decision:** `PASS_T_EXACT_NATIVE_UI_RENDERED_SOURCE_SQL_HOSTED`. Preserve S and T evidence distinctly. ChatGPT Work remains prohibited in this project.
