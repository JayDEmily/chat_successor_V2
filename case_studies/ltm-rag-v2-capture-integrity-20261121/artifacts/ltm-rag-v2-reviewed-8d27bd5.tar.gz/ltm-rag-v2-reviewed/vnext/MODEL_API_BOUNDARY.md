# API model calls, organisation reporting and complimentary allowance

This implementation follows Astra's staged approach. **No model-inference calls have been made by LTM-RAG vNext.** The locally downloaded tunnel client is a transport utility, not a supplementary reasoning model.

## Existing API Access project as the later inference boundary

The existing Ubuntu gateway at `/home/jds/openai-astra-gateway` (GitHub: `JayDEmily/openai-astra-gateway`) was independently inspected on **18 November 2026**. Local `main` and remote `origin/main` both match `60aae9020e5ce892fce2819bbcd91f5c90eb1307`, the release pinned by the installed **API Access v0.1.14** skill. The worktree was clean. Its root `AGENTS.md`, accepted budget ADR, mandatory preflight documentation and two-key identity audit were inspected.

**Decision for future implementation:** integrate with the existing gateway's supported interface for supplementary research *if that stage passes Astra's earlier evidence gates*. Do not copy its preflight, ledger, reconciliation or Responses controller into vNext. A future adapter must map the exact approved research model, effort, source and output contract to the gateway's supported CLI and validate real execution semantics before describing it as a working integration. No such adapter or job is currently deployed.

This is reuse of a separately maintained component, not an import of its historical model defaults, source documents, past projects or operating assumptions. The gateway's own skill and current source remain authoritative for each specific API job.

## Distinct credential roles

| Role | Locally verified environment variable | Current status |
|---|---|---|
| Future LTM-RAG supplementary model inference and owner-approved tunnel transport | `OPENAI_API_KEY` in `/home/jds/.env` | Used for **OpenAI tunnel transport** by a temporary process environment mapping; no Responses model inference or project model visibility check performed |
| Organisation-wide token usage and explicit tunnel metadata administration | `OPENAI_ADMIN_KEY` in `/home/jds/.env` | Used for creating this project's synthetic tunnel record and verifying its list readback; **not** used for Responses generation, runtime daemon auth or usage reporting during this stage |
| Outbound MCP transport | Process-only `CONTROL_PLANE_API_KEY` | Set from the existing `OPENAI_API_KEY` by `scripts/tunnel_using_existing_key.py`; OpenAI control-plane polling verified. **No separate third key created**, as instructed by the owner |

The admin key's normal project role is organisation-wide usage reporting; the separate tunnel setup required one explicitly scoped **admin tunnel metadata creation** and a list readback. The tunnel process **does not receive `OPENAI_ADMIN_KEY`**, and the owner-authorised existing project key proved usable for polling. The key itself was not changed or copied to a new credential file. Its existence does not establish the organisation's incentive enrolment.

## When budget enforcement becomes active

1. **Now: local synthetic retrieval.** No Responses API or usage preflight required. ChatGPT-to-Ubuntu retrieval through an MCP tunnel is a different connection.
2. **After the native retrieval compatibility gate:** Evaluate actual capture and recall before commissioning a secondary model.
3. **Before the first supplementary inference request:** Verify the selected OpenAI project, data-sharing/retention setting, exact model eligibility and live organisation usage. Use the existing API Access gateway's fresh preflight, mandatory 10%-reserved between-Responses budget admission and durable receipt reconciliation instead of creating a duplicate controller. Block any new request when the gateway's conservative admission cannot be established. Its ceiling is enforced between Responses, not as an absolute ceiling on already-running hosted tools.
4. **For later approved repeat research:** Reconcile observed request usage with organisation usage and costs, account for reporting lag, all concurrent projects in the same model group, the 00:00 UTC allowance reset, and request-level full-charge overage.

Official documentation specifies 10 million complimentary tokens per day for the eligible shared group containing `gpt-5.6-terra` and `gpt-5.6-luna`, **but only for qualifying shared traffic**. Both input and output count. The threshold is not a guaranteed live remaining-balance API. Validate actual account enrolment rather than assuming it from the key's existence.

**Privacy distinction:** the complimentary offer requires sharing API prompts/completions and OpenAI says not to submit sensitive or confidential information under the sharing programme. Astra therefore recommended complimentary capacity for synthetic/non-sensitive evaluation **only**. Personal historical conversations should use an appropriate sharing-disabled paid API project or local processing if later research is justified.

The existing gateway implements and has separately tested budget admission, but **LTM-RAG has not invoked or integrated that gateway**. This file is a stage boundary, not a deployed LTM-RAG token-budget controller. Do not describe the LTM-RAG integration as built until its own inference admission and reconciliation tests exist.

## Official references

- [OpenAI organisation usage API](https://developers.openai.com/api/reference/resources/admin/subresources/organization/subresources/usage/methods/completions)
- [Complimentary token programme and terms](https://help.openai.com/en/articles/10306912-sharing-feedback-evaluation-and-fine-tuning-data-and-api-inputs-and-outputs-with-openai)
- [Secure MCP Tunnel](https://developers.openai.com/api/docs/guides/secure-mcp-tunnels)
- [Astra's design report](https://example.invalid/private-drive-evidence)
