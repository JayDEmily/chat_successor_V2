# Astra capture and recovery foundation - synthetic-only protocol

Date: 21 November 2026
Source of requirements: vnext/reviews/20261121_complementary_memory/{ADR_COMPLEMENTARY_MEMORY.md,OFFLINE_CAPTURE_AND_RECOVERY.md,GATES_AND_EVALS.md}
Status: frozen before implementation. This protocol is NOT an owner-source deployment approval.

## Scope

Create an isolated local synthetic receipt/coverage/index-outbox foundation under vnext/; do not edit frozen Stage S/T messages, trials, quotas or their live index. No model API, real conversation ingress, plugin configuration, Windows startup or production service. No assertion of passive native ChatGPT capture.

## Cases and acceptance

CF01 - Exact source UTF-8 bytes, role, message/version/branch/position and optional source send-time are retained; missing send-time remains NULL.
CF02 - Original source and its indexing-outbox entry are committed in the same SQLite transaction; batch rejection leaves neither partial originals nor outbox rows.
CF03 - Re-ingesting the identical source identity is idempotent and leaves the original first-ingestion timestamp unchanged; changed text or role at the same identity is rejected.
CF04 - Two different messages containing identical text have separate identities; same conversation/branch position with another message identity is rejected.
CF05 - Corrections may point only to existing records in the same source/conversation/branch; originals remain unchanged and links are readable.
CF06 - Branches and edited message versions are retained without flattening into one timeline; cross-branch correction is rejected.
CF07 - Explicit coverage gaps are distinguishable from captured records; filling a declared gap changes only that coverage slot and never implies overall transcript completeness.
CF08 - A worker reserves pending work before an upload; after interruption the uncertain item is not silently reuploaded without explicit provider reconciliation; successful acknowledgement requires source payload identity.
CF09 - Unverified observations cannot be represented as verified originals; independent synthetic comparison is separate, and reconstructed text is never stored in original-source rows.
CF10 - Non-synthetic sources, absent/forged synthetic scope markers and unauthorised source locators are rejected; no network or provider operations occur.
CF11 - 12-turn offline simulation with 4 online, 4 explicitly missing during outage, 4 post-restart: replay, source fidelity, gap and pending-index state hold across process restarts.
CF12 - Existing baseline core tests remain passing, with any unavailable environment-only shadow tests reported as unavailable rather than passed.

Stop at a local synthetic-only foundation and source-backed test report. The next actual normal-Chat passive capture route must be independently demonstrated before any verified original-capture claim, and the 12-turn live Chat experiment is NOT authorised by this local protocol.
