# Stage S — dedicated native ChatGPT synthetic conversation, both sides captured

**20 November 2026 | preregistration before any native messages, hosted file uploads or chat automation.**

## Purpose and authority

The owner has expressly authorised a simulated user/assistant conversation sent from their authenticated normal ChatGPT Windows browser: we act as the **simulated user**, send fictional everyday diary messages, wait for **real ChatGPT-generated assistant responses**, and capture both sides incrementally into SQLite and an isolated OpenAI-hosted Vector Store. This specifically extends the original Stage R *scripted replies* experiment for the limited Stage S synthetic-native trial. **ChatGPT Work remains prohibited.** No genuine historical conversations, other projects, unrelated browser windows, user-authored text or real-person facts are admitted.

Native Windows UI Automation is used **only inside one newly created and uniquely identified Chrome window**, navigated to a clean `chatgpt.com` composer. The scripted user text is **not** the actual account owner's writing and cannot attest owner intent. No existing MCP/ChatGPT plugin use, Responses/Chat Completions API, new credential, autostart, genuine user data import or production connector modification.

## Frozen finite test

- Base published commit: `24cd9f456e058b2789e0e8e20ad34d0761289906`. Frozen matrix `NATIVE_DIALOGUE_S_CASES_20261120.json` contains **exactly five** unique fictional simulated-user prompts `S-N01..S-N05`, and **three** preregistered hosted search queries `S-Q01..S-Q03`; no prompt modification to improve retrieval.
- One fresh normal ChatGPT conversation, one immutable transcript within `vnext/.local/native-s-dialogue/`. Five maximum native sends, **no automatic retries** after a durable about-to-send marker. Each message goes only after the preceding assistant response is complete; never claim a response is observed if UI Automation cannot verify it, or use a model-generated reconstruction as original text.
- Per turn, exact captured synthetic user text and actual UI-observed ChatGPT reply stored in local SQLite with `author_role` separately `user`/`assistant`; `capture_method=synthetic_native_ui`, `synthetic_only=true`. User `message_sent_at` is the recorded UI send action timestamp; assistant source-send time stays NULL unless the host explicitly supplies an original timestamp. `observed_completed_at_utc` for the assistant is a separate immutable observation field. Both records receive actual UTC local ingestion timestamps and exact UTF-8 SHA-256 hashes.
- The Windows controller must verify unique dedicated window handle, expected chat origin, no pre-existing messages or unrelated composer content, and each frozen exact draft before invoking Send. Persist an about-to-send receipt to the private ledger **before** clicking. Capture through UI Automation after no active Stop button and stable distinct assistant content; document if the UI does not reveal exact underlying Markdown (rendered text is the observation boundary).
- A separate Stage S SQLite mapping table binds a hosted file ID to exactly one chronological user/actual-model pair and their local IDs. Upload no more than **five** immutable synthetic text files to exactly one **new isolated, 30-day expiring** hosted Vector Store in the already supplied API project. Leave the existing 12-file Stage R store unchanged. On any uncertain upload or crash, reconcile remote file name/ID before a retry. Store private identifiers and UI chat URL outside Git in `.local`.
- The backend should index after every successfully captured pair, before the next user message. Hosted search `S-Q01` runs after turn 3, while `S-Q02`/`S-Q03` run after turn 5. Candidates only: hosted returned file IDs => exact original SQL packets; never cite snippets as original, infer human authorship or treat semantic similarity as truth.
- Capture the actual answer to S-N05, but do not misstate that it used the external vector store: it may naturally use *that chat's ordinary context*. A distinct native ChatGPT retrieval/MCP experiment would be needed to prove automatic cross-chat incorporation.

## Verification and limits

Preregister and independently verify GitHub complete case/protocol blobs and direct parent **before first native send**. Do offline unit tests with a fake hosted transport and mocked UI samples before any native action. Check stable original records, hash/source/role and correction semantics, send/capture timing, replay/crash markers, chronological ordering, all hosted indexed-file statuses and exact query ranks. The result may be PASS, PARTIAL, or BLOCKED; never send an extra prompt or alter frozen targets to manufacture success.

Do not touch original/G/I/K/M connectors, native M/N/O/P budgets, pre-existing Chrome windows or real-history stores. Historical six-event MCP audit must be preserved. Do not create automatic background polling or use ChatGPT Work.

**Bounded accepted outcome:** 5 sent and actually replied native messages; 10 exact SQL original records with chronological timestamps; 5 completed hosted files in a separate store; 3 frozen semantic queries measured, and GitHub readback verified. A failed or unverified UIA result must be honestly held as partial evidence. No claims of full native ChatGPT memory integration or authenticated original-owner statement.
