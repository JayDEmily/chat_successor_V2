# Corrected cross-branch supersession boundary

## Verified deficiency and fix (18 November 2026)

The existing vNext synthetic archive encoded both `conversation_id` and `branch_id`, and isolated neighbouring dialogue by branch. However, when `Archive.ingest_synthetic` resolved a `supersedes` reference, it previously checked only whether the referenced message existed in the same conversation, **not** in the same branch.

An explicit negative fixture in `tests/test_archive.py::test_cross_branch_correction_rejected_atomically` moved the notebook correction (`m3`) onto the alternative branch while leaving its superseded original (`m1`) on the main branch. With the original code, the test failed (`InvalidFixture not raised`): the archive accepted the cross-branch correction. This is a directly demonstrated defect, not an inferred risk.

The revised `ltm_vnext/archive.py` query now retrieves the original's `source_id`, `conversation_id` **and `branch_id`**, and rejects the new correction unless all three agree with the correcting message. The rejection occurs inside the existing SQLite transaction, so no partial fixture import remains.

**Verification:** the new negative test passed following the change; the complete deterministic suite passed **55/55**. An independent read-only SQL check of the *existing live* six-message synthetic SQLite file verified `total=6`, `synthetic_v1=6` and `bad_correction_links=0`. The change makes future *ingestions* stricter but does not rewrite any historical source, relation or live fixture.

**Scope and limitation:** this fixes ingestion of cross-branch corrections; it does not establish that arbitrary externally edited SQLite databases have been validated against every possible graph-integrity constraint. The ongoing native ChatGPT plugin and tunnel were not reconfigured by this fix.

## Adjacent, independently observed quality findings

- Trial B's exact quoted source spans: **11/13** byte-identical, **2/13** Unicode quote-mark-only differences (H03 and H10), no other absent spans among those selected. See `TRIAL_B_QUOTE_FIDELITY_AUDIT.md`. This post-hoc audit does not change the frozen trial.
- Holdout C: **26 new fictional messages** and **16 preregistered offline retrieval probes**, lexical FTS5 registered-source recall@8 **8/8 explicit** and **6/8 implicit**. Correct source ranked first in 4/8 explicit and 1/8 implicit cases. See `HOLDOUT_C_BASELINE_RESULTS.md`. The two implicit misses I03 and I06 showed nonempty sets of other records rather than empty search results.

## Next bounded evaluation

Retain the exact-source SQLite archive as canonical. Before changing the live two-tool MCP interface, test a candidate-retrieval improvement **in shadow** on held-out, synthetic-only data; measure exact corrected-source recall@8 and incorrect-source promotion separately. Do not hardcode the test answers as query aliases merely to improve these sixteen known probes. Distinguish lexical vocabulary mismatch from correction-rank/order errors.

No OpenAI supplementary inference, real conversation ingestion, Windows boot-service configuration or external API project changes were made in this tranche.
