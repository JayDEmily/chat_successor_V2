# Stage L — conditional direct-choice source-scope admission (synthetic offline)

**Registered 20 November 2026 before implementation.** Stage K remains fixed at four native events and a documented three-call protocol deviation. Stage I remains 14/16. This is a **separate shadow experiment** designed to test a narrow conditional server boundary, not an automatic repair, not a native ChatGPT click or authenticated user-message ingress.

## Technical hypothesis

When the exact current user message is unavailable to a native MCP, the server must **not infer the requested history source from an assistant-authored tool argument**. A different **conditional** mechanism could obtain a new, explicit, direct user choice of a fictional narrative, then limit released sources to the independently chosen scope. Such a choice would authorise only **which fictional archive to inspect**, not a factual answer, the user's earlier words, the full user message, nor the original semantic intent.

OpenAI primary documents reviewed 20 November:
- https://developers.openai.com/plugins/concepts/mcp-server — model selects tool and authors arguments.
- https://developers.openai.com/plugins/reference — `_meta["openai/session"]` correlates calls, `_meta["openai/subject"]` identifies anonymised subject; widget-only tool result `_meta` is hidden from model, and `_meta.ui.visibility` separates app- from model-visible tools.
- https://developers.openai.com/plugins/build/app-quickstart — MCP Apps UI uses a host bridge, supports in-ChatGPT web component and app-initiated `tools/call`.
- https://developers.openai.com/plugins/build/mcp-server — MCP elicitation is a possible structured-input mechanism, not an authorisation substitute.
- https://developers.openai.com/plugins/build/mcp-events — server-to-host event subscriptions are not a per-turn original user-message input channel.

**Observed Stage K limitation:** all four native call contexts had `elicitation_capability_advertised=false`; no direct-user elicitation or UI confirmation was demonstrated. No native Stage L probe or client UI is authorised in this phase. An unauthenticated model-authored `selected_topic`, matching `openai/session` or a display-only click is not independently trusted.

## Frozen offline state machine

One wholly fictional 20-message, five-conversation source fixture: `fixtures/synthetic_clean_g.json`, SHA-256 `e3531da9538eb40dc41bec43f29c089f7aed7525ee574e84d21e469fabf9dcbf`. Selection options **only** `merrow_prism`, `vela_case`, `qev_tensile`, `ora_pier`, `sova_container`, as proven by the frozen main-user-evidence `REFERENT_GATE_H_MANIFEST_20261119.json`.

1. **begin** is called with a synthetic owner-controlled `(principal,session,flow)` scope. It creates an unpredictable process-local challenge and a public model-facing `AWAITING_CONFIRMATION` result containing **zero original packets and no challenge**. The challenge belongs only to a mock private UI channel. The beginning question and assistant proposals never select a topic.
2. **confirm_from_owner_ui** is a method callable by the separately simulated owner UI; **never register it as a model-callable MCP tool**. The mock UI supplies the original challenge, exact owner context and one or two distinct allowlisted topic IDs. Bad/missing/expired challenges, contexts, duplicates, empty or unknown choices fail closed. An actual deployment would additionally need documented and verified user action provenance and server-side authentication; no such guarantee is asserted here.
3. **resolve** receives an arbitrary model-authored question and optional proposed topics, but uses **only** the stored owner choice, ignoring the model proposal and prompt for source selection. A missing, unconfirmed, wrong-context, stale or already-consumed approval produces **zero packets**. One successful release consumes the approval. The selected topics are resolved through the existing original I source-integrity boundary; never expose ranked candidate packets as endorsed answers.
4. One active flow per owner session. No reused `(principal,session,flow)`, cross-session/subject choice, replay, nonempty model-only approval, guessed challenge, or choice from an unrelated fictional archive. The challenge is not written to logs or model-visible output. The offline mock's private UI return value is **not evidence** that a real user clicked in ChatGPT.
5. Deterministic tests use an injected clock for expiry; no network, new key, external inference, real chat-history import, service restarts, connector edits, production deployment or ChatGPT native send.

## Frozen acceptance cases and stopping conditions

`CLARIFICATION_L_CASES_20261120.json` freezes **20** cases, ordered L01–L20, with exact expected source packet IDs and status. Five single-topic releases, two multi-topic releases, missing/invalid choices, model-only forgery, wrong context, expiry and replay are covered. L19/L20 deliberately model the original I05/I15 ambiguous utterances: **even when a new fictional topic choice permits source inspection, neither the original utterance nor specific implied semantic intent is authenticated.**

Independent auditor must compare both frozen registration blobs **byte-for-byte** with the Git preregistration commit and verify registration parent, plan length and original fixture SHA. Run cases against a fresh per-case in-memory gateway backed by a temporary 20-message synthetic SQLite archive; compare every returned source packet with the original UTF-8 text, message/version identity, SHA-256, branch, author, reported speaker, correction links and locators. Add deliberate negative tests for guessed token, no confirmation, duplicate selection, replay, wrong session, expired request and corrupted original archive. Run all existing core and shadow regressions. **All 20 preregistered outcomes must pass.**

**Decision criteria:** If passing, label `PASS_L_CONDITIONAL_OWNER_UI_SHADOW_ONLY`. This does **not** prove ChatGPT user action, application identity, native UI support, original-question binding or native Stage I repair. If failing, report actual failures; do not change frozen cases to fit code. An actual native UI test requires a later explicit preregistered protocol and independently verified separate connector and user-origin interaction.
