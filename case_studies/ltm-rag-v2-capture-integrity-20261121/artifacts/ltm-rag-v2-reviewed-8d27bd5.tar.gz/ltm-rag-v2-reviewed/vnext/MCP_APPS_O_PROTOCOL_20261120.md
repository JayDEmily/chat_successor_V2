# Stage O — preregistered native MCP Apps safe-viewport recovery and single confirmation

**20 November 2026. Synthetic only. Freeze before creating a Stage O controller or native request.**

## Exact predecessor and decision boundary

Stage M established native embedded MCP Apps rendering and an app-only callback that returned `EXPIRED` after 262.618 s against TTL 60. Stage N used a separate single prompt, but the controller found the Merrow control outside its allowed safe viewport and **withheld the one click**. The later UI readback showed the same Merrow control inside the viewport, after the TTL. It is not established why the geometry changed; do not call it a permanent widget defect. Stage M and N results are closed and must not be reclassified.

The only new Stage O question: can the already-installed private **synthetic-only** MCP Apps UI perform one automated Merrow confirmation **within** the fixed 60-second server TTL, when the controller performs a bounded `ScrollItemPattern.ScrollIntoView()` recovery on a verified offscreen target and confirms stable in-viewport coordinates? This demonstrates functional UI/app-only callback transport, not human consent or original-message provenance.

## Frozen identity, files and preconditions

- Repository `JayDEmily/LTM_RAG`, branch `work/ltm-rag-vnext-synthetic-20261118`, exact Stage N evidence parent `25c543267c8a1f69ff3324cbc7fd12b4a89e58b3`.
- Reuse **exact** existing ChatGPT private MCP plugin `plugin_asdk_app_6affaf818f3481919433489e25b52471`, tunnel `tunnel_6affa48f70b0819187bbe06449bf2750`, listener `127.0.0.1:8791/mcp`. No new plugin, tunnel, key, external model, application source import, or OS autostart. Never repoint original/G/I/K/M connectors.
- Stage M handler and HTML widget unchanged, pinned SHA-256 respectively `a3338d83d026e6ee80e37b3b46ac320b592a4e87d77dc2b13269c42d10005391`, `bcb7b006c07d8bc464ce5cb3f0a7d8d6a39fcbe6c7b1063c982c3de50996430d`. The prior three-event M+N audit baseline is **exactly** three events, SHA-256 `f8980d0616468f3bcdf3c62f49765e87108aa89a19e77eabd4dadece90860fd6`; it must remain unchanged as a prefix. No raw conversation text or session/subject values recorded in the MCP server log.
- Prior Stage N frozen native send is exhausted, with no Stage N callback; no N retry. Stage O has a distinct one-send/one-click budget and new private local Windows markers.
- A safe **read-only** Stage N HTML inspection confirmed the actual Merrow button supports UI Automation `ScrollItemPattern` and is anchored in the embedded `LTM-RAG M - fictional topic selector` document.

## Frozen O-N01/O-N02

See `MCP_APPS_O_CASES_20261120.json`: exactly two linked cases, at most one native ChatGPT message send and one automated synthetic Merrow click.

- **O-N01:** Starting only from the identified, existing dedicated James-profile Chrome window, verify prior saved N chat, navigate *that same window* to the existing native plugin detail and use `Try in chat` **once**. Verify a fresh ChatGPT composer with the exact native plugin mention and one instance of frozen request text after the separate mention. Write durable one-send marker before pressing Send. Require one `open_topic_selector_m` native event with `AWAITING_CONFIRMATION`, `source_count=0`, client session/subject present but original-user-text not attested.
- **O-N02:** Immediately after Send, poll only **that same** saved native ChatGPT conversation for the actual embedded widget, exactly five fictional options and initial `Select a single fictional topic.` status. Require the sole exact `Confirm fictional topic: Merrow calibration log` button. If it is offscreen or its centre is outside the frozen safe rectangle, attempt **at most one** native UIA `ScrollItemPattern.ScrollIntoView()` on that button, and re-read its current rectangle. Otherwise wait for normal UI layout settlement. After two consecutive in-range positions separated by at least 250 ms, and no change to foreground or target chat URL, write a durable *pre-click* marker and click Merrow **exactly once**. **Never** click before all identity/visibility checks.
- The controller has a **38-second local send-to-click observation budget**, leaving a nominal buffer for frozen server TTL 60; actual acceptance is based only on independently audited server timestamps of the opening and callback, **strictly below** 60 seconds. If the button cannot be made safe and stable in 38 seconds, stop with **no click**. If an error or interrupted process occurs after send or click marker creation, never repeat that action.
- A native positive result requires exactly **two new** Stage O MCP events appended after the unchanged three-event baseline: `open_topic_selector_m / AWAITING_CONFIRMATION` then app-only `confirm_topic_m / CONFIRMED`, and a saved widget status acknowledging confirmation. No source packets in any result. The Windows UI automation is an **automated test interaction**, not a real human choice or consent.
- If no callback, `EXPIRED`, `DENIED`, duplicate event, unknown tool, wrong chat, or UI geometry cannot be safely verified, truthfully classify `O_NATIVE_POSITIVE_NOT_PROVEN` with its specific predicate. Never resend, click twice, enlarge TTL, modify frozen expectation or claim success based on a button alone.

## Evidence, acceptance and stopping

Write all native chat URLs, exact one-send/one-click receipts, UI proof and raw server audit under ignored Windows Temp or `vnext/.local`, not Git. Publish only dates, synthetic tool names/statuses, presence booleans, counts, SHA-256 digests and trustworthy limitations. Independently compare source and preregistration Git bytes, prior audit prefix, exact native event delta, UI status, saved prompt, actual timing and local one-send/one-click markers.

The maximum Stage O native allowance is **one send + one automated click**. Stop after that. `PASS_O_NATIVE_ACCEPTED_UI_TRANSPORT_ONLY` is permitted **only** with a verified app-only `CONFIRMED` event strictly inside 60 seconds and no source packets. It never implies a real owner approved anything, an authenticated original ChatGPT message was received, a model was forced not to call an app-only tool, or Stage I I05/I15 have been repaired.

Run 160/160 core tests, 40/40 shadow tests, Stage M frozen 16/16 offline audit, and the cumulative Stage O audit. Publish dated result, update README/PROGRESS and independently verify GitHub branch, exact parent/tree/blobs, clean worktree. Preserve original/G/I/K services.
