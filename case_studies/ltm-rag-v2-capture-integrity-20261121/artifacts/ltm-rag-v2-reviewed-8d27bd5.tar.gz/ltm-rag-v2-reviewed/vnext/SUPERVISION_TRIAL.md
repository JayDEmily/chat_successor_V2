# Synthetic MCP/tunnel supervision: bounded evaluation

**Scope:** Only the six-message, read-only LTM-RAG vNext synthetic MCP process and its dedicated private OpenAI tunnel. Other WSL/Windows projects are out of scope.

## Environment and authority

Ubuntu WSL PID 1 is `systemd`, but `systemctl --user` cannot contact the user bus from the authorised remote session. The desktop command gateway also disallows `sudo`. Therefore the tested approach is **explicit, user-space Python process supervision**, not changing system units, boot settings, Windows Task Scheduler, global services or system-wide credentials.

The supervisor in `scripts/supervise_synthetic_services.py`:
- Requires the fixture to contain exactly six records with `synthetic: true` and source `synthetic-v1`.
- Refuses to run when the existing synthetic loopback port is occupied or when the dedicated tunnel profile already has a process; never duplicates an unmanaged service.
- Takes a nonblocking local advisory lock to exclude another supervisor instance.
- Starts only `scripts/run_synthetic_mcp.sh` and `scripts/tunnel_using_existing_key.py run`; all credentials are stripped from the initial child environment, and the tunnel launcher itself reads the existing Ubuntu project key at execution.
- Records content-minimised operational events under ignored `vnext/.local/`, not in Git; logs are mode 0600, and it does not record project/admin keys or user conversations.
- Automatically restarts **unexpectedly exited** child processes with a bounded three-restarts-per-120s budget, then stops both children and exits rather than spinning indefinitely.
- Shuts down only its own child process groups when interrupted. No global `pkill` is used.

## Verification stages

1. Verify all 29 deterministic repository tests, including six security/synthetic-supervisor checks, and the local HTTP MCP smoke.
2. Record exact process identities of the current unmanaged synthetic MCP server and private tunnel, and do not interrupt them while native reliability trial B is active.
3. After trial B, stop only those two exact PIDs. Start the isolated supervisor and verify loopback MCP and the official tunnel's `readyz`.
4. Terminate the child MCP server once, verify a new child PID, and check a synthetic MCP lookup. Terminate the tunnel child once, verify a new tunnel PID and control-plane readiness. Record actual results and limitations.
5. Keep the supervised synthetic service running only if the observed restart tests pass; otherwise restore the original manual launch and document the blocker.

## Known limits

This supervisor restarts crashed children while its **own process and WSL remain running**. It is **not** verified across Windows restart, WSL shutdown, user sign-out or loss of the host computer. It detects child exit, not every possible alive-but-unhealthy tunnel state. No uptime commitment or persistent system-wide installation is claimed.

Any live execution results must be appended after the test and independently verified before marking this stage complete.

## Executed results — 18 November 2026 (AEDT)

1. **Existing-process collision:** at initial state, the unowned synthetic MCP PID `158559` held `127.0.0.1:8787`, and tunnel PID `149449` used exactly the private `ltm-vnext-synthetic` profile. Running the new supervisor returned `Synthetic MCP port is already occupied: will not duplicate owner`. No existing service was changed by that refused request.
2. **Bounded transfer:** after the native reliability test runner had stopped, inspected those two exact PIDs again and terminated **only those PIDs**. A separate status check found the MCP port unbound and no project-specific tunnel process.
3. **Supervised start:** launched `python3 vnext/scripts/supervise_synthetic_services.py run`. It reported `SYNTHETIC_SUPERVISOR_RUNNING children=2 loopback_only=true` and recorded MCP child PID `163219` and tunnel PID `163226`, both in the private event log. The tunnel's `doctor` returned `result=ok` and its actual listener returned `ready`. One health snapshot at `2026-11-18T04:20:20.965Z` recorded a successful control-plane poll with zero consecutive failures.
4. **Unexpected MCP exit:** after explicitly terminating **only** supervised MCP child `163219`, the supervisor recorded `unexpected_exit` with exit code `-15` and restarted it as PID **`163464`**. An MCP client connected to that *running* loopback server, listed exactly two read-only tools, performed `lookup_evidence`, then `fetch_source`, and verified exact synthetic source text: `SUPERVISED_MCP_SMOKE: PASS`.
5. **Unexpected tunnel exit:** after verifying exact identity of supervised tunnel PID `163226`, terminated it. The supervisor recorded the exit and started replacement PID **`163607`**. `ss -ltnp` showed the new tunnel listening on `127.0.0.1:37851`; `GET /readyz` returned **`ready`**. A later `GET /health?details=true` at `2026-11-18T04:22:14.905Z` reported `control-plane.status=ok`, `state=polling`, `last_success=2026-11-18T04:22:10.603528847Z`, `consecutive_failures=0`.
6. **Duplicate supervisor guard:** an attempted second supervisor invocation returned `Another synthetic supervisor already owns the lock`; the original supervisor and its children continued.
7. **Credential/log boundary:** verified from the actual live processes' `/proc/<pid>/environ` **key names only** that neither child carried `OPENAI_ADMIN_KEY` or `OPENAI_API_KEY`; only the dedicated tunnel carried `CONTROL_PLANE_API_KEY`. The audit, private reliability ledger, supervisor event log and both child logs were all mode `0600`. Neither child log contained credential assignment literals or a `sk-proj-` prefix. No secret value was printed.
8. **Tests:** the whole synthetic-only test suite, including supervisor and trial-result analyser tests, passed **36/36** before publication.

**Live state at last direct observation:** supervisor active, supervised MCP PID `163464` bound to loopback `8787`, dedicated tunnel PID `163607` actively polling OpenAI; no extra copy of either process, no global system/boot changes. If these PIDs change in subsequent operation, inspect the current status/event log rather than relying on these historical identifiers.

**Precise acceptance:** bounded child-exit restart in the current WSL session **PASS**; local MCP source integrity after restart **PASS**; OpenAI tunnel readiness/control-plane polling after restart **PASS**. **Not demonstrated:** native ChatGPT query after the supervisor switch (testing was stopped after unrelated desktop draft interference), supervisor parent crash, WSL shutdown, Windows reboot, user sign-out, or an alive-but-unhealthy tunnel that does not exit. These are separate gates, not implied by child-process restart.
