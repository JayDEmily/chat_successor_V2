# Stage P — native app-only UIAutomation InvokePattern confirmation (pre-registered)

**20 November 2026 | New, independent, synthetic-only native experiment. Freeze before Stage P controller and before any Stage P browser send.**

## Purpose and previous evidence

Stage M: the native ChatGPT MCP Apps widget displayed five fictional topic options and one automated Merrow mouse click delivered an `EXPIRED` app-only callback after 262.618 s (TTL 60). Stage N: one opening; a viewport guard withheld the click. Stage O: one opening; no callback, no click marker; the original post-send controller did not persist failure reasons. The missing O callback mechanism remains unknown and must not be reclassified. The postmortem/diagnostics checkpoint `7ae7e4d504745a26116d451d8ddf05b89cbb31be` introduces a read-only evaluator and a flushed private trace with 16 passing Windows self-tests. A previous read-only Stage N UIA inspection recorded that the native Merrow HTML button supports both **InvokePattern** and **ScrollItemPattern**.

**New Stage P question:** Can a verified app-only widget confirmation be delivered inside the same unchanged 60-second TTL by using exactly one UIAutomation `InvokePattern.Invoke()` on the exact fictional Merrow button, with private trace for every post-send decision? This is an automated synthetic control activation, not human consent or a trusted original ChatGPT message.

## Frozen environment

- Repository `JayDEmily/LTM_RAG`, branch `work/ltm-rag-vnext-synthetic-20261118`, parent checkpoint `7ae7e4d504745a26116d451d8ddf05b89cbb31be`.
- Existing private ChatGPT MCP plugin `plugin_asdk_app_6affaf818f3481919433489e25b52471` and private tunnel `tunnel_6affa48f70b0819187bbe06449bf2750`, unchanged loopback `127.0.0.1:8791/mcp`. No new backend/plugin, credentials, externally inferred data, application import, genuine archive, or OS startup.
- M source SHA `a3338d83d026e6ee80e37b3b46ac320b592a4e87d77dc2b13269c42d10005391`; HTML widget SHA `bcb7b006c07d8bc464ce5cb3f0a7d8d6a39fcbe6c7b1063c982c3de50996430d`; diagnostic-helper SHA `ef84a196a9b2b31bd3ad3e308c7501489d82d6b475f5b5bbe03f4e673f3f14b5`. These three tracked files must remain byte-for-byte unchanged.
- Existing cumulative M/N/O native audit must have **exactly 4 events** and SHA-256 `a50e5fe66543b155d25841585007ace06c9bd0881d44ad50c44957f7a10c5aba`. Stage P appends event(s) but never edits the first four bytes/lines. Private trace, saved native chat URL and Windows one-send/one-invoke markers remain only in ignored `vnext/.local` or Windows Temp.
- Use **one newly launched dedicated Chrome window** with the existing logged-in Windows Chrome profile, not another worker's windows. Verify its unique new handle, plugin detail `Try in chat` and fresh composer selected for the exact plugin. No unrelated Chrome navigation, window closing or background sessions. If a dedicated window cannot be uniquely identified, **do not send**.

## Fixed cases and boundaries

`MCP_APPS_P_CASES_20261120.json` freezes **two linked native cases** and at most **one native message send and one automated `InvokePattern` activation**. No duplicate sends or retries if process output, window focus or callback status is unknown. Stage M/N/O quotas remain exhausted.

- **P-N01 one opening:** Send once only the frozen English request through the already selected native plugin, preserving any UI-added plugin mention as a separate non-prompt prefix. Before Send, commit a private marker including prompt SHA-256, plugin ID, window handle and audit baseline count. Server must observe one new `open_topic_selector_m` at `AWAITING_CONFIRMATION`, session/subject presence and zero source packets. The native user message itself is not attested by the metadata.
- **P-N02 one app-only invocation:** After Send, within **40 seconds local deadline**, wait for the *same* saved ChatGPT conversation, exact five fictional widget buttons, `Choose a fictional source topic` heading, initial `Select a single fictional topic.` status, and sole enabled `Confirm fictional topic: Merrow calibration log` button. Require native `InvokePattern` support. If initially offscreen, allow **at most one** `ScrollItemPattern.ScrollIntoView()`, then recheck. Verify two stable, in-bounds samples separated by at least 250 ms; preserve foreground and expected native plugin mention and frozen prompt. Write a durable **pre-invoke marker**, call `InvokePattern.Invoke()` **once**, then mark it invoked. Never use physical mouse coordinates for confirmation.
- The controller uses the existing `NativeAppsUiDiagnostics.ps1 -Mode Library` pure geometry evaluator and private trace helper. Trace every send, poll state transition, scroll decision, invocation, result and exception to ignored private JSONL, flushing immediately. On any unexpected UIA exception or window identity drift, emit an exception state and stop fail-closed. If tool execution continues without accessible feedback, consult markers/audit rather than rerun.
- **Positive predicate** requires **two** new native server events after the original four: opening `AWAITING_CONFIRMATION` and callback `CONFIRMED`, with timestamp delta strictly less than **60 seconds**, plus native UI `Fictional topic selected...` status. Both have zero source packets, original user text unauthenticated and human consent unattested. Any `DENIED`, `EXPIRED`, missing callback, extra event, expired window, or absent UI status is a non-PASS. Do not alter TTL or requirements to manufacture success.
- The one-send/one-invoke cap is strict. If acceptance is not established, publish the actual reason and stop Stage P; only an independently preregistered new experiment could retry. No shortcuts or stage merges.

## Publication gate

Independently check preregistered Git blobs and parent **before** creating the native Stage P controller. Before native run, execute read-only PowerShell self-tests and parse validation, snapshot prior audit SHA/line count, verify tunnel readiness, and ensure exact blank plugin composer. After run, check private markers, browser readback and the cumulative audit without publishing IDs/challenges/URLs. Run core 160/160 and shadow 40/40, Stage M offline 16/16 and cumulative M/N/O audit. Publish scoped report, README/PROGRESS and independently verify GitHub commit, tree, parent, changed files and clean branch.

**Even a successful positive transport test cannot establish host-only app-tool security, actual owner consent, authenticated exact user words or repair of Stage I I05/I15.** No actual archive data are available to Stage P.
