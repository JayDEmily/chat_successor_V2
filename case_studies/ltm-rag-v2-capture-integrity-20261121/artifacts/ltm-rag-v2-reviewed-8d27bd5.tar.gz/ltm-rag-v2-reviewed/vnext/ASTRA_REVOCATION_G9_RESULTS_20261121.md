# Astra G9 — local synthetic revocation boundary

**Date:** 21 November 2026
**Base commit:** `60f60ebb212692e845fb4b698506332a6663a30d`
**Scope:** isolated synthetic-only capture ledger, no live source access or provider deletion.

## Implemented

- Durable SQLite tombstones suppress an original from synthetic source snapshots before any attempt at remote cleanup, including its indexed outbox fields and correction links.
- A revoked original cannot be verified, scheduled for index, re-queued after an uncertain upload, or marked searchable. Exact-content replay does not erase a tombstone.
- Pending-only sources require no *known* remote deletion; in-flight or indexed originals stay explicitly `REQUIRED` for remote reconciliation. Late-discovered remote file identity stays attached to the revocation record.
- Caller-supplied remote deletion evidence is recorded only as `EVIDENCE_LOGGED`, **not verified deletion**; the cleanup-pending diagnostic remains nonzero. Separate identity evidence and deletion evidence refs preserve chronology/provenance.
- In branches with multiple versions of one position, revoking one version does not incorrectly hide coverage of a still-visible version. If the predecessor is revoked, a released correction redacts its predecessor ID.
- Revocation status persists through SQLite backup/restore. Original data remains privately stored pending a separately authorised retention/backup policy; tombstoning is *not physical erasure*.

## Verification

- 11 new isolated revocation tests passed: immediate suppression, replay and source access denial, unknown in-flight remote identity, late remote record, unverified deletion receipt, cross-branch isolation, edited-version coverage, correction redaction and backup/restore.
- Full core suite **285/285 passed**.
- Astra review-tool suite **31/31 passed**.
- No native ChatGPT sends, live provider calls, remote deletions or real personal-source imports.

## Still outstanding

Provider-backed deletion and read-after-delete verification; tombstone propagation to a future general-purpose search endpoint, backups and expiry policy, owner-approved retention/scope and authenticated access. These are separate production acceptance conditions, **not passed** by the local synthetic revocation tests.

**Passive capture:** `CAPTURE_ROUTE_NOT_ESTABLISHED`; the live 12-turn native outage experiment remains `NOT_RUN`.
