# Stage K — native metadata delivery, correlation and attribution audit

**20 November 2026 (AEDT) | Synthetic-only, read-only | Evidence checkpoint**

**Disposition: NATIVE_METADATA_DELIVERY_OBSERVED_WITH_PROTOCOL_DEVIATION.** The private ChatGPT K plugin delivered per-call `openai/session` and `openai/subject` presence for four audited native invocations. Within the two-call saved chat, the process-keyed session and subject fingerprints were equal; in the separately saved chats, session fingerprints differed and subject fingerprints agreed. **This was not a clean preregistered three-call run:** a fourth invocation resulted from an additional K-N01-style send. The local Stage K adapter remains 10/10, but a three-call-limit acceptance must not be claimed.

## Pre-registered scope and plugin identity

- Frozen [protocol](MCP_METADATA_K_PROTOCOL_20261119.md) and [ten offline cases plus three native prompts](MCP_METADATA_K_CASES_20261119.json) were registered at Git `8b6ae970a8e5cdb36e0beb6882ad0ddcfa84a436`. Frozen case SHA-256: `faa8df25b4633c09c389600cc4c148ae1130adcac6927d079ea61d809589e87a`.
- New user-private plugin: `plugin_asdk_app_6aff77ff8dd48191b31949e4f23531d4`, scope USER, discoverability PRIVATE, version 1.0.0, independently read back from Plugin Creator on 20 November. Its K-only tunnel is `tunnel_6afea805cdcc819199f14b043944e415`, forwarding to loopback `127.0.0.1:8790/mcp`; only one read-only `inspect_metadata_presence_k` tool. No original/G/I connector repointing.
- Original user messages were **not** passed to, attested by, or stored by the probe. Private `vnext/.local/trial-k-mcp-audit.jsonl` contains only generated event IDs, booleans and process-keyed opaque fingerprints, never raw session/subject identifiers. The Windows send markers are retained outside Git.

## Reconciliation: four events, three registered cases

The same saved ChatGPT conversation contains **one exact K-N01 prompt and one exact K-N02 prompt**, each with a saved assistant response. A second saved chat contains one extra exact K-N01 prompt, and a third saved chat contains one exact K-N03 prompt and one saved assistant response. These were read back through UI Automation on the specifically identified K test browser window only. All counts below were checked against the frozen JSON prompt texts; raw chat/user text and chat URLs are intentionally omitted from this public evidence report.

| Native audit event | Time AEDT | Conversation evidence / marker | Classification |
| --- | --- | --- | --- |
| `de466e6c-1630-46fd-8d8b-987237839153` | 09:39:21 | K-N01, first saved chat; Windows one-send marker clicked 09:39:10; prompt SHA-256 `fff8f388406eebceb0c68b5d084c921b38acb198b57c97aefe5521f4e728911d` | **K-N01: observed** |
| `4cefb675-069e-4e98-bbda-b7a45db7c4c4` | 09:44:51 | K-N02, same saved chat; marker clicked 09:44:40; prompt SHA-256 `37b582a4c5809ede1394a14844b9f4d5010d596d8331a881079379eb99e36814` | **K-N02: observed** |
| `c0fc01cf-477d-4bbc-a0c8-c56e459ac1a3` | 09:49:50 | Additional separate saved chat with one K-N01-form prompt; N01 helper `-Action Send` launched 09:49:40. The ignored `native-k-results-20261120.jsonl` labels this event K-N01 despite an existing earlier N01 send. | **EXTRA_SEND; not K-N03** |
| `90725e1d-414f-4249-bc5c-a135c8f79b0b` | 09:58:06 | Fresh saved chat with exact K-N03 prompt; new-chat navigation marker 09:47:40 and one-send marker clicked 09:57:53, explicitly recording three earlier audit events; SHA-256 `807e0c5a35f71116fdc7866c2d406ab149f445ee3c511b80b1450d2caef3b781` | **K-N03: temporally corroborated** |

The **09:49:50 event was incorrectly attached to K-N01 as a newly added event by a legacy N01 helper ledger**; that helper's post-baseline diff cannot establish initial-case attribution. It is not the K-N03 event, and no clean three-event ledger is asserted. The K-N03 marker, frozen prompt in its distinct saved chat, and following fourth event establish a specific corroborated send/event sequence. Because the probe does not receive a host-authenticated conversation URL or original turn, temporal attribution is not cryptographic identity binding; another simultaneous K invocation cannot be excluded purely by fingerprint.

The saved K-N03 assistant answer displayed **Unknown** for both flags, despite the fourth tool-side audit event recording both as present. Accordingly the report claims **tool-side metadata delivery**, not reliable final-answer reporting or authenticated message provenance.

## Fingerprint and capability results

| Comparison / field | Observed |
| --- | --- |
| Session: event 1 versus event 2 (same saved chat) | **same** |
| Subject: event 1 versus event 2 | **same** |
| Session: event 1 versus event 3 (extra separate chat) | **different** |
| Session: event 1 versus event 4 (K-N03 separate chat) | **different** |
| Session: event 3 versus event 4 | **different** |
| Subject: all four events | **same** |
| `session_present`, `subject_present`: all four | **true, true** |
| `elicitation_capability_advertised`: all four | **false** |
| `native_user_text_attested`: all four | **false** |

No raw `openai/session`, `openai/subject` values, salted fingerprint values or genuine conversation content are reproduced here. Equality comparisons use only the ignored local audit file and its process-ephemeral key. Stable subject equality across the observed calls is correlation, **not** verified human identity or authorisation.

## Offline / connected runtime verification

- Frozen independent audit: **10/10 PASS**. Full core regression **146/146 PASS**; separate shadow suite **40/40 PASS** on 20 November. Independent native Stage I verifier unchanged at **14/16 acceptable** with I05/I15 unsupported-referent failures.
- All original/G/I/K loopback listeners were observed on 8787/8788/8789/8790 respectively. Health probes to the discovered private tunnel ports 43999/32953/46159/35501 each returned `ready`. Tunnel health ports are dynamic and must be rediscovered after a restart.
- Local K ChatGPT window geometry receipt expected Win32 `(13,13,1313,1116)`; readback after the earlier attempted restore was `(13,13,1313,978)`. Position and width match but **height does not** because of Windows clamping. No exact restoration is claimed.
- Extra untracked historic N01 helper script is a guarded investigation artefact, not a deployable/native acceptance runner. Preserve it outside the tracked source tree rather than publishing misleading stale-window instructions.
- No native message was resent during this reconciliation. No new credentials, genuine-history import, external inference, OS autostart or modifications to existing original/G/I services or connectors.

## Engineering decision

**ACCEPT OBSERVED NATIVE METADATA DELIVERY AND SESSION-CORRELATION EVIDENCE; REJECT CLAIM OF A CLEAN THREE-CALL PROTOCOL PASS; DO NOT ADMIT NATIVE REFERENT SELECTION.** The metadata are supplied by an MCP client and are not attestation of the actual current user question; a custom client could spoof them. An advertised elicitation capability was absent in these calls; this is not a general claim that ChatGPT cannot ever elicit. Stage I's two unsupported-referent failures remain unresolved. Any follow-on original-message authentication or elicitation experiment requires a separately frozen scope and tests, not a retroactive reclassification of Stage K.
