# Automatic hosted recall in normal ChatGPT — 20 November 2026

**PASS for source-dependent recall.** Two new normal ChatGPT conversations invoked the private archive automatically. The connector and skill were unselected, and the question text contained no app or tool name. Both conversations ran outside projects.

The existing private hosted-memory plugin gained an implicitly invoked fictional-diary recall skill in version `1.0.1` (release `pluginrel_6b002e298ef881919bfb4c61801b8fa8`). Its app description now advertises original wording, corrections, and archive-assigned UTC times. The same connected app, read-only lookup tool, tunnel, OpenAI Vector Store, and canonical SQLite source handled the calls. The final plugin readback confirmed the existing app binding, private personal scope, updated description, and recall skill.

| Registered case | Native result | Private backend evidence |
| --- | --- | --- |
| Z-N01, prototype review and yoga | Quoted the earlier diary entry, cited `t04u` and gave the exact UTC ingestion timestamp. | One call, `FOUND`. The first hosted result resolved to `t04u` and `t04a`. |
| Z-N02, Saturday feeding correction | Identified Casey, cited `t03u` and gave the exact UTC ingestion timestamp. | One call, `FOUND`. The first hosted result resolved to `t03u` and `t03a`. |
| Z-N03, crescent Moon | Answered the unrelated question. | Zero calls. |

Both exact reply timestamps were compared with SQLite readback, and both original pairs' roles and content hashes were verified. The timestamps were generated during archival ingestion and were absent from the prompts and originating dialogue. The four-event snapshot under `vnext/.local/native-z/trial_z_audit_at_completion.jsonl` has SHA-256 `5ac9f19ad3495c352a7c0bde39be3360805d20678e7d97a3963fe50acbdff862`. The three original send markers and browser receipts are in the same private directory. The [registration](NATIVE_RECALL_ARCHIVE_PROVENANCE_CASES_20261120.json) was verified on GitHub at `c132821d4e24c2e4ccd9604ead287b98ed42eda7` before changing app metadata or sending the questions.

The earlier [skill-only comparison](NATIVE_RECALL_ROUTING_RESULTS_20261120.md) produced correct excerpts with zero archive calls. This run establishes automatic retrieval when an answer needs information held by the archive. The effect of app-description changes alone cannot be isolated because the live prompts also changed. The current service remains an isolated synthetic pilot with a five-call budget, two used in this run. Core regression passed 244 tests and shadow regression passed 40. The archive and earlier audit snapshot hashes remained unchanged.
