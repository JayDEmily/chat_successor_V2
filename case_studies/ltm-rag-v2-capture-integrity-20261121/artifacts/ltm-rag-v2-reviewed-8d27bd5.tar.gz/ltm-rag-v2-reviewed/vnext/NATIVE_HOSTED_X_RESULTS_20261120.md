# Stage X normal-chat comparison — 20 November 2026

**A natural question retrieved the hosted original with the connector selected. Automatic recall with the connector unselected remains unverified.**

Three registered questions ran in three separate, fresh normal ChatGPT conversations. Each conversation had one user turn and one final assistant reply. The existing private connector, tunnel, and five-file Stage T OpenAI Vector Store were used.

| Case | What ChatGPT did | Hosted-memory backend |
| --- | --- | --- |
| X-N01, ordinary chat | Correctly answered that the simulated user might have to skip yoga. | Zero calls. No hosted source was established for the answer. |
| X-N02, connector selected | Answered **M6 metric bolts** and cited original user record `t02u`. The user prompt was an ordinary question about the shopping list. | One call, `FOUND`. The top-ranked hosted match resolved to the exact SQLite records `t02u` and `t02a`. |
| X-N03, unrelated ordinary chat | Correctly explained why wet cardboard softens. | Zero calls, as expected. |

The X-N02 audit completed at 10:57:23 UTC. Its three result pairs were turns 2, 4, and 1, in that order. Read-only SQLite verification confirmed the target pair's roles and content hashes. The X-N01 and X-N03 cases recorded no backend events between sending and final reply readback. The separate [Stage W test](NATIVE_HOSTED_W_RESULTS_20261120.md) already verified byte-for-byte quotation of both turn-3 originals in a live chat.

The frozen [Stage X protocol](NATIVE_HOSTED_X_PROTOCOL_20261120.md) and [cases](NATIVE_HOSTED_X_CASES_20261120.json) were published at `a6eeb042cf272c245478713836df83da55e57399` before the live run. The X process used the same W retrieval and query-validation implementation with a separate three-call budget. Ubuntu passed 244 core and 40 shadow tests. The Stage W audit and canonical Stage T SQLite hashes still match the registered values. The three X send markers, browser receipts, and two-event audit snapshot are in the ignored `vnext/.local/native-x` directory. The audit snapshot SHA-256 is `3cb3e2b24d36980861861b80e3905b99520052631609d19f6ead30d6f4f81520`. The three Stage X sends are complete.

OpenAI documents custom MCP app selection per message. The tested workflow is **Try in chat**, then ask the question in ordinary language. For automatic recall, the outstanding requirement is to make this connector available to an ordinary ChatGPT turn without that selection step. [OpenAI custom MCP guide](https://help.openai.com/en/articles/12584461-connecting-custom-mcp-servers-in-chatgpt)
