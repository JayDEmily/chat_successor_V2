# Independent Holdout E: raw cosine abstention versus lexical candidate retrieval

All 58 case labels, exact registered target source IDs and questions were committed
as the synthetic E corpus BEFORE any E embeddings were computed.
The cosine threshold was calibrated ONLY on C/D and committed at an earlier
checkpoint; it was not refitted or selected after viewing E.

Synthetic fixture SHA-256: 85c46d6a2e9f558257285dbf92f6444ce0c835d48b814976a6ca4a9459246ded
Frozen queries SHA-256: 13665770ab10c2c4070d82d0a77ee0b09e7e048e1e65fb787ed51231dc6befea
Frozen calibration gate SHA-256: 3fffb91b891b85b0f3c27fdd83df0713e6cb3686739b4de2bf42361596f1461a
Calibrated float32 cosine threshold: 0.721659660
Model: BAAI/bge-small-en-v1.5 through isolated local CPU FastEmbed 0.9.1

## Outcomes by fixed class

| Class | N | FTS5 candidates | FTS5 exact target@8 | Raw exact target@8 | Gate promotions | Gate accepted correct target@8 |
|---|---:|---:|---:|---:|---:|---:|
| explicit | 10 | 10/10 | 10/10 | 10/10 | 9/10 | 9/10 |
| implicit | 10 | 10/10 | 4/10 | 10/10 | 0/10 | 0/10 |
| original | 6 | 6/6 | 6/6 | 6/6 | 3/6 | 3/6 |
| alternative | 4 | 4/4 | 4/4 | 4/4 | 1/4 | 1/4 |
| hard_negative | 10 | 10/10 | not applicable | not applicable | 1/10 | not applicable |
| unrelated_negative | 10 | 5/10 | not applicable | not applicable | 0/10 | not applicable |
| ambiguous | 8 | 8/8 | not applicable | not applicable | 0/8 | not applicable |

## First-rank source quality on positives

| Positive class | FTS5 target rank1 | Raw dense target rank1 | Gated correct rank1 | Wrong source first after gate |
|---|---:|---:|---:|---:|
| explicit | 6/10 | 10/10 | 9/10 | 0/10 |
| implicit | 2/10 | 8/10 | 0/10 | 0/10 |
| original | 2/6 | 3/6 | 2/6 | 1/6 |
| alternative | 1/4 | 2/4 | 1/4 | 0/4 |

## Every registered case

| Case | Class | Expected target | FTS5 top | FTS5 rank@8 | Raw top | Raw rank@8 | Raw top cosine | Gate |
|---|---|---|---|---:|---|---:|---:|---|
| E01 | explicit | e03 | e01 | 2 | e03 | 1 | 0.843778 | PROMOTE |
| I01 | implicit | e03 | e02 | MISS | e01 | 2 | 0.698398 | ABSTAIN |
| O01 | original | e01 | e03 | 2 | e01 | 1 | 0.844369 | PROMOTE |
| E02 | explicit | e06 | e06 | 1 | e06 | 1 | 0.707625 | ABSTAIN |
| I02 | implicit | e06 | e15 | MISS | e06 | 1 | 0.644541 | ABSTAIN |
| O02 | original | e04 | e06 | 2 | e04 | 1 | 0.660925 | ABSTAIN |
| E03 | explicit | e09 | e09 | 1 | e09 | 1 | 0.802404 | PROMOTE |
| I03 | implicit | e09 | e32 | MISS | e09 | 1 | 0.646344 | ABSTAIN |
| O03 | original | e07 | e32 | 3 | e09 | 3 | 0.709489 | ABSTAIN |
| E04 | explicit | e12 | e12 | 1 | e12 | 1 | 0.840511 | PROMOTE |
| I04 | implicit | e12 | e15 | MISS | e12 | 1 | 0.707665 | ABSTAIN |
| O04 | original | e10 | e10 | 1 | e10 | 1 | 0.823607 | PROMOTE |
| E05 | explicit | e15 | e13 | 2 | e15 | 1 | 0.797968 | PROMOTE |
| I05 | implicit | e15 | e15 | 1 | e27 | 3 | 0.619997 | ABSTAIN |
| O05 | original | e13 | e13 | 1 | e14 | 3 | 0.790617 | PROMOTE |
| E06 | explicit | e18 | e18 | 1 | e18 | 1 | 0.802434 | PROMOTE |
| I06 | implicit | e18 | e15 | 2 | e18 | 1 | 0.623749 | ABSTAIN |
| O06 | original | e16 | e18 | 2 | e18 | 2 | 0.716962 | ABSTAIN |
| E07 | explicit | e21 | e19 | 2 | e21 | 1 | 0.805928 | PROMOTE |
| I07 | implicit | e21 | e16 | 4 | e21 | 1 | 0.654949 | ABSTAIN |
| E08 | explicit | e24 | e22 | 2 | e24 | 1 | 0.829065 | PROMOTE |
| I08 | implicit | e24 | e15 | MISS | e24 | 1 | 0.698565 | ABSTAIN |
| E09 | explicit | e27 | e27 | 1 | e27 | 1 | 0.793961 | PROMOTE |
| I09 | implicit | e27 | e27 | 1 | e27 | 1 | 0.638018 | ABSTAIN |
| E10 | explicit | e30 | e30 | 1 | e30 | 1 | 0.805366 | PROMOTE |
| I10 | implicit | e30 | e14 | MISS | e30 | 1 | 0.639433 | ABSTAIN |
| A01 | alternative | e31 | e01 | 4 | e31 | 1 | 0.705616 | ABSTAIN |
| A02 | alternative | e32 | e32 | 1 | e34 | 2 | 0.619149 | ABSTAIN |
| A03 | alternative | e33 | e18 | 2 | e33 | 1 | 0.750590 | PROMOTE |
| A04 | alternative | e34 | e33 | 2 | e27 | 2 | 0.680900 | ABSTAIN |
| H01 | hard_negative | no unique source | e03 | MISS | e03 | MISS | 0.725148 | PROMOTE |
| H02 | hard_negative | no unique source | e06 | MISS | e06 | MISS | 0.602343 | ABSTAIN |
| H03 | hard_negative | no unique source | e09 | MISS | e09 | MISS | 0.719551 | ABSTAIN |
| H04 | hard_negative | no unique source | e12 | MISS | e10 | MISS | 0.700048 | ABSTAIN |
| H05 | hard_negative | no unique source | e15 | MISS | e15 | MISS | 0.648726 | ABSTAIN |
| H06 | hard_negative | no unique source | e18 | MISS | e16 | MISS | 0.616677 | ABSTAIN |
| H07 | hard_negative | no unique source | e19 | MISS | e21 | MISS | 0.654430 | ABSTAIN |
| H08 | hard_negative | no unique source | e22 | MISS | e24 | MISS | 0.673211 | ABSTAIN |
| H09 | hard_negative | no unique source | e25 | MISS | e27 | MISS | 0.580712 | ABSTAIN |
| H10 | hard_negative | no unique source | e28 | MISS | e28 | MISS | 0.612590 | ABSTAIN |
| N01 | unrelated_negative | no unique source | none | MISS | e10 | MISS | 0.599123 | ABSTAIN |
| N02 | unrelated_negative | no unique source | e15 | MISS | e27 | MISS | 0.529677 | ABSTAIN |
| N03 | unrelated_negative | no unique source | none | MISS | e12 | MISS | 0.480797 | ABSTAIN |
| N04 | unrelated_negative | no unique source | none | MISS | e12 | MISS | 0.461580 | ABSTAIN |
| N05 | unrelated_negative | no unique source | e18 | MISS | e18 | MISS | 0.561643 | ABSTAIN |
| N06 | unrelated_negative | no unique source | none | MISS | e03 | MISS | 0.584168 | ABSTAIN |
| N07 | unrelated_negative | no unique source | e17 | MISS | e27 | MISS | 0.450829 | ABSTAIN |
| N08 | unrelated_negative | no unique source | e10 | MISS | e12 | MISS | 0.594084 | ABSTAIN |
| N09 | unrelated_negative | no unique source | e17 | MISS | e24 | MISS | 0.471206 | ABSTAIN |
| N10 | unrelated_negative | no unique source | none | MISS | e33 | MISS | 0.424461 | ABSTAIN |
| B01 | ambiguous | no unique source | e06 | MISS | e18 | MISS | 0.620217 | ABSTAIN |
| B02 | ambiguous | no unique source | e26 | MISS | e27 | MISS | 0.710471 | ABSTAIN |
| B03 | ambiguous | no unique source | e34 | MISS | e33 | MISS | 0.682654 | ABSTAIN |
| B04 | ambiguous | no unique source | e05 | MISS | e18 | MISS | 0.619477 | ABSTAIN |
| B05 | ambiguous | no unique source | e02 | MISS | e27 | MISS | 0.649979 | ABSTAIN |
| B06 | ambiguous | no unique source | e16 | MISS | e16 | MISS | 0.586682 | ABSTAIN |
| B07 | ambiguous | no unique source | e15 | MISS | e24 | MISS | 0.576655 | ABSTAIN |
| B08 | ambiguous | no unique source | e06 | MISS | e18 | MISS | 0.666436 | ABSTAIN |

## What these scores do and do not establish

A negative FTS5 candidate is an unnecessary or irrelevant retrieval candidate,
NOT evidence that the final ChatGPT assistant would assert the source was relevant.
Similarly, an ambiguous query with high cosine gives a questionable single-source
promotion; retrieving several candidates for clarification is not itself wrong.
The raw embedding method always has a nearest neighbour, even with no relevant
source. The gate prevents promotion solely when top similarity is below the
fixed C/D-calibrated cutoff; no semantic relevance classifier is used.

The data are 34 entirely invented sources and hand-authored questions.
The study is not representative of real personal chat history or a population
reliability estimate. The live MCP server still uses its original six-message
FTS5 archive, and source text/attribution were not rewritten.
