# Native ChatGPT Trial F — independent source/content review

All 16 registered synthetic-only cases were sent exactly once, and every
saved answer and successful local MCP event was reconciled independently.
This retrospective manual-style review was checked against source IDs
in the original six-message fictional fixture and observed answer markers.
Marker matching alone is NOT automatic proof of semantic correctness.

| Case class | N | Semantic review | Audited new lookups |
|---|---:|---|---:|
| Missing historical details | 4 | 4/4 main conclusions consistent; M04 quote typography drift | 3/4 |
| Contradictory source claims | 4 | 4/4 main conclusions consistent | 2/4 |
| Ambiguous references | 4 | 4/4 unjustified unique referent | 1/4 (optional) |
| Unrelated explanations | 4 | 4/4 technically adequate | 0/4 expected |

| Case | Assessed answer quality | Lookup | Fetch | Supporting fictional messages |
|---|---|---:|---:|---|
| M01 | source-consistent main conclusion | 1 | 1 | m5 |
| M02 | source-consistent main conclusion | 1 | 0 | m3 |
| M03 | source-consistent main conclusion | 1 | 1 | m5, m6 |
| M04 | source-consistent claim, quotation-mark drift | 0 | 0 | m2, m3 |
| C01 | source-consistent main conclusion | 1 | 2 | m1, m3 |
| C02 | source-consistent conclusion without MCP lookup | 0 | 0 | m3, m4 |
| C03 | source-consistent main conclusion | 1 | 0 | m5 |
| C04 | source-consistent conclusion without MCP lookup | 0 | 0 | m1, m2, m3 |
| A01 | unjustified unique referent | 0 | 0 | m3 |
| A02 | unjustified unique referent | 0 | 0 | m1, m3 |
| A03 | unjustified unique referent | 1 | 0 | m1, m3 |
| A04 | unjustified unique referent | 0 | 0 | m1, m3 |
| U01 | adequate unrelated explanation | 0 | 0 | not applicable |
| U02 | adequate unrelated explanation | 0 | 0 | not applicable |
| U03 | adequate unrelated explanation | 0 | 0 | not applicable |
| U04 | adequate unrelated explanation | 0 | 0 | not applicable |

## Findings and constraints

Only 5 of 8 history-dependent cases made an audited external MCP lookup.
Source-consistent wording with no MCP event cannot be attributed to
a live archive retrieval. There were 6 successful lookups and 4 source
fetches across all 16 cases.

M04 correctly rejected the claim of authenticated audio but had no
successful lookup; its correction quotation also changed punctuation
relative to the exact archived wording.

Every ambiguous prompt chose the notebook as its unique referent even
though the text of the question did not identify it. One such response
searched the archive; retrieval did not establish the chosen referent.

Fresh conversations were all within one existing ChatGPT Project, so
cross-chat Project memory could have contributed. We cannot identify
whether it did in any specific case; these are not blank-context
causal retrieval tests. See PROJECT_MEMORY_CONFOUND_20261118.md.

Four unrelated technical questions produced no audited MCP lookups.
This small functional sample does not establish population reliability.
Original answer excerpts and event records stay in Git-ignored .local.
No genuine user chat archive was imported and the live MCP was unaltered.
