# Native long-history comparison — 21 November 2026

**At 50,237 submitted user-text tokens, ordinary ChatGPT recovered the early diary details in both arms. The OpenAI Vector Store added verified archive provenance.** Giving it archive access did not change the old wording or correction it could already recover in this run.

| Case | Saved reply | Private MCP trace | Completion observed |
| --- | --- | --- | --- |
| Archive unavailable | Quoted Ryan’s original sentence, identified M6 bolts, correctly named Casey and Sunday morning, and reported the missing review clock time. It could not verify when the correction was archived. | One lookup returned `NO_MATCH` from the unavailable baseline. Zero OpenAI Vector Store queries. | 34.235 s |
| Archive available | Recovered the same historical details and gave **20 November 2026, 08:51:20 UTC** for original user record `t03u`. | One hosted lookup returned five pairs, including the four matching originals. The timestamp was verified to the second against SQLite. | 25.636 s |
| Recent follow-up in the same branch | Correctly recalled cobalt blue for the drawer labels. | Zero calls. | 31.608 s |
| Unrelated follow-up in the same branch | Explained why a rubber band can warm when stretched quickly. | Zero calls. | 20.825 s |

Eight separate normal ChatGPT user turns supplied the entire synthetic prefix, with a completed native model reply to each. The four short diary entries were present at the beginning of the first turn. The browser composer matched each frozen prompt before sending. The prefix made zero archive calls. After the baseline question, the native **Branch in new chat** action copied the conversation through the eighth assistant reply, before the baseline question. Both arms displayed the same High setting and had the connector and skill unselected. Independent readback confirmed the identical late question in both saved chats, and matching saved user-text previews and assistant replies for the final three inherited turns.

The baseline kept the same private plugin discoverable and supplied no archive matches. Switching the trial backend restored access to the existing hosted store. Both conditions used the same SQLite source, app connection and audit quota. There were exactly **12 native sends, one branch action, and two MCP attempts of five**, including **one live Vector Store search**. The 50,237 count uses `o200k_base` for the eight submitted user messages. The platform’s active context and cross-chat memory were unobserved. Browser completion times come from one pair and are descriptive.

The [frozen cases and payload fingerprints](NATIVE_LONG_HISTORY_CASES_20261121.json) were registered at `040cdcc6cee9e228e5302ecce6ed90ec378fce76` before the browser run. The tested runner was `98098b449380af7122d7e802d5146eda5047faa4`. The private audit snapshot SHA-256 is `6fe5356839c1b6da48031e4e2dd7fbd85450266d4507446455f8fedb8bfa8181`. The canonical SQLite bytes and the passing long-form repair audit matched their frozen hashes. The existing core suite passed 245 tests against this runner.

This establishes a provenance benefit in one 50,000-token synthetic conversation. It leaves open whether archive access improves wording recall when original passages are absent from active context. Continuous capture of ordinary chats remains unproven.
