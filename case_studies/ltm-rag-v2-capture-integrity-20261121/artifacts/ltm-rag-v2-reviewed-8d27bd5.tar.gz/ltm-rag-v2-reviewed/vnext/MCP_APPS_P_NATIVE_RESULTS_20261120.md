# Stage P — native MCP Apps positive UIAutomation confirmation

**PASS_P_NATIVE_ACCEPTED_UI_TRANSPORT_ONLY** — one native ChatGPT message, one synthetic automated InvokePattern activation, confirmed app-only callback before the frozen TTL. This is **not human consent or authenticated user-message ingress**.

## Pinned registration and source

- Preregistered at `340fe6e27277f9e3295ec0995eb4cb80b5119422`, exact direct parent `7ae7e4d504745a26116d451d8ddf05b89cbb31be`; frozen protocol and two-case matrix were independently GitHub-read-back before implementation.
- Frozen protocol SHA-256: `75a13a78baa3c4e3005058a1c75f0b4da01213de6847ad0c060f6e52b37f8860`.
- Frozen case matrix SHA-256: `d411bc5f4c497b499076f8feaac576dd6d48caacb077b3986e67b2a340802c9d`.
- Original Stage M Python handler, HTML widget and post-Stage O diagnostic helper all retained their preregistered SHA-256 values; no MCP server, host connector or fixture edits.
- Prior four M/N/O audit events preserved **byte-for-byte** with SHA-256 `a50e5fe66543b155d25841585007ace06c9bd0881d44ad50c44957f7a10c5aba`. The private cumulative audit contains exactly six events.

## Actual native outcome

- One native ChatGPT message from an isolated, newly created Chrome window, with the exact frozen request text SHA-256 `6371020525526e070b230f4a575753494c1005e949cce94e2b7d80b5dccce23a` and a separate UI-added plugin mention. The marker records one Send invocation; no duplicate send.
- One new `open_topic_selector_m` event: `AWAITING_CONFIRMATION`, client session and subject present, no source packets or original text attestation.
- The embedded MCP Apps widget displayed **five fictional topics**. The controller verified two stable positions of the exact Merrow button, performed **one** UIA `ScrollIntoView` recovery, and called its `InvokePattern.Invoke()` **once**, with a private pre-invoke marker.
- One new `confirm_topic_m` app-only callback: **`CONFIRMED`**, server event interval **12.192 seconds**, strictly less than frozen **60 seconds**.
- Independent native browser UI readback verified the frozen request and separate plugin mention, five buttons disabled after selection, and visible status **'Fictional topic selected. No sources or user messages were retrieved.'**
- Private controller trace has **14 flushed records**, including the send, widget readiness, scroll recovery, stable positioning, pre-invoke and completed invocation; no raw conversation text, challenge or session/subject value appears in the published evidence.
- Every cumulative native MCP audit record, including both new P events, reports `source_count=0`, `original_user_text_attested=false`, and synthetic-only provenance.

## Interpretation and limits

**Established:** The real ChatGPT web host rendered the fictional MCP Apps UI, and an automated UIA invocation delivered an app-only callback which the existing server accepted within its unchanged short TTL. The original source data boundary remained closed.

**Not established:** Actual human consent or identity; a trusted record of the original user's typed words; that host app-only tool visibility is an enforceable security boundary against an untrusted client; any source-selection or retrieval relevance for real history; Stage I's I05/I15 semantic referents.

Stage P's one-send/one-invoke budget is exhausted. No further P native prompts/clicks are permitted. Original/G/I/K services and past M/N/O judgments remain unchanged. Do not connect the offline shadow to genuine messages or claim a production implementation based solely on this synthetic result.
