# Native authenticated owner/source boundary — post-Stage Q engineering decision

**20 November 2026 | Read-only primary-document review.**

**Decision: AUTHENTICATED_OWNER_SOURCE_ADMISSION_NOT_YET_ESTABLISHED.** This is a material authority/identity boundary, not an ordinary test failure. Do not plug Stage L's simulated owner callback or Stage P's unauthenticated app-only confirmation into a real history source.

## Verified project facts

- Stage P: one native ChatGPT synthetic app-only `CONFIRMED` callback 12.192 seconds after opening, with zero original-source packets and zero original-message/human-consent attestation. The private plugin was registered with **No authentication**, and the existing synthetic handler returns `client_metadata_not_authorisation=true`.
- Stage L: 20/20 **offline** cases with a **simulated trusted-owner UI callback**. It does not connect to native ChatGPT or authenticate an actual human or their original words.
- Stage Q: 21/21 frozen offline composition-boundary tests. Native `CONFIRMED` + fictional topic is always quarantined, owner authorised false, zero packets. Separately simulated Stage L owner scope remains only a conditional offline comparator. Original native M/N/O/P event history is exactly six records, all zero source packets.
- The project has not connected a real personal conversation archive, deployed source-bearing plugin tools or implemented an external OAuth identity provider, server-verified access token, authenticated owner consent record or owned current-turn input controller.

## Official primary-source requirements, checked 20 November 2026

1. **Account authentication**: [OpenAI Plugins Authentication](https://developers.openai.com/plugins/build/auth) describes OAuth 2.1 for authenticated MCPs and requires the resource server to validate access token signature, issuer, audience/resource, expiry and scopes. An authenticated profile should derive from **validated credentials**, not a caller-supplied user ID.
2. **Per-tool source authorisation**: [Build an MCP server](https://developers.openai.com/plugins/build/mcp-server) requires authorisation enforced in the MCP server on every request, rather than trusting model input, security annotations or host confirmations. [Security & Privacy](https://developers.openai.com/plugins/guides/security-privacy) recommends least privilege, server-side input validation, consent and minimised data handling.
3. **MCP Apps tool visibility**: [Plugin Reference](https://developers.openai.com/plugins/reference) defines `_meta.ui.visibility = ["app"]` as a UI-versus-model tool presentation control; it is not an access token, cryptographic authorisation or proof of human-origin consent. Widget-only result `_meta` is hidden from the model, but official guidance says it does not replace authorisation/secure storage.
4. **Session/subject metadata**: [Plugin Reference](https://developers.openai.com/plugins/reference) defines `openai/session` as an anonymised conversation correlation identifier and `openai/subject` as an anonymised user identifier. No reviewed contract establishes a signed, exact copy of the *current user's original typed message* as an MCP tool-call field.
5. **Host approval lifecycle**: [Plugin changelog](https://developers.openai.com/plugins/changelog) documents host approval and delivery of widget tool inputs after approval via `ui/notifications/tool-input`. It does not by itself establish a server-verifiable attestation of the original user question or the human identity behind an app-only callback. Whether other eligible host modes can supply the required attestation remains **unverified**, not conclusively impossible.
6. **OAuth is not prompt provenance**: An OAuth-linked token can authenticate the account and scope permissions once independently implemented and verified, but a token **does not prove what a human typed during a particular ChatGPT turn**. Account access, explicit source-topic scope and exact current-question provenance are distinct requirements.

## Next admissible implementation boundary

- A separately scoped owned-account authorisation plan must first identify the source archive, authority to process it, owning principal, consent/retention rules, token issuer, scopes and access revocation. Do **not** create identity tokens or configure public/private data access just to continue the synthetic proof.
- An isolated, separately registered synthetic test may model the future OAuth/owned-controller architecture, but it should add only concrete coverage beyond Stage J (trusted-turn simulation), Stage L (simulated owner source scope), Stage P (native app transport) and Stage Q (untrusted event quarantine). Another unauthenticated topic selector or duplicate mock confirmation is not a meaningful improvement.
- Real source release requires: independently verified authenticated user identity; server-side source access checks; explicit scoped owner permission and replay protection; original message provenance **if** the product requires exact current-turn meaning; exact original source fidelity and a separate relevance/abstention decision. No current artifact satisfies this whole set.
- If only **authenticated archive access** rather than exact-message binding is required, an owner-approved OAuth scope could authorise a *bounded read-only search* without each app-only click proving a human choice; however the model would still not get to assert a unique referent from assistant-authored text. This is an architectural option, **not** an accepted project decision.
- Until authorised, preserve the no-real-data invariant, all six native events, all existing fixed test quotas and the five running loopback service/tunnel configurations. Stage I I05/I15 remain unresolved. No background worker has been created.

**Stopping criterion:** This boundary now requires a distinct authorised owner-identity/source contract before any genuine-history ingestion or a source-bearing native plugin. Continue other safe synthetic checks in subsequent active turns without routine reapproval, but do not misrepresent this identity dependency as something autonomous iteration can bypass.
