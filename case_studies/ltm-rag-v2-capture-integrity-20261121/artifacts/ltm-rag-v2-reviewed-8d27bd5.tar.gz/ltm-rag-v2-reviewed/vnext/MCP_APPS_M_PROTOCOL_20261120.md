# Stage M — isolated MCP Apps synthetic topic-selection transport

**Preregistered 20 November 2026 before any Stage M implementation or native sends.** This is a new limited UI/transport experiment derived from Stage L, not a redesign or production integration. All other original/G/I/K services, tunnels, plugins, fixtures, and earlier native ledgers are frozen. Do not treat the four-call Stage K protocol overrun as retroactively passing its three-call cap.

## Research question and primary authority

Can a **new isolated disposable** MCP Apps server expose a model-callable opening tool and a separate **app-only** confirmation tool so that a native ChatGPT-embedded UI can present fictional topics and send a single synthetic selection through the MCP Apps bridge? What information actually arrives at the server? Test that independently from the original user-message provenance question.

Official primary sources consulted 20 November 2026:
- https://developers.openai.com/plugins/reference — MCP tool descriptor `_meta.ui.visibility` (model/app), `_meta.ui.resourceUri`, tool result `_meta` delivered to UI but hidden from model, client-supplied `openai/session`/subject correlation.
- https://developers.openai.com/plugins/build/app-quickstart — `ui/initialize`, `ui/notifications/initialized`, `tools/call` bridge over `postMessage`; HTML `text/html;profile=mcp-app`; streamable HTTP.
- https://py.sdk.modelcontextprotocol.io/advanced/apps/ — installed MCP Python SDK 2.3.0 `Apps`, `@apps.tool(resource_uri=...,visibility=...)`, `apps.add_html_resource`, `MCPServer(extensions=[apps])`. It states app-only tool filtering is **the host's job** and not a backend security control.
- https://developers.openai.com/plugins/build/mcp-server — enforce authentication and authorisation server-side; elicitation is a separate mechanism.
- https://developers.openai.com/plugins/reference — server tool `_meta` is not proof of user intent or authenticated exact source text.

## Fixed local boundary

- Stage M uses **one new loopback listener 127.0.0.1:8791**, a wholly independent optional private tunnel, and, only after frozen offline PASS and independently read-back preregistration, a **new user-private plugin**. No original/G/I/K connector/server/profiles/tool changes. No new keys; existing owner-authorised tunnel control-plane credential may be reused in process, without publishing it.
- Exactly **two MCP tools**: `open_topic_selector_m` has `visibility=["model","app"]` and points at a `ui://.../selector.html` resource; `confirm_topic_m` has `visibility=["app"]` and is not intended to be shown to the model. This is a **host presentation restriction**, not an authenticated server capability.
- The first tool starts a short-lived synthetic flow and returns model-visible `AWAITING_CONFIRMATION` and **zero source packets**, while its tool result `_meta` contains a process-only random challenge for the widget and five topic IDs from original H manifest. No source text, raw native metadata, UI token, location, caller header or model prompt appears in model-visible output or public report.
- The HTML UI displays the five predeclared fictional topic names and an explicit "Confirm fictional topic" action; it only uses the MCP Apps host bridge. It must not send the challenge to third-party network endpoints, use real history, or suggest a selection happened without a button action. Disable multiple submits.
- The second tool accepts only exactly one allowlisted fictional topic + correct ephemeral challenge, within TTL 60 seconds, with a process-only flow. It records **no source packets**, only status and flags. The server must reject missing/guessed tokens, unknown topics, replay, expiry, and conflicting principal/session metadata when available. Neither `openai/session` nor subject alone authenticates a user or provides the original prompt; metadata spoofing via a custom client remains possible.
- Keep audit private under ignored `vnext/.local`, minimal event IDs, event types, boolean meta-presence, success/failure, coarse times, no raw identifiers or challenges. Do not record current user text. The server must not read source SQLite or real conversations.

## Frozen local acceptance

`MCP_APPS_M_CASES_20261120.json` specifies exactly 16 deterministic offline cases M01–M16. Tests must compare outcomes **without changing preregistered expectations**:
- descriptor/resource metadata and correct visibility;
- two-tool invariant, one HTML resource, proper MIME, no third-party resource references;
- opening tool returns no sources and model-visible response lacks the challenge;
- one valid app action records exactly one selection with no source release;
- token spoof/missing/unknown topic/invalid context/expired/replay are denied;
- model-only prompt cannot cause a confirmation;
- same versus distinct session context isolation;
- no native/real-history claims in any result.

Independent audit shall verify registration commit and parent, exact bytes and hashes of both frozen documents, count, SDK protocol shape and all 16 cases. Independently inspect source and HTML for app-only visibility and forbidden network endpoints; run isolated local SDK/client smoke where supported, and full core/shadow regressions. If any case fails, stop before native connection.

## Optional bounded native observation (NOT part of offline PASS)

Only if exact frozen offline PASS + private dedicated tunnel/plugin verified:
- **M-N01**: one explicit new ChatGPT conversation prompt: "Use the disposable LTM-RAG Stage M synthetic topic selector once. Show the fictional topic chooser; do not select a topic." One-send Windows guard, verify saved ChatGPT chat and one native server-side opening event. If UI not verifiably rendered, record `NATIVE_UI_NOT_VERIFIED`, **do not** fabricate a click.
- **M-N02**: optionally, once M-N01 is verified and only via the isolated test UI, **one automated synthetic click** on the fictional **Merrow** topic's confirm action, with a durable pre-click marker and independent app-only call audit. Explicitly label `AUTOMATED_TEST_INTERACTION`; this is **not a human consent event** or authenticated original-user-message ingress. Never execute an untracked or duplicate click.
- Maximum one native prompt and one synthetic test click. No other native sends. If tooling cannot distinguish target browser/window from unrelated automation, leave `NOT_RUN`; never modify other Chrome processes.
- Persist per-case event IDs, exact frozen prompt hash, counts, answer/chat ID privately; do not put real chat text or raw client metadata in Git. A model could still invoke an app-only tool through a hostile client or a compromised widget; never assert enforcement or identity from descriptor visibility alone.

## Decision rules

`PASS_M_OFFLINE_UI_TRANSPORT_ONLY` after 16/16 and independent SDK/HTML checks; native separate status `NOT_RUN | DISPLAY_OBSERVED | AUTOMATED_APP_CALL_OBSERVED | NATIVE_UI_NOT_VERIFIED`. Even with a native automated click, it proves **functional UI transport in the observed host**, not human consent, authenticated principal, trusted original text, secure per-user authorisation, retrieval relevance or repair of I05/I15. No source-archive import, external inference, production deployment, OS autostart, legacy service changes, or real user-data handling.
