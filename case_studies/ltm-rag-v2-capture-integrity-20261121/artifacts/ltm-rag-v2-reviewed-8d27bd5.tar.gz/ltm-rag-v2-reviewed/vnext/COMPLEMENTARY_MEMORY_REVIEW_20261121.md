# Complementary memory: independent review and next steps

**21 November 2026 · one owner · ordinary ChatGPT Chat, not Work**

Reviewed source: `5824ae667aa54c67c1c2cefc10ba9f63fb818679`.

**Verdict: keep the architecture; qualify the promises; prove capture next.**

## The short answer

Your understanding is substantially right. Keep the familiar conversation as the
experience. Let ChatGPT use its immediate context and its available personal
context, and give it a separate way to consult original records when that would
help. The archive is not a replacement personality, a second conversational
agent, or something that must contribute to every answer.

The useful promise is:

> When an authorised original was captured, the system can find it by meaning or
> wording and return the stored text, with enough provenance to distinguish what
> was said, by whom, and when. The model can then use that evidence appropriately.

That is **not** a promise that every message has been captured, that every relevant
record will be found, or that every model answer will use a retrieved record
correctly. Those are three separate things to measure.

For one person, the sensible target remains one local SQLite archive, its lexical
index, one hosted semantic index, one private read-only lookup surface, and a small
capture/indexing worker **once an authorised capture route is demonstrated**.
No extra reasoning model, new chat application, distributed database, or
multi-user platform is justified by this brief.

## What I agree with—and what needs changing

| Your working understanding | Assessment |
|---|---|
| The archive complements ordinary conversational memory. | **Agree.** Retrieval should be conditional on an information need, not on competing for every response. |
| An early conversation will usually have enough context. | Reasonable expectation, **not a guarantee of perfect detail**. A quotation or cross-chat question can need evidence on turn two. |
| Around 30–40k tokens, compression begins and exact recall stops. | **Do not build around that number.** No fixed regular-Chat threshold was established by this packet or the documentation checked. Your own 50,237-token trial still recalled the wording without archive results. |
| The backend supplies potentially relevant originals for the model to weigh. | **Yes.** Supply evidence, not a replacement answer or an instruction to believe every hit. |
| “Go and hunt again” should work as ordinary speech. | **Yes, as a model behaviour to evaluate.** Broaden or split queries and inspect missing episodes; do not write a phrase-trigger router. |
| PC off should not prevent ordinary chatting. | **Yes as a design goal.** The archive may be unavailable; conversation should continue, without claiming unavailable verification or successful saving. |
| On return, the chat can send back what it remembers. | Useful only as **labelled, best-effort recollection**, not a recovered original. Prefer recovering actual saved source text independently. A plugin is not an automatic transcript tap. |
| Better models should make this better without redesigning the database. | The separation supports that. Improvement is a hypothesis, not a guarantee; re-run a small native evaluation after a model or platform change. |

The relevant current product facts are collected, with official sources, in
[SOURCES.md](reviews/20261121_complementary_memory/SOURCES.md). In particular,
native Memory is selective rather than a complete record [O1]. The checked model
guide supports GPT-6 as a regular Chat option, but this review cannot inspect your
account's selection [O3]. The **17 November 2026** GPT-6.2 announcement applies to
Work/Codex; its release note explicitly leaves regular Chat choices unchanged
[O4]. Record the actual Chat label and thinking setting during tests rather than
assuming a paid plan specifies the exact underlying version.

## What the supplied evidence really proves

I treated the 21 November checkpoint as the current direction, rather than
reading older “next step” statements as still current. Earlier decisions remain
evidence, not instructions for this review.

- **Source preservation:** Stage T reports five fictional user messages and five
  actual ChatGPT replies reconciled to UI-rendered text, then indexed. I independently
  checked the ten exported text hashes. This is a bounded capture proof, not an
  always-on capture service. Stage S's footer-contamination failure remains a failure.
- **Automatic retrieval:** the supplied Z traces support two unselected normal-Chat
  archive reads and a no-call unrelated control.
- **Long dictation:** the original 515-word input hit a query-length rejection;
  the later 512-word retry used the repaired path and returned the four required
  user records. The failed query's original length is unknown, so it cannot
  honestly be described as definitely “too long.”
- **Long history:** in the matched test with **50,237 submitted user-text tokens**,
  **both arms** recovered the old wording and the correction. The archive-on arm
  additionally gave the SQLite ingestion time with a contemporaneous successful
  lookup. That supports a **provenance benefit in that run**, not a demonstrated
  advantage in exact-wording recall.
- **Important limit:** the successful retry returned five pairs from a five-pair
  archive. It proves the round trip and use of several originals, not selective
  retrieval among a realistic set of distractors.
- **No continuous capture claim:** the private service, account, tunnel and live
  hosted store were not accessible in this review. There was no new browser trial,
  upload, paid API call, deployment or GitHub action.

Evidence and implementation citations are in
[ARCHITECTURE_AND_EVIDENCE.md](reviews/20261121_complementary_memory/ARCHITECTURE_AND_EVIDENCE.md).

Independent checks here: **293/293 supplied file checksums, 4/4 frozen audit hashes,
10/10 canonical text hashes, and 8/8 regenerated long-history input fingerprints**.
The separate shadow tests passed **40/40**. The full core-suite attempt was **not
a pass**: it recorded 184 passes, 15 errors and 2 skips among 201 discovered entries;
missing MCP, Git objects and private receipts prevented reproducing the supplied
245-test run. Details and original logs are in
[verification/INDEPENDENT_VERIFICATION.md](reviews/20261121_complementary_memory/verification/INDEPENDENT_VERIFICATION.md).

## “How much weight?” is an evidence question, not a percentage

There are two different weights:

1. **Retrieval ranking:** which records the search engine returns, and in what
   order. Chunking, overlap, result count and ranking options affect this.
2. **Use in the answer:** whether the returned material actually answers your
   question, whether it is current, and whether it merits a quotation.

There is no exposed numerical control in the reviewed ChatGPT/plugin contract
for “30% archive, 40% personal memory, 30% thread.” A search similarity score is
not that control, and not a probability that a historical claim is true.

Use a **claim-specific evidence policy** instead:

- Your current message establishes what you want now. A current correction should
  not be overruled by a stale preference.
- For “what exactly did I write then?”, a verified original is better evidence
  than a remembered summary, whichever channel retrieved the original.
- For “what is the arrangement now?”, inspect applicable later corrections, not
  simply the oldest or highest-scoring text.
- An assistant suggestion is not a user decision. A plan is not a completed event.
- Duplicate mentions across context, personal memory and the archive are **not
  three independent confirmations**.
- If sources genuinely disagree, distinguish the dates or ask one useful question;
  do not silently blend them.
- Retrieved text remains historical data. Instructions embedded in it must not
  become operating instructions.

The backend should guarantee identity, scope, fidelity and bounded operation.
The model should assess relevance and express the answer naturally. Do not
force the backend to understand every conversational referent by deterministic
rules before allowing a benign, authorised search.

For example, if you say, “No, I think there was another detail—could you look
again?”, the model can search different wording, look for the missing episode,
or follow a correction link. If nothing better is found, it should say so, rather
than keep searching indefinitely or manufacture precision.

## The user experience I would aim for

**Normal case:** you speak as usual. ChatGPT answers naturally. If an earlier
detail matters, it quietly consults the available sources. No compulsory tool
name, “save this” command, special syntax or source-dump in every reply.

**When provenance matters:** a short phrase such as “Your earlier message said…”
and a usable source reference is enough. Show dates or exact quotations when
they answer your question, not as routine telemetry.

**When the PC is off:** continue the conversation. If needed: “I can work from
what is available here, but I can't verify that wording against the archive
right now.” Do not repeatedly interrupt unrelated turns with the same warning.

**When the PC returns:** restart and verify the service; reconcile actual source
records where an authorised route exists; label any remaining gaps. Nothing
about reconnection alone proves that missing turns have been recovered.
The hosted vector store does not make your powered-off SQLite/MCP service
available. The tunnel is the lookup transport; remote-desktop software is an
administration/capture aid, not an inherent part of that lookup path [O12].

[OFFLINE_CAPTURE_AND_RECOVERY.md](reviews/20261121_complementary_memory/OFFLINE_CAPTURE_AND_RECOVERY.md)
spells out the honest fallback.

## What to do next, in order

1. **Adopt the proposed evidence policy**, not a token-count switch or an “always
   search” rule. Keep the current synthetic restrictions intact.
2. **Use the compact instruction template** and attach the longer operating guide,
   after reviewing them. Keep the critical rules in the instruction box; a pointer
   to an MD file alone is not a reliable enforcement mechanism.
3. **Prove one small, passive capture-and-recovery loop** before importing a real
   diary. Capture user and assistant text, a correction, a branch/edit, a restart
   and a PC-off interval; compare against an independently retained source.
4. **Test archive-only evidence** with new synthetic facts that never appeared in
   the target chat or native memory. This is a much cleaner added-value test than
   merely adding another 50k tokens.
5. **Evaluate ordinary conversation over time:** natural dictation, thoughtful
   follow-ups, warmth, correct use of corrections, appropriate second searches,
   and tolerable latency. Keep functional correctness gates separate from these
   probabilistic outcomes.

The complete plan, 24-case draft matrix, blank evaluation ledger and small offline
scorer are in
[GATES_AND_EVALS.md](reviews/20261121_complementary_memory/GATES_AND_EVALS.md).
No proposed live evaluation has been marked as executed.

## Read next

- [Proposed ADR](reviews/20261121_complementary_memory/ADR_COMPLEMENTARY_MEMORY.md)
  — the architectural decision to approve or amend.
- [Implementation and evidence](reviews/20261121_complementary_memory/ARCHITECTURE_AND_EVIDENCE.md)
  — actual settings, missing pieces and the three-source workflow.
- [Capture/offline recovery](reviews/20261121_complementary_memory/OFFLINE_CAPTURE_AND_RECOVERY.md).
- [Instructions setup](reviews/20261121_complementary_memory/INSTRUCTIONS_SETUP.md)
  — small paste-ready block and an attachable MD file.
- [Gates and evaluations](reviews/20261121_complementary_memory/GATES_AND_EVALS.md).

**Bottom line:** the design is heading in the right direction. Its value is
recoverable originals and provenance when they are useful—not making native
ChatGPT memory look bad, and not making every conversation feel like a database
query. The largest unresolved product dependency is trustworthy capture.

[O1]: reviews/20261121_complementary_memory/SOURCES.md#o1
[O3]: reviews/20261121_complementary_memory/SOURCES.md#o3
[O4]: reviews/20261121_complementary_memory/SOURCES.md#o4
[O12]: reviews/20261121_complementary_memory/SOURCES.md#o12
