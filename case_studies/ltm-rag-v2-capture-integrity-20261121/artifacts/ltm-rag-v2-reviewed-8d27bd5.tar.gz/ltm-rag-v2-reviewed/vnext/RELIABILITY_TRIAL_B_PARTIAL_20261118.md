# Native synthetic reliability trial B — interrupted checkpoint

**Status: INCOMPLETE, NOT ACCEPTED.** 19 of 20 pre-registered cases were actually sent, observed and recorded; N10 was not sent. The original 20-case plan remains immutable.

## Pre-registration and method

- Locked design published before execution: Git commit `db19a0b`, files `RELIABILITY_TRIAL_B_20261118.json` and `RELIABILITY_TRIAL_B_PROTOCOL.md`.
- Guarded native UI runner: commit `bafc260`, `scripts/Run-SyntheticNativeTrial.ps1`.
- One fresh chat within `LTM-RAG vNext Synthetic Trial` per observed case; no explicit plugin name or chip. Private event and response ledgers remain under ignored `vnext/.local/`.

## Observed primary results so far

| Measure | Executed | Observed pass | Limit |
|---|---:|---:|---|
| Necessary lookup initiation | 10/10 history-needed | **10/10** | All history cases executed |
| Source fetch plus pre-registered answer markers | 10/10 history-needed | **9/10** | **H10 FAILED** the source-fetch requirement |
| Unnecessary lookup avoidance | 9/10 unrelated | **9/9 executed** | **N10 NOT EXECUTED**; do not count as a pass |
| Overall completed cases | **19/20** | **18/19** met both applicable primary/end-to-end criteria | No final 20-case verdict |

Within the 19 completed cases: 10 successful `lookup_evidence` invocations and 9 successful `fetch_source` invocations. A plausible answer that did not fetch sources is **not** counted as end-to-end verified evidence.

### H10 — observed end-to-end evidence failure

- Exact registered request: contrast the notebook's main correction with the alternative-branch drawer inference.
- [Native source chat](https://example.invalid/private-chatgpt-evidence).
- ChatGPT's actual answer was **substantively consistent** with the fixture, recognising the library correction as the user's reported recollection and the drawer as an assistant inference. This is not a demonstrated wrong answer.
- Ubuntu audit recorded `lookup_evidence` event `fc80e908-efb5-49bc-90b4-436374997701` at 2026-11-18T04:16:09.554Z (15:16:09 AEDT), with 5 matches, but **no `fetch_source` event** for that turn.
- Under the immutable protocol: **initiation PASS; source-fidelity chain FAIL**. Do not infer from accurate-looking answer text that the fetch tool ran.

### N10 — safely blocked before any send

- The worker navigated to the dedicated Project's new-chat composer and found a **non-empty draft belonging to an unrelated engineering task**, not its registered N10 prompt. This was likely concurrent desktop input; the source of that draft was **not independently verified**.
- The runner's explicit preservation guard stopped with `NONEMPTY_PROJECT_DRAFT` **before calling Send**, and without altering the unrelated draft.
- The result ledger contains 19 actual cases, no N10 row; the separate pending-send marker was absent after the stop. **Do not fabricate a 20th result or claim the draft was resolved.**
- This confirms an important desktop-automation isolation concern. The pre-registered stop condition was obeyed. Do not interact with the other task's draft merely to complete the synthetic test.

## Interpretation

Astra's suggested 90% initiation and ≤10% unnecessary-search targets have **not** been statistically accepted. These are small, non-randomly sampled synthetic controls, and one registered case was not executed. The valid observation is 10/10 initiated, 9/10 fetched and met markers, and 0/9 unrelated lookups among completed cases.

Any continuation must first establish an isolated, empty, correctly identified ChatGPT Project composer without disturbing that unrelated draft. An incomplete trial is not equivalent to 20/20.

TS: 18-11-26 (AEDT; machine event times preserved above)
