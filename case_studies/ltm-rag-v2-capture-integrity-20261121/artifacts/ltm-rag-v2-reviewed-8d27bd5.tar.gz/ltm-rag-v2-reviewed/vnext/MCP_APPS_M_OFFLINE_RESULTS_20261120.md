# Stage M — independent preregistered MCP Apps offline audit

**16/16 frozen offline cases PASS; no native ChatGPT or human click.**

- Frozen registration commit: `2c24a4ebabb5a8be8ec4d3ecabc5cedc73a69193`; exact parent `3703f8b9dd633d0ddcc05d6bdae3e4d28a0ba81c`.
- Protocol SHA-256 `f50d539abdc14a2beb7588caad17cb3210c35ad76df14fd27dd7a062cdf744b6`.
- Case matrix SHA-256 `da7aa66175291e69ee0b397f272f8c4295b5c956abb3113427da62e5152113e3`.
- Preregistered blobs compared byte-for-byte against Git before scoring.
- Original synthetic 20-message fixture SHA-256 checked; no source DB read in Stage M handler.
- MCP Python SDK 2.3.0 reports exactly two tools and one HTML resource.
- Model/app opening tool and app-only confirmation descriptor visibility checked.
- Resource MIME `text/html;profile=mcp-app`; UI bridge wiring and no external network/storage use inspected.
- Frozen case outcomes: `{"AWAITING_CONFIRMATION_NO_SOURCES": 2, "CONFIRMED": 2, "DENIED": 6, "EXPIRED": 1, "FIRST_ONLY": 1, "ONE_MCP_APPS_HTML_RESOURCE": 1, "SECOND_ACTIVE_FLOW_REJECTED": 1, "TWO_TOOLS_CORRECT_VISIBILITY": 1, "WRONG_SESSION_DENIED": 1}`.
- The server always returns zero source packets, even after simulated confirmation.
- Private one-use challenge is never included in model-visible structured/text output.
- Client-supplied session and subject values are used for ephemeral **correlation only**, not authentication.

**Decision: PASS_M_OFFLINE_UI_TRANSPORT_ONLY.** This test does not prove host-side tool filtering,
a visible native ChatGPT widget, real user click or consent, authenticated current-message
content, or a Stage I remedy. Any native observation must be reported separately.
