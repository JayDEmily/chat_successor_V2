# Stage M — native ChatGPT MCP Apps observation

**Outcome: NATIVE_M_UI_AND_APP_CALLBACK_TRANSPORT_OBSERVED; EXPIRED CONFIRMATION; NO TRUSTED USER ATTESTATION.**

## Reconciliation and lineage

- Frozen pre-implementation registration `2c24a4ebabb5a8be8ec4d3ecabc5cedc73a69193`, direct parent `3703f8b9dd633d0ddcc05d6bdae3e4d28a0ba81c`.
- Frozen protocol SHA-256 `f50d539abdc14a2beb7588caad17cb3210c35ad76df14fd27dd7a062cdf744b6` and cases SHA-256 `da7aa66175291e69ee0b397f272f8c4295b5c956abb3113427da62e5152113e3`, verified byte-for-byte against preregistered Git blobs.
- Stage M native-handler source remains byte-identical to offline implementation commit `9f67a287f598964c03ae157fadc82d0da8ff64e4`.
- Dedicated tunnel: `tunnel_6affa48f70b0819187bbe06449bf2750`. Native ChatGPT custom MCP plugin: `plugin_asdk_app_6affaf818f3481919433489e25b52471`, personally private.
- The earlier portable/desktop plugin package is a separate registration, not the native ChatGPT web plugin.
- Frozen user-request text SHA-256: `b5fc29f6ce6547d4772d69f4e3202c7e37443f05463f809ed1f1775527ff47e6`.
- Exactly one native message send and one automated synthetic widget click, checked against one-send markers.
- The saved ChatGPT message shows the frozen text verbatim **after** a separate UI-added plugin mention; therefore **the complete displayed message is not a byte-identical stand-alone frozen prompt**.

## Native server and UI evidence

- **M-N01:** one native `open_topic_selector_m` event. `AWAITING_CONFIRMATION`, session and subject supplied, zero source packets, no original-user-text attestation.
- The saved native ChatGPT conversation rendered the actual embedded MCP Apps HTML with all five preregistered fictional topic controls and the initial 'Select a single fictional topic.' status.
- **M-N02:** exactly one automated click on the **Merrow calibration log** widget button. The `confirm_topic_m` **app-only** tool reached the server as a second native MCP event.
- Time between native tool events: **262.618 seconds**; frozen TTL **60 seconds**. Confirmation returned `EXPIRED`, not `CONFIRMED`. The actual native widget visibly updated to `Confirmation not accepted: EXPIRED`.
- Both private-audit records report session and subject presence, synthetic-only status, no source packets and no original text attestation. No raw session/subject values, token, user-message content, chat URL or raw event IDs are included in this published report.
- Because the handler returns `EXPIRED` only on a **matching existing scoped flow**, that outcome supports process-local equality of the two **client-supplied** session/subject correlation scopes; it does not authenticate the client or user.
- The assistant's initial textual reply indicating no topic was selected preceded the automated widget click; it must not be treated as evidence about the later `EXPIRED` tool event.

## Decision and strict limits

**ACCEPT native opening-tool delivery, embedded-widget rendering, widget-to-MCP app-only callback delivery, source-exclusion and timeout enforcement.**

**DO NOT claim a successful confirmed choice or genuine human consent.** The confirm event expired after the 60-second window while the UI was being inspected, so the positive live-confirmation path has **not** been exercised. The UI-added plugin mention changes the complete displayed message compared with the frozen stand-alone prompt; record this as a native prompt presentation deviation, not a clean exact-message attestation.

The app-only descriptor is a host-side presentation filter, **not** a server-enforced identity or authorisation boundary. Client-provided `openai/session` and subject still cannot prove the original current user message or speaker. Stage I remains 14/16 with I05/I15 unsupported referents; Stage K retains its earlier four-call deviation.

**No additional Stage M native sends or clicks.** Any live accepted-confirmation test requires a *new*, separately preregistered time-bounded stage, using the existing M-only connector. No real conversation history, external inference, production imports, new API keys, OS autostart or original/G/I/K connector changes were made.
