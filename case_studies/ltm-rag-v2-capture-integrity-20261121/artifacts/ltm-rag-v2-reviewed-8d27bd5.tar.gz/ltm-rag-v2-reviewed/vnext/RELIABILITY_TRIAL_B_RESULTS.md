# LTM-RAG vNext: pre-registered native trial B results

All 20 cases are from the fixed input in RELIABILITY_TRIAL_B_20261118.json,
committed before the first question was sent. No completed case was excluded.

History-needed retrieval initiated: 10/10 (100.0%), two-sided Wilson 95% interval 72.2%–100.0%.
Unnecessary retrieval on unrelated controls: 0/10 (0.0%), two-sided Wilson 95% interval 0.0%–27.8%.
End-to-end content/source checks: 9/10 history cases. H10 initiated lookup but did not call fetch_source; this is the frozen two-tool protocol failure, not evidence its answer was wrong. See [H10 mechanism](H10_SOURCE_FETCH_DIAGNOSIS_20261118.md).
Actual local MCP calls: 10 successful lookups, 9 successful source fetches.

Astra's proposed future population thresholds are ≥90% necessary initiation and ≤10%
unnecessary retrieval. This small synthetic dataset does NOT establish those population bounds.

| Case | Class | Lookup | Fetch | Primary | Content | Native ChatGPT Project chat |
|---|---|---:|---:|---|---|---|
| H01 | history | 1 | 1 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| N01 | unrelated | 0 | 0 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| H02 | history | 1 | 1 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| N02 | unrelated | 0 | 0 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| H03 | history | 1 | 1 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| N03 | unrelated | 0 | 0 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| H04 | history | 1 | 1 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| N04 | unrelated | 0 | 0 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| H05 | history | 1 | 1 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| N05 | unrelated | 0 | 0 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| H06 | history | 1 | 1 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| N06 | unrelated | 0 | 0 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| H07 | history | 1 | 1 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| N07 | unrelated | 0 | 0 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| H08 | history | 1 | 1 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| N08 | unrelated | 0 | 0 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| H09 | history | 1 | 1 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| N09 | unrelated | 0 | 0 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |
| H10 | history | 1 | 0 | PASS | FAIL | [View](https://example.invalid/private-chatgpt-evidence) |
| N10 | unrelated | 0 | 0 | PASS | PASS | [View](https://example.invalid/private-chatgpt-evidence) |

## Evidence boundaries

- The private trial ledger and content-minimised invocation audit are held locally under vnext/.local;
  they were not committed or uploaded.
- Each case was submitted in a distinct saved chat inside the synthetic-only ChatGPT Project,
  with no selected plugin chip or explicit instruction to call the plugin.
- Local audit entries establish successful MCP handler calls, not the absence of every failed attempt.
- The automated content check requires the registered answer terms and a source fetch;
  it does not replace a full independent human semantic review.
- Results use six invented fixture messages, not actual personal conversations.
- Boot persistence, host shutdown and other projects are outside this trial.
