# LTM-RAG vNext: relevance/abstention Gate E verdict

**Verdict: REJECT_COSINE_ONLY_ABSTENTION_FOR_LIVE_INTEGRATION.**

## Prior commitments and verified sequence

1. Prior native ChatGPT Trial B: 20/20 cases executed on six invented source messages; automatic lookup initiation 10/10 on history-needed prompts, 0/10 unnecessary calls on unrelated controls, with the separately preserved H10 strict fetch-call failure. This tested the *model's decision to call the plugin*, not an embedding similarity threshold.
2. Holdout C/D: existing SQLite FTS5 missed many paraphrases; raw local BGE-small embeddings found all registered target messages within top 8 on C and D's synthetic tests. However raw dense always outputs a nearest source for any question.
3. **Holdout E**: the 34-message invented corpus, 58 fixed prompts, all expected target identities and class labels, and the score-gate rule were published before the E model ran. Registration commit: `e543ea2`.
4. **Frozen C/D calibration**: 24 explanatory negatives across C/D, no E input, single predeclared `T = nextafter(max negative top-1 cosine, +∞)`. Recorded exact IEEE float32 threshold **0.7216596603393555**, commit `7e4ee08`. C/D calibration outcomes: **0/24 negative promotions** by construction; only **27/48** relevant calibration cases were accepted. The frozen numerical gate and all inputs can be inspected separately.
5. **E independent evaluation**: `HOLDOUT_E_RELEVANCE_RESULTS.md` records every question, raw top source, FTS5 top source, exact registered target rank, similarity and gate output. The program verifies that the cutoff's stored float32 value satisfies the same registered formula and matches the calibration-file SHA-256.

## New, previously untested E outcomes

| Class | Cases | FTS5 correct source @8 | Raw dense correct @8 | Cosine gate accepted correct source |
|---|---:|---:|---:|---:|
| Explicit corrections | 10 | 10 | **10** | 9 |
| Implicit/paraphrased corrections | 10 | 4 | **10** | **0** |
| Superseded originals | 6 | 6 | **6** | 3 |
| Alternative-branch inferences | 4 | 4 | **4** | 1 |
| **Relevant total** | **30** | **24** | **30** | **13** |

Negative/ambiguous categories:

| Category | N | FTS5 nonempty candidates | Gated dense promoted a candidate |
|---|---:|---:|---:|
| Hard negatives sharing archive vocabulary | 10 | 10 | **1** |
| Entirely unrelated explanatory questions | 10 | 5 | 0 |
| Ambiguous, no unique target | 8 | 8 | 0 |
| **Total** | **28** | **23** | **1** |

Raw dense improves source *coverage* on this fabricated test: 30/30 exact registered sources in top 8 versus FTS5 24/30. Its correct first-ranked source is only **23/30**, with original/alternative branch ambiguity. Under the frozen threshold, 13/30 relevant cases retain the correct target; all ten implicit cases are rejected. One irrelevant topical question is nevertheless promoted.

No candidate retrieval method, including FTS5, is a human-independent proof that the query is a request for a source. FTS5 returned a nonempty candidate list on 23/28 no-unique-source prompts, but this is **not** equivalent to ChatGPT making a hallucinated claim or unnecessary MCP call.

## Mechanism and decision

A high cosine score measures similarity to the local record's words, not whether the user is asking about a remembered historical fact. A high threshold suppresses many paraphrases that share meaning but few lexical details; a lower threshold would admit more irrelevant discussions. The E result directly demonstrates the limitation without asserting that every conceivable threshold fails.

**Do not install this gate in the native MCP server or tune it against E.** Keep it as a rejected, reproducible experiment. **Retain RAW_DENSE as the leading offline candidate ranker**, separate from the *invocation/relevance decision* and from exact-source verification. Distinguish:

- **Invocation:** native ChatGPT must decide whether a previous conversation is needed; the earlier, small synthetic native trial demonstrated basic selectivity but did not establish population reliability.
- **Candidate ranking:** raw dense may supply plausible source IDs when explicitly asked for historical evidence. It must not silently assert relevance, change historical source versions, or merge branches.
- **Source evidence:** resolve stable IDs through the canonical SQLite read-only `Archive.fetch`, verify byte-exact text hash, original message author, reported speaker, source locator, supersession and branch. A similarity score is *not* source-authentication evidence.
- **Answer and abstention:** when a candidate does not actually support a requested proposition, the assistant must say it cannot verify the source or ask for a clearer reference. This requires later end-to-end testing; no simple threshold has been accepted as a sufficient rule.

## Next bounded implementation

Prototype a **shadow source-packet resolver** that ranks the synthetic E corpus locally but retrieves **unmodified** SQLite records only by stable source identity and labels every output `unverified_candidate`. Verify its exact-source hash and correction/branch boundaries on known and adversarial samples. Do not connect it to the live ChatGPT plugin in this tranche. Investigate semantic relevance and no-source controls in a separately registered native test only after this packet boundary is proved.

## Limits

The 34 records and 58 prompts are hand-authored, fictional and not an unbiased population sample. The gate model and corpus were small; no inference API was called and no real personal history was imported. No claim of statistical reliability, production approval, real-history safety or automatic ChatGPT response fidelity is made.
