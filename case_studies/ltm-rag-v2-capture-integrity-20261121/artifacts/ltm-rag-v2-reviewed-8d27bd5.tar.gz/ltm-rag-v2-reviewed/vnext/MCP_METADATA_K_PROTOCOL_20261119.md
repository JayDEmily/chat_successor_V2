# Stage K — private MCP call-metadata presence and clarification transport probe

**Registered before implementation or any new native sends, 19 November 2026.** No new genuine conversation history, external inference, credentials, model calls, changes to original/G/I services, or operating system startup. Code stays `vnext/`.

## Purpose
Stage I returned sources for the ambiguous original user texts I05/I15 despite a correct offline referent gate. Stage J proved an **owned** original-message input can prevent this, but found no documented native host-attested prompt ingress. K investigates whether a **disposable** custom ChatGPT MCP can observe the documented per-call session/subject metadata and whether the client's capabilities advertise structured elicitation. This does NOT attempt to authenticate any user message, remediate native I05/I15, or investigate real history.

## Official sources checked
- [Plugins reference, client-provided _meta](https://developers.openai.com/plugins/reference): `openai/session` anonymised conversation ID, `openai/subject` anonymised user ID, keys on tool calls; none is original user text or per-turn attestation.
- [Build an MCP server](https://developers.openai.com/plugins/build/mcp-server): MCP elicitation may request structured user input; actual ChatGPT client support must be tested rather than inferred from docs.
- [Python SDK context](https://py.sdk.modelcontextprotocol.io/handlers/context/): injected `Context` may provide client capabilities, request metadata; inspect current installed SDK. SDK's `ctx.headers` are client-supplied and untrusted.
- [Python SDK v2 multi-round-trip](https://py.sdk.modelcontextprotocol.io/whats-new/): elicitation API and protocol revision alter mechanics; a capability flag is NOT a demonstrated user-facing interaction.

## Fixed privacy and trust boundary
Dedicated, synthetic-only, read-only, single-tool MCP on a new loopback port, isolated tunnel and plugin **only after** offline passes and independent GitHub preregistration. Probe returns only `true/false` presence/type flags for documented keys, a **process-ephemeral** random-salted fingerprint for session and subject (prefer returning only equality class labels where possible), and boolean elicitation capability. No raw `_meta`, caller headers, user question, credential, original identifier, coarse location or new full transcripts in tool output or logs. The disposable tool has no source retrieval, SQLite database, or filesystem read capability beyond its own local audit. No egress except owner-approved private tunnel.

Transport `_meta` may be supplied by the client and can be spoofed by a custom client; presence proves **delivery**, not identity or integrity. A model-authored argument containing `openai/session` cannot count as host `_meta`. Do not grant access/permissions based on metadata alone.

## Frozen deterministic local cases
The separate JSON case file specifies exact expected booleans for: missing meta, valid meta values, other key only, wrong value types, tool-argument key spoofing, second call same session, different conversation ID, different user ID, and leaked raw IDs in output. An independent auditor rechecks frozen cases against the registration commit, runs offline logic with ephemeral salt and checks source boundary. **All cases must pass as registered**. Verify one-shot actual private HTTP transport with SDK client if supported, but this is not a native host test.

## Native observation scope — max three explicit calls, only if separate plugin connection verified
- **K-N01**: In a brand-new ChatGPT conversation explicitly invoke disposable K metadata tool once. Record only event ID, boolean metadata presence and opaque process-only fingerprint, never raw IDs or chat text.
- **K-N02**: A second explicit invocation in the **same saved ChatGPT chat**. Compare whether nonempty session fingerprint stays the same. Record result `same/different/absent`.
- **K-N03**: A new chat, single explicit invocation. Compare session fingerprint against N01: `different/same/absent`; optionally compare subject fingerprint but don't interpret it as identity proof.
- All three prompts are fixed and hashed *before* any native Send. If plugin cannot be verified, skip all native sends and explicitly say `NOT_RUN`, not failed or passed.
- Never manufacture user-side clicks or confirmation in an elicitation interface. Read client-advertised elicitation capability only. Any actual direct-user clarification UI requires separate future protocol and actual user decision.

**Acceptance boundary:** offline passing proves an adapter can discriminate request metadata from model arguments. Only genuine observed ChatGPT plugin events can establish native delivery and same/new-chat metadata behaviour. Neither result satisfies trusted original-message binding or source-relevance admission. An absent field is a measured local configuration outcome, not proof that OpenAI never provides it elsewhere. Preserve the I native result unchanged.
