# Stage K — independent preregistered metadata adapter audit

**10/10 frozen cases PASS. 0 native ChatGPT calls executed in this local audit.**

## Reproducibility

- Registered Git commit: `8b6ae970a8e5cdb36e0beb6882ad0ddcfa84a436`; exact parent `660434d352b735d5886476b7738263d193dce996`.
- The frozen protocol and 10-case plan were compared byte-for-byte
  with the remote-registered Git content before running any case.
- Local outcomes: {'not_present_both': 5, 'present_both': 5}.
- Two different synthetic session IDs produce distinct process-keyed
  fingerprints; repeated same-session calls produce the same fingerprint
  within the same process. A different process key changes fingerprints.
- Model-supplied fake metadata in tool arguments never counts as MCP
  request metadata. No raw ID, prompt, location or credential is logged
  or returned by the standalone probe.

## Hard interpretation boundary

The MCP request `_meta` fields are **client-supplied** and are
not an independently authenticated copy of the original user text.
A local SDK client can simulate this metadata and must not be mistaken
for proof of native ChatGPT delivery. Even if ChatGPT genuinely delivers
an anonymised `openai/session`, a per-turn user-message binding is
still absent. Capability advertisement is not a completed human
clarification interaction. The SDK's `ctx._input_params` is an
implementation detail; no production dependency is approved.

**Decision: ACCEPT_K_OFFLINE_METADATA_ADAPTER_ONLY pending verified native connection.**

## Actual isolated MCP transport check (not ChatGPT)

A temporary random-port loopback HTTP MCP server accepted exactly one read-only tool named `inspect_metadata_presence_k`. An independent local Python MCP client made four calls: one without ChatGPT metadata, two with identical **synthetic client-supplied** session/subject values, and one with a different synthetic session but the same subject. All four returned expected booleans and the private 0600 audit observed the expected process-salted equality/difference pattern. No raw test identifiers, message bodies, location or authentication information were persisted. The temporary server terminated normally.

The ability to supply `_meta` using a Python MCP client is **not** evidence that ChatGPT sent these fields, and no real user message was attested.

**Regression:** 146/146 core tests, 40/40 shadow tests pass. Stage I previously published native failures remain unchanged.
