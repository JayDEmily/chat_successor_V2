#!/usr/bin/env python3
"""Rerun original snapshot tests offline; report errors without turning them into skips.

Requires the extracted source packet, not the user's live worktree. This executes
the reviewed tests. Python network connects are disabled; it is not a general
sandbox for arbitrary untrusted code.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import socket
import sys
import unittest

from verify_snapshot import verify_manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--suite", choices=["core", "shadow"], required=True)
    args = parser.parse_args()
    root = args.snapshot.resolve()
    verify_manifest(root)
    for key in list(os.environ):
        if any(part in key.upper() for part in
               ("KEY", "SECRET", "TOKEN", "PASSWORD", "CREDENTIAL", "PROXY")):
            del os.environ[key]
    sys.dont_write_bytecode = True
    folder = "tests" if args.suite == "core" else "tests_shadow"
    sys.path.insert(0, str(root/"vnext"))
    sys.path.insert(0, str(root/"vnext"/folder))
    def no_network(*args, **kwargs):
        raise RuntimeError("Network disabled for independent offline source review")
    socket.create_connection = no_network
    socket.socket.connect = no_network
    socket.socket.connect_ex = no_network
    print("Python:", sys.version, flush=True)
    print("Mode: source review; no credentials; Python network connects disabled", flush=True)
    suite = unittest.defaultTestLoader.discover(str(root/"vnext"/folder), pattern="test*.py")
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    summary = {
        "suite": args.suite, "discovered_entries_run": result.testsRun,
        "passed": result.testsRun-len(result.errors)-len(result.failures)-len(result.skipped),
        "errors": len(result.errors), "failures": len(result.failures),
        "skipped": len(result.skipped),
        "error_ids": [test.id() for test, _ in result.errors],
        "failure_ids": [test.id() for test, _ in result.failures],
        "successful": result.wasSuccessful(),
        "note": "Import-failure entries are module placeholders, not all tests within those modules."
    }
    print("RESULT_JSON="+json.dumps(summary, sort_keys=True), flush=True)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
