# Independent verification report

**21 November 2026 · source snapshot `5824ae667aa54c67c1c2cefc10ba9f63fb818679`**

## Scope and method

The uploaded tarball was present in this sandbox. It contained 311 members:
17 directories and **294 regular files**, approximately 1.71 MB uncompressed.
It was checked for absolute/traversal/link members before bounded extraction.
All 294 files were inventoried and hashed; 73 JSON files and 99 Python files
parsed successfully. Selected current architecture, code paths, tests and primary
receipts were read in depth. This is not a line-by-line security audit of every
historical experiment.

No repository instructions were treated as authority to operate services.
No credentials, original `.local` runtime, `.git` objects, live ChatGPT UI,
tunnel or provider store were available. There was no GitHub access, live
retrieval, upload, paid inference, package download, account change, service
start or personal-history import.

Review utilities use only the standard library (plus local Node for the optional
pinned generator). Source shadow tests use the already available NumPy. Native
MCP dependencies were not faked or installed.

## Independently checked results

| Check | Result | Meaning / limit |
|---|---|---|
| Supplied `SHA256SUMS` | 293/293 members match; manifest itself pinned | Preservation, not external authenticity. |
| Frozen audit hashes | 4/4 match | Same archived audit bytes as the supplied pins. |
| Audit joins | Z: 2 FOUND; original long-form: 1 DENIED_SCOPE/BAD_LENGTH; retry: 1 FOUND; history: NO_MATCH then FOUND | Internal event/source-ID consistency, not fresh provider proof. |
| Canonical exported messages | 10/10 text hashes match; roles/order coherent; 5 assistant send times NULL | Export checked; original SQLite file not present to re-hash. |
| Retry source provenance | Four required original user IDs joined to FOUND; source/send/ingestion times match exported t03u | Semantic body not automatically regraded by the checker. |
| History saved answers | Both contain the same exact old sentence; ON time matches exported t03u to the second | Does not show hidden context loss or isolate all native memory. |
| Long-history generator | 8/8 local Node outputs match frozen lengths and SHA-256 | Reported token counts sum to 50,237; no tokenizer installed to recompute BPE counts. |
| Original shadow suite rerun | **40/40 passed** | Algorithm/integrity unit tests, not a new BGE embedding retrieval experiment. |
| Original core suite rerun | **Not a pass**: 201 discovered entries; 184 pass, 15 errors, 2 skips; no assertion failures | Environment/private-input limitations described below. |
| New review-tool tests | **31/31 passed** | Validates the review utilities, not ChatGPT or the production design. |
| Blank eval ledger | 24 NOT_RUN; all scores unknown; `NO_EXECUTED_CASES` | No native evaluation was invented. |

Machine-readable details: [SNAPSHOT_CHECKS.json](SNAPSHOT_CHECKS.json),
[SOURCE_TEST_SUMMARY.json](SOURCE_TEST_SUMMARY.json),
[EMPTY_EVAL_SUMMARY.json](EMPTY_EVAL_SUMMARY.json).

## Why 245 core tests were not independently reproduced

The source packet reports **245 successful tests** on Ubuntu Python 3.14.4 with
`mcp==2.3.0`. The present sandbox has Python **3.13.5** and no MCP package.

Our full discovery attempt produced:
- **8 error entries due to missing MCP**, including five module-import placeholders;
- **1 error** in W's frozen-registration check because Git objects are absent;
- **6 errors** in the fake-provider T tests because their constructor still needs
  the original private verified UI transcript;
- **2 skips** performed by the supplied MCP tests themselves.

The 201-entry discovery count includes five import-failure placeholders instead
of all 49 tests in those modules. It must not be compared to 245 as if the
missing cases passed. We did not fabricate private receipts, mock the entire
MCP package, alter the pinned registration or relabel errors as skips.

The supplied exported **13-test MCP smoke** is preserved as historical evidence;
it could not be repeated here without the missing dependency. The 40 shadow
tests are a separate independently passing suite.

Raw logs:
- [SOURCE_CORE_TESTS.txt](SOURCE_CORE_TESTS.txt)
- [SOURCE_SHADOW_TESTS.txt](SOURCE_SHADOW_TESTS.txt)
- [REVIEW_TOOLS_TESTS.txt](REVIEW_TOOLS_TESTS.txt)

## Reproduce the review, not the live service

From a repository with this additive overlay, set:

```bash
R=vnext/reviews/20261121_complementary_memory
SNAPSHOT=/path/to/extracted/LTM-RAG-vNext-Astra-review-5824ae6

# Static evidence check. Optional --generator needs local Node.
python3 "$R/scripts/verify_snapshot.py" --snapshot "$SNAPSHOT" --generator \
  --output /private/path/snapshot_checks.json

# Review-only unit tests; standard library, no original packet required.
python3 -B -m unittest discover -s "$R/tests" -v

# Original snapshot suites. Core may fail on missing original prerequisites;
# a failure is deliberately returned with a nonzero process status.
python3 -B "$R/scripts/review_source_tests.py" --snapshot "$SNAPSHOT" --suite core
python3 -B "$R/scripts/review_source_tests.py" --snapshot "$SNAPSHOT" --suite shadow

# Verify that the blank ledger is still unexecuted.
python3 "$R/scripts/summarize_evals.py" \
  --plan "$R/evals/plan.json" --run "$R/evals/run_template.json"
```

`review_source_tests.py` verifies the pinned source manifest, strips
credential-like environment variables and disables Python socket connects before
discovery. It is a reproducibility helper for this reviewed snapshot, not a
security sandbox for arbitrary modified tests.

The source packet's original smoke can be repeated in the owner's appropriate
isolated environment, using its pinned dependencies:

```bash
PYTHONPATH=vnext:vnext/tests python -m unittest -q \
  test_hosted_mcp_u test_mcp \
  test_hosted_mcp_w.TestStageWSemanticGate.test_native_recall_handles_compact_and_long_queries_through_mcp
```

Do not install dependencies, reset quotas or reconstruct private state merely to
make a green badge. Keep owner-environment evidence checks distinct from hermetic
unit tests.

## Preserved boundaries

All supplied source files still match their original digests after review.
This handoff adds files only. The fictional-only controls, frozen cases, service
configuration, existing skill, old audits and failure history are unchanged.
The proposed general archive, capture adapter, authentication changes, recovery
worker, new native experiments and instruction installation have **not** been
implemented or performed.
