# Architecture, evidence and the meaning of “weight”

**Snapshot review, 21 November 2026.** Paths below are relative to `vnext/` unless
prefixed `evidence/`. Source labels resolve in [SOURCES.md](SOURCES.md).
“Observed” means supported by the supplied record; it does not mean a fresh live
test by this reviewer.

## 1. Map of the intended experience

```text
Owner speaks/types in ordinary ChatGPT
       |
       +--> active conversational context ----------------------+
       |                                                        |
       +--> native personal/project context, when available ----+--> ChatGPT
       |                                                        |    answers
       +--> optional archive lookup ----------------------------+
                    |
             private MCP + tunnel
                    |
            authenticate / scope / bound
                    |
             retrieve candidates
            /                   \
       lexical/FTS          hosted semantic index
            \                   /
             canonical SQLite resolution
                    |
          originals + attribution + relevant context
          (data, not instructions and not a finished answer)

Separate, conditional write path:
owner-authorised source capture/import
       -> durable local receipt -> SQLite + indexing outbox
       -> hosted index -> reconciliation / coverage ledger
```

The diagram is a proposed logical map. **The current hosted T lookup only follows
the hosted-search → SQLite path.** The older FTS lookup exists separately; one
general hybrid orchestration and continuous capture are not present. The native
personal-context channel is controlled by ChatGPT, not by this MCP service.
Having both services under your account does not make the native personal-context
lookup query your API vector store automatically; the demonstrated path is the
explicit plugin → gateway → store → SQLite round trip. No automatic synchronization
between the two memory systems was established.

No remote desktop is required to carry the lookup request itself. In the supplied
experiments, Windows UI automation and remote administration helped send/capture
the synthetic dialogue, and Ubuntu ran under WSL. Treat a standalone Ubuntu
deployment and a Windows/WSL deployment as different restart environments [E8].
Do not silently install boot tasks or assume either survives shutdown.

## 2. Evidence ladder: do not promote a lower layer into a higher claim

| Layer | What the packet supports | What it does not support |
|---|---|---|
| Source/index integrity | Stage T: 10 clean UI-rendered records; 5 indexed pairs; exported hashes check. | Authentic audio, complete personal transcript, cryptographic host attestation. |
| Transport/native invocation | Z: 2 automatic unselected lookups; unrelated control 0. | Reliability over arbitrary dictation, all settings or all clients. |
| Long-form repair | 512-word retry: one successful attempt, 5 pairs, required 4 originals cited; control 0. | Which bound the earlier failed query crossed; retrieval discrimination in a large corpus. |
| Matched long history | Both arms recalled old wording/correction; ON also supplied matching ingestion time through current lookup. | Original text absent from active context; native memory unused; exact-recall superiority. |
| Capture availability | Bounded S/T UI capture and specific outage/restart observations. | Passive all-turn capture, mobile capture, off-PC exact catch-up. |
| Conversational quality | Some accurate source use and no-call controls. | Seamless day-to-day experience, calibrated ambiguity or better empathy. |

References: [E2–E6]. In the history comparison, the “OFF” arm still had a
discoverable tool, which intentionally returned `NO_MATCH` without hosted search.
That is a **no-results backend control**, not a tool-disabled baseline and not a
real network timeout. Preserve that label in future comparisons.

The four pinned audits can be checked for event pairing and source IDs. Their
hashes show preservation relative to the supplied manifest, not independent
certification that the originating computer or provider was honest. The SQLite
file, original private captures, provider bindings and full saved prefix are not
all in this packet. The sanitized readback verifies shared previews for the last
three prefix turns; it is not an independent full-byte capture of all inherited
native context.

The history timestamp claim is appropriately narrow: source `t03u` has exported
ingestion time `2026-11-20T08:51:20.291203Z`; the ON answer gives it to the second,
and the contemporaneous audit lists that source. This supports archive-grounded
provenance. The earlier failed long-form answer also knew that timestamp from
prior context despite no successful retrieval. Therefore **a correct timestamp
alone is not proof of a new read**; the joined trace matters.

## 3. What the code actually does now

| Item | Inspected setting / behaviour | Reference |
|---|---|---|
| Canonical ID | First 32 hex characters of SHA-256 over source, message and version identity; not a timestamp ID. | `ltm_vnext/archive.py::_local_id` |
| Chronology | Separate `position`, event time/precision, source send time, normalized UTC send time and first ingestion time. | `archive.py`, [E9] |
| Canonical storage | Synthetic-only admission; exact text/hash; role/attribution; immutable identity conflicts rejected; branch-local correction checks. | `Archive._validate`, `ingest_synthetic` |
| Lexical lookup | FTS5 BM25; OR over the first 12 word tokens; default 8 hits; allowed 1–20; neighbour radius 1. | `Archive.lookup` |
| Source fetch | Neighbour radius 0–3, same source/conversation/branch. | `Archive.fetch`, `_packet` |
| Hosted payload | One user/assistant pair per file, labelled by role; T derives payload from independently reconciled UI receipts. | `verified_dialogue_t.py::_payload` |
| Hosted attachment | No explicit `chunking_strategy` in the attach request. | `hosted_memory_r.py::OpenAIHttpR.attach` |
| Hosted search | `rewrite_query=False`, synthetic-source filter, bounded result count. No explicit ranker/threshold/hybrid weights configured. | `OpenAIHttpR.search` |
| Repaired native query | 2–4,096 normalized characters; requested limit 1–10, clamped to 5 pairs. | `hosted_mcp_w.py::validate_native_recall` |
| Latest retry/history launcher | Default 5 pairs; finite shared 5-attempt trial quota persisted in audit. | `scripts/run_native_recall_routing.py` |
| Older W/U defaults | W retains 8–640/3-pair settings; U retains its fictional topic anchors. They are not the repaired general entry mode. | `hosted_mcp_w.py`, `hosted_mcp_u.py` |
| Current result | Original user/assistant records with text, IDs, hashes, roles and timestamps; `candidate_only=True`. | `HostedMemoryGatewayU.lookup/public` |
| Index lifecycle | T store requires a 30-day last-active expiration setting. | `NativeVerifiedT.store` |

These are source-code facts, **not a readback of what is running on your PC now**.
Startup path and plugin release must be included in every live test.

### Overlap: broader recall does not mean duplicating everything

The API reference currently documents automatic chunks of **800 tokens with
400-token overlap** [O7]. Because the code omits a chunking setting, it relies on
provider defaults; the packet does not contain an independent per-file chunking
readback. Do not claim those are verified live settings.

Overlap is within an indexed file. It does **not** automatically connect adjacent
one-pair files. Short pairs may not span multiple chunks at all. For long inputs,
provider chunks locate a pair; the backend should recover the original message or
an explicit, source-bounded span from SQLite.

My recommendation:

- Be generous in **candidate discovery**, economical in **what is injected into
  the answer context**, and strict about **identity and provenance**.
- Keep the original text unchanged. Normalize the query, not the quote.
- Deduplicate the same message/version/span before returning it.
- Add the relevant neighbouring turn and correction, rather than several copies
  of one highly similar passage.
- Split a multi-episode question when an episode is missing. Return enough
  alternative candidates to let the model resolve ambiguity.
- Tune unique-source recall, correction coverage and distracting material together.
  Do not maximise overlap or reinstate the rejected cosine gate [E7].

Proposed comparison, not a deployment default: on a new long-message/distractor
fixture compare 800/200 with 800/400, then vary unique-pair budgets (e.g. 4 and 8)
separately. Measure recall at a fixed returned-text budget, not just raw hit count.
Retain the smaller configuration if wider retrieval adds no benefit. The present
five-pair archive is too small to decide this.

Gate E used a local BGE shadow ranker, not the hosted OpenAI score. Its rejected
numeric cutoff is not a calibration for this hosted store; the transferable
lesson is to separate candidate ranking from answer relevance and source fidelity.

## 4. What “weight” can and cannot mean

In the documented MCP flow, the model chooses a tool and arguments, the server
returns a result, and the model continues its response [O8]. The reviewed
contract does not expose the model's private attention allocation or a numerical
mixing ratio among native memory and tool output.

**Backend controls:** what is searchable; access scope; query/result limits;
candidate order; source fidelity; neighbouring/correction context; output size;
timeout/retry limits; and concise tool metadata.

**Instruction-level guidance:** when evidence is worth seeking, how to handle
conflicts, quote faithfully, distinguish a plan from an event, and retry
meaningfully. Guidance is not guaranteed routing.

**Observable outcomes:** did an archive call occur, what records were returned,
what claims the answer made, whether they are supported, and whether the user
preferred the reply? A matching answer is not proof of the hidden reason for it.

Native memory can return useful original context as well as summaries. Do not
demote it solely because it is “native.” Conversely, a SQLite original reliably
preserves what was captured, not whether the author's statement was true.
Use quality and relevance of evidence, not brand or channel priority.

### Recommended response envelope for a later generalised tool

This is a **design sketch, not the existing API**:

```json
{
  "status": "CANDIDATES",
  "coverage": {
    "conversation_id": "approved-scope",
    "capture_complete": false,
    "known_gaps": true,
    "index_current": false
  },
  "records": [
    {
      "source_id": "owner-approved-source",
      "message_id": "stable-message-id",
      "version_id": "1",
      "conversation_id": "approved-scope",
      "branch_id": "main",
      "position": 12,
      "author_role": "user",
      "attribution": "direct_message",
      "reported_speaker": null,
      "fidelity": "ui_rendered",
      "capture_method": "owner-approved-adapter",
      "exact_text": "[original source text, not a generated summary]",
      "content_sha256": "[hash of the original UTF-8 text]",
      "message_sent_at_utc": null,
      "ingested_at_utc": "[actual first local receipt time]",
      "supersedes_local_id": null,
      "corrected_by": [],
      "candidate_relevance": "unassessed",
      "source_integrity": "verified_against_capture",
      "source_locator": "[usable source reference]",
      "truncated": false
    }
  ]
}
```

Return only the fields needed for the task. Source timestamps may matter to
chronology; request IDs, query hashes and other operational telemetry belong
in private logs, not routine model output [O11]. A displayed source excerpt must
say if it is truncated. Hash/offset verification applies to the referenced
original; do not silently label a summary as `exact_text`.

Use distinct statuses for no match, unavailable provider, unauthorised scope,
not-yet-indexed coverage, corruption and exhausted budget. An honest empty result
does not assert that something never happened.

## 5. Concrete gaps to address before general use

These are focused one-person concerns, not reasons to build a scalable platform.

1. **No passive capture hook.** S/T automation controls five scripted sends and
   reads the UI; it is not a listener for all ordinary user-typed turns. Current
   ingestion intentionally rejects real/unlabelled sources [C1, C3].
2. **Read authorisation remains a separate requirement.** A private listing,
   tunnel credential and pseudonymous session field do not by themselves prove
   owner access at the resource server. Implement the smallest supported,
   server-verified owner credential/scope model; OAuth 2.1 is the documented
   authenticated-plugin route [O9, O10]. Do not repeat UI-selector experiments
   as a substitute for this.
3. **Duplicate chunk results need normalization.** Stage R deduplicates file
   candidates. The S search inherited by T does not; the gateway rejects duplicate
   turns. Repeated hits from one long file could turn a useful search into an
   error. This is a code-path finding, not an observed live duplicate-chunk
   failure. Fix/test it before expanding overlap and long-file coverage [C2–C4].
4. **Correction metadata is not carried end to end in the current T interface.**
   `Archive` supports correction links, but T `_messages` does not populate them
   and the U output projection omits version/correction fields. The Casey trial
   demonstrates interpretation of correction text, not a complete correction-graph
   service. Return both relevant records; only assert a verified correction edge
   when its basis is known.
5. **No in-tool lexical fallback.** Separate FTS is useful but not wired into
   current hosted lookup. Also, first-12-token OR search is not an exact-phrase
   endpoint. Generalise deliberately if word-search behaviour is required.
6. **Temporal growth still matters.** `files()` lists at most 100 without
   pagination. Upload-before-mapping crash reconciliation can miss an older file
   after that point. One owner's long-running archive can hit this; add a
   pagination/reconciliation test without adding infrastructure [C2].
7. **Offline recovery is not implemented by reconnecting.** There is no general
   capture outbox/coverage ledger, and hosted T indexing enforces its fixed turn
   sequence. Add those local states only after the capture contract is agreed.
8. **Retention/deletion are unfinished.** The pilot intentionally expires its
   index. Choose an explicit durable-use policy and deletion propagation before
   real data, rather than treating pilot expiry as a permanent-memory guarantee.
9. **Test portability needs cleanup.** Some “offline” tests depend on private
   transcripts and Git objects. Inject hermetic synthetic receipts into unit
   tests; keep frozen live-evidence checks in a separately named environment suite.

A ChatGPT model upgrade does not itself require changing the canonical archive
or re-embedding it. Treat embedding/index configuration changes and platform/API
compatibility changes as separate events that may require reindexing or adapter
work. Re-evaluate tool routing after a Chat model change.

None of these gaps calls for rewriting the core concept. Avoid relaxing the
synthetic safeguards in place; implement an explicitly separate authorised
personal-source path after its acceptance criteria pass.

[C2]: SOURCES.md#code
[E7]: SOURCES.md#e7
[E8]: SOURCES.md#e8
[E9]: SOURCES.md#e9
[O7]: SOURCES.md#o7
[O8]: SOURCES.md#o8
[O11]: SOURCES.md#o11
