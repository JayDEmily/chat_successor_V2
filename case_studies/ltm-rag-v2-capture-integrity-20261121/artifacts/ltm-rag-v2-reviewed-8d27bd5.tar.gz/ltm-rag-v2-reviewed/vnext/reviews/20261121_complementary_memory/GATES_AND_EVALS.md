# Deterministic gates and longitudinal evaluations

**Draft evaluation plan, 21 November 2026. No new native run is claimed.**
The goal is not to discover a universal compression threshold. It is to learn
when this extra evidence makes **your** conversations more useful, while keeping
the record trustworthy.

## 1. The distinction

**Gates** protect things engineering can check: source identity, bytes, roles,
access, replay, deletion, bounded work and correct failure states.
A failed integrity gate blocks the affected deployment or source release.

**Evaluations** measure variable model behaviour: whether to retrieve, how to
search, which evidence to use, when to clarify, whether the answer is helpful, and
how naturally it reads. A native evaluation can become a release checkpoint,
but that does not make the underlying behaviour deterministic.

A green unit suite is necessary evidence about code. It is not a green evaluation
of ChatGPT. Conversely, a beautiful answer does not excuse corrupt provenance.

## 2. Compact gate set

| Gate | Required invariant and fault test | Status in this snapshot |
|---|---|---|
| G1 Source admission/access | Wrong/revoked principal or source never releases private text; read permission does not permit writes. | Synthetic admission tested; authenticated personal source still proposed. |
| G2 Fidelity/roles | Exact Unicode, role and source version survive save/index/fetch. Mutate text/hash/role/file mapping: reject affected evidence. UI footer or partial stream cannot be certified as complete source. | Strong synthetic tests; S failed, T reconciled five replies. |
| G3 Chronology/identity | Replay preserves IDs and first ingestion; unknown send time stays NULL; timezone-aware values only; clock times do not replace branch order. | Existing chronology tests. No general off-PC recovery proof. |
| G4 Corrections/branches | Preserve superseded text; no cross-branch neighbour/correction leakage; versioned edits/regenerations remain distinct. | Archive checks exist; hosted T metadata/lineage remains incomplete. |
| G5 Capture/outbox/index | Commit source before index; retry crash points without duplicate identities or uploads; distinguish captured and searchable; reconcile beyond first provider page. | Fixed-pilot replay tests exist; general outbox, coverage and pagination need work. |
| G6 Search contract | Compact/long dictation queries accepted within documented bounds; oversize returns actionable error; duplicate chunk hits deduplicate; output truncation declared. | Repaired native validator tested in origin environment; duplicate/long-result handling needs focused tests. |
| G7 Failure/cost bounds | Timeout, auth failure, quota, missing index and no match are distinct; bounded retries; no false “saved/found” acknowledgement. | Some bounded quota/outage coverage; general states not implemented. |
| G8 Prompt/data separation | Source text cannot change server scope, execute SQL or trigger writes; queries parameterized; credentials/log content minimized. | Partial existing boundaries. Model obedience to injected prose still needs adversarial native evals. |
| G9 Retention/revocation | Tombstoned records never returned/re-ingested; remote cleanup tracked; backups and restore preserve deletion decisions. | Not established for a real archive. |
| G10 Restore/operation | Restore source+mapping coherently; fail closed on corruption; single-worker start/restart safe; recovery does not invent capture coverage. | Bounded supervisor/restart proof, not unattended boot or full recovery. |

Source mapping: [C1–C6, E2, E7–E9](SOURCES.md).
These are proposed acceptance criteria, not claims that ten gates already pass.
Do not add a “correctly answer every ambiguity” unit gate using hard-coded topic
names: it hides the very behaviour the native evaluations need to expose.

## 3. Evaluation dimensions

Use the 24-case [draft plan](evals/plan.json) as a compact regression menu.
It includes early context, personal-context conflicts, archive-only originals,
paraphrase/word search, long dictation, corrections, role attribution, ambiguity,
re-search, long history, outages and prompt injection.

Record separate outcomes:

- **Task completion:** was the requested information supplied? An honest inability
  to quote can be good behaviour yet still fail an exact-recall task.
- **Support/attribution:** can each material historical claim be traced to the
  right source and author? Distinguish reported speech and assistant inference.
- **Quote fidelity:** strict comparison with the original Unicode substring.
  A typography-normalized secondary score may be useful, but never call it
  byte-exact. Do not normalize away meaningful punctuation.
- **Correction accuracy:** did the response use the applicable latest user
  correction while preserving what the original said?
- **Routing:** did a search add needed evidence, or did it interrupt a sufficient
  recent/general answer? “History question” does not automatically mean “external
  lookup required” when an original is already available.
- **Re-search value:** new relevant evidence, corrected interpretation or a
  justified stop—not the number of calls.
- **Honest limitation:** no claims of complete coverage, successful current reads
  or verbatim recovery without evidence.
- **Experience:** owner-rated naturalness/warmth, unwanted citation clutter,
  clarifying questions, visible wait, and interruption of a sounding-board turn.
- **Operating cost:** query count, result bytes/tokens, retry count and measured
  provider usage where observable. Keep an unknown cost NULL, not zero.

Log the displayed model/effort, Chat surface/client, instruction hash, plugin
release, backend commit, corpus hash, index settings and memory configuration.
Record visible native-memory Sources if offered, but do not treat the absence
of a displayed source as proof that native memory was unused [O1].

Do not ask the model to reveal hidden chain-of-thought or assign causal percentages
to its own answer. Behaviour, sources and controlled comparisons are enough.

## 4. Clean added-value experiment before more token stuffing

**Experiment A: new archive-only evidence.**

**Prerequisite:** register a separate synthetic-corpus/index binding and adapt
the fixed five-turn T gateway in a new experimental path. Its current source
IDs, receipt hashes and quota are deliberately frozen; the 12-episode plan
cannot run against it unchanged. Preserve those old trials rather than weakening
their guards or resetting their exhausted budgets.

Create 12 new fictional episodes locally, with random, unguessable wording/code
markers, different topic descriptions and later corrections. Keep their original
bytes and source hashes outside ChatGPT. Include at least 40 plausible distractor
records so returning five records cannot mean returning the whole corpus. This
is a retrieval-discrimination fixture, not a scalability test.

Do not reuse Ryan/Nimbus or the published expected answers. Do not attach the
golden answers or evaluation folder to a Project. A fresh Project chat is not a
blank memory boundary; same-project chats can supply context [O2].

Suggested arms:

| Arm | Meaning |
|---|---|
| A: native only | Archive tool disconnected/unavailable by controlled configuration; native memory settings otherwise unchanged. |
| B: sham/no results | Same discoverable tool returns a clearly recorded experimental empty result. Preserves the old long-history control. |
| C: archive on | Same current prompt/instructions; authorised source records available; tool calls and returned source identities traced. |
| D: explicit source supplied | Optional diagnostic: deliberately give the original excerpt, to separate retrieval problems from synthesis problems. |

Arm D is not the normal user experience. A/B/C are distinct; do not call B “tool
off.” Do not pretend a simulated empty result is a real network outage.

**Avoid contamination:** for a shared episode, run all OFF/no-result probes before
any ON response exposes its answer, and acknowledge the fixed-order limitation.
Alternatively counterbalance conditions across matched, disjoint new episode
sets and repeat with fresh random markers. Never run a successful ON response
and then call the same-account OFF response a clean unseen baseline. Keep
ground-truth and withheld corrections private.

Unpersonalized Temporary Chat currently disables plugins; personalized Temporary
Chat can use existing memory/plugins [O14]. It is therefore not a drop-in way to
have both a guaranteed blank memory baseline and the connected tool. Verify any
proposed test configuration instead of assuming it isolates context.

**Primary outcome:** exact-source task completion with correct attribution and no
unsupported additions. **Secondary outcomes:** correction use, helpfulness,
unnecessary search on controls, latency and cost.

This demonstrates added value when source wording was **never supplied to the
target chat**, not that ChatGPT underwent a specific compression process. If a
baseline supplies a truly hidden random string, investigate leakage before
counting anything as impressive recall.

## 5. Long-history and three-channel comparisons

**Experiment B: continuity in realistic long threads.**

Keep the existing 50,237-token result unchanged. Build new matched prefixes,
vary where facts and corrections appear, and use realistic mixed dictation
instead of only repetitive filler. Freeze prompts and source digests first.
Record cumulative submitted tokens separately from active context, which remains
unobserved unless the platform supplies reliable evidence.

Start with a manageable short/medium/approximately-50k set. Go toward 100k only if
the earlier result leaves a concrete question unanswered. Do not spend tokens to
force a preferred failure. Repeat independent scenarios and counterbalance
conditions without leaking the answers between them. Use a true tool-disabled
control as well as the discoverable/no-results arm where feasible.

A result “both succeeded” is valid. A result “ON succeeded, OFF failed” supports
incremental task performance under the recorded conditions, not a discovered
compaction threshold.

**Experiment C: coexistence, not source competition.**

Keep the owner's normal personal memory enabled for the main experiential run.
Use controlled synthetic conflicts: a stale preference, a fresh correction, an
assistant suggestion that was not accepted, and the same record surfaced through
more than one channel. Evaluate reconciliation and absence of double-counting.

Where settings permit and the owner deliberately agrees, a separate isolation
run can compare native continuity with and without the external archive. Record
settings before changing them; some memory-setting changes affect stored state.
Do not erase or toggle the owner's real memories just to obtain a cleaner score.
No native-memory toggle is necessary for the archive-only experiment.

## 6. Practical cadence and stopping rules

1. **Before implementation changes:** run affected deterministic tests; preserve
   historical fixtures and reports. Keep hermetic unit tests separate from
   owner-environment evidence checks.
2. **Next milestone:** the passive capture/outage experiment in
   [OFFLINE_CAPTURE_AND_RECOVERY.md](OFFLINE_CAPTURE_AND_RECOVERY.md).
3. **First native quality tranche:** 12 unseen archive-only episodes plus
   12 matched recent/unrelated/ambiguous controls. Freeze the plan and a modest
   call/time/spend cap; do not tune on the holdout. The 24-case matrix is a
   coverage menu, not proof that these newly generated episodes already exist.
4. **Weekly personal review, if authorised:** sample a few useful/annoying
   episodes and one failure. Keep private content local; retain a content-minimized
   summary in Git. Do not log every personal turn into a public evaluation file.
5. **On model, instruction, plugin description, chunking or capture changes:**
   repeat a small sentinel set and the affected dimensions. New model quality
   need not improve monotonically.
6. **Stop/pause:** any source corruption, private-source leak, falsely certified
   recovered original or fabricated successful read warrants investigation.
   Routine ranking misses and style weaknesses go into the next eval tranche.
7. **Promote conservatively:** zero observed critical failures, all applicable
   engineering gates passed, and an owner-approved practical gain without
   unacceptable latency/friction. This is a small personal MVP decision, not
   certification of population reliability.

The prior 90% initiation / at-most-10% unnecessary-search targets are useful
aspirations, not established rates. Ten successes out of ten have a two-sided
Wilson 95% lower bound of about 72.2%; zero out of ten has an upper bound about
27.8%. Small, clustered same-account trials also are not independent population
samples. Report counts and uncertainty, and do not chase a statistically
impressive number instead of an actually helpful system.

## 7. Supplied offline evaluation utility

`evals/run_template.json` contains **NOT_RUN** rows, not invented results.
Copy it to a private location and fill only observed fields after execution and
source review. `scripts/summarize_evals.py` validates statuses/types/identity and
summarises per-metric counts, missingness, Wilson intervals and observed latency.
It does not perform semantic grading, run ChatGPT, measure hidden model weights,
or automatically approve deployment.

Keep different arms, model/settings or corpus versions in separate ledgers.
Unknown is `null`; unexecuted, blocked and inconclusive cases remain visible.
The scorer refuses mismatched plan hashes, duplicate case IDs and scored
unexecuted rows. Missing observations are never silently counted as passes.

```bash
R=vnext/reviews/20261121_complementary_memory
python3 "$R/scripts/summarize_evals.py" \
  --plan "$R/evals/plan.json" --run /private/path/run.json \
  --output /private/path/summary.json
```

A full causal comparison still needs episode-level review and matched-arm
analysis. The small utility intentionally does not pretend that one aggregate
percentage measures “how much the archive contributed.”

[O1]: SOURCES.md#o1
[O2]: SOURCES.md#o2
[O14]: SOURCES.md#o14
