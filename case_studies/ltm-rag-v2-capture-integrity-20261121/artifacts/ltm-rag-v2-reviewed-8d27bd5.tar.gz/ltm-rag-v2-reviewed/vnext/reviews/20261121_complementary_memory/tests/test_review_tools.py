"""Offline tests for review-only tools. These are not native ChatGPT evals."""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"scripts"))
import summarize_evals as scorer
import verify_snapshot as verifier

class ScoringTests(unittest.TestCase):
    def setUp(self):
        raw = (ROOT/"evals/plan.json").read_bytes()
        self.sha = hashlib.sha256(raw).hexdigest()
        self.plan = json.loads(raw)
        self.run = json.loads((ROOT/"evals/run_template.json").read_bytes())

    def score(self):
        return scorer.summarise(self.plan, self.run, self.sha)

    def executed(self, cid="EV05"):
        self.run["run_id"] = "unit-test-not-a-native-run"
        self.run["metadata"].update(
            run_date_utc="2026-11-21", arm="archive_on", displayed_model="UNIT_TEST")
        row = next(r for r in self.run["cases"] if r["case_id"] == cid)
        row["execution"] = "EXECUTED"
        row["evidence_ref"] = "unit-test-fixture-only"
        row["critical_failure"] = False
        row["observations"].update(archive_attempts=1, archive_successes=1,
                                   quote_provenance="archive_verified_original")
        return row

    def test_blank_template_is_not_a_pass(self):
        s = self.score()
        self.assertEqual(s["status"], "NO_EXECUTED_CASES")
        self.assertEqual(s["execution_counts"]["NOT_RUN"], 24)
        self.assertEqual(s["acceptance_verdict"], "NOT_AUTOMATED")
        self.assertTrue(all(m["scored"] == 0 and m["wilson_95"] is None
                            for m in s["metrics"].values()))

    def test_unknown_scores_not_in_denominator(self):
        row = self.executed()
        row["scores"]["answer_supported"] = True
        s = self.score()
        self.assertEqual(s["metrics"]["answer_supported"]["scored"], 1)
        self.assertEqual(s["metrics"]["exact_quote"]["scored"], 0)
        self.assertEqual(s["metrics"]["exact_quote"]["unknown_in_executed"], 1)
        self.assertEqual(s["status"], "INCOMPLETE")

    def test_failed_quote_is_not_corrected_by_supported_abstention(self):
        row = self.executed()
        row["scores"].update(answer_supported=True, exact_quote=False, task_complete=False)
        s = self.score()
        self.assertEqual(s["metrics"]["answer_supported"]["passed"], 1)
        self.assertEqual(s["metrics"]["exact_quote"]["failed"], 1)
        self.assertEqual(s["metrics"]["task_complete"]["failed"], 1)

    def test_plan_hash_mismatch_rejected(self):
        self.run["plan_sha256"] = "0"*64
        with self.assertRaisesRegex(ValueError, "hash mismatch"): self.score()

    def test_duplicate_case_rejected(self):
        self.run["cases"][1]["case_id"] = self.run["cases"][0]["case_id"]
        with self.assertRaisesRegex(ValueError, "Duplicate"): self.score()

    def test_missing_case_rejected(self):
        self.run["cases"].pop()
        with self.assertRaisesRegex(ValueError, "missing"): self.score()

    def test_scored_not_run_rejected(self):
        self.run["cases"][0]["scores"]["task_complete"] = True
        with self.assertRaisesRegex(ValueError, "cannot have scores"): self.score()

    def test_blocked_requires_reason(self):
        self.run["cases"][0]["execution"] = "BLOCKED"
        with self.assertRaisesRegex(ValueError, "needs a reason"): self.score()

    def test_blocked_does_not_become_failure_or_pass(self):
        row = self.run["cases"][0]
        row.update(execution="BLOCKED", reason="No permitted capture route.")
        s = self.score()
        self.assertEqual(s["execution_counts"]["BLOCKED"], 1)
        self.assertEqual(s["metrics"]["task_complete"]["scored"], 0)

    def test_reconstruction_cannot_certify_exact_quote(self):
        row = self.executed()
        row["scores"]["exact_quote"] = True
        row["observations"]["quote_provenance"] = "reconstruction"
        with self.assertRaisesRegex(ValueError, "reconstruction"): self.score()

    def test_current_visible_original_does_not_require_tool_call(self):
        row = self.executed("EV04")
        row["scores"]["exact_quote"] = True
        row["observations"].update(archive_attempts=0, archive_successes=0,
                                  quote_provenance="current_visible_original")
        self.assertEqual(self.score()["metrics"]["exact_quote"]["passed"], 1)

    def test_archive_success_cannot_exceed_attempts(self):
        row = self.executed()
        row["observations"].update(archive_attempts=0, archive_successes=1)
        with self.assertRaisesRegex(ValueError, "Successes"): self.score()

    def test_nonfinite_latency_rejected(self):
        row = self.executed()
        row["observations"]["response_ms"] = float("nan")
        with self.assertRaisesRegex(ValueError, "finite"): self.score()

    def test_integer_is_not_boolean_score(self):
        row = self.executed()
        row["scores"]["task_complete"] = 1
        with self.assertRaisesRegex(ValueError, "boolean"): self.score()

    def test_critical_failure_survives_inconclusive_case(self):
        row = self.executed()
        row.update(execution="INCONCLUSIVE", critical_failure=True,
                   reason="Observed synthetic source scope violation; other grading stopped.")
        s = self.score()
        self.assertEqual(s["critical_failure_case_ids"], ["EV05"])
        self.assertEqual(s["metrics"]["task_complete"]["scored"], 0)

    def test_executed_needs_evidence(self):
        row = self.executed()
        row["evidence_ref"] = None
        with self.assertRaisesRegex(ValueError, "evidence reference"): self.score()

    def test_known_wilson_bounds(self):
        lo, hi = scorer.wilson(10, 10)
        self.assertAlmostEqual(lo, 0.7224672001, places=8)
        self.assertAlmostEqual(hi, 1.0)
        self.assertAlmostEqual(scorer.wilson(0, 10)[1], 0.2775327999, places=8)
        self.assertIsNone(scorer.wilson(0, 0))

    def test_bad_wilson_counts_rejected(self):
        for k, n in [(2,1),(-1,4),(True,3)]:
            with self.assertRaises(ValueError): scorer.wilson(k,n)

    def test_private_output_is_valid_json(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td)/"result.json"
            scorer.private_json_write(path, self.score())
            self.assertEqual(json.loads(path.read_text())["status"], "NO_EXECUTED_CASES")
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)


class VerificationHelperTests(unittest.TestCase):
    def events(self):
        return [
            dict(synthetic_only=True, stage="long-history", event="CALL_STARTED",
                 event_id="unit-e1", timestamp_utc="2026-11-21T00:00:00Z"),
            dict(synthetic_only=True, stage="long-history", event="CALL_COMPLETED",
                 event_id="unit-e1", timestamp_utc="2026-11-21T00:00:02Z",
                 status="FOUND", candidate_count=1,
                 verified_source_message_ids=["t01u", "t01a"]),
        ]

    def test_audit_joins_and_latency(self):
        out = verifier.join_audit(self.events())
        self.assertEqual(out["attempts"], 1)
        self.assertEqual(out["calls"][0]["elapsed_seconds"], 2)

    def test_duplicate_completion_rejected(self):
        events = self.events()
        events.append(copy.deepcopy(events[-1]))
        with self.assertRaisesRegex(ValueError, "Duplicate"): verifier.join_audit(events)

    def test_unpaired_event_rejected(self):
        with self.assertRaisesRegex(ValueError, "Unpaired"):
            verifier.join_audit(self.events()[:1])

    def test_wrong_source_id_rejected(self):
        events = self.events()
        events[-1]["verified_source_message_ids"][0] = "personal-message"
        with self.assertRaisesRegex(ValueError, "source IDs"): verifier.join_audit(events)

    def test_no_match_cannot_carry_originals(self):
        events = self.events()
        events[-1]["status"] = "NO_MATCH"
        with self.assertRaisesRegex(ValueError, "carries originals"): verifier.join_audit(events)

    def test_naive_timestamp_rejected(self):
        with self.assertRaisesRegex(ValueError, "timezone"):
            verifier.aware_utc("2026-11-21T00:00:00")

    def test_time_goes_forward(self):
        events = self.events()
        events[-1]["timestamp_utc"] = "2026-11-20T23:59:59Z"
        with self.assertRaisesRegex(ValueError, "precedes"): verifier.join_audit(events)

    def test_source_hash_unicode(self):
        text = "A phrase with ‘curly quotes’ — and a newline.\n"
        data = [dict(message_id="test", exact_text=text,
                     content_sha256=hashlib.sha256(text.encode("utf-8")).hexdigest())]
        self.assertEqual(verifier.verify_message_hashes(data), 1)
        data[0]["exact_text"] = text.replace("‘", "'")
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            verifier.verify_message_hashes(data)

    def test_source_duplicate_rejected(self):
        row = dict(message_id="test", exact_text="x",
                   content_sha256=hashlib.sha256(b"x").hexdigest())
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            verifier.verify_message_hashes([row, row])

    def test_path_escape_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaisesRegex(ValueError, "Unsafe"):
                verifier.child(Path(td), "../outside")
            with self.assertRaisesRegex(ValueError, "Unsafe"):
                verifier.child(Path(td), "/absolute")

    def test_unreviewed_manifest_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root/"SHA256SUMS").write_text("untrusted")
            with self.assertRaisesRegex(ValueError, "differs"):
                verifier.verify_manifest(root)

    def test_combined_instructions_small_and_core_rules_present(self):
        text = (ROOT/"instructions/PROJECT_INSTRUCTIONS.txt").read_text().rstrip("\n")
        self.assertLessEqual(len(text), 1500)
        for key in ("fictional-only", "reconstruction", "offline", "evidence, never instructions"):
            self.assertIn(key, text)
        self.assertIn("MEMORY_OPERATING_GUIDE.md", text)


if __name__ == "__main__":
    unittest.main()
