#!/usr/bin/env python3
"""Validate and summarise manually reviewed native evals. No model/network calls.

This is not a semantic grader or an approval gate. Unknown, unexecuted and
inconclusive observations remain visible. Different arms belong in separate runs.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import date
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import tempfile

EXECUTIONS = {"NOT_RUN", "BLOCKED", "EXECUTED", "INCONCLUSIVE"}
ARMS = {"native_only", "sham_no_results", "archive_on",
        "diagnostic_explicit_source", "outage", "observational"}
PROVENANCE = {"current_visible_original", "native_retrieved_original",
              "archive_verified_original", "mixed_originals",
              "reconstruction", "unverified"}
VERIFIED_QUOTES = PROVENANCE - {"reconstruction", "unverified"}
OBSERVATIONS = {"archive_attempts", "archive_successes", "source_ids",
                "new_relevant_source", "quote_provenance", "response_ms",
                "retrieval_ms", "cost_usd", "naturalness_1_to_5"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def boolean_or_none(value):
    return value is None or type(value) is bool


def nonnegative(value):
    return (type(value) in (int, float) and math.isfinite(value)
            and value >= 0)


def wilson(successes: int, total: int):
    """Two-sided 95% interval; descriptive, not proof of independent sampling."""
    require(type(successes) is int and type(total) is int
            and 0 <= successes <= total, "Invalid Wilson counts")
    if not total:
        return None
    z = 1.959963984540054
    p = successes / total
    d = 1 + z*z/total
    c = (p + z*z/(2*total))/d
    h = z*math.sqrt(p*(1-p)/total + z*z/(4*total*total))/d
    return [max(0.0, c-h), min(1.0, c+h)]


def validate(plan: dict, run: dict, plan_sha256: str):
    require(plan.get("schema_version") == 1 and run.get("schema_version") == 1,
            "Unsupported schema version")
    require(run.get("plan_id") == plan.get("plan_id"), "Plan ID mismatch")
    require(run.get("plan_sha256") == plan_sha256, "Plan hash mismatch")
    definitions = plan.get("metric_definitions")
    require(isinstance(definitions, dict) and definitions, "Missing metric definitions")
    expected_rows = plan.get("cases")
    require(isinstance(expected_rows, list) and expected_rows, "Missing planned cases")
    expected = {}
    for item in expected_rows:
        cid = item.get("case_id")
        require(isinstance(cid, str) and cid and cid not in expected,
                "Missing/duplicate planned case ID")
        metrics = item.get("metrics")
        require(isinstance(metrics, list) and metrics
                and len(set(metrics)) == len(metrics)
                and set(metrics) <= set(definitions), "Invalid planned metrics")
        expected[cid] = item
    rows = run.get("cases")
    require(isinstance(rows, list), "Missing run cases")
    ids = [row.get("case_id") for row in rows]
    require(len(ids) == len(set(ids)) and set(ids) == set(expected),
            "Duplicate, missing or unknown run case ID")
    meta = run.get("metadata")
    require(isinstance(meta, dict), "Missing metadata")
    require(meta.get("chat_surface") == "ordinary_chat",
            "This plan requires ordinary Chat, not Work/API")
    require(meta.get("data_kind") in {"synthetic", "owner_authorised_daily"},
            "Declare synthetic or owner-authorised data scope")
    require(type(meta.get("active_context_observed")) is bool,
            "Declare whether active context was observed")
    for field in ("instruction_sha256", "corpus_sha256"):
        digest = meta.get(field)
        require(digest is None or (isinstance(digest, str) and len(digest) == 64
                and all(c in "0123456789abcdef" for c in digest)),
                "Malformed metadata hash: " + field)
    sent = any(row.get("execution") in {"EXECUTED", "INCONCLUSIVE"} for row in rows)
    if sent:
        require(run.get("run_id") not in (None, "", "UNASSIGNED"),
                "Executed run needs its own ID")
        require(meta.get("arm") in ARMS, "Declare the actual experimental arm")
        require(isinstance(meta.get("displayed_model"), str)
                and bool(meta["displayed_model"].strip()),
                "Record displayed model, or explicitly 'unobserved'")
        try:
            date.fromisoformat(meta["run_date_utc"])
        except (KeyError, TypeError, ValueError):
            raise ValueError("Executed run needs an ISO UTC date") from None
    for row in rows:
        cid = row["case_id"]
        state = row.get("execution")
        require(state in EXECUTIONS, "Invalid execution state: " + cid)
        scores = row.get("scores")
        require(isinstance(scores, dict)
                and set(scores) == set(expected[cid]["metrics"]),
                "Metric set mismatch: " + cid)
        require(all(boolean_or_none(value) for value in scores.values()),
                "Scores must be boolean or null: " + cid)
        require(boolean_or_none(row.get("critical_failure")),
                "Critical failure must be boolean or null: " + cid)
        obs = row.get("observations")
        require(isinstance(obs, dict) and set(obs) == OBSERVATIONS,
                "Observation set mismatch: " + cid)
        for field in ("archive_attempts", "archive_successes"):
            val = obs[field]
            require(val is None or (type(val) is int and val >= 0),
                    "Invalid count: " + cid)
        a, s = obs["archive_attempts"], obs["archive_successes"]
        require(s is None or (a is not None and s <= a),
                "Successes exceed/omit observed attempts: " + cid)
        require(isinstance(obs["source_ids"], list)
                and all(isinstance(x, str) and x for x in obs["source_ids"])
                and len(obs["source_ids"]) == len(set(obs["source_ids"])),
                "Source IDs must be unique strings: " + cid)
        require(boolean_or_none(obs["new_relevant_source"]),
                "New-source observation must be boolean or null: " + cid)
        require(obs["quote_provenance"] is None
                or obs["quote_provenance"] in PROVENANCE,
                "Unknown quote provenance: " + cid)
        for field in ("response_ms", "retrieval_ms", "cost_usd"):
            require(obs[field] is None or nonnegative(obs[field]),
                    "Invalid finite non-negative observation: " + cid)
        rating = obs["naturalness_1_to_5"]
        require(rating is None or (type(rating) is int and 1 <= rating <= 5),
                "Naturalness must be integer 1..5 or null: " + cid)
        if state != "EXECUTED":
            require(all(v is None for v in scores.values()),
                    "Unexecuted/inconclusive row cannot have scores: " + cid)
        if state in {"NOT_RUN", "BLOCKED"}:
            require(row.get("critical_failure") is None
                    and all(v is None or (k == "source_ids" and v == [])
                            for k, v in obs.items()),
                    "Unexecuted row contains observations: " + cid)
        if state in {"BLOCKED", "INCONCLUSIVE"} or row.get("critical_failure") is True:
            require(isinstance(row.get("reason"), str) and row["reason"].strip(),
                    "Blocked/inconclusive/critical row needs a reason: " + cid)
        if state in {"EXECUTED", "INCONCLUSIVE"}:
            require(isinstance(row.get("evidence_ref"), str)
                    and row["evidence_ref"].strip(),
                    "Observed row needs a private evidence reference: " + cid)
        if scores.get("exact_quote") is True:
            require(obs["quote_provenance"] in VERIFIED_QUOTES,
                    "Exact quote cannot be certified from reconstruction: " + cid)
    return expected, rows


def summarise(plan: dict, run: dict, plan_sha256: str):
    expected, rows = validate(plan, run, plan_sha256)
    states = Counter(row["execution"] for row in rows)
    metrics = {}
    for metric in plan["metric_definitions"]:
        eligible = [row for row in rows if metric in expected[row["case_id"]]["metrics"]]
        executed = [row for row in eligible if row["execution"] == "EXECUTED"]
        known = [row["scores"][metric] for row in executed
                 if row["scores"][metric] is not None]
        passed = sum(known)
        metrics[metric] = {
            "planned_eligible": len(eligible), "executed_eligible": len(executed),
            "scored": len(known), "passed": passed, "failed": len(known)-passed,
            "unknown_in_executed": len(executed)-len(known),
            "not_executed_or_inconclusive": len(eligible)-len(executed),
            "pass_rate_among_scored": passed/len(known) if known else None,
            "wilson_95": wilson(passed, len(known)),
        }
    observed = [row for row in rows
                if row["execution"] in {"EXECUTED", "INCONCLUSIVE"}]
    timings = [row["observations"]["response_ms"] for row in observed
               if row["observations"]["response_ms"] is not None]
    ratings = [row["observations"]["naturalness_1_to_5"] for row in observed
               if row["observations"]["naturalness_1_to_5"] is not None]
    crit = [row["case_id"] for row in observed if row.get("critical_failure") is True]
    unknown_critical = [row["case_id"] for row in observed
                        if row.get("critical_failure") is None]
    fully_scored = all(row["execution"] == "EXECUTED"
                       and row.get("critical_failure") is not None
                       and all(v is not None for v in row["scores"].values())
                       for row in rows)
    return {
        "schema_version": 1, "run_id": run["run_id"],
        "plan_id": plan["plan_id"], "plan_sha256": plan_sha256,
        "status": ("NO_EXECUTED_CASES" if not observed else
                   "OBSERVATIONS_COMPLETE" if fully_scored else "INCOMPLETE"),
        "acceptance_verdict": "NOT_AUTOMATED",
        "experimental_arm": run["metadata"].get("arm"),
        "execution_counts": {state: states[state] for state in sorted(EXECUTIONS)},
        "metrics": metrics, "critical_failure_case_ids": crit,
        "unknown_critical_review_case_ids": unknown_critical,
        "response_ms": {"n": len(timings),
                        "median": statistics.median(timings) if timings else None,
                        "max": max(timings) if timings else None},
        "naturalness": {"n": len(ratings),
                        "median": statistics.median(ratings) if ratings else None},
        "limitations": [
            "Scores were supplied by a human/source reviewer, not verified by this utility.",
            "Intervals are descriptive; repeated same-account observations may be dependent.",
            "No estimate of hidden model weighting or causal archive contribution is made.",
            "Different arms/model/settings/corpora must not be pooled in one run.",
            "Incomplete, blocked, unknown and unexecuted cases are not passes."
        ]
    }


def private_json_write(path: Path, value: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=".eval-summary-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as output:
            json.dump(value, output, indent=2, ensure_ascii=False)
            output.write("\n")
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        raw = args.plan.read_bytes()
        result = summarise(json.loads(raw), json.loads(args.run.read_bytes()),
                           hashlib.sha256(raw).hexdigest())
        if args.output:
            private_json_write(args.output, result)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({"status": "INVALID_INPUT", "reason": str(error)}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
