# Instructions setup: small core, optional longer guide

The supplied text is a **template for review**, not a change to your account.
No instructions were installed and no app/skill metadata was edited.

## Minimal setup

1. Keep the project private to your own account.
2. Review `instructions/PROJECT_INSTRUCTIONS.txt`. It combines the sounding-board
   style with the essential evidence/failure rules.
3. Paste that block into the project's instruction field, or merge just
   `instructions/MEMORY_ADDON.txt` into your existing style instructions.
4. Attach **only** `instructions/MEMORY_OPERATING_GUIDE.md`, retaining its filename.
5. Test a new ordinary Chat inside the intended project: a recent follow-up, a
   source-dependent synthetic question, a “look again” request and an outage.
   Do not assume a setup success means the MD file is always loaded.

The combined block is **1426 characters excluding the final newline**.
The add-on is **703 characters excluding the final newline**.
The current official global-custom-instructions guide documents 1,500 characters
for Free/Go and 5,000 for the listed paid plans [O5]; that is **not evidence of an
identical project-instructions limit**. Check the actual field. This deliberately
small block leaves room to develop your conversational style.

## Which native memory setting?

For your preferred all-my-account continuity, start from your existing private
project/default-memory configuration if it is available and intended. The
official Projects guide distinguishes default and project-only modes: project-only
does not use outside saved memories/chats, but can still use chats within that
project. Project instructions override global custom instructions in the project
[O2]. Include the important tone guidance in the project itself.

The archive's source scope is separate from that setting. A project-only chat
with an archive connector can still retrieve whatever **the connector is
authorised to expose**; enforce archive boundaries in the backend if project
isolation is desired. Do not assume the product toggle scopes your SQLite files.

## What belongs where?

| Place | Content |
|---|---|
| Project instruction box | Preferred conversational style and the few indispensable source/offline rules. |
| Attached MD guide | Examples and richer handling of corrections, attribution, re-search and uncertainty. |
| Tool metadata/skill | The tool's actual purpose, arguments, declared source scope, when it is useful and its real failure states. |
| Backend | Credentials/access checks, source integrity, idempotency, bounds, logging, coverage and retention. |
| Private eval workspace | Ground truth, test scripts, traces and score ledgers. Never attach these to the conversation being tested. |

A one-line “read the MD file” instruction alone is too fragile for the critical
rules. Nor does a project file gain system-level authority merely by its filename.

## Tool guidance is deliberately not deployed

`instructions/ARCHIVE_TOOL_GUIDANCE.template.md` is for a later authorised general
archive. The existing installed `fictional-diary-recall/SKILL.md` must remain
fictional-only until source admission and authentication have been separately
implemented and accepted. Do not paste personal-history scope into its description
as a shortcut.

No need to create another agent/personality for the archive. Tool results should
supply relevant evidence. The main Chat remains the one conversational partner.

## Small acceptance check after changing instructions

- Does it still listen naturally rather than narrating retrieval?
- Can it use current context without unnecessary calls?
- Does a genuine original-wording task obtain/identify actual source evidence?
- Does it distinguish your correction from its own earlier suggestion?
- Does “have another look” produce a useful revised search or an honest stop?
- Can it continue through an outage without pretending to save/verify?
- Does it avoid sending real history to a fictional-only tool?

Log the instruction hash and plugin version with these outcomes. A failure to
load the longer guide is an eval observation, not something to cover up by
claiming the rules were surely applied.

[O2]: SOURCES.md#o2
[O5]: SOURCES.md#o5
