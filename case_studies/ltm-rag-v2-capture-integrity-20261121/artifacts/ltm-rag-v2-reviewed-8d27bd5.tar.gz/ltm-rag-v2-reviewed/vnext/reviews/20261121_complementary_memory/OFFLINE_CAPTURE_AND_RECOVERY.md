# Capture, PC-off operation and honest recovery

**Design proposal, not an installed capture feature.** The brief explicitly allows
gaps. That is a sound trade-off for a one-person system—as long as uncertainty is
not converted into false originals.

## 1. Three different records

| Class | What can be claimed | How to retain it |
|---|---|---|
| Original-source capture/import | Exact relative to the identified source representation: exported text, or verified UI-rendered text. | Immutable source record; role, identity/version/branch, original bytes/hash and capture provenance. |
| Directly observed but unverified copy | An observer copied visible text, but independent reconciliation is incomplete. | Quarantine/staging with its actual observation time; no “verified original” label yet. |
| Model reconstruction / recollection | A model supplied its best available account of earlier conversation. | Separate derived record with `fidelity=model_reconstruction`, unknown original timestamps/IDs, known authoring model/run where available. |

A faithful text record is not necessarily a faithful **audio** record. For your
speech-to-text workflow, “verbatim” normally means the submitted transcript,
including transcription mistakes, not independently established spoken words.
A later correction is a new record, not permission to silently repair the old
transcript.

A content hash protects fidelity relative to captured bytes. It cannot prove
that those bytes were originally yours, that a timestamp came from the platform,
or that no other messages were missed.

## 2. What a native plugin does not establish

The documented MCP model chooses call arguments; those arguments are not an
automatic copy of the original user message [O8]. The reviewed metadata fields
identify/correlate subject and session, not an exact-message attestation [O16].
No always-on original-transcript delivery contract was established for this
integration.

Consequently:
- a read-only lookup cannot capture every turn merely by being installed;
- no backend request occurs while a powered-off host is unavailable;
- even a successful call need not contain all words from the current turn;
- a missing call does not imply a missing ChatGPT conversation, and a present call
  does not imply complete capture;
- reconnecting cannot discover or backfill every missed message by itself.

OpenAI's plugin security guidance also rules out using broad history fields,
accumulated prior-turn arrays, or full-log reconstruction as an incidental
MCP context-collection mechanism [O11]. Do not create an `all_prior_messages`
parameter or prompt the model to ship its entire remembered history on each
lookup.

A separately consented, user-selected export/import is a clearer source route.
Exports currently support eligible personal plans and contain conversation JSON;
delivery is asynchronous and should not be treated as an automatic live feed
[O13]. A passive local capture companion is only a **candidate experiment**:
confirm its permitted access, selected scope and source fidelity before relying
on it. No such companion is implemented in this handoff.

## 3. What happens when something is off

| Condition | Conversation | Capture/index action | What the answer must not imply |
|---|---|---|---|
| Everything reachable; source captured and indexed | Answer normally; retrieve when useful. | Durable receipt → local commit → async index. | That a high score makes the claim true. |
| SQLite/MCP reachable; hosted search down | Continue; use an implemented lexical fallback if available. | Keep originals and pending index work. | That a semantic search was performed. Current hosted T path has no such fallback. |
| Source captured locally; embedding/index pending | Use current context or local exact/lexical source. | Retry pending index work with a bounded backoff. | “No match” means no original exists. |
| Ubuntu/WSL/PC off | Ordinary Chat can continue; archive cannot be consulted through this host. | No local work runs. A separate device queue exists only if actually implemented. | That the latest turns were saved locally or that verification succeeded. |
| Host restarts | Resume chat; health-check before claiming archive availability. | Reconcile durable local records/outbox; recover explicit source gaps if possible. | “Online” means “caught up.” |
| Missing originals recoverable from authorised source | Treat restored source as source-backed after checking it. | Preserve original identity/order/time where supplied; set new actual ingestion time. | The recovery time was the original send time. |
| Only recollection is available | Work with it as qualified context. | Optional scoped derived note, never an original transcript row. | “Verbatim,” complete coverage, or invented message IDs/timestamps. |
| Neither available | Admit the gap only when relevant. | Keep an unknown/missing interval. | The user never discussed the subject. |

The user should not have to repeat ordinary information for infrastructure
housekeeping. An occasional relevant clarification is legitimate; repeated
“please save this” or “please reconnect” prompts are not the desired workflow.
Host-side retry/timeout controls can bound your service's work, but they cannot
promise an exact ChatGPT UI timeout. Measure perceived delay in a real outage.

## 4. The smallest recovery design worth building

One SQLite database can hold source rows, an indexing outbox and a coverage table.
A single writer/worker is sufficient. No broker or distributed queue is needed.

**Source identity**
- Prefer actual platform/export message IDs and revisions when present.
- Otherwise allocate local receipt IDs, preserving the source locator and explicitly
  weaker provenance.
- Keep branch and sequence independent of timestamps. Do not use “same text” as
  the only deduplication key: two legitimate “yes” messages can differ.
- Replays of the same identity/version must not duplicate rows or refresh original
  ingestion time. Changed text needs a new version or a conflict, never an upsert
  over the old text.

**Transactional local state**
1. Save the raw receipt with a manifest/hash and its actual capture time.
2. Atomically commit accepted message records and their outbox entries.
3. Index deterministic source payloads; persist provider mapping/completion.
4. After a crash, reconcile known uploads before retrying. Acknowledge “captured”
   separately from “searchable.”
5. Maintain coverage **per conversation and branch**, including holes, rather
   than one global “last synced” time. A high-water mark alone cannot prove there
   are no skipped turns below it.

**After a PC-off gap**
1. Check source database integrity and the read service/tunnel.
2. Replay the local outbox. This repairs upload gaps, not uncaptured conversation.
3. If an owner-authorised source adapter/export can access the missed interval,
   ingest that source and verify identities, bytes, roles and order.
4. Compare against the previous coverage inventory; keep unresolved holes explicit.
5. If only a limited, task-relevant recollection exists, allow it to help the
   current conversation. If the owner chooses to retain it, store it as derived
   material through a separately authorised path. The lookup tool remains read-only.
   Retention can be an up-front owner choice rather than an approval on every
   turn; any automatic derived-note path would still be bounded, task-scoped and
   separately labelled. It is not a guaranteed background catch-up hook.
6. Later source recovery may link to or supersede a derived note as evidence,
   while retaining that note's reconstruction label. User approval of a summary
   does not retroactively make it the original wording.

**State labels:** `SOURCE_OBSERVED`, `SOURCE_VERIFIED`, `LOCAL_COMMITTED`,
`INDEX_PENDING`, `SEARCHABLE`, `GAP_UNKNOWN`, `RECONSTRUCTION_ONLY`, `REVOKED`.
These are proposed internal states, not new current API fields.

A useful quiet diagnostic page would show retrieval readiness, last actual
capture, pending index count and known gaps separately. Ordinary answers need
only disclose the limitation that affects the requested claim.

## 5. Highest-value next experiment: passive capture + one outage

**Draft protocol C1; no execution is claimed.** This should precede another giant
context-window test. It needs a new, separately registered synthetic capture
adapter/corpus path: the current S/T classes accept only their frozen five turns.
Do not expand those fixtures in place or claim this handoff implements the adapter.

**Goal:** prove that actual ordinary user input and actual model replies can be
recorded without the sending automation knowing the expected text in advance.

1. Freeze the capture representation and acceptance rules. Use a new synthetic-only,
   owner-selected ordinary Chat conversation. No Work and no API generation.
2. The owner dictates/types **12 ordinary user turns**: four while capture is on,
   four while the Ubuntu host is off (from a reachable Chat client), four after
   restart. Wait for a completed assistant reply to each. Do not resend on
   uncertain UI acknowledgement.
3. Include Unicode quotes, multiline text, an explicit correction, “I might”
   versus “I did,” and one user-authored sentence that resembles UI boilerplate.
   The adapter must capture by message boundary, not remove arbitrary matching
   phrases from user content.
4. The capture adapter observes passively; it must not receive the scripted expected
   answers or manufacture assistant text. If no supported/passive adapter can be
   established, record **CAPTURE_ROUTE_NOT_ESTABLISHED** and stop that experiment;
   manual exports may still support a less seamless MVP.
5. Retain an independent source inventory for comparison, preferably an authorised
   export plus message-boundary UI readback. Do not count an export generated
   from the adapter's own output as independent ground truth.
6. Reconcile online and recovered records: exact text, roles, distinct messages,
   ordering, provenance and known timestamps. Keep absent timestamps NULL.
7. Replay the same import/recovery twice. Restart between local commit and hosted
   acknowledgement. Require no changed originals, duplicate identity rows or
   duplicate index mapping.
8. Ask one natural cross-chat recall question about an off-PC correction; verify
   whether an original was recovered, not merely whether the answer sounds right.

**Acceptance:** 100% fidelity for every record labelled verified, zero false
coverage/capture claims, no duplicate identities on replay, and an explicit
accounting of all 12 user turns and observed replies. Recovery coverage may be
partial, because the product permits gaps. A partial result must identify which
messages are source-backed, reconstructed or unknown—not just a percentage.

Only after that passes, add an edit/regeneration/branch test and a second device.
An edited or regenerated branch needs its own lineage; flattening it into one
timeline is unacceptable. If the supported capture route cannot cover a device,
describe that limitation rather than suggesting the LLM can reliably fill it.

## 6. Privacy, retention and reversibility

Before personal data: approve the conversation/source scope, keep credentials out
of Git, restrict local files, choose a backup/restore policy, and test revocation.
A one-owner system still contains private data.

Separate ChatGPT-native memory controls, local archive retention, hosted files,
vector-store attachments and backups. Deleting one is not an instruction to all
the others. Proposed deletion flow: tombstone locally to prevent release and
re-ingestion; delete relevant remote index/file objects; verify completion; apply
the chosen backup-expiry policy; disclose remaining platform copies. Provider
index removal can be eventually consistent, so enforce the tombstone before
returning a candidate [O6]. Do not promise instantaneous eradication.

The API and consumer ChatGPT have different data-control settings; API content
is not used for training by default, but persistent files/vector-store state
require an explicit lifecycle [O15]. These are reasons for deliberate scope and
retention—not for a more elaborate multi-user architecture.

[O6]: SOURCES.md#o6
[O8]: SOURCES.md#o8
[O11]: SOURCES.md#o11
[O13]: SOURCES.md#o13
[O15]: SOURCES.md#o15
[O16]: SOURCES.md#o16
