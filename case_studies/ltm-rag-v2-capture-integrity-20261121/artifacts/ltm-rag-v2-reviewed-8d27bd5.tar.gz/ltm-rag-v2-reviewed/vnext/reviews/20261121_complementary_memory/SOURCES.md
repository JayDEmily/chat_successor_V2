# Sources and evidence register

**Review date: 21 November 2026.** Official web documentation was checked on that
date. Product behaviour can change; the owner's actual plan, client, model
selection, memory settings and running service were not inspected.

References `[E…]` and `[C…]` identify supplied files/code, not web claims.
References `[O…]` identify current official documentation. Architectural
recommendations in this handoff are the reviewer's proposals, not platform
guarantees.

## Supplied source identity

- Archive: `file-Tyozkpn7kBWfHJnrnnuCZT-LTM-RAG-vNext-Astra-review-5824ae6.tar.gz`
- Archive SHA-256: `c8b5171cbcd691867e5fcb9901a25f9a5b2886a6af17c9e46f35191bd6a2a3dd`
- Commit: `5824ae667aa54c67c1c2cefc10ba9f63fb818679`
- Branch: `work/ltm-rag-vnext-synthetic-20261118`
- Supplied files: 294; 293 member digests plus the separately pinned checksum file.
- Full inventory: [verification/SOURCE_INVENTORY.json](verification/SOURCE_INVENTORY.json).

The original Drive-hosted Astra design report and its earlier ZIP are not part of
the supplied bytes and were not accessed. No GitHub or original Git objects were
available. Historical reports are distinguished from reruns in
[verification/INDEPENDENT_VERIFICATION.md](verification/INDEPENDENT_VERIFICATION.md).

## Evidence

### E1
**Current direction.** `vnext/PROGRESS.md`, “Current checkpoint — 21 November 2026”;
`START_HERE.md`; `git/source.json`; `git/commits.txt`.
The checkpoint's later retry/history completion paragraphs supersede its earlier
“awaits execution” paragraph for status, not for the preserved failure history.

### E2
**Capture and fidelity.** `vnext/NATIVE_DIALOGUE_S_RESULTS_20261120.md`;
`vnext/NATIVE_DIALOGUE_T_RESULTS_20261120.md`;
`vnext/NATIVE_DIALOGUE_T_CASES_20261120.json`;
`evidence/stage-t-canonical-messages.json`;
`evidence/stage-t-hosted-search-results.json`.
S footer contamination, T bounded reconciliation, role/time provenance.

### E3
**Automatic recall and native-memory confound.**
`vnext/NATIVE_RECALL_ARCHIVE_PROVENANCE_RESULTS_20261120.md`;
`vnext/NATIVE_RECALL_ROUTING_RESULTS_20261120.md`;
`vnext/PROJECT_MEMORY_CONFOUND_20261118.md`;
`evidence/native-z/*`.
Current reads require trace evidence, not just correct answers.

### E4
**Long-form failure and repair.**
`vnext/NATIVE_RECALL_LONG_FORM_RESULTS_20261121.md`;
`vnext/NATIVE_RECALL_LONG_FORM_RETRY_RESULTS_20261121.md`;
their corresponding `*_CASES_*.json`;
`evidence/native-long-form/*`; `evidence/native-long-form-retry/*`.
The original failed query length is not recoverable from the audit.

### E5
**Matched long history.**
`vnext/NATIVE_LONG_HISTORY_RESULTS_20261121.md`;
`vnext/NATIVE_LONG_HISTORY_CASES_20261121.json`;
`vnext/fixtures/native_long_history.mjs`;
`evidence/native-long-history/*`.
Submitted-token count, no-results baseline, ON lookup, saved answers and limited
prefix readback—not a measurement of active model context.

### E6
**Original environment test reports and preserved audits.**
`evidence/checkpoint-core-suite.txt`;
`evidence/archive-offline-smoke.txt`;
`evidence/frozen-audit-sha256.json`; `SHA256SUMS`.
These report the original 245 core tests and 13-test exported smoke; the review's
different-environment results are separately labelled.

### E7
**Boundaries and rejected relevance policy.**
`vnext/SOURCE_PACKET_BOUNDARY_DECISION_20261118.md`;
`vnext/ABSTENTION_GATE_DECISION_20261118.md`;
`vnext/HOLDOUT_E_RELEVANCE_RESULTS.md`;
`vnext/NATIVE_OWNER_AUTH_BOUNDARY_DECISION_20261120.md`;
`vnext/TRUSTED_TURN_J_DECISION_20261119.md`.
Exact-source integrity, relevance, account authority and prompt provenance are
distinct. Historical synthetic UI/semantic tests do not become production proof.

### E8
**Operations and bounded restart.**
`vnext/SUPERVISION_TRIAL.md`;
`vnext/POST_SHUTDOWN_RECOVERY_20261118.md`;
`vnext/UBUNTU_RESTART_RECOVERY_20261118.md`;
`vnext/POST_RESTART_CONNECTED_PLUGIN_SMOKE_20261118.md`.
Observed administration/WSL/tunnel paths; no general automatic boot/capture claim.

### E9
**Chronology and early quality results.**
`vnext/STAGE_R_CHRONOLOGY_AMENDMENT_20261120.md`;
`vnext/RELIABILITY_TRIAL_B_RESULTS.md`;
`vnext/H10_SOURCE_FETCH_DIAGNOSIS_20261118.md`;
`vnext/TRIAL_B_QUOTE_FIDELITY_AUDIT.md`.
Separate timestamp meanings, small-sample caveats and the distinction between
source-bearing lookup and mandatory extra-fetch counting.

## Code

Line numbers refer only to the supplied commit. Use symbols after later edits.

| ID | File/symbol | Why inspected |
|---|---|---|
| C1 | `vnext/ltm_vnext/archive.py`: `_local_id` (44), `ingest_synthetic` (165), `_packet` (229), `lookup` (282) | Identity, synthetic-only admission, timestamps, corrections, FTS behaviour. |
| C2 | `vnext/ltm_vnext/hosted_memory_r.py`: `OpenAIHttpR.files` (85), `attach` (112), `search` (116), `SyntheticConversationR.search_candidates` (291) | Provider calls, omitted chunk settings, pagination limit, replay and R deduplication. |
| C3 | `vnext/ltm_vnext/native_dialogue_s.py`: `_messages` (155), `_payload` (176), `index_turn` (198), `search` (301); `verified_dialogue_t.py`: `NativeVerifiedT` | Fixed source capture, paired files, T inheritance, receipt reconciliation and expiry. |
| C4 | `vnext/ltm_vnext/hosted_mcp_u.py`: `HostedMemoryGatewayU.lookup` (144), evidence projection (186), `create_server` (204) | Candidate-only results, duplicate-turn rejection, output fields, read-only surface. |
| C5 | `vnext/ltm_vnext/hosted_mcp_w.py`: `validate_native_recall` (76); `vnext/scripts/run_native_recall_routing.py` | Repaired query range, 5-pair default, trial quota, sham baseline. |
| C6 | `vnext/tests/test_hosted_mcp_w.py`; `test_archive*.py`; `test_hosted_memory_r.py`; `test_verified_dialogue_t.py`; `vnext/tests_shadow/*`; `vnext/requirements-mcp.txt` | Regression scope, private-input dependencies, original runtime pin. |

## Official documentation checked

### O1
**Memory in ChatGPT** — OpenAI Help Center

`https://help.openai.com/en/articles/8590148-memory-in-chatgpt`

Memory is selective; its sources/settings vary, and displayed Sources need not
show every influence. Separate stored memories, chats and other sources when
reasoning about corrections or deletion. This does not specify a universal
regular-Chat compression threshold.

### O2
**Projects in ChatGPT** — OpenAI Help Center

`https://help.openai.com/en/articles/10169521-projects-in-chatgpt`

Sections checked: project instructions and default/project-only memory. Project
instructions override global custom instructions within the project. A fresh
project chat is not automatically isolated from other chats in that project.

### O3
**GPT-6 and other models in ChatGPT** — OpenAI Help Center

`https://help.openai.com/en/articles/20001354-gpt-6-and-other-models-in-chatgpt`

When GPT-6 is selected, the guide identifies Sol for Instant through Extra High
and Astra for Pro. Availability and actual selections depend on the account.
This is not an independent identification of the model in the user's session.

### O4
**ChatGPT release notes**, 17 November 2026 entry — OpenAI Help Center

`https://help.openai.com/en/articles/6825453-chatgpt-release-notes`

The GPT-6.2 preview announcement concerns Work and Codex; regular Chat keeps its
existing model choices. Do not infer a regular-Chat upgrade from an API/Work release.

### O5
**ChatGPT Custom Instructions** — OpenAI Help Center

`https://help.openai.com/en/articles/8096356-chatgpt-custom-instructions`

Current documented global limits differ by plan: 1,500 for Free/Go and 5,000 for
the listed paid plans. The article does not establish the project field's limit.

### O6
**Retrieval** — OpenAI API guide

`https://developers.openai.com/api/docs/guides/retrieval`

Sections checked: ranking, vector stores, file operations and chunking.
Files are automatically indexed; ranking controls concern retrieval. Indexing is
asynchronous and removed-file search results can persist briefly during
eventual consistency. None of this specifies how ChatGPT internally weights an answer.

### O7
**Vector Stores** — OpenAI API reference

`https://developers.openai.com/api/reference/python/resources/vector_stores`

The documented automatic chunk strategy is 800-token chunks with 400-token
overlap. That documents a default, not an inspected setting of the private live
store. No project-specific override/readback was supplied.

### O8
**MCP server** — OpenAI Plugins concepts

`https://developers.openai.com/plugins/concepts/mcp-server`

“How tool calls work”: model-selected arguments, server operation and returned
result, then continuation. Tool-call arguments are not documented as an exact
original-user transcript feed.

### O9
**Authentication** — OpenAI Plugins build guide

`https://developers.openai.com/plugins/build/auth`

Authenticated private-data tools need server-verified credentials and permissions;
the documented user-authentication route uses OAuth 2.1. Client transport identity
and the authenticated user's resource scope are separate concepts.

### O10
**Build an MCP server** — OpenAI Plugins build guide

`https://developers.openai.com/plugins/build/mcp-server`

Sections checked: useful non-UI results, authentication/authorisation and
annotations. Permissions must be enforced at the server; a read-only annotation
is not the enforcement mechanism.

### O11
**Security & Privacy** — OpenAI Plugins guide

`https://developers.openai.com/plugins/guides/security-privacy`

Sections checked: least privilege, input/context collection, response minimisation,
chat-context boundaries, retention and logging.

### O12
**Secure MCP Tunnel** — OpenAI API guide

`https://developers.openai.com/api/docs/guides/secure-mcp-tunnels`

The client uses an outbound connection, forwards requests to the private MCP
server and returns responses. This does not make the private service run while its
host is off or make a desktop-control connection necessary for every lookup.

### O13
**Exporting your ChatGPT history and data** — OpenAI Help Center

`https://help.openai.com/en/articles/7260999-exporting-your-chatgpt-history-and-data`

Exports are available to eligible personal accounts, include conversation data
and arrive asynchronously. This is a source-recovery option, not evidence of a
supported automatic all-turn capture hook.

### O14
**Temporary chat in ChatGPT** — OpenAI Help Center

`https://help.openai.com/en/articles/8914046-temporary-chat-in-chatgpt`

The checked document distinguishes personalized and unpersonalized temporary
chats. Unpersonalized mode excludes plugins, so it cannot simply be assumed to
supply a memory-isolated, plugin-enabled test arm.

### O15
**Data controls in the OpenAI platform** — OpenAI API guide

`https://developers.openai.com/api/docs/guides/your-data`

API data is not used for training by default; persistent application state and
abuse-monitoring retention are separate. Review Files/Vector Stores lifecycle
independently of consumer ChatGPT settings.

### O16
**Reference** — OpenAI Plugins

`https://developers.openai.com/plugins/reference`

The documented `openai/subject` and `openai/session` fields identify/correlate
user/session metadata. They are not a documented signed original-message
delivery contract.

## Explicit unknowns

No inspected source establishes a fixed 30–40k regular-Chat compression point,
perfect first-15-turn recall, numerical memory-source mixing weights, guaranteed
loading of an attached MD file, or automatic off-PC transcript recovery for the
installed plugin. These remain unproven assumptions, not features to advertise.
