#!/usr/bin/env python3
"""Verify the supplied review packet without credentials or network access.

Checks preservation and internal consistency, not live provider truth, original
SQLite contents, source authenticity or ChatGPT's hidden context. --generator
runs only the explicitly pinned, reviewed JavaScript fixture using local Node.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

EXPECTED_MANIFEST_SHA256 = "803f9cc931bf0d158edbde8764b46bc114f15f95539c932ccbcb08bf6924deaa"
EXPECTED_COMMIT = "5824ae667aa54c67c1c2cefc10ba9f63fb818679"
GENERATOR_SHA256 = "8e820f3a18056b1d6bf3b329e777d3b799a2e2eabc4532d764ad8285341b232e"
EXPECTED_AUDITS = {
 "evidence/native-z/trial_z_audit_at_completion.jsonl":
 "5ac9f19ad3495c352a7c0bde39be3360805d20678e7d97a3963fe50acbdff862",
 "evidence/native-long-form/trial_long_form_audit_at_completion.jsonl":
 "ac675d4b54f21fdd37382f983e1ef492330771b45f8adc4777ea963a0bff8f22",
 "evidence/native-long-form-retry/trial_long_form_retry_audit_at_completion.jsonl":
 "ece6e076360c4a91c85dac2d216fcc6ef4124fe82d3cbcb787692c22aff7fbee",
 "evidence/native-long-history/trial_long_history_audit_at_completion.jsonl":
 "6fe5356839c1b6da48031e4e2dd7fbd85450266d4507446455f8fedb8bfa8181",
}
VALID_SOURCE_IDS = {f"t{n:02d}{role}" for n in range(1, 6) for role in "ua"}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path: Path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for part in iter(lambda: stream.read(1024*1024), b""):
            value.update(part)
    return value.hexdigest()


def child(root: Path, relative: str):
    p = Path(relative)
    require(not p.is_absolute() and ".." not in p.parts, "Unsafe packet path")
    full = root / p
    require(not full.is_symlink(), "Symlink is not a canonical packet member")
    require(full.resolve().is_relative_to(root.resolve()), "Path escapes packet")
    return full


def aware_utc(text: str):
    require(isinstance(text, str), "Missing timestamp")
    stamp = datetime.fromisoformat(text.replace("Z", "+00:00"))
    require(stamp.tzinfo is not None and stamp.utcoffset() is not None,
            "Timestamp lacks timezone")
    return stamp.astimezone(timezone.utc)


def verify_manifest(root: Path):
    manifest = child(root, "SHA256SUMS")
    require(digest(manifest) == EXPECTED_MANIFEST_SHA256,
            "The supplied SHA256SUMS file differs from the reviewed snapshot")
    names = set()
    for line in manifest.read_text(encoding="utf-8").splitlines():
        sha, rel = line.split(None, 1)
        rel = rel.lstrip("* ")
        require(bool(re.fullmatch(r"[0-9a-f]{64}", sha)), "Malformed manifest digest")
        require(rel not in names, "Duplicate manifest name")
        names.add(rel)
        p = child(root, rel)
        require(p.is_file(), "Missing manifest member: " + rel)
        require(digest(p) == sha, "Changed manifest member: " + rel)
    require(len(names) == 293, "Unexpected manifest member count")
    return {"listed_files_verified": len(names),
            "manifest_sha256": EXPECTED_MANIFEST_SHA256}


def verify_message_hashes(messages: list):
    require(isinstance(messages, list), "Messages must be a list")
    seen = set()
    for item in messages:
        mid = item["message_id"]
        require(mid not in seen, "Duplicate source message ID")
        seen.add(mid)
        text = item["exact_text"]
        require(isinstance(text, str), "Non-text original")
        require(hashlib.sha256(text.encode("utf-8")).hexdigest()
                == item["content_sha256"], "Original text hash mismatch: " + mid)
    return len(messages)


def join_audit(events: list):
    starts, ends = {}, {}
    denials = 0
    for row in events:
        require(row.get("synthetic_only") is True, "Non-synthetic audit record")
        event = row.get("event")
        aware_utc(row["timestamp_utc"])
        if event == "CALL_DENIED_QUOTA":
            denials += 1
            continue
        require(event in {"CALL_STARTED", "CALL_COMPLETED"}, "Unknown audit event")
        eid = row.get("event_id")
        require(isinstance(eid, str) and eid, "Missing audit event ID")
        target = starts if event == "CALL_STARTED" else ends
        require(eid not in target, "Duplicate audit event")
        target[eid] = row
    require(set(starts) == set(ends), "Unpaired start/completion")
    results = []
    for eid, begin in starts.items():
        end = ends[eid]
        require(begin["stage"] == end["stage"], "Audit stage changed")
        elapsed = (aware_utc(end["timestamp_utc"]) -
                   aware_utc(begin["timestamp_utc"])).total_seconds()
        require(elapsed >= 0, "Completion precedes start")
        status = end.get("status")
        require(status in {"FOUND", "NO_MATCH", "DENIED_SCOPE", "ERROR"},
                "Unknown completion status")
        ids = end.get("verified_source_message_ids", [])
        require(isinstance(ids, list) and len(set(ids)) == len(ids)
                and set(ids) <= VALID_SOURCE_IDS, "Invalid audit source IDs")
        count = end.get("candidate_count")
        require(type(count) is int and count >= 0, "Bad candidate count")
        if status == "FOUND":
            require(count > 0 and len(ids) == count*2,
                    "Pair count/source ID inconsistency")
        else:
            require(count == 0 and not ids, "Failure/no-match carries originals")
        results.append({
            "event_id": eid, "stage": begin["stage"], "status": status,
            "candidate_pairs": count, "source_ids": ids,
            "elapsed_seconds": elapsed,
            "rejection_reason": end.get("rejection_reason"),
            "normalized_query_characters": end.get("normalized_query_characters")
        })
    return {"attempts": len(starts), "quota_denials": denials, "calls": results}


def verify(root: Path, generator: bool = False):
    root = root.resolve()
    checks = []
    def check(name, fn):
        try:
            details = fn()
            checks.append({"check": name, "status": "PASS", "details": details})
            return details
        except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as exc:
            checks.append({"check": name, "status": "FAIL", "error": str(exc)})
            return None
    def read_json(rel):
        return json.loads(child(root, rel).read_bytes())
    manifest = check("supplied_manifest", lambda: verify_manifest(root))
    def identity():
        source = read_json("git/source.json")
        require(source["commit"] == EXPECTED_COMMIT, "Commit identity differs")
        return {"commit": source["commit"], "git_objects_present": (root/".git").exists()}
    check("source_identity", identity)
    canonical = read_json("evidence/stage-t-canonical-messages.json")
    messages = canonical["messages"]
    by_id = {m["message_id"]: m for m in messages}
    def sources():
        n = verify_message_hashes(messages)
        require(n == 10 and set(by_id) == VALID_SOURCE_IDS, "Wrong canonical ID set")
        for n, item in enumerate(messages, 1):
            require(item["position"] == n, "Source order mismatch")
            role = "user" if n % 2 else "assistant"
            require(item["author_role"] == role, "Wrong source role")
            require(item["source_id"] == "synthetic-native-dialogue-t"
                    and item["fidelity"] == "synthetic_only", "Wrong source class")
            aware_utc(item["ingested_at_utc"])
            if role == "assistant":
                require(item["message_sent_at_utc"] is None,
                        "Assistant original send time should be unknown")
            else:
                aware_utc(item["message_sent_at_utc"])
        return {"canonical_texts_verified": 10, "assistant_send_times_unknown": 5,
                "source_t03u_ingested_at_utc": by_id["t03u"]["ingested_at_utc"],
                "sqlite_file_sha256_reported_only": canonical["original_sqlite_sha256"]}
    check("canonical_export", sources)
    audits = {}
    registered = read_json("evidence/frozen-audit-sha256.json")
    def audit_pins():
        require(registered == EXPECTED_AUDITS, "Audit pin manifest differs")
        for rel, sha in EXPECTED_AUDITS.items():
            require(digest(child(root, rel)) == sha, "Frozen audit hash differs: " + rel)
            rows = [json.loads(line) for line in child(root, rel).read_text().splitlines()
                    if line.strip()]
            audits[rel] = join_audit(rows)
        return {"frozen_audits_verified": len(audits), "audits": audits}
    check("audit_bytes_and_joins", audit_pins)
    def retry():
        path = "evidence/native-long-form-retry/trial_long_form_retry_audit_at_completion.jsonl"
        calls = audits[path]["calls"]
        receipt = read_json("evidence/native-long-form-retry/lf_r01_ui_capture.json")
        require(len(calls) == 1 and calls[0]["status"] == "FOUND", "Retry not one FOUND")
        require(calls[0]["event_id"] == receipt["verified_found_event_id"], "Retry join differs")
        require(set(receipt["original_user_ids"]) == {"t01u", "t02u", "t03u", "t04u"}
                and set(receipt["original_user_ids"]) <= set(calls[0]["source_ids"]),
                "Retry required sources absent")
        for source_field, reply_field in [
            ("ingested_at_utc", "reported_t03u_ingestion_utc"),
            ("message_sent_at_utc", "reported_t03u_send_utc")]:
            require(receipt[reply_field] == by_id["t03u"][source_field],
                    "Retry source time differs")
        return {"required_user_records_joined": 4,
                "prompt_words_reported": receipt["prompt_words"],
                "body_words_reported": receipt["body_words"],
                "timestamp_matches_export": True,
                "semantic_regrading_performed": False}
    check("retry_receipt_provenance", retry)
    def failure():
        path = "evidence/native-long-form/trial_long_form_audit_at_completion.jsonl"
        calls = audits[path]["calls"]
        require(len(calls) == 1 and calls[0]["status"] == "DENIED_SCOPE"
                and calls[0]["rejection_reason"] == "BAD_LENGTH",
                "Original rejection changed")
        return {"no_originals_returned": not calls[0]["source_ids"],
                "original_query_length_known": calls[0]["normalized_query_characters"] is not None}
    check("failed_long_form_preserved", failure)
    history_plan = read_json("vnext/NATIVE_LONG_HISTORY_CASES_20261121.json")
    def history():
        path = "evidence/native-long-history/trial_long_history_audit_at_completion.jsonl"
        calls = audits[path]["calls"]
        require([c["status"] for c in calls] == ["NO_MATCH", "FOUND"],
                "Matched-arm audit differs")
        require({"t01u", "t02u", "t03u", "t04u"} <= set(calls[1]["source_ids"]),
                "History originals missing")
        receipt = read_json("evidence/native-long-history/trial_long_history_receipt.json")
        require(receipt["audit"] == EXPECTED_AUDITS[path], "History receipt audit mismatch")
        quoted = ("I saw my old friend Ryan, who enjoys designing rowing shells, "
                  "and my neighbour Emily at lunch, then rushed to yoga.")
        require(quoted in by_id["t01u"]["exact_text"], "Quote absent from original")
        both = all(quoted in receipt["readback"][k] for k in ("probe1", "probe2"))
        require(both, "Exact old sentence absent from one saved reply")
        expected_time = aware_utc(by_id["t03u"]["ingested_at_utc"])
        require(expected_time.strftime("%d %B %Y") in receipt["readback"]["probe2"]
                and expected_time.strftime("%H:%M:%S UTC") in receipt["readback"]["probe2"],
                "Archive timestamp-to-second absent from ON reply")
        total = sum(x["o200k_base_tokens"] for x in history_plan["fixture"]["prefix"])
        require(total == 50237 == history_plan["fixture"]["prefix_user_text_tokens"],
                "Reported token sum differs")
        return {"both_saved_answers_contain_exact_old_sentence": both,
                "on_timestamp_matches_export_to_second": True,
                "user_tokens_reported": total, "token_counts_recomputed": False,
                "receipt_counts_reported": receipt["counts"],
                "active_context_observed": False}
    check("long_history_saved_answers", history)
    if generator:
        def inputs():
            require(manifest is not None, "Refuse fixture execution after manifest failure")
            script = child(root, "vnext/fixtures/native_long_history.mjs")
            require(digest(script) == GENERATOR_SHA256, "Unreviewed generator")
            node = shutil.which("node")
            require(node is not None, "Node is not installed")
            result = subprocess.run([node, str(script), "58"], check=True, timeout=30,
                                    capture_output=True, text=True)
            actual = json.loads(result.stdout)
            registered_prefix = history_plan["fixture"]["prefix"]
            require(len(actual) == len(registered_prefix) == 8, "Wrong prefix count")
            rows = []
            for text, spec in zip(actual, registered_prefix):
                value = hashlib.sha256(text.encode("utf-8")).hexdigest()
                require(len(text) == spec["characters"] and value == spec["sha256"],
                        "Generated prefix differs: " + spec["id"])
                rows.append({"id": spec["id"], "characters": len(text),
                             "sha256": value, "hash_and_length_match": True})
            return {"input_fingerprints_verified": 8, "inputs": rows,
                    "tokenizer_counts_recomputed": False}
        check("regenerated_long_history_inputs", inputs)
    else:
        checks.append({"check": "regenerated_long_history_inputs", "status": "NOT_RUN",
                       "reason": "Use --generator with local Node after reviewing the pinned fixture."})
    passed = all(c["status"] != "FAIL" for c in checks)
    return {"status": "PASS_ARTIFACT_CONSISTENCY_ONLY" if passed else "FAIL",
            "reviewed_commit": EXPECTED_COMMIT, "checks": checks,
            "limitations": ["No live ChatGPT/tunnel/provider/SQLite readback.",
                            "Hashes verify preservation relative to the reviewed packet, not source authenticity.",
                            "The reported o200k_base token counts were not independently recomputed.",
                            "No claim about hidden active context or capture completeness."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", type=Path, required=True,
                        help="Extracted original packet root containing SHA256SUMS, evidence and vnext")
    parser.add_argument("--generator", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        result = verify(args.snapshot, args.generator)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        result = {"status": "FAIL", "error": str(exc)}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False)+"\n",
                               encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if result["status"] == "PASS_ARTIFACT_CONSISTENCY_ONLY" else 1


if __name__ == "__main__":
    raise SystemExit(main())
