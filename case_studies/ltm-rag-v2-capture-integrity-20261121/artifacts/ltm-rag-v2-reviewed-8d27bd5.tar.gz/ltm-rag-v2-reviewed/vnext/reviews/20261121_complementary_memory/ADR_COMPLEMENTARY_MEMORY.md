# ADR: complementary, evidence-led memory for one owner

**Date:** 21 November 2026

**Status:** PROPOSED FOR OWNER REVIEW; not deployed or an authority to ingest personal data

**Baseline:** `5824ae667aa54c67c1c2cefc10ba9f63fb818679`

## Context

The current checkpoint keeps ordinary ChatGPT primary and SQLite authoritative for
captured source text. The hosted Vector Store supplies candidates. Functional
synthetic retrieval works, while capture coverage and long-term conversational
value remain unproven. The owner wants natural speech-to-text conversation, sensible
re-search, and graceful operation when the Ubuntu host is off.

This proposal develops that direction. It preserves the exact-source boundary
from `SOURCE_PACKET_BOUNDARY_DECISION_20261118.md` and the account/source distinction
in `NATIVE_OWNER_AUTH_BOUNDARY_DECISION_20261120.md`. It does not erase rejected
experiments or promote the synthetic pilot into a personal archive. See [E1–E7
and C1–C6](SOURCES.md).

## Decision

1. **One conversational decision-maker.** Ordinary ChatGPT decides when more
   historical evidence would help and writes the response. No supplementary
   reasoning model is required.
2. **Three complementary information channels.** Active conversation provides
   immediate context; native personal/project context supplies available continuity;
   the external archive supplies source records. No fixed percentage, global
   source winner, or token-count trigger is assigned.
3. **SQLite is the source record, not the vector response.** Stable identity,
   exact UTF-8 text, author role, source/version/branch and time provenance are
   preserved. The semantic index is rebuildable. Scores rank candidates; they do
   not establish truth or importance in the answer.
4. **One read-only archive lookup surface.** A general implementation may combine
   semantic and lexical search internally, then resolve and deduplicate by
   canonical source identity. Returning exact packets in that same call is enough;
   a second fetch is not inherently required. Further calls remain available for
   missing episodes, contradictions or requested detail.
5. **Separate source capture from model-authored queries.** A lookup call is not
   an original-message capture event. An approved source importer/capture adapter
   must establish its own provenance and coverage. Model recollections occupy a
   distinct, non-verbatim class and never overwrite original rows.
6. **Fail closed on evidence integrity, fail gracefully on conversation.** Wrong
   account, revoked source, corrupt mapping or hash mismatch releases no affected
   evidence. Provider/PC failure does not stop ordinary conversation. Missing
   coverage is not described as evidence that an event never occurred.
7. **Bound work, not human phrasing.** Server-side byte/result/time/spend bounds
   are legitimate. Topic-name whitelists, exact trigger phrases and cosine-only
   answer permission are not a general personal-memory policy.
8. **One-owner security, not multi-user infrastructure.** Scope access to the
   owner's approved corpus using supported server-verified credentials. Separate
   read permission, capture permission and deletion permission. No routine
   per-turn consent click is proposed for already authorised read-only search.
9. **Capture first locally, then index asynchronously.** Use SQLite records and
   a small transactional outbox/checkpoint. A failed upload must not lose the
   source or force the conversation to wait. No new queue server is needed.
10. **Model-agnostic contracts, repeatable native evaluations.** Version tools,
    instructions and corpus/index settings. Preserve unit gates across model
    upgrades; rerun outcome evaluations on the actual Chat surface. Better models
    may improve query construction and evidence use, but can also change routing
    or style.

Items 4, 5, 8 and 9 describe the intended generalised design, not capabilities
already implemented by the fixed Stage T service.

## Source-use rules

| Question/claim | Preferred evidence and resolution |
|---|---|
| What does the user want now? | Current explicit request or correction, subject to normal safety/permissions. |
| What were the original words? | Original text visible or retrieved with a verifiable source; otherwise say wording is unavailable. |
| What is the current plan? | Applicable latest user correction within the same topic/time/branch, not ingestion-time ordering alone. |
| What did the assistant suggest? | Assistant-authored source, explicitly attributed as a suggestion/reply. |
| What did another person actually say? | A user's written report supports “you reported…”; it does not authenticate that person's speech. |
| Does a remembered profile conflict with an original? | Compare specificity and dates; do not let a vague summary rewrite an exact historical record. |
| Do multiple channels repeat the same claim? | Treat shared lineage as one piece of evidence, not independent corroboration. |
| Is there no result? | Distinguish no relevant match, unavailable service, incomplete capture and missing index coverage. |

A user's present correction may change today's understanding without changing
what an older message originally contained. Preserve both.

## Alternatives not selected

- **Always retrieve / wait until 40k tokens:** confuses age with need; adds friction
  or misses early cross-chat/source questions.
- **Trust the top vector score:** the project's Gate E already failed as a
  relevance policy; do not reuse its rejected threshold.
- **Inject the entire archive or maximise overlap:** wastes context and repeats
  evidence; does not create new information.
- **Have the LLM continuously transcribe itself through lookup arguments:** neither
  source capture nor completeness follows from those arguments.
- **Build an API-owned replacement chat to guarantee each input:** not the owner's
  preferred experience. Revisit only if guaranteed capture later becomes more
  important than native Chat.
- **Require a signed exact current question for every read:** account authorisation
  and source integrity are hard boundaries; relevance and referent resolution are
  model behaviours. Original-question attestation is needed only for a separately
  specified exact-capture or high-consequence action requirement.
- **Add a selector widget to each ordinary recall:** the prior UI experiments
  established transport limitations, not a reason to impose routine friction.

## Consequences and acceptance

The model remains fallible. We cannot expose a private attention weight, know
every hidden context selection, or guarantee project-file instructions are read
on every turn. We can test the source chain, tool traces and answer outcomes.

Before personal-source deployment, require:
- owner-approved source scope, retention/deletion policy and real authentication;
- a source-fidelity and capture-coverage experiment;
- deterministic identity/correction/replay/outage tests;
- a modest native evaluation of correct evidence use and conversational behaviour.

An occasional failed search is tolerable if handled honestly. Silent source
corruption, fabricated “verbatim” recovery, cross-scope access or falsely reported
capture success is not.

## Scope of this change set

Documentation, instruction templates, draft evaluation cases, offline review
utilities and verification reports only. Existing source, fixture hashes, frozen
trials, plugin skills, credentials, services and account settings are unchanged.
Owner acceptance of this ADR is a future decision, not recorded by this review.
