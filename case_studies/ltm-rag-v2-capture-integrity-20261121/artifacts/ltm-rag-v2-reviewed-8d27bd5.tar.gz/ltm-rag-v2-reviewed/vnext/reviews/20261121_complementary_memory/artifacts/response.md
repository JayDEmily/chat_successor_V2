I’ll review the latest ADR, implementation, and tests, then package a Git-ready set of additions covering the workflow, memory-source priorities, offline recovery, suggested instructions, and what to gate versus evaluate over time. I’ll also check the current ChatGPT documentation where the design depends on platform behavior.
The evidence supports the complementary approach, with an important limit: in the 50,237-token trial, both versions still recalled the earlier wording. The archive demonstrably added provenance—not better wording recall in that particular run.

I’m also separating retrieval from capture. The synthetic retrieval round trip is demonstrated; automatic capture of ordinary conversations and catch-up after the PC has been off are not yet established. That distinction matters for what the system can honestly call “verbatim.”
I’ve drafted the workflow, instructions, and test plan without changing the existing prototype. The guidance keeps the safeguards in the backend, leaves conversational judgment to ChatGPT, and separates verified originals from best-effort recollections after an outage.

The review also flags two issues to test before broadening retrieval: duplicate chunks can reach a gateway that rejects repeated turns, and the current five-pair corpus is too small to demonstrate selective retrieval. The package includes the verification logs and clearly marks which tests I could not reproduce here.
[Download the Git-ready review tarball](sandbox:/mnt/data/ltm_rag_complementary_review_20261121.tar.gz)

Start with **`README_FIRST.md`**. The package includes:

- Independent architecture and evidence assessment.
- Proposed ADR and three-source memory workflow.
- Paste-ready project instructions and an attachable operating guide.
- PC-off recovery and capture recommendations.
- Deterministic gates, a 24-case evaluation plan, and offline verification tools.
- An additive Git patch, test logs, and checksums.

**Main conclusion:** the complementary architecture is sound. The existing long-history trial supports a provenance benefit, but not improved verbatim recall in that run. Trustworthy continuous capture and honest offline catch-up are the next major capabilities to prove.

Existing implementation files and frozen evidence remain unchanged.