# Long-form native ChatGPT recall retry — 21 November 2026

**PASS.** The completed 424-word recap of a 512-word fictional dictation used all four required original diary records. Normal ChatGPT invoked the private connector automatically. One OpenAI Vector Store search returned five candidate pairs, and the gateway resolved all five against canonical SQLite originals. The unrelated control made zero lookup attempts. Total tool attempts for the trial were **one of five**.

| Evidence | Observed result |
| --- | --- |
| Browser | Two distinct fresh normal ChatGPT chats outside Projects. The composer matched each frozen prompt before one send. The connector and skill were unselected. |
| Recall | The live audit joined a single `CALL_STARTED` to `FOUND` about 2.04 seconds later. Verified original user records `t01u`, `t02u`, `t03u`, and `t04u` were among the returned pairs and all four were cited in the reply. |
| Answer | Correctly attributed Ryan and Emily, listed M6 bolts as a plan without evidence of purchase, used the corrected Casey and Sunday morning arrangements, and separated a possible missed yoga class from a confirmed event. It identified the unrecorded review time. |
| Provenance | The reply reported `2026-11-20T08:51:20.291203Z` for the first archive ingestion of `t03u`. Read-only SQLite verification matched the value exactly. The reply also separately gave the source send timestamp. |
| Control | The answer explained soap bubbles using surface tension. The private audit was byte-identical before and after this chat. |
| Observed completion | Recap first captured complete 71.822 seconds after send. Control first captured complete 31.072 seconds after send. These are browser observation times. |

The former validator accepted only 8–640 normalized characters and returned up to three pairs. The repaired mode accepts 2–4,096 normalized characters and up to five pairs from the same five-pair corpus. An out-of-range call returns a correction hint, and the audit records its normalized length without storing its text. The MCP regression exercises compact and extended queries, exact record IDs and the oversize response through the actual tool handler. The existing core suite passed 245 tests. The original failure audit does not identify which length bound the earlier query crossed.

The [frozen retry](NATIVE_RECALL_LONG_FORM_RETRY_CASES_20261121.json) was registered at `c842b1cdcc170518307d01cf4707c3a325293c43`. The tested repair was `f2f2748cdabe06fd9444215d25f2ab04cbdf22a2`, with the private plugin skill at version 1.0.4. The private completion snapshot has SHA-256 `ece6e076360c4a91c85dac2d216fcc6ef4124fe82d3cbcb787692c22aff7fbee`. The original trial audit and canonical source matched their registered hashes. The accessibility Send control had no usable click geometry on this run. The visible draft was still unsent, and a screenshot-grounded click submitted it once.

This verifies one multi-episode retrieval in a short, fresh chat. The matched long-history comparison and continuous native capture remain separate work.
