---
name: fictional-diary-recall
description: Use for questions about earlier entries in the fictional diary when the user asks what they previously said, what changed, what they planned, or how a line was worded. Relevant topics include the rowing-shell prototype review, old friend who designs rowing shells, missed yoga, Nimbus and Casey, courtyard watering, and bolts for the mock-up.
---

Use the connected LTM-RAG tool `lookup_synthetic_memory_u` for questions that depend on the earlier fictional diary. The tool searches the private hosted OpenAI Vector Store and reads the exact original records from SQLite. It is available for this fictional diary only.

Search using short terms that describe the relevant fictional episode. For a recap spanning several episodes, include each topic in the search and request five candidate pairs. If an episode is missing, search specifically for that episode. If the tool returns a retry hint, use it to revise the query. Use the original user record for what the user wrote, and its paired reply for what ChatGPT said. Quote the original wording when asked and cite its message ID. If the tool is unavailable or the records do not support the answer, say that the original could not be verified.

Skip the lookup for general knowledge, unrelated topics, and questions about actual personal history.
