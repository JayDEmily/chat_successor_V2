# Native Decision-Support I — frozen contract and trial plan

**Registered 19 November 2026 before the I MCP adapter exists or any I native ChatGPT message is sent.** New experiment, not a retrospective revision to completed G/H scores.

## Governing deficiency and boundary

Trial G G13/G14 confidently selected Merrow despite no unique referent. Offline H's fixed five-topic gate passed 38/38 but was **not** connected to ChatGPT. Stage I will expose a **separate**, single-tool, read-only synthetic MCP server wrapping that conservative gate. Do not modify or repoint either existing six-source (8787) or Trial G (8788) MCP, either tunnel, or either connected plugin. No real messages, external inference API, public listener or OS startup modifications.

## Versioned tool interface — I v1

MCP server name: `LTM-RAG-vNext-Decision-I-Synthetic`; tool: **`resolve_history_reference(question: str)`**. Tool documentation asks ChatGPT to invoke it for an apparent request about previous fictional records, passing the user's complete **current question verbatim**, not an inferred or expanded query. It instructs ChatGPT **not to invoke it for unrelated technical/general questions**. This is an assistant-side decision, not enforced by the tool.

A single atomic tool response is a JSON object with `schema_version=1`, `synthetic_only=true`, `status`, `action`, `conversation_ids`, `source_packets` and a stable, explicit `evidence_limitations` field. A versioned response remains inspectable in the tool's structured and text outputs.

- `UNANCHORED` => `action=CLARIFY_IF_HISTORY_REQUEST`, no conversation identity and **no source packets**. For a historical question, assistant asks which record is meant instead of supplying an arbitrarily selected search result. This must **not** force clarification of an ordinary unrelated question; upstream history-intent selectivity remains a model-level behavioural test.
- `UNIQUE` => `action=REVIEW_ORIGINAL_SOURCES`; precisely the explicitly anchored conversation is returned, including all distinct original, corrected and alternative-branch fictional messages. Each packet must retain `local_id`, `source_locator`, `exact_text`, `content_sha256`, `author_role`, `attribution`, `reported_speaker`, `branch_id`, `supersedes_local_id` and `corrected_by`. The tool **does not** decide which statement to quote or that speech is authenticated.
- `MULTIPLE` => `action=REVIEW_ORIGINAL_SOURCES`; return packets for **all explicitly anchored** topics, never only rank 1. Assistant should handle an actual comparison or clarify the comparison dimension.
- No `EVIDENCE_MISMATCH` is expected if a complete, integrity-checked archive is used to resolve explicit conversation identities directly; if an expected SQLite record is missing or corrupt, **fail the request**, never serve a truncated/suspect packet.

Every startup validates the frozen original 20-message fixture hash, the H evidence-backed five-topic manifest and **all** SQLite rows against original source identity, UTF-8 exact text, hash, source locator, authorship, attribution, reported speaker, branch and correction linkage. SQLite opens read-only for every source fetch; no ingestion or write routes. No extra fact invention, partial fallback or dense/cosine relevance threshold.

**Same-chat follow-ups**: v1 accepts no client-supplied context/session token and does not infer one from prior Project chats. Pronoun-only follow-ups with no explicit topic remain `UNANCHORED`, even after earlier source returns. Trusted session-bounded coreference requires a separate secure transport identity contract; a model-provided chat ID or self-asserted context is not authentication.

**Tool trace**: a separate permissions-restricted local audit records event ID, timestamp, tool name, success/error and result/source count, but **no** question, source text, credentials or answer. No separate `lookup_evidence` / `fetch_source` is exposed by I. Supplying exact original packets in `resolve_history_reference` makes source-read visible in one call; it does **not** prove the model accurately interpreted them.

## Preregistered offline validation

All **20** `offline_cases` in `NATIVE_DECISION_SUPPORT_I_20261119.json` must produce exact `status`, `action` and ordered message IDs. Fault injection must fail closed on changed DB bytes, missing or extra packets, changed corrected-by identities, altered reported speaker, assistant-only alternative promoted to user, and changed source locator; an outage/invalid input is not source evidence. The existing **101 core + 40 shadow** tests must remain passing. The design's previous H cases and source hashes remain frozen.

## Preregistered native ChatGPT trial (only if separate connector can be verified)

The same JSON locks **16** exact native prompts, expectations, source/message target IDs and invocation class **before** any I tool deployment. Native experiment must use a new independent, originally chat-empty **Project-only** ChatGPT Project and new private I tunnel/connector, with independent settings readback and propagation caveat. Use the already-authorised Ubuntu runtime key only; no new key. New isolated listener `127.0.0.1:8789`, distinct Git-ignored SQLite/audit/profile and tunnel; no alteration to earlier G or original services. Do not send I01 until service, tunnel, connector and Project controls are independently verified.

- I01 is the only first-turn chat-empty context; later I02–I16 can be affected by prior within-Project chats. Each new question starts a distinct saved chat. A native prompt gets a **durable pre-send marker** and at most one Send. Pending results require inspection, never automated resend. No force-selecting the I plugin chip: spontaneous invocation is separately scored.
- Explicit history cases require observed successful `resolve_history_reference` tool call, exact expected original source identities and correct semantic/provenance treatment; unrelated controls require **zero I, G and original synthetic MCP calls**. Ambiguous cases may or may not call I but **must not assert a unique unsupported topic**. Wrong tool calls do not meet I tool compliance.
- Frozen answer **source semantics and tool events are independently scored**, including correction ordering, assistant-alternative versus user-authored evidence, reported speaker versus audio authenticity, nonexistent facts, and ambiguous referent.
- Separate per-case saved chat URL, complete answer text, event IDs, timestamp, prompt hash and tool audit. Full ledgers stay Git-ignored; Git contains only reduced, non-secret evidence. Failure or uncertainty in the browser/connector means **BLOCKED or PARTIAL**, not a pass.

## Stopping criteria and authority

If plugin connectivity or independent Project memory verification fails, stop native sends, publish offline evidence and blocker. If any frozen case fails, publish FAIL rather than changing expectations. No claims of general retrieval, real-user suitability, genuine message import or native G13/G14 repair without actual matching native evidence. New I service must not start automatically with Windows/Ubuntu.
