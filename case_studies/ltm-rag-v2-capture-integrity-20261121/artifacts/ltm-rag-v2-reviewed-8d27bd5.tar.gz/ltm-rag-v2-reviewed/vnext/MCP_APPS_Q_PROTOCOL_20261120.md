# Stage Q — offline native-event quarantine and Stage L source-scope separation

**20 November 2026 | Pre-register before implementation. No native ChatGPT message.**

## Narrow engineering requirement

Stage P demonstrated in real ChatGPT web that one synthetic app-only `confirm_topic_m` returned `CONFIRMED` within 12.192 s. Stage L separately passed its 20-case **offline simulated owner** confirmation source gate. Native app-only tool visibility, client-supplied session/subject and an automated synthetic click **cannot authenticate the human, original current user message or owner approval**. Composing these two mechanisms must never silently promote a model-/client-supplied `CONFIRMED` result to source authorisation.

Implement a small isolated, read-only **quarantine boundary** for the exact Stage M public structured tool-result envelope. A valid `CONFIRMED` plus fictional topic may be acknowledged as *untrusted transport*, but never yields source packets, a trusted scope token or an owner-confirmed topic. Model-only source requests must always fail closed. Malformed/spoofed claims are rejected. Other statuses are recorded as non-confirmed, still without packets. The quarantine component must have **no reference to the underlying SQLite archive, resolver, owner challenge, owner context or Stage L gateway**, and expose no MCP server or native connection.

To verify that genuine source-scope admission is still possible through a different premise, independently execute the **existing** Stage L in-memory simulated owner controller path as a separate offline comparator. Check original packet identity and one-time scope, and preserve `original_user_text_attested=false`. This is an *assumed offline owner* and not an actual ChatGPT owner click. Never connect the new quarantine class directly to Stage L's `confirm_from_owner_ui`.

## Frozen source identity and scope

- Repository branch `work/ltm-rag-vnext-synthetic-20261118`, parent checkpoint `4768bf6c79dc72528c3eddf630a3cf3f08152816` with owner continuous-work policy already published.
- Existing Stage M `SelectorM.public` is the public envelope shape; `mcp_apps_m.py` is unchanged. Stage L `clarification_l.py` and original I synthetic source resolver/fixture remain unchanged.
- Frozen 20-message synthetic source `fixtures/synthetic_clean_g.json`, SHA-256 `e3531da9538eb40dc41bec43f29c089f7aed7525ee574e84d21e469fabf9dcbf`; five canonical topic IDs: `merrow_prism`, `vela_case`, `qev_tensile`, `ora_pier`, `sova_container`.
- No real user data, source archive import, external inference, new API key, plugin, OS startup, listener, Chrome navigation or native MCP event. Preserve all six existing Stage M/N/O/P events and one-send/one-click native quotas.
- `MCP_APPS_Q_CASES_20261120.json` freezes exactly **21 ordered cases** Q01–Q21 and expected outcomes, before creating the quarantine code.

## Frozen case types

- Q01–Q05: five valid-looking synthetic `CONFIRMED` envelopes, one for each fictional topic; `QUARANTINED_APP_EVENT`, zero packets and `owner_authorised=false`.
- Q06–Q12: forged, malformed or scope-promoting envelopes: model-topic injection, false human-consent attestation, false original-user-text attestation, nonzero source count, fabricated packets, removed client-auth flag or unknown topic; `INVALID_APP_EVENT`, no source.
- Q13–Q15: native `DENIED`, `EXPIRED`, `AWAITING_CONFIRMATION`; `NOT_CONFIRMED_APP_EVENT`, no source.
- Q16: model-origin attempt to request sources with fabricated topic/context/approval; `UNTRUSTED_NO_SOURCE_SCOPE`, no source.
- Q17: separate Stage L simulated owner-controlled Merrow source choice, explicitly unrelated to the quarantined app event; `CONFIRMED_SOURCE_SCOPE`, independently checked original packet integrity.
- Q18: same Stage L owner grant cannot be reused; `NO_CONFIRMED_SCOPE`, zero packets.
- Q19: separately confirmed two-topic Stage L owner selection uses canonical topic ordering and exact original packets.
- Q20–Q21: original I05/I15 ambiguous model questions accompanied by **separately simulated** Stage L owner choice release only the selected fictional source scope; they do **not** authenticate the user's original utterance or implied referent, and must retain `original_user_text_attested=false`.

## Acceptance and publication

Use a deterministic fresh isolated fixture/archive per independent L owner comparator, exact original packet validation (IDs, hashes, UTF-8 text, author and correction identity). No expected result or case count changes after frozen Git registration. Independently compare preregistration commit, parent and complete protocol/matrix Git blobs before code. Run all 21 cases, 160/160 existing core + 40/40 shadow, Stage L frozen 20/20, M frozen 16/16, and Stage P audit 6 events unchanged. If valid, label **`PASS_Q_APP_EVENT_QUARANTINED_AND_OFFLINE_OWNER_SCOPE_SEPARATED`**. This is not a new native data retrieval capability or authentication.

Keep implementation and tests inside `vnext/`, publish a result and README/PROGRESS notes, check clean worktree, push and independently verify GitHub commit, parent, tree and changed file blobs. Continue next task without asking for routine reapproval. Stop or escalate only for a material trust/permission boundary.
