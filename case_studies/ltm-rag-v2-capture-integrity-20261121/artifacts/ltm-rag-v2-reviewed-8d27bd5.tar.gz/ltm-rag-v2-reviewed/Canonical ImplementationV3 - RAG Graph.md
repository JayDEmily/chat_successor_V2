# Canonical Implementation V3 — RAG Graph Extension (Design)

_This document extends the existing, known-good V2 implementation. It does **not** replace V2; all current behaviour is assumed correct and remains the baseline._

## 0. Current Architecture (concise restatement)
- **Transcripts (S3, canonical log)**: Append-only JSONL at `sessions/{root_session_id}/{session_id}.log.jsonl`, each line an immutable `Event` (id/root/session/sequence/role/created_at/content/metadata).
- **Branch state (DynamoDB, short-term memory)**: One item per `(PK=root_session_id, SK=session_id)` storing `short_summary`, bounded `recent_events`, `next_sequence`, `summary_turns_since_update`. Rebuildable from transcripts.
- **Semantic memory (OpenAI vector store)**: Assistant turns only; files API upload with metadata (root/session/id/sequence/role/kind/created_at). Searches filter by `root_session_id` (optional `session_id`) using the current user message.
- **/post flow**: Load state, allocate sequences for user+assistant, append to S3, update short-term memory (summarise when ≥6 assistant turns since last refresh or buffer≥40, trim buffer), conditionally index semantic memory, persist state. Non-idempotent.
- **/pre flow**: Load state, perform semantic search when enabled, return `short_summary`, `recent_events`, `semantic_hits`. Read-only.
- **Surfaces**: Lambda Function URL `/pre`/`/post`/`/turn` + MCP tools; cold-start healthcheck validates env, S3/Dynamo reachability, vector store, optional LLM probes.

### 0.1 Composite `/turn` endpoint (agent-friendly)
- **Path**: `POST /turn` on the same Function URL.
- **Request**: `{root_session_id, session_id, current_user_message, last_user_message|null, last_assistant_message|null}`; the last_* fields must be both null (first turn) or both non-null (completed prior turn).
- **Semantics**: When last_* are provided, execute the full `/post` pipeline for that pair (transcript append, BranchState update, semantic index, graph enqueue) and then return the `/pre` payload for `current_user_message`. When last_* are null, skip the persist step and behave like `/pre`.
- **Response**: `/pre` payload (`short_summary`, `recent_events`, `semantic_hits`, optional `graph_memory_facts`/`graph_memory_history`) plus `persisted_last_turn: bool`.
- **Compatibility**: `/pre` and `/post` remain available for clients/harnesses; `/turn` is a convenience surface to make Custom GPT/agent usage deterministic.

## 1. RAG Graph / Long-Term Memory Extension

### 1.1 Data Model
- **Tables**
  - `memory_nodes` (DynamoDB):
    - **PK**: `root_session_id`.
    - **SK**: `entity#type#node_id` (node_id is deterministic hash in code).
    - Current implementation does not use GSIs; `/pre` queries the table by `PK` and filters in-process (optionally by `entity_hint`) to find active facts and build history.
  - Optional `memory_edges` (if relations needed):
    - **PK**: `root_session_id`.
    - **SK**: `from_node_id#to_node_id#relation`.
    - **GSI (by to-node)**: `GSI1PK = root_session_id#to_node_id`, `GSI1SK = relation#from_node_id`.
- **`memory_nodes` fields**
  - `node_id` (UUID), `root_session_id`, `entity`, `type` (e.g., config/version/preference/decision), `fact` (string), `state` (`active|superseded|reopened`), `confidence` (0–1), `updated_at`, `valid_from`, `valid_to` (null when active), `source_event_ids` (list of `Event.event_id`), `source_session_ids`, `source_root_session_id`, `supersedes` (list of node_ids), `superseded_by` (node_id or null), `history_reason` (short rationale), `tags` (optional), `kind` (`graph_fact` for vector index).
- **Vector store reuse**
  - Reuse existing OpenAI store; upload consolidated facts as small text blobs with `kind=graph_fact` and the same metadata (root/session/node_id/entity/type/state/updated_at). Legacy message chunks remain `kind=message`. Search filters `kind` to avoid mixing. New store is optional only if isolation is required.

### 1.2 Processing Pipeline (async, post-success)
1. **Emit work item** after `/post` succeeds:
   - SQS/EventBridge payload: `{ root_session_id, session_id, user_event_id, assistant_event_id, sequence_start, sequence_end, transcript_key, timestamp }`.
   - Idempotency token: `dedupe_key = hash(root_session_id, session_id, assistant_event_id)` carried in the message.
2. **Extraction worker (Lambda)**:
   - Loads a bounded window: latest events referenced by `user_event_id`/`assistant_event_id` plus recent transcript tail for that session (or `BranchState.recent_events` if available), anchored on `source_event_ids`.
   - LLM extraction prompt emits candidate memories with schema `{entity, type, fact, confidence, source_event_ids:[...], source_session_id, kind="graph_fact", temporal hints}`.
   - Writes candidates to an internal buffer (in-memory) passed to consolidation; no Dynamo writes yet.
3. **Consolidation worker (same or chained Lambda)**:
   - Queries `memory_nodes` for the root/entity/type via GSI1; fetches active/superseded timeline.
   - For each candidate, runs consolidation prompt to choose `ADD | UPDATE (supersede) | NO_OP | REOPEN`.
   - Creates/updates nodes with deterministic `node_id`: `node_id = hash(entity, type, fact_normalized, source_event_ids_sorted)` to make inserts idempotent; conditional put on `node_id` avoids duplicates.
   - Supersedence: new active node sets `supersedes` to prior active node(s) for same entity/type, updates prior nodes to `state=superseded`, `superseded_by=new_id`, `valid_to=now`.
   - Reopens: set prior `state=reopened` if appropriate.
   - Upserts also set `last_processed_sequence` per `(root, session)` in a lightweight marker item to short-circuit duplicate messages.
   - After Dynamo writes, upload a `graph_fact` file to the vector store (optional, gated by config) with the node text + metadata.
4. **Idempotency rules**
   - Conditional writes on `node_id`.
   - `last_processed_sequence` guard: skip work when `sequence_end <= last_processed_sequence`.
   - SQS FIFO or dedupe ID = `dedupe_key` to avoid double-delivery; consolidation remains idempotent via deterministic node IDs and conditional updates.

### 1.3 /pre Retrieval Strategy
- **Default path**: Query `memory_nodes` by `PK=root_session_id`, optionally filter in-process by a simple entity hint (currently `python_version` detection). Build:
  - `graph_memory_facts`: most recent `state in {active,reopened}` node per `(entity,type)` with fields `entity`, `type`, `fact`, `state`, `confidence`, `updated_at`, `valid_from`, `valid_to`, `source_event_ids`, `supersedes`, `superseded_by`, `tags`.
  - `graph_memory_history`: per-entity list of all nodes (active + superseded/reopened) with `fact`, `state`, `valid_from`, `valid_to`, `updated_at`, `source_event_ids`, `supersedes`, `superseded_by`, `history_reason`.
- **Semantic fallback (optional)**: If graph is enabled but no facts are returned, run OpenAI vector store search with `kind=graph_fact` and `root_session_id` filter (optional `session_id`), returning top-K nodes; merge into the same shape (history entries may omit `history_reason`/validity timestamps).
- **Latency posture**: Dynamo-first for predictable `/pre` latency; vector search only when no facts were found.

### 1.4 /pre Response Extension (backward-compatible)
- New fields are optional; existing fields stay unchanged.
```json
{
  "short_summary": "...",
  "recent_events": [...],
  "semantic_hits": [...],
  "graph_memory_facts": [
    {
      "entity": "python_version",
      "type": "config",
      "fact": "3.11.9",
      "state": "active",
      "confidence": 0.92,
      "updated_at": "2025-12-10T12:34:56Z",
      "valid_from": "2025-12-01T00:00:00Z",
      "valid_to": null,
      "source_event_ids": ["evt-a", "evt-b"],
      "supersedes": ["node-old"],
      "superseded_by": null,
      "tags": ["runtime"]
    }
  ],
  "graph_memory_history": {
    "python_version": [
      {
        "fact": "3.10",
        "state": "superseded",
        "valid_from": "2025-10-01T00:00:00Z",
        "valid_to": "2025-12-01T00:00:00Z",
        "source_event_ids": ["evt-old"],
        "superseded_by": "node-new",
        "history_reason": "superseded by newer decision"
      },
      {
        "fact": "3.11.9",
        "state": "active",
        "valid_from": "2025-12-01T00:00:00Z",
        "valid_to": null,
        "source_event_ids": ["evt-a", "evt-b"],
        "supersedes": ["node-old"],
        "history_reason": "latest decision"
      }
    ]
  }
}
```

### 1.5 Linking Memories to Transcripts
- `source_event_ids` are the `Event.event_id` values created in `/post` (user and assistant). They appear:
  - In `memory_nodes.source_event_ids`.
  - In vector store metadata (both `graph_fact` and legacy `message` uploads) as `event_id`.
- **Traceability**:
  - Given a node, you can locate S3 lines by searching `event_id` in `sessions/{root}/{session}.log.jsonl`.
  - `BranchState.recent_events` already contains those events for the tail window; node metadata can include `source_session_ids` to disambiguate branches.
- **Context windows**: Extractor builds windows around the specific `source_event_ids` (user+assistant just written) plus a small tail for coherence, not arbitrary large tails, to keep extraction targeted.

## 2. Prompt Patterns
- **Extraction prompt**: Input = recent turns anchored on `source_event_ids`; Output = candidate memories `{entity, type, fact, confidence, source_event_ids, temporal hints}`; Emphasis on structured, minimal facts and avoiding chitchat.
- **Consolidation prompt**: Input = existing timeline for entity/type (active + superseded) + candidate; Output = action (`ADD/UPDATE(NO_OP/REOPEN)`) + rationale; Must choose supersedence targets and produce normalised fact text.
- **Query/format prompt**: Input = selected active facts + optional history per entity; Output = formatted `graph_memory_facts`/`graph_memory_history` tailored for `/pre` response; avoids re-summarising free-form text.

## 3. Testing & Observability
- **Scenarios**: Python/Ruff version flapping (3.10→3.11→3.12→3.11), tool preference reversals, reopen a superseded fact, no-op when duplicate evidence arrives.
- **Invariants**:
  - Only one `active` node per `(root, entity, type)`.
  - Superseded nodes retain `valid_to` and `superseded_by`; new nodes list `supersedes`.
  - `source_event_ids` resolve to transcript lines and recent events.
  - Idempotency: repeating the same SQS message does not create extra nodes.
- **Health/Logging**: Optional healthcheck probes for `memory_nodes` table and vector-store `kind=graph_fact`; structured logs for extraction/consolidation decisions (action, entity, node_id, dedupe hit) in existing JSON style; metrics on pipeline throughput and skips (already processed).

## 4. Integration Summary
- **/post** unchanged for clients; internally emits async work item after success.
- **Async pipeline** creates/updates `memory_nodes` (and edges if enabled) with idempotent writes; optionally indexes `graph_fact` in the vector store.
- **/pre** optionally enriches responses with `graph_memory_facts` (active facts) and `graph_memory_history` (timelines) while preserving `short_summary`, `recent_events`, and `semantic_hits`.
- **Storage triad remains**: S3 transcripts (ground truth), Dynamo `BranchState` (short-term), OpenAI vector store (semantic over messages + optional graph facts); `memory_nodes` add durable, conflict-resolved facts with lineage.
