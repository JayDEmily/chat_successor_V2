"""AWS Lambda entrypoint for the memory-agent backend.

This module routes Function URL (or API Gateway/ALB) style events to the
`/pre` and `/post` handlers. A one-time healthcheck guarded by
`_HEALTHCHECK_RAN` runs on cold start to validate configuration via
`load_settings`, S3/DynamoDB reachability, OpenAI vector store reachability
when `SEMANTIC_BACKEND=openai`, and optional embedding/summary calls when
`HEALTHCHECK_LLM_CALLS` is true. Errors in handlers bubble to HTTP 500; there
is no rollback/compensation around partial writes. The canonical front door
is a Lambda Function URL; API Gateway can sit in front if you need extra
auth/routing, but the code does not require it.
"""

from __future__ import annotations

import base64
import json
import uuid
from typing import Any, Dict

from app.healthcheck import run_healthcheck
from app.handler import handle_post, handle_pre, handle_turn
from app.models import PostPhaseRequest, PrePhaseRequest, TurnRequest
from app.logging_utils import get_logger, init_logging, request_context, update_request_context
from app.response_utils import response_to_body


# Guard to ensure the healthcheck runs once per cold start/process.
_HEALTHCHECK_RAN = False
init_logging()
logger = get_logger(__name__)


def _ensure_healthcheck() -> None:
    """Run startup healthcheck once per cold start.

    In a Lambda environment this function will be called on the first
    invocation and skipped thereafter for the lifetime of the container. Any
    error from `run_healthcheck()` is allowed to bubble so the request fails
    fast with HTTP 500 instead of executing handler logic.
    """
    global _HEALTHCHECK_RAN
    if not _HEALTHCHECK_RAN:
        run_healthcheck()
        _HEALTHCHECK_RAN = True


def _response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Helper to build a Lambda proxy integration response."""
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }


def _validate_required_fields(body: Dict[str, Any], fields: list[str]) -> None:
    """Ensure required fields exist as non-empty strings."""
    for name in fields:
        if name not in body:
            raise KeyError(name)
        value = body[name]
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"Invalid field: {name}")


def _validate_optional_string_field(body: Dict[str, Any], name: str) -> Any:
    """Return an optional string field, enforcing type/emptiness when present."""
    if name not in body:
        return None
    value = body[name]
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"Invalid field: {name}")
    return value


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """AWS Lambda entrypoint for the memory-agent.

    Expects an API Gateway or Function URL style event with:
        * HTTP method (GET/POST),
        * path `/pre` or `/post`,
        * JSON body or query string parameters containing the required
          fields for PrePhaseRequest / PostPhaseRequest.

    This is intentionally minimal and can be adapted to your specific
    HTTP routing setup. Routing is path + method gated: only `POST /pre`
    and `POST /post` are accepted. Successful calls return HTTP 200 with
    JSON bodies; missing/invalid fields or malformed JSON yield HTTP 400,
    wrong paths/methods yield HTTP 404, and unexpected errors yield
    HTTP 500, all with the shape {"error": "<message>"}.
    """
    path = event.get("rawPath") or event.get("path", "")
    method = event.get("requestContext", {}).get("http", {}).get("method")
    if not method:
        method = event.get("httpMethod", "GET")
    method = method.upper()
    request_id = getattr(context, "aws_request_id", None) or str(uuid.uuid4())

    with request_context(request_id=request_id, path=path, method=method):
        logger.info("request_start", extra={"stage": "request_start"})
        try:
            _ensure_healthcheck()
        except Exception as exc:
            logger.error(
                "healthcheck_failed",
                extra={"stage": "healthcheck", "status": "error", "status_code": 500},
                exc_info=True,
            )
            return _response(500, {"error": str(exc)})

        body_raw = event.get("body")
        if body_raw and event.get("isBase64Encoded"):
            body_raw = base64.b64decode(body_raw).decode("utf-8")  # type: ignore[name-defined]
        if body_raw:
            try:
                body = json.loads(body_raw)
            except json.JSONDecodeError:
                body = {}
        else:
            body = {}

        try:
            if path.endswith("/turn") and method == "POST":
                _validate_required_fields(
                    body,
                    ["root_session_id", "session_id", "current_user_message"],
                )
                last_user_message = _validate_optional_string_field(
                    body, "last_user_message"
                )
                last_assistant_message = _validate_optional_string_field(
                    body, "last_assistant_message"
                )
                if (last_user_message is None) != (last_assistant_message is None):
                    raise ValueError(
                        "last_user_message and last_assistant_message must both be provided together or both null"
                    )
                root_session_id = body["root_session_id"]
                session_id = body["session_id"]
                current_user_message = body["current_user_message"]
                update_request_context(
                    {
                        "root_session_id": root_session_id,
                        "session_id": session_id,
                        "path": "/turn",
                    }
                )
                turn_req = TurnRequest(
                    root_session_id=root_session_id,
                    session_id=session_id,
                    last_user_message=last_user_message,
                    last_assistant_message=last_assistant_message,
                    current_user_message=current_user_message,
                )
                turn_resp = handle_turn(turn_req)
                logger.info(
                    "request_success",
                    extra={"stage": "request_success", "status": "ok", "status_code": 200},
                )
                body = response_to_body(turn_resp)
                return _response(200, body)

            if path.endswith("/pre") and method == "POST":
                _validate_required_fields(
                    body, ["root_session_id", "session_id", "user_message"]
                )
                root_session_id = body["root_session_id"]
                session_id = body["session_id"]
                user_message = body["user_message"]
                update_request_context(
                    {
                        "root_session_id": root_session_id,
                        "session_id": session_id,
                        "path": "/pre",
                    }
                )

                pre_req = PrePhaseRequest(
                    root_session_id=root_session_id,
                    session_id=session_id,
                    user_message=user_message,
                )
                pre_resp = handle_pre(pre_req)
                logger.info(
                    "request_success",
                    extra={"stage": "request_success", "status": "ok", "status_code": 200},
                )
                body = response_to_body(pre_resp)
                return _response(
                    200,
                    body,
                )

            if path.endswith("/post") and method == "POST":
                _validate_required_fields(
                    body,
                    ["root_session_id", "session_id", "user_message", "assistant_message"],
                )
                root_session_id = body["root_session_id"]
                session_id = body["session_id"]
                user_message = body["user_message"]
                assistant_message = body["assistant_message"]
                update_request_context(
                    {
                        "root_session_id": root_session_id,
                        "session_id": session_id,
                        "path": "/post",
                    }
                )

                post_req = PostPhaseRequest(
                    root_session_id=root_session_id,
                    session_id=session_id,
                    user_message=user_message,
                    assistant_message=assistant_message,
                )
                post_resp = handle_post(post_req)
                logger.info(
                    "request_success",
                    extra={"stage": "request_success", "status": "ok", "status_code": 200},
                )
                body = {"ok": post_resp.ok}
                if getattr(post_resp, "memory_telemetry", None) is not None:
                    body["memory_telemetry"] = post_resp.memory_telemetry.to_dict()
                return _response(200, body)

            logger.info(
                "request_not_found",
                extra={"stage": "routing", "status": "not_found", "status_code": 404},
            )
            return _response(404, {"error": "Not found"})

        except KeyError as exc:
            # Required field missing -> HTTP 400 with minimal error shape.
            logger.warning(
                "request_validation_error",
                extra={
                    "stage": "validation",
                    "status": "error",
                    "missing_field": str(exc),
                    "status_code": 400,
                },
            )
            return _response(400, {"error": f"Missing field: {exc}"})
        except ValueError as exc:
            # Invalid field types/contents -> HTTP 400 with minimal error shape.
            logger.warning(
                "request_validation_error",
                extra={
                    "stage": "validation",
                    "status": "error",
                    "invalid_field": str(exc),
                    "status_code": 400,
                },
            )
            return _response(400, {"error": str(exc)})

        except Exception as exc:  # pragma: no cover - top-level guard
            logger.error(
                "request_error",
                extra={"stage": "handler", "status": "error", "status_code": 500},
                exc_info=True,
            )
            return _response(500, {"error": str(exc)})
