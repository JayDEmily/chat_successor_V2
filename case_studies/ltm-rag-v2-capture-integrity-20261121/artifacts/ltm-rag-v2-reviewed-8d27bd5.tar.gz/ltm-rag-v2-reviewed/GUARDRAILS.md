# LTM-RAG vNext - frozen execution guardrails

**Owner-directed process baseline: 21 November 2026.** Owner-authorised R2 revision of the previously independently reviewed governance candidate at `acb474dcd7370565f763f40eb1607bb489c18d83`; it additionally proposes a minimal synthetic-only PR CI workflow. The freeze is a documented process, not branch protection. A new independent review, PR checks and merge authority are still needed to adopt this revision.

## Scope and authority

- These rules govern **vNext work only** in this repository. Legacy code and unrelated NVIDIA/Chat Succession projects do not inherit vNext requirements. The NVIDIA precedent supplies an execution pattern, not domain decisions, fixture budgets or test admissions.
- Resolve current explicit owner instructions first, followed by this frozen process, applicable `AGENTS.md` instructions, the **accepted** technical ADR and authorised execution leaf, then implementation and evidence. A Git commit, passing test or proposed ADR does not alone prove acceptance.
- Latest technical review: `vnext/COMPLEMENTARY_MEMORY_REVIEW_20261121.md`, with ADR `vnext/reviews/20261121_complementary_memory/ADR_COMPLEMENTARY_MEMORY.md` and existing G1-G10 gates in `vnext/reviews/20261121_complementary_memory/GATES_AND_EVALS.md`. The ADR's original status is **PROPOSED FOR OWNER REVIEW**, not silently promoted by this governance change.
- The current gate plan is **not** a numbered implementation-leaf register. A new leaf requires an identified source requirement, authorised bounded scope, pinned base, dependencies, pass/fail evidence and explicit next step. No agent may invent a leaf queue or change priorities just because adjacent work is convenient.
- Preserve earlier frozen native trials and budget limits, all original source roles/bytes/timestamps and the prohibition on real-history capture, new paid inference, public deployment, production plugin reconfiguration and ChatGPT Work without specific later authority.

## Frozen worker-review-PR-merge process

1. **Select one admitted leaf.** Read only the relevant governing ADR section, gate, source and current result/decision. Establish dependencies and a concrete end state before implementation. If an external capture/authentication requirement is unproven, record that blocker; do not replace it with another mock platform or scope expansion.
2. **Worker in local Ubuntu/WSL.** Implement one coherent bounded change and its proportional development tests. Preserve untouched evidence. Inspect the actual diff and failures. Commit and push the exact work to a feature branch in GitHub; record the base and candidate SHAs, tests with exits, changed paths and limitations. Do not mark it independently accepted.
3. **Fresh independent reviewer/tester.** After verified remote readback, use a distinct ChatGPT thread in the same nominated Project, with an exact commit-pinned GitHub assignment, to independently inspect the source, requirements, affected tests and relevant failure lineage. Derive at least one meaningful check rather than trusting the worker's own fixtures/summary. Record `PASS`, `RETURN_TO_WORKER` or `BLOCKED` and evidence on GitHub. The worker cannot sign its own acceptance.
4. **Repair loop.** On a demonstrated defect, return only the bounded defect to a worker; publish a new commit and obtain new independent review of the affected path. A reviewer cannot change the frozen gate or reinterpret a failure as success. Repeated materially related failures require investigation of the common mechanism before another ad-hoc patch.
5. **PR after reviewer clearance.** Submit the reviewed head SHA as a pull request to the expressly nominated integration branch. Include the leaf, source/base/head, review verdict, affected gates and precise test evidence. No PR implies automatic merge; a changed head invalidates the previous verdict as applicable.
6. **GitHub Actions on a separate Ubuntu runner.** Run the configured PR checks and evaluate their real status against the reviewed head. A local Ubuntu pass is not a CI pass; a CI pass is not independent semantic review or native ChatGPT outcome evidence. Required tests must not be waived because a workflow is missing. If checks are absent, failed or pending, the integration gate is **NOT_ESTABLISHED**.
7. **Merge and advance only when authorised.** Require an accepted review, the required successful PR checks and the applicable owner/branch merge authority. Merge exactly the reviewed change, verify the resulting remote commit, then release the next dependency-eligible leaf. Do not merge to `main`, deploy, or operate personal-source services under the synthetic-only grant.

The first development commit necessarily precedes independent review and the PR; the **integration/merge commit** comes last. Keep the PR change set and its reviewer evidence attributable to one coherent leaf. Gate-level integration testing may cover several independently reviewed leaves when the accepted plan provides for it.

## Actual automation boundary

- A separate Chat Succession project has demonstrated bounded automatic new-ChatGPT-thread handoffs. **No LTM-RAG worker/reviewer controller binding is verified here.** Until separately tested and authorised for this repo/account/Project, use an explicit fresh-thread handover; do not claim that writing `AGENTS.md` starts or schedules a reviewer.
- The inspected implementation branch had **no** LTM-RAG `.github/workflows/` CI. The candidate includes `.github/workflows/vnext-synthetic.yml` for secret-free PR validation on a reproducible 276-test synthetic subset. There is no observed passing PR Actions run, configured required check, branch protection or owner merge authorisation yet. Historical Stage T/W tests requiring untracked private trial receipts are not included in hosted CI; their exclusion is **not** a pass.
- A ChatGPT thread cannot continue acting after its response without a real running controller/automation. Repo instructions do not change platform capability.

## This candidate's PR base, review and CI evidence

The recommended base for a narrowly scoped governance PR is
`work/ltm-rag-vnext-astra-implementation-20261121` at
`62074121e629ae7a5ea68f784fae38a2df5fd3ab`. This is a
**recommendation**, not a nominated integration authority. Require the
owner's explicit PR-base selection and verify its actual SHA and
`git diff --name-status <base>...<reviewed-head>` before opening the PR.
Do **not** use `main` by default: it stood at
`4296e884dad89757bf2808ac3a59fcd3ac3666b3`, 91 commits
behind the implementation parent. A PR to main would unintentionally
include the intervening vNext implementation history.

R1 at `acb474dcd7370565f763f40eb1607bb489c18d83`
remains the immutable subject of the first independent review.
This R2 revision is **not yet independently reviewed**. A fresh reviewer
must verify R2's exact source and publish an attributable verdict and
evidence in GitHub before reviewer clearance can be claimed. A worker
transcribing a chat verdict does not independently certify it.

A GitHub PR workflow normally tests a generated **synthetic merge ref**,
which is not necessarily the review-pinned feature-branch head SHA.
Record the exact base SHA, source-head SHA, workflow run and tested merge
ref separately. Require a fresh review assessment when the source head
changes materially. A locally passing suite does not substitute for
a verified green check on the actual PR revision.

The proposed CI covers **276 reproducible synthetic tests**: the previous
263-case subset plus 13 Stage W fake-provider cases. The **one excluded
Stage W preregistration** and **eight excluded Stage T source-fidelity**
tests require original historical Git/private native ChatGPT evidence.
Their exclusion is not a PASS; those outcomes require their own verified
evidence, not fabricated substitutes on an Ubuntu Actions runner. The original
21 November Astra ADR remains PROPOSED and the numbered LTM leaf queue
and automatic reviewer handoff remain separately unqualified.

## Freeze and amendments

Workers, testers and automation may not silently change this document, rewrite the original Astra review, relax a frozen native quota, broaden a leaf or self-authorise a merge. An actual owner-directed amendment must identify the precise rule and rationale, retain the earlier Git version, be independently reviewed and pass the same PR/CI process before becoming the new baseline. A new technical ADR version requires its own explicit acceptance; updating progress or code never changes that status.

Keep records proportionate: Git source commit, independent review evidence, PR Actions result and merge SHA are the essential handoff. Do not introduce a gate registry, second controller or extra bureaucracy without a demonstrated requirement.
