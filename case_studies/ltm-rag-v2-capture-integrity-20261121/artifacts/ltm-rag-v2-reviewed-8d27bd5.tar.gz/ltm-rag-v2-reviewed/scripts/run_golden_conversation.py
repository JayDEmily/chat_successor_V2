"""Generate a committed "golden set" conversation via MicroAgent (live /turn + OpenAI).

This script runs a named scenario, writes a deterministic local JSONL transcript plus
manifest, and ensures the final assistant message is persisted to S3 by flushing the
last turn through an extra /turn call (no model call for the flush).
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import time
import uuid
from typing import Any, Dict, Optional

from app.micro_agent.env_loader import load_env
from app.micro_agent.micro_agent import MicroAgent
from app.micro_agent.scenarios import get_scenario
from app.micro_agent.turn_client import TurnClientError, post_turn, resolve_function_url


NVDA_DESK_INSTRUCTIONS = (
    "You are a Tier-1 equities execution assistant for a memory-enabled RAG prototype. "
    "You help day-trade NVDA stock only (no options) using rule-based execution. "
    "Use the conversation summary, recent events, semantic hits, and graph memory facts "
    "(when present) to answer the latest user message. "
    "Be specific: include hard numbers (levels, stops, sizing examples, risk limits), "
    "scenario thresholds, and catalyst rules. "
    "When the user asks you to quote exact lines verbatim, reproduce them exactly. "
    "Prefer structured output with short headings and bullet points where helpful. "
    "Avoid fluff and avoid 'vibes'; justify actions with explicit rules. "
    "Keep replies concise (aim for < 1,800 characters unless the user explicitly requests more)."
)


ENV_SNAPSHOT_ALLOWLIST = (
    "MICRO_AGENT_MODEL",
    "LIVE_LAMBDA_URL",
    "LIVE_FUNCTION_URL",
    "MEMORY_AGENT_URL",
    "AWS_REGION",
    "COEFFICIENTS_PRESET",
    "SEMANTIC_BACKEND",
    "SEMANTIC_SEARCH_SCOPE",
    "GRAPH_ENABLED",
    "GRAPH_VECTOR_INDEX_ENABLED",
    "RESPONSE_BUDGET_BYTES",
)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _safe_env_snapshot() -> Dict[str, str]:
    snap: Dict[str, str] = {}
    for name in ENV_SNAPSHOT_ALLOWLIST:
        val = os.getenv(name)
        if val is not None and val != "":
            snap[name] = val
    return snap


def _git_sha() -> Optional[str]:
    try:
        proc = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
        )
    except Exception:
        return None
    sha = (proc.stdout or "").strip()
    return sha or None


def _transcript_key(root_session_id: str, session_id: str) -> str:
    return f"sessions/{root_session_id}/{session_id}.log.jsonl"


def _write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a golden conversation artefact.")
    parser.add_argument("--scenario", default="nvda_desk_v1", help="Scenario name to run.")
    parser.add_argument(
        "--output-dir",
        default="golden_sets",
        help="Directory to write JSONL + manifest (default: golden_sets).",
    )
    parser.add_argument(
        "--output-base",
        default="golden_nvda_desk_v1",
        help="Base filename (without extension) for JSONL + manifest.",
    )
    parser.add_argument(
        "--max-turns",
        type=int,
        default=None,
        help="Run only the first N turns (default: run full scenario).",
    )
    parser.add_argument(
        "--attempts",
        type=int,
        default=3,
        help="Number of full-run attempts before failing (default: 3).",
    )
    parser.add_argument(
        "--attempt-backoff-seconds",
        type=float,
        default=5.0,
        help="Seconds to sleep between failed attempts (default: 5.0).",
    )
    parser.add_argument(
        "--turn-sleep-seconds",
        type=float,
        default=0.0,
        help="Seconds to sleep between turns (default: 0.0).",
    )
    parser.add_argument(
        "--root-session-id",
        default=None,
        help="Override root_session_id (default: golden-nvda-desk-<uuid>).",
    )
    parser.add_argument(
        "--session-id",
        default=None,
        help="Override session_id (default: same as root_session_id).",
    )
    parser.add_argument(
        "--max-output-tokens",
        type=int,
        default=1100,
        help="Responses API max_output_tokens for assistant replies (default: 1100).",
    )
    parser.add_argument(
        "--timeout-seconds",
        type=int,
        default=90,
        help="Timeout for /turn HTTP calls (default: 90).",
    )
    parser.add_argument(
        "--no-flush-persist",
        action="store_true",
        help="Skip final /turn flush that persists the last assistant message to S3.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite output files if they already exist.",
    )
    args = parser.parse_args()

    if args.attempts <= 0:
        print("ERROR: --attempts must be > 0.")
        return 4
    if (args.root_session_id or args.session_id) and args.attempts != 1:
        print("ERROR: --attempts must be 1 when --root-session-id/--session-id are provided.")
        return 4
    if args.turn_sleep_seconds < 0:
        print("ERROR: --turn-sleep-seconds must be >= 0.")
        return 4
    if args.attempt_backoff_seconds < 0:
        print("ERROR: --attempt-backoff-seconds must be >= 0.")
        return 4

    load_env()

    try:
        function_url = resolve_function_url()
    except TurnClientError as exc:
        print(f"ERROR: {exc}")
        return 4

    scenario = get_scenario(args.scenario)
    if not scenario:
        print(f"ERROR: scenario is empty: {args.scenario!r}")
        return 4

    max_turns = len(scenario)
    if args.max_turns is not None:
        if args.max_turns <= 0:
            print("ERROR: --max-turns must be > 0 when provided.")
            return 4
        max_turns = min(max_turns, args.max_turns)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    jsonl_path = out_dir / f"{args.output_base}.jsonl"
    manifest_path = out_dir / f"{args.output_base}.manifest.json"

    for path in (jsonl_path, manifest_path):
        if path.exists() and not args.overwrite:
            print(f"ERROR: output exists: {path} (use --overwrite to replace)")
            return 2

    git_sha = _git_sha()

    for attempt in range(1, args.attempts + 1):
        root_session_id = args.root_session_id or f"golden-nvda-desk-{uuid.uuid4().hex}"
        session_id = args.session_id or root_session_id
        transcript_key = _transcript_key(root_session_id, session_id)

        tmp_id = uuid.uuid4().hex
        jsonl_tmp = out_dir / f".{args.output_base}.{tmp_id}.jsonl.tmp"
        manifest_tmp = out_dir / f".{args.output_base}.{tmp_id}.manifest.json.tmp"

        try:
            agent = MicroAgent(
                root_session_id=root_session_id,
                session_id=session_id,
                scenario_name=args.scenario,
                function_url=function_url,
                instructions=NVDA_DESK_INSTRUCTIONS,
                max_output_tokens=args.max_output_tokens,
                timeout_seconds=args.timeout_seconds,
            )

            with jsonl_tmp.open("w", encoding="utf-8") as handle:
                for idx, turn in enumerate(scenario[:max_turns], start=1):
                    user_message = turn["user"]
                    ts = _utc_now_iso()
                    result = agent.step(user_message)
                    body = result.turn_response

                    telemetry = body.get("memory_telemetry") or {}
                    semantic_hits = body.get("semantic_hits") or []
                    graph_facts = body.get("graph_memory_facts") or []
                    windows = body.get("rehydrated_s3_windows") or []

                    line: Dict[str, Any] = {
                        "timestamp_utc": ts,
                        "root_session_id": root_session_id,
                        "session_id": session_id,
                        "turn_index": idx,
                        "scenario_name": args.scenario,
                        "user_message": user_message,
                        "assistant_text": result.assistant_text,
                        "model_used": result.model_used,
                        "turn_http_status": result.http_status,
                        "persisted_last_turn": body.get("persisted_last_turn"),
                        "bytes_total": body.get("bytes_total"),
                        "response_truncated": body.get("response_truncated"),
                        "memory_telemetry": telemetry,
                        "semantic_hits_count": (
                            len(semantic_hits) if isinstance(semantic_hits, list) else None
                        ),
                        "graph_memory_facts_count": (
                            len(graph_facts) if isinstance(graph_facts, list) else None
                        ),
                        "rehydrated_windows_count": (
                            len(windows) if isinstance(windows, list) else None
                        ),
                        "transcript_key": transcript_key,
                    }
                    handle.write(json.dumps(line, ensure_ascii=False) + "\n")

                    if args.turn_sleep_seconds:
                        time.sleep(args.turn_sleep_seconds)

            flush_ran = not args.no_flush_persist
            flush_http_status: Optional[int] = None
            flush_persisted_last_turn: Optional[bool] = None
            if flush_ran:
                payload = {
                    "root_session_id": root_session_id,
                    "session_id": session_id,
                    "last_user_message": agent.last_user_message,
                    "last_assistant_message": agent.last_assistant_message,
                    "current_user_message": "flush persist (end of golden run)",
                }
                flush = post_turn(function_url, payload, timeout=args.timeout_seconds)
                flush_http_status = int(flush.get("status", 0))
                flush_body = flush.get("body") or {}
                if isinstance(flush_body, dict):
                    flush_persisted_last_turn = flush_body.get("persisted_last_turn")
                if flush_http_status != 200 or flush_persisted_last_turn is not True:
                    raise RuntimeError(
                        f"Flush persist failed (status={flush_http_status}, "
                        f"persisted_last_turn={flush_persisted_last_turn})"
                    )

            manifest: Dict[str, Any] = {
                "git_sha": git_sha,
                "generated_at_utc": _utc_now_iso(),
                "scenario_name": args.scenario,
                "model_configured": agent.model_name,
                "assistant_instructions": agent.instructions,
                "function_url": function_url,
                "root_session_id": root_session_id,
                "session_id": session_id,
                "transcript_key": transcript_key,
                "env_snapshot": _safe_env_snapshot(),
                "runner": {
                    "max_turns": max_turns,
                    "max_output_tokens": args.max_output_tokens,
                    "timeout_seconds": args.timeout_seconds,
                    "flush_persist_ran": flush_ran,
                    "flush_http_status": flush_http_status,
                    "flush_persisted_last_turn": flush_persisted_last_turn,
                    "attempt": attempt,
                    "attempts_total": args.attempts,
                },
            }
            _write_json(manifest_tmp, manifest)

            jsonl_tmp.replace(jsonl_path)
            manifest_tmp.replace(manifest_path)

            print(f"Wrote JSONL: {jsonl_path}")
            print(f"Wrote manifest: {manifest_path}")
            print(f"root_session_id={root_session_id}")
            print(f"session_id={session_id}")
            print(f"transcript_key={transcript_key}")
            return 0
        except Exception as exc:
            jsonl_tmp.unlink(missing_ok=True)
            manifest_tmp.unlink(missing_ok=True)
            if attempt >= args.attempts:
                print(f"ERROR: golden run failed after {attempt} attempt(s): {exc}")
                return 1
            print(f"WARNING: attempt {attempt} failed: {exc}")
            if args.attempt_backoff_seconds:
                time.sleep(args.attempt_backoff_seconds)
            continue


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
