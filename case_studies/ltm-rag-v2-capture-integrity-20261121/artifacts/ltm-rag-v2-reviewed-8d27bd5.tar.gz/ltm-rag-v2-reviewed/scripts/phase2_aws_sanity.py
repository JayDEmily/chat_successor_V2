from __future__ import annotations

from app.config import load_settings
from app.handler import handle_post, handle_pre
from app.models import PostPhaseRequest, PrePhaseRequest


def main() -> None:
    settings = load_settings()
    if settings.semantic_backend != "none":
        raise SystemExit("SEMANTIC_BACKEND must be 'none' for this Phase 2 sanity check.")

    root_session_id = "phase2-root-1"
    session_id = "phase2-session-1"
    user_message = "Hello from Phase 2 test"
    assistant_message = "Phase 2 response"

    print(
        f"Using AWS region={settings.aws_region}, bucket={settings.transcript_bucket}, table={settings.state_table}, backend={settings.semantic_backend}"
    )

    post_req = PostPhaseRequest(
        root_session_id=root_session_id,
        session_id=session_id,
        user_message=user_message,
        assistant_message=assistant_message,
    )
    post_resp = handle_post(post_req)

    pre_req = PrePhaseRequest(
        root_session_id=root_session_id,
        session_id=session_id,
        user_message="Phase 2",
    )
    pre_resp = handle_pre(pre_req)

    print(
        f"POST ok={post_resp.ok}, PRE short_summary='{pre_resp.short_summary}', "
        f"recent_events_count={len(pre_resp.recent_events)}, semantic_hits_count={len(pre_resp.semantic_hits)}"
    )
    s3_key = f"sessions/{root_session_id}/{session_id}.log.jsonl"
    print(
        f"S3 key: {s3_key} (bucket: {settings.transcript_bucket}); "
        f"Dynamo PK/SK: ({root_session_id}, {session_id}) in table {settings.state_table}"
    )


if __name__ == "__main__":
    main()
