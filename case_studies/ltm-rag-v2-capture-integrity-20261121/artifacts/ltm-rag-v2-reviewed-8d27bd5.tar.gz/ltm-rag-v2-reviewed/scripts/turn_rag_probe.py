"""Deterministic live probe to prove semantic + graph RAG activation via /turn.

Phases:
1) Seed assistant messages with stable facts (semantic index is assistant-only).
2) Ask memory-dependent questions and assert semantic_search_ran + hit matches.
3) Optionally poll for graph facts (when enabled or explicitly required).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import requests


ENV_URL_KEYS = ("LIVE_LAMBDA_URL", "LIVE_FUNCTION_URL", "MEMORY_AGENT_URL")

SEED_TURNS = [
    {
        "user": "Please capture our runtime and language preferences clearly.",
        "assistant": (
            "Decision: PYTHON_VERSION = 3.12.3.\n"
            "Config: AWS_REGION = ap-southeast-2.\n"
            "Preference: Use Australian English in all documentation and replies."
        ),
    },
    {
        "user": "Document the response budget and semantic backend choices.",
        "assistant": (
            "Config: RESPONSE_BUDGET_BYTES = 200000.\n"
            "Config: SEMANTIC_BACKEND = openai.\n"
            "I'll keep Australian English spelling consistent."
        ),
    },
    {
        "user": "Note the service identity as well for graph extraction.",
        "assistant": (
            "Service: Lambda function name is memory-agent.\n"
            "Reminder: PYTHON_VERSION = 3.12.3 and AWS_REGION = ap-southeast-2."
        ),
    },
]

SEMANTIC_QUESTIONS = [
    {
        "label": "python_version",
        "prompt": "What python version did we decide on?",
        "expected": "3.12.3",
        "assistant": "We locked in PYTHON_VERSION = 3.12.3 for this project.",
    },
    {
        "label": "response_budget",
        "prompt": "What config value is RESPONSE_BUDGET_BYTES set to?",
        "expected": "200000",
        "assistant": "RESPONSE_BUDGET_BYTES stays at 200000 with SEMANTIC_BACKEND openai.",
    },
    {
        "label": "aws_region",
        "prompt": "What AWS region are we using?",
        "expected": "ap-southeast-2",
        "assistant": "We're anchored in AWS_REGION ap-southeast-2 and using Australian English.",
    },
]

GRAPH_POLL_PROMPT = "Confirm our python version and region from graph memory."
GRAPH_ASSISTANT = "Graph check: python 3.12.3 in ap-southeast-2 for memory-agent."


class ProtocolError(RuntimeError):
    """Raised when HTTP or response parsing fails."""


@dataclass
class ProbeConfig:
    function_url: str
    root_session_id: str
    session_id: str
    poll_seconds: int
    poll_interval: int
    require_graph: bool
    policy: Optional[str] = None
    timeout: int = 90


@dataclass
class ProbeResult:
    root_session_id: str
    session_id: str
    semantic_ok: bool
    semantic_matches: Dict[str, bool]
    semantic_evidence: Dict[str, str]
    graph_ok: bool
    graph_matches: Dict[str, bool]
    graph_not_ready: bool
    last_memory_telemetry: Optional[Dict[str, Any]]
    bytes_total: Optional[int]
    response_truncated: Optional[bool]


def _env_true(val: Optional[str]) -> bool:
    return str(val).lower() in {"1", "true", "yes", "y", "on"}


def resolve_function_url(cli_arg: Optional[str]) -> str:
    """Return the function URL from CLI or env, raising if missing."""
    if cli_arg:
        return cli_arg.rstrip("/")
    for key in ENV_URL_KEYS:
        val = os.getenv(key)
        if val:
            return val.rstrip("/")
    raise ProtocolError("Function URL missing; set --url or LIVE_LAMBDA_URL/LIVE_FUNCTION_URL/MEMORY_AGENT_URL")


def _post_turn(function_url: str, payload: Dict[str, Any], timeout: int) -> Dict[str, Any]:
    url = function_url.rstrip("/") + "/turn"
    try:
        resp = requests.post(url, json=payload, timeout=timeout)
    except requests.RequestException as exc:  # pragma: no cover - network failure path
        raise ProtocolError(f"Request to {url} failed: {exc}") from exc
    if resp.status_code != 200:
        raise ProtocolError(f"/turn returned {resp.status_code}: {resp.text}")
    try:
        return resp.json()
    except json.JSONDecodeError as exc:
        raise ProtocolError(f"/turn response was not JSON: {resp.text}") from exc


def _extract_memory_telemetry(body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    telemetry = body.get("memory_telemetry")
    if isinstance(telemetry, dict):
        return telemetry
    return None


def _match_in_hits(hits: Any, needle: str) -> Tuple[bool, str]:
    """Return (matched?, sample_text)."""
    if not isinstance(hits, list):
        return False, ""
    for hit in hits:
        text = ""
        if isinstance(hit, dict):
            text = str(hit.get("text") or "")
        else:
            text = str(hit)
        if needle in text:
            return True, text
    return False, ""


def _graph_matches(facts: Any, expected: Dict[str, str]) -> Dict[str, bool]:
    matches = {label: False for label in expected}
    if not isinstance(facts, list):
        return matches
    for fact in facts:
        blob = json.dumps(fact, default=str) if isinstance(fact, dict) else str(fact)
        for label, needle in expected.items():
            if needle in blob:
                matches[label] = True
    return matches


def run_probe(config: ProbeConfig) -> ProbeResult:
    last_user: Optional[str] = None
    last_assistant: Optional[str] = None
    last_memory_telemetry: Optional[Dict[str, Any]] = None
    bytes_total: Optional[int] = None
    response_truncated: Optional[bool] = None

    def _call_turn(current_user_message: str, next_assistant: str) -> Dict[str, Any]:
        nonlocal last_user, last_assistant, last_memory_telemetry, bytes_total, response_truncated
        payload: Dict[str, Any] = {
            "root_session_id": config.root_session_id,
            "session_id": config.session_id,
            "last_user_message": last_user,
            "last_assistant_message": last_assistant,
            "current_user_message": current_user_message,
        }
        if config.policy:
            payload["policy"] = config.policy
        body = _post_turn(config.function_url, payload, timeout=config.timeout)
        last_memory_telemetry = _extract_memory_telemetry(body)
        if "bytes_total" in body:
            bytes_total = body.get("bytes_total")
        if "response_truncated" in body:
            response_truncated = body.get("response_truncated")
        last_user = current_user_message
        last_assistant = next_assistant
        return body

    graph_hint = _env_true(os.getenv("GRAPH_ENABLED")) or _env_true(os.getenv("GRAPH_MEMORY_ENABLED"))

    for turn in SEED_TURNS:
        body = _call_turn(turn["user"], turn["assistant"])
        telemetry = _extract_memory_telemetry(body)
        if telemetry and telemetry.get("graph_read_ran"):
            graph_hint = True
        if body.get("graph_memory_facts"):
            graph_hint = True

    semantic_matches: Dict[str, bool] = {}
    semantic_evidence: Dict[str, str] = {}
    semantic_ok = True
    last_semantic_body: Optional[Dict[str, Any]] = None

    for question in SEMANTIC_QUESTIONS:
        body = _call_turn(question["prompt"], question["assistant"])
        last_semantic_body = body
        telemetry = _extract_memory_telemetry(body)
        if telemetry and telemetry.get("graph_read_ran"):
            graph_hint = True
        if body.get("graph_memory_facts"):
            graph_hint = True
        hits = body.get("semantic_hits")
        matched, sample = _match_in_hits(hits, question["expected"])
        semantic_evidence[question["label"]] = sample
        ok = bool(telemetry) and bool(telemetry.get("semantic_search_ran")) and isinstance(hits, list) and len(hits) > 0 and matched
        semantic_matches[question["label"]] = ok
        semantic_ok = semantic_ok and ok

    graph_matches = {"python_version": False, "aws_region": False}
    graph_ok = False
    graph_not_ready = False

    should_poll_graph = config.require_graph or graph_hint
    if should_poll_graph:
        expected = {"python_version": "3.12.3", "aws_region": "ap-southeast-2"}
        deadline = time.time() + config.poll_seconds
        while True:
            body = _call_turn(GRAPH_POLL_PROMPT, GRAPH_ASSISTANT)
            telemetry = _extract_memory_telemetry(body)
            if telemetry and telemetry.get("graph_read_ran"):
                graph_hint = True
            facts = body.get("graph_memory_facts") or []
            graph_matches = _graph_matches(facts, expected)
            if telemetry and telemetry.get("graph_read_ran") and all(graph_matches.values()):
                graph_ok = True
                last_semantic_body = body
                break
            if time.time() >= deadline:
                graph_not_ready = True
                last_semantic_body = body
                break
            time.sleep(config.poll_interval)

    if last_semantic_body:
        last_memory_telemetry = _extract_memory_telemetry(last_semantic_body) or last_memory_telemetry
        if "bytes_total" in last_semantic_body:
            bytes_total = last_semantic_body.get("bytes_total", bytes_total)
        if "response_truncated" in last_semantic_body:
            response_truncated = last_semantic_body.get("response_truncated", response_truncated)

    return ProbeResult(
        root_session_id=config.root_session_id,
        session_id=config.session_id,
        semantic_ok=semantic_ok,
        semantic_matches=semantic_matches,
        semantic_evidence=semantic_evidence,
        graph_ok=graph_ok,
        graph_matches=graph_matches,
        graph_not_ready=graph_not_ready,
        last_memory_telemetry=last_memory_telemetry,
        bytes_total=bytes_total,
        response_truncated=response_truncated,
    )


def _default_root() -> str:
    return f"rag-probe-{uuid.uuid4().hex}"


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Live RAG activation probe via /turn.")
    parser.add_argument("--url", help="Lambda Function URL (default from env LIVE_LAMBDA_URL/LIVE_FUNCTION_URL/MEMORY_AGENT_URL)")
    parser.add_argument("--root", default=None, help="root_session_id (default rag-probe-<uuid>)")
    parser.add_argument("--session", default=None, help="session_id (default = root)")
    parser.add_argument("--poll-seconds", type=int, default=60, help="Total seconds to poll for graph facts")
    parser.add_argument("--poll-interval", type=int, default=5, help="Seconds between graph polls")
    parser.add_argument("--require-graph", action="store_true", help="Fail if graph facts are not retrieved in time")
    parser.add_argument("--policy", default="auto", help='Memory policy to pass through (default "auto")')
    parser.add_argument("--timeout", type=int, default=90, help="Per-request timeout seconds")
    args = parser.parse_args(argv)

    try:
        function_url = resolve_function_url(args.url)
    except ProtocolError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 4

    root_session_id = args.root or _default_root()
    session_id = args.session or root_session_id

    print(f"Function URL: {function_url}")
    print(f"root_session_id: {root_session_id}")
    print(f"session_id:     {session_id}")
    print(f"require_graph:  {bool(args.require_graph)}")
    sys.stdout.flush()

    config = ProbeConfig(
        function_url=function_url,
        root_session_id=root_session_id,
        session_id=session_id,
        poll_seconds=args.poll_seconds,
        poll_interval=args.poll_interval,
        require_graph=bool(args.require_graph),
        policy=args.policy,
        timeout=args.timeout,
    )

    try:
        result = run_probe(config)
    except ProtocolError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 4

    summary = {
        "root_session_id": result.root_session_id,
        "session_id": result.session_id,
        "semantic_ok": result.semantic_ok,
        "semantic_matches": result.semantic_matches,
        "semantic_evidence": result.semantic_evidence,
        "graph_ok": result.graph_ok,
        "graph_matches": result.graph_matches,
        "graph_not_ready": result.graph_not_ready,
        "last_memory_telemetry": result.last_memory_telemetry,
        "bytes_total": result.bytes_total,
        "response_truncated": result.response_truncated,
    }
    print(json.dumps(summary))

    if not result.semantic_ok:
        return 2
    if config.require_graph and not result.graph_ok:
        return 3
    return 0


if __name__ == "__main__":  # pragma: no cover - manual live probe
    raise SystemExit(main())
