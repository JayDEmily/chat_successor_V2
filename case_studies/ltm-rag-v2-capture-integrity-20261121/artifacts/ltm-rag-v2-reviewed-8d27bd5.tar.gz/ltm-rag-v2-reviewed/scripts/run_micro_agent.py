from __future__ import annotations

import uuid

from app.micro_agent.env_loader import load_env
from app.micro_agent.micro_agent import MicroAgent
from app.micro_agent.scenarios import get_scenario, DEFAULT_SCENARIO_NAME
from app.micro_agent.turn_client import resolve_function_url, TurnClientError


def main() -> int:
    """Run the default micro-agent scenario and print per-step telemetry."""
    load_env()

    try:
        function_url = resolve_function_url()
    except TurnClientError as exc:
        print(f"ERROR: {exc}")
        return 4

    root_session_id = f"micro-agent-cli-{uuid.uuid4().hex}"
    session_id = root_session_id

    agent = MicroAgent(
        root_session_id=root_session_id,
        session_id=session_id,
        scenario_name=DEFAULT_SCENARIO_NAME,
        function_url=function_url,
    )

    scenario = get_scenario(DEFAULT_SCENARIO_NAME)

    for idx, turn in enumerate(scenario, start=1):
        result = agent.step(turn["user"])
        body = result.turn_response
        telemetry = body.get("memory_telemetry") or {}
        bytes_total = body.get("bytes_total")
        semantic_ran = telemetry.get("semantic_search_ran")
        graph_read_ran = telemetry.get("graph_read_ran")
        graph_hits = len(body.get("semantic_hits") or [])
        graph_facts = len(body.get("graph_memory_facts") or [])

        print(
            f"step={idx} status={result.http_status} "
            f"bytes_total={bytes_total} "
            f"semantic_search_ran={semantic_ran} "
            f"graph_read_ran={graph_read_ran} "
            f"semantic_hits={graph_hits} "
            f"graph_fact_count={graph_facts}"
        )
        print(f"assistant: {result.assistant_text[:200]}")
        print("-" * 60)

    return 0


if __name__ == "__main__":  # pragma: no cover - manual CLI runner
    raise SystemExit(main())

