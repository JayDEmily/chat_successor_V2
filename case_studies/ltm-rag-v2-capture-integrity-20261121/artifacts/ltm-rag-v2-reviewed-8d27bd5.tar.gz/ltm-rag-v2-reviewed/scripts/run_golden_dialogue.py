"""Generate Golden Set v2 as a real two-LLM dialogue (User-Agent + Desk-Agent).

Key properties:
  - Calls deployed /turn exactly once per user message (threads last_* pair).
  - Uses the /turn response as the "context pack" for BOTH agents every exchange.
  - Strict: fails fast on empty output or ACK (no silent fallbacks).
  - Writes artefacts atomically: staging dir -> final output dir.
  - Produces JSONL + manifest + human-readable dialogue.md + baseline metrics.json.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

from openai import OpenAI

from app.micro_agent.context_pack import build_context_pack
from app.micro_agent.env_loader import load_env
from app.micro_agent.golden_metrics import (
    ANCHORS_NVDA_DESK_V2,
    compute_baseline_metrics,
    compute_anchor_report,
    enforce_quality_gates,
)
from app.micro_agent.response_text import ResponseTextError, extract_output_text_strict
from app.micro_agent.turn_client import TurnClientError, post_turn, resolve_function_url


DEFAULT_MODEL = "gpt-5-nano"
GPT5_NANO_PREFIX = "gpt-5-nano"
GPT5_NANO_REASONING = {"effort": "low"}


DESK_AGENT_INSTRUCTIONS = (
    "You are a Tier-1 equities desk execution assistant for NVDA stock ONLY (no options). "
    "You must provide structured, rule-based, testable output with hard numbers (levels, "
    "risk limits, stops, sizing examples, scenario thresholds, catalyst rules). "
    "Use headings and bullets/tables where helpful. No fluff, no vibes. "
    "Within the first 2 turns, you MUST output an 'Execution Card' that contains these "
    "exact lines verbatim (do not alter spacing/case):\n"
    "PLAYBOOK_VERSION=NVDA_DESK_V2\n"
    "RISK_BUDGET_USD=7500\n"
    "REGIME_TAG=risk_off\n"
    "CATALYST=FOMC_2025_03\n"
    "RULE: if VWAP_reclaim then add\n"
    "LEVELS: buy=495.50 sell=510.25\n"
    "When asked to quote prior lines or an Execution Card, reproduce them verbatim. "
    "You must NOT reply with 'ACK'."
)


USER_AGENT_INSTRUCTIONS = (
    "You are an analytical trader refining a rules-based NVDA day-trading playbook. "
    "Each turn you must do at least one: ask a follow-up, challenge an assumption, add/change a constraint, "
    "or request an exact quote from earlier. "
    "Periodically force recall/rehydration by using recall cues like 'quote exactly what you said earlier'. "
    "Keep the user message realistic, specific, and not repetitive. "
    "Return ONLY the next user message; do not add preambles, labels, or multiple options."
)


ENV_SNAPSHOT_ALLOWLIST = (
    "GOLDEN_DIALOGUE_USER_MODEL",
    "GOLDEN_DIALOGUE_DESK_MODEL",
    "MICRO_AGENT_MODEL",
    "LIVE_LAMBDA_URL",
    "LIVE_FUNCTION_URL",
    "MEMORY_AGENT_URL",
    "AWS_REGION",
    "COEFFICIENTS_PRESET",
    "SEMANTIC_BACKEND",
    "SEMANTIC_SEARCH_SCOPE",
    "GRAPH_ENABLED",
    "GRAPH_VECTOR_INDEX_ENABLED",
    "RESPONSE_BUDGET_BYTES",
)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _git_sha() -> Optional[str]:
    try:
        proc = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
        )
    except Exception:
        return None
    sha = (proc.stdout or "").strip()
    return sha or None


def _safe_env_snapshot() -> Dict[str, str]:
    snap: Dict[str, str] = {}
    for name in ENV_SNAPSHOT_ALLOWLIST:
        val = os.getenv(name)
        if val is not None and val != "":
            snap[name] = val
    return snap


def _transcript_key(root_session_id: str, session_id: str) -> str:
    return f"sessions/{root_session_id}/{session_id}.log.jsonl"


def _write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        if not raw.strip():
            continue
        rows.append(json.loads(raw))
    return rows


def _bounded_recent_event_ids(turn_body: Dict[str, Any], max_ids: int = 20) -> List[str]:
    events = turn_body.get("recent_events") or []
    if not isinstance(events, list):
        return []
    ids: List[str] = []
    for evt in events[-max_ids:]:
        if not isinstance(evt, dict):
            continue
        event_id = evt.get("event_id")
        if isinstance(event_id, str) and event_id:
            ids.append(event_id)
    return ids


def _bounded_semantic_hit_metadata_keys(turn_body: Dict[str, Any], max_hits: int = 3) -> List[str]:
    hits = turn_body.get("semantic_hits") or []
    if not isinstance(hits, list):
        return []
    keys: set[str] = set()
    for hit in hits[:max_hits]:
        if not isinstance(hit, dict):
            continue
        meta = hit.get("metadata")
        if not isinstance(meta, dict):
            continue
        keys.update(str(k) for k in meta.keys())
    return sorted(keys)


def _bounded_rehydrated_window_sources(turn_body: Dict[str, Any], max_windows: int = 2) -> List[str]:
    windows = turn_body.get("rehydrated_s3_windows") or []
    if not isinstance(windows, list):
        return []
    sources: List[str] = []
    for window in windows[:max_windows]:
        if not isinstance(window, dict):
            continue
        source = window.get("source")
        if not isinstance(source, dict):
            continue
        key = source.get("transcript_key")
        bucket = source.get("bucket")
        if key and bucket:
            sources.append(f"{bucket}:{key}")
        elif key:
            sources.append(str(key))
    return sources


def _enforce_non_empty(text: str, *, label: str) -> str:
    cleaned = (text or "").strip()
    if not cleaned:
        raise ValueError(f"{label}: empty output")
    return cleaned


def _enforce_no_ack(text: str, *, label: str) -> str:
    cleaned = _enforce_non_empty(text, label=label)
    if cleaned.strip().upper() == "ACK":
        raise ValueError(f"{label}: ACK output is forbidden")
    return cleaned


def _post_turn_with_retry(
    function_url: str,
    payload: Dict[str, Any],
    *,
    timeout: int,
    label: str,
    attempts: int = 3,
) -> Dict[str, Any]:
    last_exc: Optional[Exception] = None
    for attempt in range(1, attempts + 1):
        try:
            turn_http = post_turn(function_url, payload, timeout=timeout)
            status = int(turn_http.get("status", 0))
            if status >= 500 and attempt < attempts:
                time.sleep(1 + attempt)
                continue
            return turn_http
        except TurnClientError as exc:
            last_exc = exc
            if attempt >= attempts:
                break
            time.sleep(1 + attempt)
            continue
    assert last_exc is not None
    raise TurnClientError(f"{label}: {last_exc}") from last_exc


def _call_responses(
    client: OpenAI,
    *,
    model: str,
    instructions: str,
    prompt: str,
    max_output_tokens: int,
    label: str,
) -> Tuple[str, str]:
    request_data: Dict[str, Any] = {
        "model": model,
        "instructions": instructions,
        "input": [
            {
                "role": "user",
                "content": [{"type": "input_text", "text": prompt}],
            }
        ],
        "max_output_tokens": max_output_tokens,
    }
    if model.startswith(GPT5_NANO_PREFIX):
        request_data["reasoning"] = GPT5_NANO_REASONING

    # Best-effort retry: transient OpenAI errors should not create partial golden artefacts.
    last_exc: Optional[Exception] = None
    for attempt in range(3):
        try:
            resp = client.responses.create(**request_data)
            text = extract_output_text_strict(resp, label=label)
            model_used = getattr(resp, "model", model) or model
            return text, str(model_used)
        except ResponseTextError as exc:
            last_exc = exc
            if attempt == 2:
                break
            time.sleep(1 + attempt)
        except Exception as exc:  # pragma: no cover - best-effort retry
            last_exc = exc
            if attempt == 2:
                break
            time.sleep(1 + attempt)
    assert last_exc is not None
    raise last_exc


def _desk_prompt(context_pack: str, user_message: str) -> str:
    return (
        "CONTEXT_PACK\n"
        "===========\n"
        f"{context_pack}\n"
        "CURRENT_USER_MESSAGE\n"
        "====================\n"
        f"{user_message}\n\n"
        "TASK\n"
        "====\n"
        "Answer the user as the Desk-Agent. Be structured and specific. "
        "If you refer to previously stated exact lines, quote them verbatim.\n"
    )


def _user_prompt(context_pack: str, last_desk_reply: str, turn_index: int) -> str:
    schedule_hint = ""
    if turn_index <= 2:
        schedule_hint = (
            "For turn 1–2, steer toward producing an Execution Card early (ask for it if missing).\n"
        )
    elif turn_index in {4, 5, 8, 12, 16}:
        schedule_hint = (
            "This turn MUST include a recall cue requesting a verbatim quote of earlier key lines.\n"
        )
    return (
        "CONTEXT_PACK\n"
        "===========\n"
        f"{context_pack}\n"
        "LAST_DESK_REPLY\n"
        "==============\n"
        f"{last_desk_reply}\n\n"
        "OBJECTIVE\n"
        "=========\n"
        "Refine a fictional, scenario-based NVDA day-trading playbook (NOT live market data). "
        "Ensure earlier commitments are tested via re-quotes and constraint changes.\n\n"
        "TASK\n"
        "====\n"
        f"{schedule_hint}"
        "Write the NEXT user message to send to /turn. It must be a single message.\n"
    )


@dataclass
class Exchange:
    turn_index: int
    timestamp_utc: str
    user_agent_text: str
    desk_agent_text: str
    model_used_user: str
    model_used_desk: str
    turn_http_status: int
    persisted_last_turn: Any
    bytes_total: Any
    response_truncated: Any
    memory_telemetry: Any
    semantic_hits_count: int
    rehydrated_windows_count: int
    graph_memory_facts_count: int
    recent_event_ids: List[str]
    semantic_hit_metadata_keys: List[str]
    rehydrated_window_sources: List[str]

    def to_json(self, *, root_session_id: str, session_id: str, transcript_key: str) -> Dict[str, Any]:
        return {
            "timestamp_utc": self.timestamp_utc,
            "root_session_id": root_session_id,
            "session_id": session_id,
            "turn_index": self.turn_index,
            "transcript_key": transcript_key,
            "user_agent_text": self.user_agent_text,
            "desk_agent_text": self.desk_agent_text,
            "model_used_user": self.model_used_user,
            "model_used_desk": self.model_used_desk,
            "http_status": self.turn_http_status,
            "persisted_last_turn": self.persisted_last_turn,
            "bytes_total": self.bytes_total,
            "response_truncated": self.response_truncated,
            "memory_telemetry": self.memory_telemetry,
            "semantic_hits_count": self.semantic_hits_count,
            "rehydrated_windows_count": self.rehydrated_windows_count,
            "graph_memory_facts_count": self.graph_memory_facts_count,
            "recent_event_ids": self.recent_event_ids,
            "semantic_hit_metadata_keys": self.semantic_hit_metadata_keys,
            "rehydrated_window_sources": self.rehydrated_window_sources,
        }


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate Golden Set v2 two-agent dialogue artefacts.")
    parser.add_argument("--exchanges", type=int, default=20, help="Number of exchanges (default: 20).")
    parser.add_argument(
        "--output-dir",
        default="golden_sets_v2",
        help="Output directory for committed artefacts (default: golden_sets_v2).",
    )
    parser.add_argument(
        "--output-base",
        default="golden_nvda_desk_v2",
        help="Base filename for artefacts (default: golden_nvda_desk_v2).",
    )
    parser.add_argument(
        "--max-user-tokens",
        type=int,
        default=600,
        help="Max output tokens for User-Agent (default: 600).",
    )
    parser.add_argument(
        "--max-desk-tokens",
        type=int,
        default=1100,
        help="Max output tokens for Desk-Agent (default: 1100).",
    )
    parser.add_argument(
        "--timeout-seconds",
        type=int,
        default=90,
        help="Timeout for /turn calls (default: 90).",
    )
    parser.add_argument(
        "--attempts",
        type=int,
        default=3,
        help="Full-run attempts before failing (default: 3).",
    )
    parser.add_argument(
        "--attempt-backoff-seconds",
        type=float,
        default=5.0,
        help="Seconds to sleep between failed attempts (default: 5.0).",
    )
    parser.add_argument(
        "--turn-sleep-seconds",
        type=float,
        default=0.0,
        help="Seconds to sleep between exchanges (default: 0.0).",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite output files if present.",
    )
    args = parser.parse_args()

    if os.getenv("LIVE_AGENT") != "1":
        print("ERROR: LIVE_AGENT=1 is required to run the v2 golden dialogue runner.")
        return 3
    if args.exchanges <= 0:
        print("ERROR: --exchanges must be > 0.")
        return 2
    if args.attempts <= 0:
        print("ERROR: --attempts must be > 0.")
        return 2
    if args.turn_sleep_seconds < 0:
        print("ERROR: --turn-sleep-seconds must be >= 0.")
        return 2

    load_env()
    if not os.getenv("OPENAI_API_KEY"):
        print("ERROR: OPENAI_API_KEY must be set.")
        return 3

    try:
        function_url = resolve_function_url()
    except TurnClientError as exc:
        print(f"ERROR: {exc}")
        return 4

    user_model = os.getenv("GOLDEN_DIALOGUE_USER_MODEL") or DEFAULT_MODEL
    desk_model = os.getenv("GOLDEN_DIALOGUE_DESK_MODEL") or DEFAULT_MODEL

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    jsonl_final = out_dir / f"{args.output_base}.jsonl"
    manifest_final = out_dir / f"{args.output_base}.manifest.json"
    dialogue_final = out_dir / f"{args.output_base}.dialogue.md"
    metrics_final = out_dir / f"{args.output_base}.metrics.json"

    for path in (jsonl_final, manifest_final, dialogue_final, metrics_final):
        if path.exists() and not args.overwrite:
            print(f"ERROR: output exists: {path} (use --overwrite to replace)")
            return 2

    client = OpenAI()
    git_sha = _git_sha()

    for attempt in range(1, args.attempts + 1):
        root_session_id = f"golden-nvda-desk-v2-{uuid.uuid4().hex}"
        session_id = root_session_id
        transcript_key = _transcript_key(root_session_id, session_id)

        staging_dir = out_dir / f".staging-{args.output_base}-{uuid.uuid4().hex}"
        staging_dir.mkdir(parents=True, exist_ok=False)
        jsonl_path = staging_dir / jsonl_final.name
        manifest_path = staging_dir / manifest_final.name
        dialogue_path = staging_dir / dialogue_final.name
        metrics_path = staging_dir / metrics_final.name

        exchanges: List[Exchange] = []
        last_user_message: Optional[str] = None
        last_assistant_message: Optional[str] = None
        last_turn_body: Dict[str, Any] = {}
        last_desk_reply: str = ""

        try:
            # Bootstrap: generate first user message from an empty context pack.
            bootstrap_context = build_context_pack({})
            first_user_msg, model_used_user = _call_responses(
                client,
                model=user_model,
                instructions=USER_AGENT_INSTRUCTIONS,
                prompt=_user_prompt(bootstrap_context, last_desk_reply, 1),
                max_output_tokens=args.max_user_tokens,
                label="User-Agent bootstrap",
            )
            user_message = _enforce_non_empty(first_user_msg, label="User-Agent")

            with jsonl_path.open("w", encoding="utf-8") as handle:
                for turn_index in range(1, args.exchanges + 1):
                    payload: Dict[str, Any] = {
                        "root_session_id": root_session_id,
                        "session_id": session_id,
                        "last_user_message": last_user_message,
                        "last_assistant_message": last_assistant_message,
                        "current_user_message": user_message,
                    }
                    turn_http = _post_turn_with_retry(
                        function_url,
                        payload,
                        timeout=args.timeout_seconds,
                        label=f"/turn exchange turn={turn_index}",
                    )
                    status = int(turn_http.get("status", 0))
                    body = turn_http.get("body") or {}
                    if status != 200 or not isinstance(body, dict):
                        raise TurnClientError(f"/turn returned HTTP {status}: {body}")

                    last_turn_body = body
                    context_pack = build_context_pack(body)

                    desk_text, model_used_desk = _call_responses(
                        client,
                        model=desk_model,
                        instructions=DESK_AGENT_INSTRUCTIONS,
                        prompt=_desk_prompt(context_pack, user_message),
                        max_output_tokens=args.max_desk_tokens,
                        label=f"Desk-Agent turn={turn_index}",
                    )
                    desk_reply = _enforce_no_ack(desk_text, label="Desk-Agent")

                    semantic_hits = body.get("semantic_hits") or []
                    windows = body.get("rehydrated_s3_windows") or []
                    facts = body.get("graph_memory_facts") or []
                    memory_telemetry = body.get("memory_telemetry") or {}
                    exchange = Exchange(
                        turn_index=turn_index,
                        timestamp_utc=_utc_now_iso(),
                        user_agent_text=user_message,
                        desk_agent_text=desk_reply,
                        model_used_user=model_used_user,
                        model_used_desk=model_used_desk,
                        turn_http_status=status,
                        persisted_last_turn=body.get("persisted_last_turn"),
                        bytes_total=body.get("bytes_total"),
                        response_truncated=body.get("response_truncated"),
                        memory_telemetry=memory_telemetry,
                        semantic_hits_count=len(semantic_hits) if isinstance(semantic_hits, list) else 0,
                        rehydrated_windows_count=len(windows) if isinstance(windows, list) else 0,
                        graph_memory_facts_count=len(facts) if isinstance(facts, list) else 0,
                        recent_event_ids=_bounded_recent_event_ids(body),
                        semantic_hit_metadata_keys=_bounded_semantic_hit_metadata_keys(body),
                        rehydrated_window_sources=_bounded_rehydrated_window_sources(body),
                    )
                    exchanges.append(exchange)
                    handle.write(
                        json.dumps(
                            exchange.to_json(
                                root_session_id=root_session_id,
                                session_id=session_id,
                                transcript_key=transcript_key,
                            ),
                            ensure_ascii=False,
                        )
                        + "\n"
                    )

                    last_user_message = user_message
                    last_assistant_message = desk_reply
                    last_desk_reply = desk_reply

                    if args.turn_sleep_seconds:
                        time.sleep(args.turn_sleep_seconds)

                    if turn_index == args.exchanges:
                        break

                    next_user_msg, model_used_user = _call_responses(
                        client,
                        model=user_model,
                        instructions=USER_AGENT_INSTRUCTIONS,
                        prompt=_user_prompt(context_pack, last_desk_reply, turn_index + 1),
                        max_output_tokens=args.max_user_tokens,
                        label=f"User-Agent turn={turn_index + 1}",
                    )
                    user_message = _enforce_non_empty(next_user_msg, label="User-Agent")

            # Flush persist: persist the final (user, assistant) pair.
            flush_payload: Dict[str, Any] = {
                "root_session_id": root_session_id,
                "session_id": session_id,
                "last_user_message": last_user_message,
                "last_assistant_message": last_assistant_message,
                "current_user_message": "flush persist (end of golden dialogue v2)",
            }
            flush = _post_turn_with_retry(
                function_url,
                flush_payload,
                timeout=args.timeout_seconds,
                label="/turn flush persist",
            )
            flush_status = int(flush.get("status", 0))
            flush_body = flush.get("body") or {}
            flush_persisted = (
                flush_status == 200
                and isinstance(flush_body, dict)
                and flush_body.get("persisted_last_turn") is True
            )
            if not flush_persisted:
                raise RuntimeError(
                    f"Flush persist failed (status={flush_status}, body={flush_body})"
                )

            # Gates + metrics
            rows = _read_jsonl(jsonl_path)

            # Ensure anchors appear early (first 2 exchanges).
            first_two = [r for r in rows if int(r.get("turn_index") or 0) <= 2]
            anchor_report_early = compute_anchor_report(first_two)
            missing_early = [a for a in ANCHORS_NVDA_DESK_V2 if not anchor_report_early.seen.get(a)]
            if missing_early:
                raise ValueError(f"Anchors missing in first 2 desk outputs: {missing_early}")

            enforce_quality_gates(rows)
            metrics = compute_baseline_metrics(rows)
            _write_json(metrics_path, metrics)

            # Dialogue.md
            md_lines: List[str] = []
            md_lines.append(f"# Golden NVDA Desk v2 Dialogue\n")
            md_lines.append(f"- generated_at_utc: `{_utc_now_iso()}`")
            md_lines.append(f"- git_sha: `{git_sha}`")
            md_lines.append(f"- function_url: `{function_url}`")
            md_lines.append(f"- root_session_id: `{root_session_id}`")
            md_lines.append(f"- session_id: `{session_id}`")
            md_lines.append(f"- transcript_key: `{transcript_key}`")
            md_lines.append(f"- user_model: `{user_model}`")
            md_lines.append(f"- desk_model: `{desk_model}`")
            md_lines.append("")

            for row in rows:
                ti = int(row.get("turn_index") or 0)
                user_txt = str(row.get("user_agent_text") or "")
                desk_txt = str(row.get("desk_agent_text") or "")
                telemetry = row.get("memory_telemetry") or {}
                semantic_ran = None
                graph_read = None
                if isinstance(telemetry, dict):
                    semantic_ran = telemetry.get("semantic_search_ran")
                    graph_read = telemetry.get("graph_read_ran")
                windows_count = int(row.get("rehydrated_windows_count") or 0)
                bytes_total = row.get("bytes_total")
                md_lines.append(f"## Turn {ti}\n")
                md_lines.append("**User-Agent**")
                md_lines.append("")
                md_lines.append(user_txt)
                md_lines.append("")
                md_lines.append("**Desk-Agent**")
                md_lines.append("")
                md_lines.append(desk_txt)
                md_lines.append("")
                md_lines.append(
                    f"_telemetry: semantic_search_ran={semantic_ran} "
                    f"graph_read_ran={graph_read} "
                    f"rehydrated_windows_count={windows_count} "
                    f"bytes_total={bytes_total}_"
                )
                md_lines.append("")

            dialogue_path.write_text("\n".join(md_lines).rstrip() + "\n", encoding="utf-8")

            manifest: Dict[str, Any] = {
                "git_sha": git_sha,
                "generated_at_utc": _utc_now_iso(),
                "function_url": function_url,
                "root_session_id": root_session_id,
                "session_id": session_id,
                "transcript_key": transcript_key,
                "models": {
                    "user_model_configured": user_model,
                    "desk_model_configured": desk_model,
                },
                "instructions": {
                    "user_agent": USER_AGENT_INSTRUCTIONS,
                    "desk_agent": DESK_AGENT_INSTRUCTIONS,
                },
                "runner": {
                    "exchanges": args.exchanges,
                    "max_user_tokens": args.max_user_tokens,
                    "max_desk_tokens": args.max_desk_tokens,
                    "timeout_seconds": args.timeout_seconds,
                    "gpt5_nano_reasoning_effort": GPT5_NANO_REASONING.get("effort"),
                    "strict_no_ack": True,
                    "strict_non_empty": True,
                    "atomic_writes": True,
                    "flush_persist_ran": True,
                    "flush_persist_ok": True,
                    "attempt": attempt,
                    "attempts_total": args.attempts,
                },
                "env_snapshot": _safe_env_snapshot(),
            }
            _write_json(manifest_path, manifest)

            # Atomic publish: only now touch final paths.
            jsonl_path.replace(jsonl_final)
            manifest_path.replace(manifest_final)
            dialogue_path.replace(dialogue_final)
            metrics_path.replace(metrics_final)
            staging_dir.rmdir()

            print(f"Wrote: {jsonl_final}")
            print(f"Wrote: {manifest_final}")
            print(f"Wrote: {dialogue_final}")
            print(f"Wrote: {metrics_final}")
            print(f"root_session_id={root_session_id}")
            print(f"transcript_key={transcript_key}")
            return 0
        except Exception as exc:
            # Clean up staging dir on failure (no partial artefacts published).
            for path in list(staging_dir.glob("*")):
                path.unlink(missing_ok=True)
            staging_dir.rmdir()

            if attempt >= args.attempts:
                print(f"ERROR: golden dialogue failed after {attempt} attempt(s): {exc}")
                return 1
            print(f"WARNING: attempt {attempt} failed: {exc}")
            time.sleep(args.attempt_backoff_seconds)
            continue

    return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
