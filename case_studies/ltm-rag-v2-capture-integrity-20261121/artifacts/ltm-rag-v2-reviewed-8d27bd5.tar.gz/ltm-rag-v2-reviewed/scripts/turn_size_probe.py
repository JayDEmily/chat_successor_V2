"""Scripted /turn ladder to surface response sizes and failure thresholds.

Usage example:

    .venv/bin/python scripts/turn_size_probe.py --turns 30 --user-bytes 13000 --assistant-bytes 200

Defaults point at the deployed Function URL; override via --function-url or env
LIVE_LAMBDA_URL / LIVE_FUNCTION_URL / MEMORY_AGENT_URL.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import uuid
from typing import Any, Dict, Optional

import requests


DEFAULT_FUNCTION_URL = (
    os.getenv("LIVE_LAMBDA_URL")
    or os.getenv("LIVE_FUNCTION_URL")
    or os.getenv("MEMORY_AGENT_URL")
    or "https://example.invalid"
)


def _fixed_payload(label: str, target_bytes: int) -> str:
    """Return a deterministic string of roughly target_bytes length."""
    if target_bytes <= 0:
        return ""
    block = (label + " ") * 32
    repeated = (block * ((target_bytes // len(block)) + 2))[:target_bytes]
    return repeated


def _post(function_url: str, path: str, body: Dict[str, Any], timeout: int) -> requests.Response:
    url = function_url.rstrip("/") + path
    return requests.post(url, json=body, timeout=timeout)


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Drive /turn until responses grow large.")
    parser.add_argument("--function-url", default=DEFAULT_FUNCTION_URL, help="Lambda Function URL base")
    parser.add_argument("--turns", type=int, default=30, help="Number of /turn calls to attempt")
    parser.add_argument("--user-bytes", type=int, default=13000, help="Approx bytes in each synthetic user message")
    parser.add_argument(
        "--assistant-bytes",
        type=int,
        default=200,
        help="Approx bytes in each synthetic assistant reply (persisted next call)",
    )
    parser.add_argument("--timeout", type=int, default=90, help="Per-request timeout seconds")
    parser.add_argument("--session-id", help="Optional fixed session_id/root_session_id")
    args = parser.parse_args(argv)

    session_id = args.session_id or f"turn-size-{uuid.uuid4().hex}"
    last_user: Optional[str] = None
    last_assistant: Optional[str] = None

    print(f"Function URL: {args.function_url}")
    print(f"Session ID:   {session_id}")
    print(f"User bytes:   ~{args.user_bytes}, assistant bytes: ~{args.assistant_bytes}")
    print(f"Target turns: {args.turns}")
    sys.stdout.flush()

    for turn in range(1, args.turns + 1):
        current_user = f"[turn {turn}] " + _fixed_payload("user", args.user_bytes)
        resp = _post(
            args.function_url,
            "/turn",
            {
                "root_session_id": session_id,
                "session_id": session_id,
                "last_user_message": last_user,
                "last_assistant_message": last_assistant,
                "current_user_message": current_user,
            },
            timeout=args.timeout,
        )
        body_text = resp.text
        body_size = len(body_text.encode("utf-8"))
        try:
            body = resp.json()
        except json.JSONDecodeError:
            body = {"raw": body_text}

        recent_events = body.get("recent_events") if isinstance(body, dict) else None
        events_count = len(recent_events) if isinstance(recent_events, list) else 0
        persisted = body.get("persisted_last_turn") if isinstance(body, dict) else None
        response_truncated = body.get("response_truncated") if isinstance(body, dict) else None
        bytes_total = body.get("bytes_total") if isinstance(body, dict) else None

        print(
            f"turn={turn:02d} status={resp.status_code} persisted={persisted} "
            f"recent_events={events_count} response_bytes={body_size} "
            f"bytes_total_field={bytes_total} truncated={response_truncated}"
        )
        if resp.status_code != 200:
            print(f"Stopping early due to status {resp.status_code}: {body}")
            return 1

        # Prepare the next persisted pair.
        last_user = current_user
        last_assistant = f"[assistant {turn}] " + _fixed_payload("assistant", args.assistant_bytes)

        # Be gentle with the backend.
        time.sleep(1.0)

    return 0


if __name__ == "__main__":  # pragma: no cover - manual diagnostic script
    raise SystemExit(main())
