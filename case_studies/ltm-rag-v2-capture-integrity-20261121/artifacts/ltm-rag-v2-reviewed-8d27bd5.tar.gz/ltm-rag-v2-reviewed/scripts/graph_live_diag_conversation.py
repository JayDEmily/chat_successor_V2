"""Live diagnostic conversation to validate graph memory readiness.

Run with the repo virtualenv interpreter:

    .venv/bin/python scripts/graph_live_diag_conversation.py

Or use the helper that resolves the correct interpreter automatically:

    ./scripts/venv_python.sh scripts/graph_live_diag_conversation.py
"""

from __future__ import annotations

import json
import os
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence

import boto3
import requests
from boto3.dynamodb.conditions import Key
from botocore.exceptions import BotoCoreError, ClientError


ROOT_ID = "diag-root-graph-1"
SESSION_ID = "diag-session-graph-1"
POLL_USER_MESSAGE = "Diagnostic poll for graph readiness"
HTTP_TIMEOUT_SECONDS = 10
MAX_HTTP_ATTEMPTS = 3
HTTP_BACKOFF_SECONDS = [1, 2]


@dataclass
class Turn:
    turn_number: int
    user_message: str
    assistant_message: str


TURNS: List[Turn] = [
    Turn(
        turn_number=1,
        user_message="Hi, I want to talk about how this project is configured.",
        assistant_message="Sure - let's look at how the project is configured.",
    ),
    Turn(
        turn_number=2,
        user_message="Right now we are using Python 3.10 for this project.",
        assistant_message="Understood - for now the project is using Python 3.10.",
    ),
    Turn(
        turn_number=3,
        user_message="Actually, let's standardise on Python 3.11.9 going forward.",
        assistant_message="Got it - the project standard Python version is now 3.11.9.",
    ),
    Turn(
        turn_number=4,
        user_message="What Python version did we settle on for this project?",
        assistant_message="",  # will be filled based on graph facts
    ),
    Turn(
        turn_number=5,
        user_message="On second thoughts, change it again to Python 3.12.7.",
        assistant_message="Acknowledged - updating the project Python version to 3.12.7.",
    ),
]


def fail(message: str) -> None:
    print(message, file=sys.stderr)
    sys.exit(1)


def ensure_env() -> Dict[str, str]:
    memory_agent_url = os.environ.get("MEMORY_AGENT_URL")
    if not memory_agent_url:
        fail("ERROR: MEMORY_AGENT_URL missing.")
    aws_region = os.environ.get("AWS_REGION", "ap-southeast-2")
    memory_nodes_table = os.environ.get("MEMORY_NODES_TABLE", "memory-nodes")
    return {
        "MEMORY_AGENT_URL": memory_agent_url.rstrip("/"),
        "AWS_REGION": aws_region,
        "MEMORY_NODES_TABLE": memory_nodes_table,
    }


def parse_json_response(response: requests.Response, label: str) -> Dict[str, Any]:
    content_type = response.headers.get("Content-Type", "").lower()
    if "application/json" not in content_type:
        fail(f"ERROR: {label} response malformed or missing required keys.")
    try:
        return response.json()
    except ValueError:
        fail(f"ERROR: {label} response malformed or missing required keys.")
    return {}


def validate_pre_response_schema(data: Dict[str, Any], label: str) -> None:
    required_keys = {"short_summary", "recent_events", "semantic_hits"}
    if not all(key in data for key in required_keys):
        fail(f"ERROR: {label} response malformed or missing required keys.")

    if not isinstance(data.get("recent_events"), list) or not isinstance(
        data.get("semantic_hits"), list
    ):
        fail(f"ERROR: {label} schema mismatch with expected contract.")

    if "graph_memory_facts" in data and not isinstance(data.get("graph_memory_facts"), list):
        fail(f"ERROR: {label} schema mismatch with expected contract.")

    if "graph_memory_history" in data and not isinstance(
        data.get("graph_memory_history"), dict
    ):
        fail(f"ERROR: {label} schema mismatch with expected contract.")


def validate_post_response_schema(data: Dict[str, Any], label: str) -> None:
    if not isinstance(data, dict):
        fail(f"ERROR: {label} response malformed or missing required keys.")

    required_keys = {"short_summary", "recent_events", "semantic_hits"}
    if all(key in data for key in required_keys):
        validate_pre_response_schema(data, label)
        return

    if "ok" in data:
        return

    fail(f"ERROR: {label} response malformed or missing required keys.")


def perform_request(url: str, payload: Dict[str, Any], label: str, schema: str) -> Dict[str, Any]:
    last_exception: Optional[Exception] = None
    for attempt in range(MAX_HTTP_ATTEMPTS):
        try:
            response = requests.post(url, json=payload, timeout=HTTP_TIMEOUT_SECONDS)
        except requests.RequestException as exc:
            last_exception = exc
            if attempt < MAX_HTTP_ATTEMPTS - 1:
                time.sleep(HTTP_BACKOFF_SECONDS[min(attempt, len(HTTP_BACKOFF_SECONDS) - 1)])
                continue
            fail(f"ERROR: {label} request failed after retries: {exc}")

        if response.status_code >= 500:
            if attempt < MAX_HTTP_ATTEMPTS - 1:
                time.sleep(HTTP_BACKOFF_SECONDS[min(attempt, len(HTTP_BACKOFF_SECONDS) - 1)])
                continue
            fail(f"ERROR: {label} request failed after retries")

        if not (200 <= response.status_code < 300):
            fail(f"ERROR: {label} returned {response.status_code}")

        data = parse_json_response(response, label)
        if schema == "pre":
            validate_pre_response_schema(data, label)
        elif schema == "post":
            validate_post_response_schema(data, label)
        return data

    if last_exception:
        fail(f"ERROR: {label} request failed after retries: {last_exception}")
    fail(f"ERROR: {label} request failed after retries")
    return {}


def build_diag_block(
    turn_number: int, pre_data: Dict[str, Any], root_session_id: str, session_id: str
) -> Dict[str, Any]:
    recent_events: List[Dict[str, Any]] = pre_data.get("recent_events", [])
    semantic_hits: List[Dict[str, Any]] = pre_data.get("semantic_hits", [])
    graph_memory_facts: List[Dict[str, Any]] = pre_data.get("graph_memory_facts", []) or []
    graph_memory_history: Dict[str, Any] = pre_data.get("graph_memory_history", {}) or {}

    recent_tail = [
        {"role": ev.get("role"), "content": ev.get("content")}
        for ev in recent_events[-2:]
        if isinstance(ev, dict)
    ]

    semantic_hits_text: List[str] = []
    for hit in semantic_hits:
        if isinstance(hit, dict) and "text" in hit:
            semantic_hits_text.append(hit["text"])
        if len(semantic_hits_text) >= 2:
            break

    truncated_facts: List[Dict[str, Any]] = []
    for fact in graph_memory_facts:
        if not isinstance(fact, dict):
            continue
        truncated = {
            "entity": fact.get("entity"),
            "type": fact.get("type"),
            "fact": fact.get("fact"),
            "state": fact.get("state"),
            "updated_at": fact.get("updated_at"),
        }
        if "source_event_ids" in fact:
            truncated["source_event_ids"] = fact.get("source_event_ids")
        truncated_facts.append(truncated)

    truncated_history: Dict[str, Any] = {}
    if isinstance(graph_memory_history, dict):
        for entity, history_entries in graph_memory_history.items():
            if not isinstance(history_entries, Sequence):
                continue
            entity_history: List[Dict[str, Any]] = []
            for entry in history_entries:
                if not isinstance(entry, dict):
                    continue
                entity_history.append(
                    {
                        "fact": entry.get("fact"),
                        "state": entry.get("state"),
                        "valid_from": entry.get("valid_from"),
                        "valid_to": entry.get("valid_to"),
                        "history_reason": entry.get("history_reason"),
                    }
                )
            truncated_history[entity] = entity_history

    diag = {
        "diag": {
            "turn": turn_number,
            "root_session_id": root_session_id,
            "session_id": session_id,
            "short_summary_present": bool(pre_data.get("short_summary")),
            "recent_events_count": len(recent_events),
            "recent_events_tail": recent_tail,
            "semantic_hits_text": semantic_hits_text,
            "graph_memory_facts": truncated_facts,
            "graph_memory_history": truncated_history,
        }
    }
    return diag


def print_diag(diag_block: Dict[str, Any]) -> None:
    print(json.dumps(diag_block, indent=2))


def choose_turn4_response(graph_memory_facts: List[Dict[str, Any]]) -> str:
    matches: List[Dict[str, Any]] = []
    for fact in graph_memory_facts:
        if not isinstance(fact, dict):
            continue
        if "3.11.9" in str(fact.get("fact", "")):
            matches.append(fact)

    if not matches:
        return "I'm not sure yet - the graph hasn't surfaced the Python version."

    parsed_timestamps: List[Optional[datetime]] = []
    for fact in matches:
        raw_ts = fact.get("updated_at")
        parsed_ts: Optional[datetime] = None
        if isinstance(raw_ts, str):
            try:
                if raw_ts.endswith("Z"):
                    parsed_ts = datetime.fromisoformat(raw_ts.replace("Z", "+00:00"))
                else:
                    parsed_ts = datetime.fromisoformat(raw_ts)
            except ValueError:
                parsed_ts = None
        parsed_timestamps.append(parsed_ts)

    if all(ts is not None for ts in parsed_timestamps):
        matches = [
            fact
            for _, fact in sorted(
                zip(parsed_timestamps, matches), key=lambda pair: pair[0]  # type: ignore[arg-type]
            )
        ]
    else:
        # Use original order; matches already in response order.
        pass

    if matches:
        return "We settled on Python 3.11.9 for this project."
    return "I'm not sure yet - the graph hasn't surfaced the Python version."


def wait_for_graph_update(
    base_url: str, expected_substring: str, timeout_seconds: int, root_session_id: str, session_id: str
) -> None:
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        pre_payload = {
            "root_session_id": root_session_id,
            "session_id": session_id,
            "user_message": POLL_USER_MESSAGE,
        }
        pre_data = perform_request(
            f"{base_url}/pre", pre_payload, "/pre poll", schema="pre"
        )
        graph_memory_facts = pre_data.get("graph_memory_facts") or []
        if any(
            isinstance(fact, dict) and expected_substring in str(fact.get("fact", ""))
            for fact in graph_memory_facts
        ):
            return
        time.sleep(5)

    fail(f"ERROR: wait_for_graph_update timeout waiting for '{expected_substring}'.")


def run_turn(
    turn: Turn,
    base_url: str,
    root_session_id: str,
    session_id: str,
) -> Dict[str, Any]:
    pre_payload = {
        "root_session_id": root_session_id,
        "session_id": session_id,
        "user_message": turn.user_message,
    }
    pre_data = perform_request(f"{base_url}/pre", pre_payload, "/pre", schema="pre")

    diag_block = build_diag_block(turn.turn_number, pre_data, root_session_id, session_id)
    print_diag(diag_block)

    graph_memory_facts = pre_data.get("graph_memory_facts", []) or []
    assistant_message = turn.assistant_message
    if turn.turn_number == 4:
        assistant_message = choose_turn4_response(graph_memory_facts)

    post_payload = {
        "root_session_id": root_session_id,
        "session_id": session_id,
        "user_message": turn.user_message,
        "assistant_message": assistant_message,
    }
    perform_request(f"{base_url}/post", post_payload, "/post", schema="post")
    return pre_data


def query_dynamo(
    region: str, table_name: str, root_session_id: str
) -> List[Dict[str, Any]]:
    try:
        table = boto3.resource("dynamodb", region_name=region).Table(table_name)
    except (BotoCoreError, ClientError) as exc:
        fail(f"ERROR: AWS call failed: {exc}")

    items: List[Dict[str, Any]] = []
    last_evaluated_key: Optional[Dict[str, Any]] = None
    total_scanned = 0
    while True:
        query_kwargs: Dict[str, Any] = {
            "KeyConditionExpression": Key("PK").eq(root_session_id),
            "Limit": 100,
        }
        if last_evaluated_key:
            query_kwargs["ExclusiveStartKey"] = last_evaluated_key
        try:
            resp = table.query(**query_kwargs)
        except (BotoCoreError, ClientError) as exc:
            fail(f"ERROR: AWS call failed: {exc}")

        items.extend(resp.get("Items", []))
        total_scanned += len(resp.get("Items", []))

        last_evaluated_key = resp.get("LastEvaluatedKey")
        if not last_evaluated_key or total_scanned >= 1000:
            break

    filtered: List[Dict[str, Any]] = []
    for item in items:
        entity_val = item.get("entity")
        if isinstance(entity_val, str) and "python" in entity_val.lower():
            filtered.append(item)
    return filtered


def summarize_node(item: Dict[str, Any]) -> Dict[str, Any]:
    summary = {
        "entity": item.get("entity"),
        "type": item.get("type"),
        "fact": item.get("fact"),
        "state": item.get("state"),
        "updated_at": item.get("updated_at"),
        "supersedes": item.get("supersedes"),
        "superseded_by": item.get("superseded_by"),
        "source_event_ids": item.get("source_event_ids"),
    }
    return summary


def main() -> None:
    env = ensure_env()
    base_url = env["MEMORY_AGENT_URL"]
    aws_region = env["AWS_REGION"]
    memory_nodes_table = env["MEMORY_NODES_TABLE"]

    saw_graph_memory = False
    for turn in TURNS:
        pre_data = run_turn(turn, base_url, ROOT_ID, SESSION_ID)
        if pre_data.get("graph_memory_facts"):
            saw_graph_memory = True

        if turn.turn_number == 3:
            wait_for_graph_update(base_url, "3.11.9", 120, ROOT_ID, SESSION_ID)
        if turn.turn_number == 5:
            wait_for_graph_update(base_url, "3.12.7", 120, ROOT_ID, SESSION_ID)

    nodes = query_dynamo(aws_region, memory_nodes_table, ROOT_ID)
    if not nodes:
        fail("ERROR: Dynamo query returned no python-related nodes.")

    active_python_nodes = [
        node
        for node in nodes
        if isinstance(node.get("state"), str) and node.get("state") == "active"
    ]
    active_python_with_latest_fact = [
        node
        for node in active_python_nodes
        if "3.12.7" in str(node.get("fact", ""))
    ]

    if len(active_python_nodes) > 1:
        print("WARNING: multiple active python nodes found; using latest for display.")

    print("=== Dynamo python_version nodes ===")
    for node in nodes:
        print(json.dumps(summarize_node(node)))

    if not saw_graph_memory:
        fail("ERROR: No graph_memory_facts observed in diagnostics.")

    if not active_python_with_latest_fact:
        fail("ERROR: No active python node with fact containing 3.12.7 found.")

    print("All checks passed.")


if __name__ == "__main__":
    main()
