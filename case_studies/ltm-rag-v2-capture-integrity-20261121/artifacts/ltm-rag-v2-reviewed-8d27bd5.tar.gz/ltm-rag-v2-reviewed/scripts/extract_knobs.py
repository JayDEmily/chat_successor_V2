#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


ENV_NAME_PATTERN = r"^[A-Z][A-Z0-9_]{2,}$"
INTERESTING_KNOB_SUBSTRINGS = (
    "BUDGET",
    "REHYDRATION",
    "GRAPH",
    "SEMANTIC",
    "MICRO",
    "RECENT",
    "SUMMARY",
    "HEALTHCHECK",
    "LOG",
    "LIVE",
    "REQUIRE",
    "CANONICAL",
    "DISCOVERY",
)


@dataclass(frozen=True)
class EnvUse:
    name: str
    default: str | None
    source: str


@dataclass(frozen=True)
class CodeKnob:
    identifier: str
    default: str
    source: str
    kind: str  # constant | function_default | class_default


def _const_str(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _const_scalar(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant):
        if node.value is None:
            return "None"
        if isinstance(node.value, (bool, int, float, str)):
            return repr(node.value)
    return None


def _const_collection(node: ast.AST) -> str | None:
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        rendered: list[str] = []
        for elt in node.elts:
            val = _const_scalar(elt)
            if val is None:
                return None
            rendered.append(val)
        open_bracket, close_bracket = ("[", "]") if isinstance(node, ast.List) else ("(", ")")
        if isinstance(node, ast.Set):
            open_bracket, close_bracket = ("{", "}")
        inner = ", ".join(rendered)
        # Render single-element tuples with trailing comma.
        if isinstance(node, ast.Tuple) and len(rendered) == 1:
            inner = inner + ","
        return f"{open_bracket}{inner}{close_bracket}"
    if isinstance(node, ast.Dict):
        items: list[str] = []
        for k, v in zip(node.keys, node.values):
            if k is None:
                return None
            ks = _const_scalar(k)
            vs = _const_scalar(v) or _const_collection(v)
            if ks is None or vs is None:
                return None
            items.append(f"{ks}: {vs}")
        return "{" + ", ".join(items) + "}"
    return None


def _looks_like_env(name: str) -> bool:
    import re

    return bool(re.match(ENV_NAME_PATTERN, name))


def _iter_py_files(roots: Iterable[Path]) -> Iterable[Path]:
    for root in roots:
        if root.is_file() and root.suffix == ".py":
            yield root
        elif root.is_dir():
            yield from root.rglob("*.py")


def _extract_env_uses(path: Path) -> list[EnvUse]:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return []

    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError:
        return []

    uses: list[EnvUse] = []

    class V(ast.NodeVisitor):
        def visit_Call(self, node: ast.Call) -> Any:
            fn = node.func

            # os.getenv("NAME", default?)
            if (
                isinstance(fn, ast.Attribute)
                and fn.attr == "getenv"
                and isinstance(fn.value, ast.Name)
                and fn.value.id == "os"
            ):
                name = _const_str(node.args[0]) if node.args else None
                default = _const_scalar(node.args[1]) if len(node.args) >= 2 else None
                if name and _looks_like_env(name):
                    uses.append(
                        EnvUse(
                            name=name,
                            default=default,
                            source=f"{path.as_posix()}:os.getenv",
                        )
                    )

            # os.environ.get("NAME", default?)
            if (
                isinstance(fn, ast.Attribute)
                and fn.attr == "get"
                and isinstance(fn.value, ast.Attribute)
                and fn.value.attr == "environ"
                and isinstance(fn.value.value, ast.Name)
                and fn.value.value.id == "os"
            ):
                name = _const_str(node.args[0]) if node.args else None
                default = _const_scalar(node.args[1]) if len(node.args) >= 2 else None
                if name and _looks_like_env(name):
                    uses.append(
                        EnvUse(
                            name=name,
                            default=default,
                            source=f"{path.as_posix()}:os.environ.get",
                        )
                    )

            # app/config.py helpers: _require_env("NAME"), _get_bool_env("NAME", default=...), _get_log_level(...)
            if isinstance(fn, ast.Name) and fn.id in {"_require_env", "_get_bool_env", "_get_log_level"}:
                name = _const_str(node.args[0]) if node.args else None
                default = None
                if fn.id in {"_get_bool_env", "_get_log_level"}:
                    for kw in node.keywords or []:
                        if kw.arg == "default":
                            default = _const_scalar(kw.value)
                if name and _looks_like_env(name):
                    uses.append(
                        EnvUse(
                            name=name,
                            default=default,
                            source=f"{path.as_posix()}:{fn.id}",
                        )
                    )

            return self.generic_visit(node)

        def visit_Assign(self, node: ast.Assign) -> Any:
            # ENV_URL_KEYS = ("A", "B", ...)
            targets = [t.id for t in node.targets if isinstance(t, ast.Name)]
            if not targets:
                return self.generic_visit(node)
            target = targets[0]
            if target.endswith("_ENV_KEYS") or target in {"ENV_URL_KEYS"}:
                values: list[str] = []
                if isinstance(node.value, (ast.Tuple, ast.List)):
                    for elt in node.value.elts:
                        s = _const_str(elt)
                        if s and _looks_like_env(s):
                            values.append(s)
                for env_name in values:
                    uses.append(
                        EnvUse(
                            name=env_name,
                            default=None,
                            source=f"{path.as_posix()}:{target}",
                        )
                    )
            return self.generic_visit(node)

    V().visit(tree)
    return uses


def _interesting_identifier(identifier: str, *, include_all: bool) -> bool:
    if include_all:
        return True
    upper = identifier.upper()
    return any(s in upper for s in INTERESTING_KNOB_SUBSTRINGS)


def _extract_code_knobs(path: Path, *, include_all: bool) -> list[CodeKnob]:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return []

    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError:
        return []

    knobs: list[CodeKnob] = []

    def _render_value(node: ast.AST) -> str | None:
        return _const_scalar(node) or _const_collection(node)

    class V(ast.NodeVisitor):
        def __init__(self) -> None:
            super().__init__()
            self._class_stack: list[str] = []

        def _qual(self, name: str) -> str:
            if not self._class_stack:
                return name
            return ".".join(self._class_stack + [name])

        def visit_Assign(self, node: ast.Assign) -> Any:
            if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
                return self.generic_visit(node)
            name = node.targets[0].id
            if not _interesting_identifier(name, include_all=include_all):
                return self.generic_visit(node)
            value = _render_value(node.value)
            if value is None:
                return self.generic_visit(node)
            knobs.append(
                CodeKnob(
                    identifier=name,
                    default=value,
                    source=f"{path.as_posix()}:{node.lineno}",
                    kind="constant",
                )
            )
            return self.generic_visit(node)

        def visit_FunctionDef(self, node: ast.FunctionDef) -> Any:
            # Capture literal default values (e.g., search_memory(k: int = 8)).
            args = node.args
            defaults = list(args.defaults or [])
            if not defaults:
                return self.generic_visit(node)
            func_name = self._qual(node.name)
            # Defaults apply to the last N positional args.
            positional = list(args.posonlyargs or []) + list(args.args or [])
            defaulted = positional[-len(defaults) :] if len(defaults) <= len(positional) else []
            for arg_node, default_node in zip(defaulted, defaults):
                arg_name = getattr(arg_node, "arg", None)
                if not arg_name:
                    continue
                identifier = f"{func_name}.{arg_name}"
                if not _interesting_identifier(identifier, include_all=include_all):
                    continue
                value = _render_value(default_node)
                if value is None:
                    continue
                knobs.append(
                    CodeKnob(
                        identifier=identifier,
                        default=value,
                        source=f"{path.as_posix()}:{node.lineno}",
                        kind="function_default",
                    )
                )
            return self.generic_visit(node)

        def visit_ClassDef(self, node: ast.ClassDef) -> Any:
            self._class_stack.append(node.name)
            # Capture class attribute defaults (e.g., MemoryTelemetry fields).
            for stmt in node.body:
                if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name) and stmt.value is not None:
                    attr = stmt.target.id
                    identifier = f"{node.name}.{attr}"
                    if not _interesting_identifier(identifier, include_all=include_all):
                        continue
                    value = _render_value(stmt.value)
                    if value is None:
                        continue
                    knobs.append(
                        CodeKnob(
                            identifier=identifier,
                            default=value,
                            source=f"{path.as_posix()}:{stmt.lineno}",
                            kind="class_default",
                        )
                    )
                elif isinstance(stmt, ast.Assign) and len(stmt.targets) == 1 and isinstance(stmt.targets[0], ast.Name):
                    attr = stmt.targets[0].id
                    identifier = f"{node.name}.{attr}"
                    if not _interesting_identifier(identifier, include_all=include_all):
                        continue
                    value = _render_value(stmt.value)
                    if value is None:
                        continue
                    knobs.append(
                        CodeKnob(
                            identifier=identifier,
                            default=value,
                            source=f"{path.as_posix()}:{stmt.lineno}",
                            kind="class_default",
                        )
                    )
            self.generic_visit(node)
            self._class_stack.pop()
            return None

    V().visit(tree)
    return knobs


def _merge_uses(uses: Iterable[EnvUse]) -> dict[str, dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    for use in uses:
        entry = merged.setdefault(use.name, {"defaults": set(), "sources": set()})
        entry["sources"].add(use.source)
        entry["defaults"].add(use.default if use.default is not None else "None")
    # Sort sources for stable output.
    out: dict[str, dict[str, Any]] = {}
    for name in sorted(merged.keys()):
        out[name] = {
            "defaults": sorted(merged[name]["defaults"]),
            "sources": sorted(merged[name]["sources"]),
        }
    return out


def _to_markdown_table(env_map: dict[str, dict[str, Any]]) -> str:
    lines = []
    lines.append("| Env var | Defaults seen | Sources |")
    lines.append("|---|---:|---|")
    for name, meta in env_map.items():
        defaults = meta.get("defaults") or ["None"]
        default_cell = "<br>".join(f"`{d}`" for d in defaults)
        sources = "<br>".join(meta.get("sources") or [])
        lines.append(f"| `{name}` | {default_cell} | {sources} |")
    return "\n".join(lines) + "\n"


def _to_markdown_code_knobs(knobs: list[CodeKnob]) -> str:
    lines = []
    lines.append("| Identifier | Default | Kind | Source |")
    lines.append("|---|---:|---|---|")
    for knob in sorted(knobs, key=lambda k: (k.identifier, k.kind, k.source)):
        lines.append(
            f"| `{knob.identifier}` | `{knob.default}` | `{knob.kind}` | {knob.source} |"
        )
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Extract env-driven knobs (env var names + defaults) from repo code."
    )
    parser.add_argument(
        "--format",
        choices=("json", "md"),
        default="md",
        help="Output format (default: md).",
    )
    parser.add_argument(
        "--roots",
        nargs="*",
        default=["app", "scripts", "tests"],
        help="Roots to scan (default: app scripts tests).",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Include all discovered constants/defaults (can be noisy).",
    )
    args = parser.parse_args()

    roots = [Path(r) for r in args.roots]
    uses: list[EnvUse] = []
    code_knobs: list[CodeKnob] = []
    for path in _iter_py_files(roots):
        uses.extend(_extract_env_uses(path))
        code_knobs.extend(_extract_code_knobs(path, include_all=bool(args.all)))

    env_map = _merge_uses(uses)

    if args.format == "json":
        payload = {
            "env": env_map,
            "code": [
                {
                    "identifier": k.identifier,
                    "default": k.default,
                    "kind": k.kind,
                    "source": k.source,
                }
                for k in sorted(code_knobs, key=lambda k: (k.identifier, k.kind, k.source))
            ],
        }
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print("## Environment variables\n")
        print(_to_markdown_table(env_map))
        print("\n## Code defaults and constants\n")
        print(_to_markdown_code_knobs(code_knobs))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
