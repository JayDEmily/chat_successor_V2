from __future__ import annotations

from openai import OpenAI

from app.config import load_settings
from app.handler import handle_post, handle_pre
from app.logging_utils import get_logger
from app.models import PostPhaseRequest, PrePhaseRequest


logger = get_logger(__name__)


def main() -> None:
    settings = load_settings()
    if settings.semantic_backend != "openai":
        raise SystemExit("SEMANTIC_BACKEND must be 'openai' for this Phase 3 sanity check.")

    key_prefix = settings.openai_api_key[:7] if settings.openai_api_key else ""
    key_suffix = settings.openai_api_key[-4:] if settings.openai_api_key else ""
    logger.info(
        "phase3_openai_config",
        extra={
            "openai_key_present": bool(settings.openai_api_key),
            "openai_key_length": len(settings.openai_api_key or ""),
            "openai_key_prefix": key_prefix,
            "openai_key_suffix": key_suffix,
            "openai_vector_store_id": settings.openai_vector_store_id,
        },
    )

    client = OpenAI(api_key=settings.openai_api_key)
    models = client.models.list()
    logger.info(
        "phase3_models_list_ok",
        extra={"model_count": len(models.data)},
    )

    vector_store = None
    if settings.openai_vector_store_id:
        vector_store = client.vector_stores.retrieve(settings.openai_vector_store_id)
        logger.info(
            "phase3_vector_store_ok",
            extra={"vector_store_id": settings.openai_vector_store_id},
        )

    root_session_id = "phase3-root-1"
    session_id = "phase3-session-1"
    user_message = "This is a Phase 3 OpenAI integration test."
    assistant_message = "Phase 3 semantic memory test payload about purple kangaroos."

    print(
        f"Using settings: region={settings.aws_region}, bucket={settings.transcript_bucket}, "
        f"table={settings.state_table}, backend={settings.semantic_backend}, "
        f"vector_store_id={settings.openai_vector_store_id}"
    )
    print(
        f"OPENAI_API_KEY present={bool(settings.openai_api_key)}, "
        f"len={len(settings.openai_api_key)}, prefix={key_prefix}, suffix={key_suffix}"
    )
    if vector_store is not None:
        store_model = getattr(vector_store, "embedding_model", None)
        if store_model is None and hasattr(vector_store, "embedding_configuration"):
            store_model = getattr(vector_store.embedding_configuration, "model", None)
        print(
            f"Retrieved vector store id={settings.openai_vector_store_id}, embedding_model={store_model}"
        )

    post_req = PostPhaseRequest(
        root_session_id=root_session_id,
        session_id=session_id,
        user_message=user_message,
        assistant_message=assistant_message,
    )
    post_resp = handle_post(post_req)

    pre_req = PrePhaseRequest(
        root_session_id=root_session_id,
        session_id=session_id,
        user_message="purple kangaroos",
    )
    pre_resp = handle_pre(pre_req)

    hit_text = pre_resp.semantic_hits[0].text if pre_resp.semantic_hits else ""
    hit_meta = pre_resp.semantic_hits[0].metadata if pre_resp.semantic_hits else {}
    print(
        f"POST ok={post_resp.ok}, PRE short_summary='{pre_resp.short_summary}', "
        f"recent_events_count={len(pre_resp.recent_events)}, semantic_hits_count={len(pre_resp.semantic_hits)}"
    )
    if pre_resp.semantic_hits:
        print(
            f"First hit text='{hit_text[:120]}' meta={hit_meta}"
        )
    s3_key = f"sessions/{root_session_id}/{session_id}.log.jsonl"
    print(
        f"S3 key: {s3_key} (bucket: {settings.transcript_bucket}); "
        f"Dynamo PK/SK: ({root_session_id}, {session_id}) in table {settings.state_table}"
    )


if __name__ == "__main__":
    main()
