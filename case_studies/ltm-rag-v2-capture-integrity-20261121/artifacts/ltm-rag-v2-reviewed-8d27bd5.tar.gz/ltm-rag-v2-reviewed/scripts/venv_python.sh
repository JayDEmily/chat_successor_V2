#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd -- "${script_dir}/.." && pwd)"

if [[ -n "${VIRTUAL_ENV:-}" ]]; then
  candidate="${VIRTUAL_ENV}/bin/python"
  if [[ -x "${candidate}" ]]; then
    exec "${candidate}" "$@"
  fi
  echo "ERROR: VIRTUAL_ENV is set to '${VIRTUAL_ENV}', but '${candidate}' is missing/not executable." >&2
  exit 2
fi

candidate="${repo_root}/.venv/bin/python"
if [[ -x "${candidate}" ]]; then
  exec "${candidate}" "$@"
fi

echo "ERROR: No venv Python found." >&2
echo "Activate a venv (set VIRTUAL_ENV) or create the repo venv:" >&2
echo "  python3.12 -m venv ${repo_root}/.venv" >&2
exit 2
