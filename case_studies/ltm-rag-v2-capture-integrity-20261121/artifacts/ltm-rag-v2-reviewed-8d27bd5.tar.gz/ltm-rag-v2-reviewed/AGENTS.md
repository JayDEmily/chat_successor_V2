# AGENTS.md - LTM-RAG repository entry point

**Scope:** new LTM-RAG vNext work under `vnext/`. Do not infer authority to change legacy source or another project.

## Read the relevant instructions

- **Frozen execution process:** [GUARDRAILS.md](GUARDRAILS.md). Treat it as immutable during ordinary implementation.
- **vNext operating restrictions:** [vnext/AGENTS.md](vnext/AGENTS.md), including previously exhausted native-trial quotas and synthetic-only permissions.
- **Latest architectural review:** [21 November complementary-memory overview](vnext/COMPLEMENTARY_MEMORY_REVIEW_20261121.md) and its [ADR](vnext/reviews/20261121_complementary_memory/ADR_COMPLEMENTARY_MEMORY.md). The technical ADR is still proposed, not accepted by the mere existence of this file.
- **Existing gates and evaluation plan:** [G1-G10 and 24 draft cases](vnext/reviews/20261121_complementary_memory/GATES_AND_EVALS.md). For source capture/outages use [capture/recovery plan](vnext/reviews/20261121_complementary_memory/OFFLINE_CAPTURE_AND_RECOVERY.md). Read only the sections material to the current task.
- **Actual completed work and blockers:** [vNext progress](vnext/PROGRESS.md) and the exact referenced Git commits. Older stage-specific 'next' instructions are historical unless reaffirmed by the current admitted plan.

**Missing planning artefact:** There is not yet a frozen, numbered LTM-RAG implementation-leaf register. Do not pretend G1-G10 are leaf cards or copy the Chat Succession 23-leaf plan into this repo. Require an accepted bounded assignment and dependencies before selecting the next implementation step.

## Worker -> independent tester -> PR -> GitHub Actions -> merge

1. **Worker (Ubuntu/WSL):** execute one authorised leaf, inspect its diff, run targeted tests, commit/push a feature branch and verify the remote commit. A worker result is not independent acceptance.
2. **Independent tester:** a genuinely new ChatGPT thread in the nominated Project reads the pinned GitHub source and applicable gates, independently checks the behaviour and publishes a specific `PASS`, `RETURN_TO_WORKER` or `BLOCKED` verdict. A failed review loops back to a worker without silently changing acceptance criteria.
3. **PR:** after that review passes, open a PR against the nominated integration branch at the same reviewed commit.
4. **GitHub Actions:** require the actual PR workflow result on its Ubuntu runner, in addition to independent semantic/native testing where applicable. No workflow/no green check is not a pass.
5. **Merge:** only under the applicable explicit merge authority and when review and required CI are green. Verify the merge commit and then select the next dependency-released leaf.

The **worker's development commit is before review**; the final **merge commit is after PR checks**. A separately running Chat Succession controller may launch the fresh tester only after its LTM-RAG route is qualified; these documents do not deploy one.

## Proposed integration base for this candidate

Use `work/ltm-rag-vnext-astra-implementation-20261121` at
`62074121e629ae7a5ea68f784fae38a2df5fd3ab` as the
**recommended, not yet owner-nominated** base for a governance-only PR.
Do not target `main` without a separate scope decision; it is 91
commits behind that parent. Verify the base and exact changed files
before opening a PR. The candidate includes a
`.github/workflows/vnext-synthetic.yml`, which has **not**
yet passed a real GitHub PR run. Its 276 reproducible synthetic tests do not replace
private Stage T/W source-fidelity checks or native ChatGPT evaluations.

## Code review rules

- Reject any source-capture claim based solely on a model-supplied tool query, a simulated replay, an indexed chunk, or a UI response including page furniture. Safe path: independently grounded exact user/assistant source and explicit coverage.
- Reject incorrect historical role, corrected/versioned source, timestamp, branch, revoked-record or source-hash release. Safe path: resolve against canonical SQLite and retain original evidence.
- Reject work outside the assigned leaf, unverified native/chat tests presented as passing, or worker self-approval. Safe path: preserve the failure and route an exact independent review.
- Keep reproducible mechanical checks in CI and review judgments tied to the actual ADR and source. The proposed workflow checks links, a synthetic unit subset and diff whitespace; it does not establish comprehensive lint or native product acceptance.

This is a governance-and-CI candidate, **not** evidence that automatic LTM-RAG reviewer handoff, successful PR CI, enforced required checks or an authorised merge exists.
