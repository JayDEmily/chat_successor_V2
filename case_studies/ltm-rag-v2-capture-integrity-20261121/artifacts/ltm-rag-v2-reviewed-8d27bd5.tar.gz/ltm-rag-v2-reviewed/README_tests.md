# Test Suite Overview (V2 + V3)

This repository contains the canonical V2 memory-agent tests plus new V3 RAG-graph coverage. The suite doubles as an eval harness to catch regressions when models, prompts, or infrastructure change.

## What’s covered
- **V2 core**: S3 transcripts (append-only JSONL), Dynamo `BranchState`, OpenAI vector store search/index, `/pre` and `/post` handler contracts, logging, and healthcheck.
- **V3 graph layer**: `memory_nodes`/`memory_edges` data model, consolidation invariants (single active per entity/type, supersedence, reopen), async pipeline (`/post` → SQS → extraction → consolidation → nodes/vector), `/pre` enrichment with graph facts/history, healthcheck for graph resources, logging, and failure modes (LLM errors, malformed payloads, idempotency).

## Structure (coverage mapping)
- `tests/test_graph_nodes_model.py` — Data model round-trips and state fields (A).
- `tests/test_graph_consolidation.py` — Consolidation scenarios: flapping, reopen, duplicate evidence, supersedes (B).
- `tests/test_graph_consolidation_worker.py` — Worker markers/idempotency, vector uploads, evidence linkage (B/C).
- `tests/test_graph_pipeline_integration.py` — `/post` + SQS emission, payload/attributes, backward compatibility (C/D).
- `tests/test_graph_extraction_worker.py` — Extraction context window, no-candidate noop (C).
- `tests/test_graph_pre_integration.py` — `/pre` enrichment/compatibility, Dynamo vs vector paths, history ordering (D).
- `tests/test_graph_healthcheck.py` — Graph healthcheck for tables and optional graph_fact vector probe (E).
- `tests/test_graph_logging.py` — Structured logging for extraction/consolidation (E).
- `tests/test_graph_pipeline_errors.py` — Edge/failure modes: LLM error, malformed consolidation, missing candidates, partial failure, retry idempotency (F).

## Prerequisites / Environment
- Python 3.12 with virtualenv (Python 3.13 is blocked because black/ruff tooling is unstable there; Makefile/hygiene checks will error).
- Environment variables (point to test resources, **not** production):
  - `AWS_REGION`
  - `TRANSCRIPT_BUCKET` (test bucket)
  - `STATE_TABLE` (test BranchState table)
  - `MEMORY_NODES_TABLE` (graph nodes table)
  - `GRAPH_PIPELINE_QUEUE_URL` (SQS FIFO for V3 pipeline)
  - `OPENAI_API_KEY`
  - `OPENAI_VECTOR_STORE_ID` (test store; used for vector tests including `kind=graph_fact` when enabled)
- Tests assume isolated test accounts/buckets/tables; do not run against production data.

## How to run (documentation only)
- Full suite: `.venv/bin/python -m pytest` (equivalently `make test`)
- Subsets: `.venv/bin/python -m pytest tests/test_graph_*.py` or per-file selection; the Makefile targets call `.venv/bin/python -m pytest` under the hood so `make test-*` keeps the interpreter pinned as well.
- No tests are marked skip/xfail; they are intended to run live once V3 code is implemented.

## Key invariants under test
- Single `active` node per `(root_session_id, entity, type)`; superseded nodes carry `valid_to`/`superseded_by`; new nodes list `supersedes`; reopen sets state/reason.
- Idempotency via `last_processed_sequence` markers and SQS FIFO dedupe; duplicate evidence is a no-op.
- `/post` and `/pre` retain V2 response shapes; graph enrichment is additive/feature-flagged.
- Graph facts/history align with transcript `event_id`s and BranchState; graph_fact vector uploads/search (optional) use dedicated metadata.
- Healthcheck covers graph tables and optional vector store; logging emits stage/status for success, skip, and failure paths.

## Future work
- Expand integration coverage once the concrete module boundaries for graph workers are finalized (names are fixed in tests). 
