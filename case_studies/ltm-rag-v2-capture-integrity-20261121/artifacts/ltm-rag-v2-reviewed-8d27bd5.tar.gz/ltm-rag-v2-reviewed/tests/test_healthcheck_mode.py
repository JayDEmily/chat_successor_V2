"""Healthcheck mode-awareness tests.

Ensures semantic backend gating and optional token-spending checks behave as expected.
"""

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from app import config, healthcheck


def _set_minimal_env(monkeypatch, **overrides):
    base = {
        "AWS_REGION": "us-east-1",
        "TRANSCRIPT_BUCKET": "test-bucket",
        "STATE_TABLE": "test-table",
        "OPENAI_API_KEY": "sk-test",
        "OPENAI_VECTOR_STORE_ID": "vs_dummy",
        "EMBEDDING_MODEL_NAME": "text-embedding-3-large",
        "SUMMARY_MODEL_NAME": "gpt-5.1",
        "SEMANTIC_BACKEND": "openai",
    }
    base.update(overrides)
    for k, v in base.items():
        if v is None:
            monkeypatch.delenv(k, raising=False)
        else:
            monkeypatch.setenv(k, v)


def _mk_settings(backend="none", llm_calls=False):
    return SimpleNamespace(
        semantic_backend=backend,
        transcript_bucket="bucket",
        state_table="table",
        openai_vector_store_id="vs_dummy",
        openai_api_key="sk-test",
        embedding_model="text-embedding-3-large",
        summary_model="gpt-5.1",
        healthcheck_llm_calls=llm_calls,
        healthcheck_write_probes=False,
        aws_region="us-east-1",
    )


def test_healthcheck_llm_calls_default_false(monkeypatch):
    _set_minimal_env(monkeypatch, HEALTHCHECK_LLM_CALLS=None)
    settings = config.load_settings()
    assert settings.healthcheck_llm_calls is False


@pytest.mark.parametrize("value", ["true", "True", "1"])
def test_healthcheck_llm_calls_parses_true(monkeypatch, value):
    _set_minimal_env(monkeypatch, HEALTHCHECK_LLM_CALLS=value)
    settings = config.load_settings()
    assert settings.healthcheck_llm_calls is True


@pytest.mark.parametrize("value", ["false", "False", "0"])
def test_healthcheck_llm_calls_parses_false(monkeypatch, value):
    _set_minimal_env(monkeypatch, HEALTHCHECK_LLM_CALLS=value)
    settings = config.load_settings()
    assert settings.healthcheck_llm_calls is False


def test_healthcheck_skips_semantic_when_none(monkeypatch):
    settings = _mk_settings(backend="none")
    monkeypatch.setattr(healthcheck, "load_settings", lambda: settings)

    dyn = MagicMock()
    s3 = MagicMock()
    monkeypatch.setattr(healthcheck, "get_dynamodb_table", lambda _s: dyn)
    monkeypatch.setattr(healthcheck, "get_s3_client", lambda _s: s3)

    openai_client = MagicMock()
    openai_ctor = MagicMock(return_value=openai_client)
    monkeypatch.setattr(healthcheck, "OpenAI", openai_ctor)
    llm = MagicMock()
    monkeypatch.setattr(healthcheck, "LLMClient", lambda _s: llm)

    healthcheck.run_healthcheck()

    openai_ctor.assert_not_called()
    openai_client.vector_stores.retrieve.assert_not_called()
    llm.embed.assert_not_called()


def test_healthcheck_openai_calls_vector_store(monkeypatch):
    settings = _mk_settings(backend="openai", llm_calls=False)
    monkeypatch.setattr(healthcheck, "load_settings", lambda: settings)

    dyn = MagicMock()
    s3 = MagicMock()
    monkeypatch.setattr(healthcheck, "get_dynamodb_table", lambda _s: dyn)
    monkeypatch.setattr(healthcheck, "get_s3_client", lambda _s: s3)

    vs = MagicMock()
    openai_client = MagicMock(vector_stores=vs)
    monkeypatch.setattr(healthcheck, "OpenAI", lambda api_key=None: openai_client)

    llm = MagicMock()
    llm.summarise = MagicMock()
    monkeypatch.setattr(healthcheck, "LLMClient", lambda _s: llm)

    healthcheck.run_healthcheck()

    vs.retrieve.assert_called_once_with(settings.openai_vector_store_id)
    llm.embed.assert_not_called()
    llm.summarise.assert_not_called()


def test_healthcheck_openai_llm_calls_trigger_token_checks(monkeypatch):
    settings = _mk_settings(backend="openai", llm_calls=True)
    monkeypatch.setattr(healthcheck, "load_settings", lambda: settings)

    dyn = MagicMock()
    s3 = MagicMock()
    monkeypatch.setattr(healthcheck, "get_dynamodb_table", lambda _s: dyn)
    monkeypatch.setattr(healthcheck, "get_s3_client", lambda _s: s3)

    vs = MagicMock()
    openai_client = MagicMock(vector_stores=vs)
    monkeypatch.setattr(healthcheck, "OpenAI", lambda api_key=None: openai_client)

    llm = MagicMock()
    llm.embed = MagicMock()
    llm.summarise = MagicMock()
    monkeypatch.setattr(healthcheck, "LLMClient", lambda _s: llm)

    healthcheck.run_healthcheck()

    vs.retrieve.assert_called_once_with(settings.openai_vector_store_id)
    llm.embed.assert_called()
    llm.summarise.assert_called()
    # Ensure a non-empty probe string was used for embed() calls.
    assert any(arg for call in llm.embed.call_args_list for arg in call[0] if arg)


def test_healthcheck_write_probes_disabled(monkeypatch):
    settings = _mk_settings(backend="none", llm_calls=False)
    settings.healthcheck_write_probes = False
    monkeypatch.setattr(healthcheck, "load_settings", lambda: settings)

    dyn = MagicMock(load=MagicMock())
    dyn.put_item = MagicMock()
    dyn.delete_item = MagicMock()
    s3 = MagicMock(list_objects_v2=MagicMock())
    s3.put_object = MagicMock()
    s3.delete_object = MagicMock()
    monkeypatch.setattr(healthcheck, "get_dynamodb_table", lambda _s: dyn)
    monkeypatch.setattr(healthcheck, "get_s3_client", lambda _s: s3)

    healthcheck.run_healthcheck()

    dyn.load.assert_called_once()
    s3.list_objects_v2.assert_called_once()
    dyn.put_item.assert_not_called()
    dyn.delete_item.assert_not_called()
    s3.put_object.assert_not_called()
    s3.delete_object.assert_not_called()


def test_healthcheck_write_probes_enabled(monkeypatch):
    settings = _mk_settings(backend="none", llm_calls=False)
    settings.healthcheck_write_probes = True
    monkeypatch.setattr(healthcheck, "load_settings", lambda: settings)

    dyn = MagicMock(load=MagicMock())
    dyn.put_item = MagicMock()
    dyn.delete_item = MagicMock()
    s3 = MagicMock(list_objects_v2=MagicMock())
    s3.put_object = MagicMock()
    s3.delete_object = MagicMock()
    monkeypatch.setattr(healthcheck, "get_dynamodb_table", lambda _s: dyn)
    monkeypatch.setattr(healthcheck, "get_s3_client", lambda _s: s3)

    healthcheck.run_healthcheck()

    dyn.put_item.assert_called_once()
    dyn.delete_item.assert_called_once()
    s3.put_object.assert_called_once()
    s3.delete_object.assert_called_once()


def test_healthcheck_warns_on_embedding_mismatch(monkeypatch):
    settings = _mk_settings(backend="openai", llm_calls=False)
    monkeypatch.setattr(healthcheck, "load_settings", lambda: settings)

    dyn = MagicMock()
    s3 = MagicMock()
    monkeypatch.setattr(healthcheck, "get_dynamodb_table", lambda _s: dyn)
    monkeypatch.setattr(healthcheck, "get_s3_client", lambda _s: s3)

    store = SimpleNamespace(embedding_model="text-embedding-3-small")
    openai_client = MagicMock(vector_stores=MagicMock(retrieve=MagicMock(return_value=store)))
    monkeypatch.setattr(healthcheck, "OpenAI", lambda api_key=None: openai_client)

    logger = MagicMock()
    monkeypatch.setattr(healthcheck, "logger", logger)

    healthcheck.run_healthcheck()

    assert any(
        call.args and call.args[0] == "embedding_model_mismatch"
        for call in logger.warning.call_args_list
    )
