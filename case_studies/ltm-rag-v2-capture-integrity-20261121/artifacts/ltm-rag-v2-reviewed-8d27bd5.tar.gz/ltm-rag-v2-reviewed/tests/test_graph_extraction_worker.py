"""Extraction worker behaviours for V3 graph pipeline."""

from __future__ import annotations

from datetime import datetime, timezone
from io import BytesIO
from types import SimpleNamespace

import pytest


class FakeS3:
    def __init__(self, body: str):
        self.body = body.encode("utf-8")

    def get_object(self, Bucket=None, Key=None):
        return {"Body": BytesIO(self.body)}


class FakeLLM:
    def __init__(self, candidates):
        self.candidates = candidates
        self.calls = []

    def extract_memories(self, prompt: str):
        self.calls.append(prompt)
        return self.candidates


def _message():
    return {
        "root_session_id": "root",
        "session_id": "sess",
        "user_event_id": "evt-1",
        "assistant_event_id": "evt-2",
        "transcript_key": "sessions/root/sess.log.jsonl",
    }


def _run_worker(s3_client, llm_client, branch_state=None):
    import app.graph_extraction_worker as worker  # type: ignore[import-not-found]

    return worker.handle_extraction_message(
        message=_message(),
        s3_client=s3_client,
        branch_state=branch_state,
        llm_client=llm_client,
    )


def test_extraction_builds_context_window_anchored_on_source_event_ids():
    """Worker should build prompt from transcript lines and recent_events containing the new event_ids."""
    transcript_lines = [
        '{"event_id": "evt-0", "content": "older"}\n',
        '{"event_id": "evt-1", "content": "user message"}\n',
        '{"event_id": "evt-2", "content": "assistant reply"}\n',
    ]
    s3 = FakeS3("".join(transcript_lines))
    branch_state = SimpleNamespace(
        recent_events=[
            {"event_id": "evt-1", "content": "user message"},
            {"event_id": "evt-2", "content": "assistant reply"},
        ]
    )
    llm = FakeLLM(candidates=[{"entity": "python_version", "type": "config", "fact": "3.11", "source_event_ids": ["evt-2"]}])

    results = _run_worker(s3, llm, branch_state=branch_state)

    assert llm.calls, "LLM should be invoked once"
    prompt = llm.calls[0]
    assert "evt-1" in prompt and "evt-2" in prompt
    assert results and results[0]["fact"] == "3.11"


def test_extraction_no_candidates_is_noop():
    """If LLM returns no candidates, worker should return empty and avoid errors."""
    s3 = FakeS3("")
    llm = FakeLLM(candidates=[])
    results = _run_worker(s3, llm, branch_state=SimpleNamespace(recent_events=[]))
    assert results == []
    assert llm.calls, "LLM still called even if empty transcript"


def test_structured_parser_handles_quoted_fact_with_spaces():
    """Structured parser should capture quoted facts with spaces and skip the LLM."""
    branch_state = SimpleNamespace(
        recent_events=[
            {
                "event_id": "evt-1",
                "content": 'Graph fact: entity=python_version type=config fact="python version 3.12.1";',
            }
        ]
    )
    llm = FakeLLM(candidates=[{"entity": "noop"}])
    results = _run_worker(s3_client=None, llm_client=llm, branch_state=branch_state)
    assert not llm.calls, "LLM should not be invoked when structured parse succeeds"
    assert results and results[0]["fact"] == "python version 3.12.1"
    assert results[0]["structured_parse_used"] is True
    assert results[0]["llm_fallback_used"] is False
    assert "extraction:structured" in results[0].get("tags", [])


def test_structured_parser_handles_unquoted_fact():
    branch_state = SimpleNamespace(
        recent_events=[
            {
                "event_id": "evt-1",
                "content": "entity=python_version type=config fact=python_version=3.12.5.",
            }
        ]
    )
    llm = FakeLLM(candidates=[{"entity": "noop"}])
    results = _run_worker(s3_client=None, llm_client=llm, branch_state=branch_state)
    assert results and results[0]["fact"] == "python_version=3.12.5"
    assert results[0]["structured_parse_used"] is True
    assert results[0]["llm_fallback_used"] is False
    assert "extraction:structured" in results[0].get("tags", [])


def test_llm_fallback_flag_set_when_no_structured_match():
    """When no structured pattern matches, fallback path must mark telemetry flags."""
    branch_state = SimpleNamespace(
        recent_events=[{"event_id": "evt-1", "content": "just chatting about nothing structured"}]
    )
    llm = FakeLLM(candidates=[{"entity": "python_version", "type": "config", "fact": "python_version=3.13"}])
    results = _run_worker(s3_client=None, llm_client=llm, branch_state=branch_state)
    assert llm.calls, "LLM should be invoked on fallback"
    assert results and results[0]["llm_fallback_used"] is True
    assert results[0]["structured_parse_used"] is False
    assert "extraction:llm_fallback" in results[0].get("tags", [])
