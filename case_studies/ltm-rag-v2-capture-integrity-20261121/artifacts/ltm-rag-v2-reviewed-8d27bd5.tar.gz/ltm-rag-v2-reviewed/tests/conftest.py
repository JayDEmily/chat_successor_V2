import os
import sys
from types import SimpleNamespace

import pytest

# Ensure repo root is on sys.path for helper modules (e.g., custom_gpt_turn_client).
sys.path.insert(0, os.getcwd())

# Ensure MCP Server exposes the tool decorator to avoid import-time skips on older MCP versions.
try:
    from mcp.server import Server  # type: ignore

    if not hasattr(Server, "tool"):
        def _noop_tool(*args, **kwargs):
            def _decorator(fn):
                return fn
            return _decorator

        Server.tool = staticmethod(_noop_tool)  # type: ignore[attr-defined]
except Exception:
    pass


def make_settings(**overrides):
    """Factory for lightweight settings objects used in tests.

    Uses SimpleNamespace so we can include future fields (e.g., semantic_backend)
    without touching production code.
    """
    base = dict(
        aws_region="us-east-1",
        transcript_bucket="test-transcripts",
        state_table="test-state",
        openai_api_key=os.getenv("OPENAI_API_KEY", "sk-test"),
        embedding_model="text-embedding-3-small",
        summary_model="gpt-4o-mini",
        semantic_backend="none",
        semantic_search_scope="root",
        healthcheck_write_probes=False,
        openai_vector_store_id=os.getenv(
            "OPENAI_VECTOR_STORE_ID", "vs_dummy_for_tests"
        ),
        response_budget_bytes=200000,
    )
    base.update(overrides)
    return SimpleNamespace(**base)


@pytest.fixture(autouse=True)
def reset_handler_globals():
    """Ensure handler globals are restored between tests."""
    try:
        from app import handler
    except ModuleNotFoundError:
        yield
        return

    orig_settings = handler._settings
    orig_llm = handler._llm_client
    yield
    handler._settings = orig_settings
    handler._llm_client = orig_llm


@pytest.fixture
def settings_factory():
    return make_settings


@pytest.fixture
def fake_llm():
    class FakeLLM:
        def __init__(self):
            self.embed_called = 0
            self.embeds = []

        def embed(self, text):
            self.embed_called += 1
            self.embeds.append(text)
            return [0.1, 0.2]

        def summarise(self, history_text):
            return "SUMMARY"

    return FakeLLM()
