"""Verify the repo never drifts off the canonical .venv/Python 3.12 interpreter."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest


def test_repo_python_is_canonical():
    repo_root = Path(__file__).resolve().parent.parent
    venv_python = (repo_root / ".venv" / "bin" / "python").resolve()
    assert venv_python.exists(), f"Create {repo_root / '.venv'} first (`python3.12 -m venv .venv`)."

    python_executable_raw = Path(sys.executable)
    python_executable = python_executable_raw.resolve()
    assert python_executable == venv_python, (
        f"Tests must run on {venv_python}, but sys.executable is {python_executable}."
    )
    assert ".venv" in python_executable_raw.as_posix(), "Interpreter path must flow through `.venv`."

    version_info = sys.version_info
    assert (version_info.major, version_info.minor) == (3, 12), "Repo automation targets Python 3.12."

    result = subprocess.run([sys.executable, "--version"], check=True, capture_output=True, text=True)
    reported_version = (result.stdout or result.stderr).strip()
    assert reported_version.startswith("Python 3.12."), (
        f"Canonical runner reported {reported_version} instead of Python 3.12.x."
    )

    pytest_path = Path(pytest.__file__).resolve()
    assert ".venv" in pytest_path.as_posix(), "Pytest must be loaded from the .venv site-packages."
