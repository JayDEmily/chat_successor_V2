"""Opt-in OpenAI vector store witness test.

This test only runs when OPENAI_INTEGRATION=1, OPENAI_VECTOR_STORE_ID, and
OPENAI_WITNESS_TOKEN are set. It uploads a small text file named
`witness_<token>.txt` to the configured vector store and intentionally does
not delete it so you can verify in the OpenAI dashboard that real calls were
made. Intended for manual runs, not routine CI.
"""

from __future__ import annotations

import io
import os

import pytest
from openai import OpenAI

from app.config import load_settings


@pytest.mark.skipif(
    os.getenv("OPENAI_INTEGRATION", "0") != "1",
    reason="Set OPENAI_INTEGRATION=1 to run the OpenAI witness test",
)
def test_openai_vector_store_witness():
    vector_store_id = os.getenv("OPENAI_VECTOR_STORE_ID", "")
    token = os.getenv("OPENAI_WITNESS_TOKEN", "")
    if not vector_store_id or not token:
        pytest.skip(
            "Set OPENAI_VECTOR_STORE_ID and OPENAI_WITNESS_TOKEN to run the OpenAI witness test"
        )

    settings = load_settings()
    client = OpenAI(api_key=settings.openai_api_key)

    text = f"WITNESS::{token}"
    payload = text.encode("utf-8")
    filename = f"witness_{token}.txt"

    file_obj = client.files.create(
        file=(filename, io.BytesIO(payload)),
        purpose="assistants",
    )

    vs_file = client.vector_stores.files.create_and_poll(
        vector_store_id=settings.openai_vector_store_id,
        file_id=file_obj.id,
    )

    assert vs_file.vector_store_id == settings.openai_vector_store_id
    assert vs_file.status == "completed"

    print(
        f"WITNESS_CREATED file_id={file_obj.id} vector_store_file_id={vs_file.id} filename={filename}"
    )
