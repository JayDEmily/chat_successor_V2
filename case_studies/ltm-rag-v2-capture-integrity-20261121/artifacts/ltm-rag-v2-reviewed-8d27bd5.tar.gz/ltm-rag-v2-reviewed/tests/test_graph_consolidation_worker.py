"""Consolidation worker behaviours: markers, idempotency, evidence linkage."""

from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace

import pytest


class FakeDynamo:
    def __init__(self):
        self.nodes: dict[str, SimpleNamespace] = {}
        self.marker = {}

    def put_node(self, node: SimpleNamespace):
        self.nodes[node.node_id] = node

    def get_nodes(self, root_session_id: str):
        return [n for n in self.nodes.values() if n.root_session_id == root_session_id]

    def get_marker(self, root_session_id: str, session_id: str):
        return self.marker.get((root_session_id, session_id))

    def update_marker(self, root_session_id: str, session_id: str, seq: int):
        self.marker[(root_session_id, session_id)] = seq


class FakeVectorStore:
    def __init__(self):
        self.uploads = []

    def upload(self, node: SimpleNamespace):
        self.uploads.append(node)


class FakeLogger:
    def __init__(self):
        self.infos = []
        self.warnings = []

    def info(self, msg, extra=None):
        self.infos.append((msg, extra or {}))

    def warning(self, msg, extra=None):
        self.warnings.append((msg, extra or {}))


def _message(seq_start=0, seq_end=1, candidates=None):
    return {
        "root_session_id": "root",
        "session_id": "sess",
        "sequence_start": seq_start,
        "sequence_end": seq_end,
        "candidates": candidates or [
            {
                "entity": "python_version",
                "type": "config",
                "fact": "3.11.9",
                "confidence": 0.9,
                "source_event_ids": ["evt-1", "evt-2"],
            }
        ],
        "transcript_events": [
            {"event_id": "evt-1", "content": "user: install python"},
            {"event_id": "evt-2", "content": "assistant: set python 3.11.9"},
        ],
    }


def _run_worker(msg, store, vector=None, logger=None):
    import app.graph_consolidation_worker as worker  # type: ignore[import-not-found]

    return worker.handle_consolidation_message(
        message=msg,
        node_store=store,
        vector_store=vector or FakeVectorStore(),
        logger=logger or FakeLogger(),
        now=datetime.now(timezone.utc),
    )


def test_consolidation_updates_last_processed_sequence_marker():
    """After processing, marker for (root, session) should reflect sequence_end."""
    store = FakeDynamo()
    msg = _message(seq_start=10, seq_end=12)

    _run_worker(msg, store)

    assert store.get_marker("root", "sess") == 12


def test_consolidation_skips_when_sequence_already_processed():
    """If marker already at or beyond sequence_end, worker should skip and not write nodes or upload."""
    store = FakeDynamo()
    store.update_marker("root", "sess", 15)
    vector = FakeVectorStore()
    logger = FakeLogger()
    msg = _message(seq_start=10, seq_end=12)

    _run_worker(msg, store, vector=vector, logger=logger)

    assert store.get_nodes("root") == []
    assert vector.uploads == []
    assert any("skip" in (extra or {}).get("status", "") or "skip" in (extra or {}).get("stage", "")
               for _, extra in logger.infos + logger.warnings)


def test_consolidation_idempotent_on_duplicate_message():
    """Replaying same message should not duplicate nodes or uploads."""
    store = FakeDynamo()
    vector = FakeVectorStore()
    msg = _message(seq_start=0, seq_end=1)

    _run_worker(msg, store, vector=vector)
    first_nodes = list(store.nodes.keys())
    _run_worker(msg, store, vector=vector)
    second_nodes = list(store.nodes.keys())

    assert first_nodes == second_nodes
    assert len(vector.uploads) == 1


def test_consolidation_applies_actions_and_persists_invariants():
    """Integration path: node persisted with active state; previous superseded gets valid_to and superseded_by."""
    store = FakeDynamo()
    # first version
    _run_worker(_message(seq_start=0, seq_end=1, candidates=[{"entity": "python_version", "type": "config", "fact": "3.10", "confidence": 0.9, "source_event_ids": ["evt-1"]}]), store)
    # superseding version
    _run_worker(_message(seq_start=2, seq_end=3, candidates=[{"entity": "python_version", "type": "config", "fact": "3.11", "confidence": 0.9, "source_event_ids": ["evt-2"]}]), store)

    nodes = store.get_nodes("root")
    actives = [n for n in nodes if n.state == "active"]
    superseded = [n for n in nodes if n.state == "superseded"]
    assert len(actives) == 1
    assert actives[0].fact == "3.11"
    assert len(superseded) == 1
    assert superseded[0].superseded_by == actives[0].node_id
    assert superseded[0].valid_to is not None
    assert actives[0].supersedes and superseded[0].node_id in actives[0].supersedes


def test_consolidation_indexes_graph_fact_vector_optionally():
    """When enabled, consolidated node triggers graph_fact upload with metadata."""
    store = FakeDynamo()
    vector = FakeVectorStore()
    msg = _message()

    _run_worker(msg, store, vector=vector)

    assert vector.uploads, "Expected graph_fact upload"
    upload = vector.uploads[0]
    assert upload.fact == "3.11.9"
    assert upload.kind in ("graph_fact", "graph_fact_upload")


def test_persisted_nodes_source_event_ids_resolve_to_transcript_events():
    """All source_event_ids on persisted nodes must map to transcript events / recent_events set."""
    store = FakeDynamo()
    msg = _message(candidates=[{"entity": "python_version", "type": "config", "fact": "3.11", "confidence": 0.9, "source_event_ids": ["evt-1", "evt-2"]}])

    _run_worker(msg, store)

    nodes = store.get_nodes("root")
    assert nodes, "Expected node persisted"
    node = nodes[0]
    transcript_ids = {evt["event_id"] for evt in msg["transcript_events"]}
    assert set(node.source_event_ids).issubset(transcript_ids)
