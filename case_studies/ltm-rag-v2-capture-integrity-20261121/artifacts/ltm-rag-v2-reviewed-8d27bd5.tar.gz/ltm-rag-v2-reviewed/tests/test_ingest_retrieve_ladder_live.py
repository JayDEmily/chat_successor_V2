"""Live ladder: prove user fact is indexed then retrieved on the very next /turn."""

from __future__ import annotations

import os
import uuid

import pytest

from app.micro_agent import MicroAgent
from app.micro_agent.env_loader import load_env
from app.micro_agent.turn_client import resolve_function_url


load_env()


@pytest.mark.skipif(os.getenv("LIVE_RAG") != "1", reason="Set LIVE_RAG=1 to run live ladder test")
def test_ingest_then_retrieve_user_fact_ladder_live():
    function_url = resolve_function_url()

    root_session_id = f"ladder-{uuid.uuid4().hex}"
    session_id = root_session_id
    agent = MicroAgent(root_session_id, session_id, function_url=function_url)

    user_fact = f"USER_FACT_{uuid.uuid4().hex}"
    seed_message = (
        f"Please store this token exactly: {user_fact}. Reply only with 'ACK' and do not repeat the token."
    )

    r1 = agent.step(seed_message)
    assert r1.http_status == 200
    assert r1.turn_response.get("persisted_last_turn") is False
    assert isinstance(r1.assistant_text, str)
    assert user_fact not in r1.assistant_text
    telemetry1 = r1.turn_response.get("memory_telemetry")
    assert isinstance(telemetry1, dict)

    probe_message = "What is the exact token I gave you earlier? Reply with the token only."
    r2 = agent.step(probe_message)
    body2 = r2.turn_response

    assert r2.http_status == 200
    assert body2.get("persisted_last_turn") is True

    telemetry = body2.get("memory_telemetry")
    assert isinstance(telemetry, dict)
    assert telemetry.get("semantic_search_ran") is True
    assert telemetry.get("semantic_index_ran") is True

    hits = body2.get("semantic_hits")
    assert isinstance(hits, list) and hits
    fact_hits = [hit for hit in hits if isinstance(hit, dict) and user_fact in str(hit.get("text", ""))]
    assert fact_hits
    hit = fact_hits[0]
    meta = hit.get("metadata")
    assert isinstance(meta, dict)
    assert meta.get("role") == "user"
    assert meta.get("root_session_id") == root_session_id
    assert meta.get("session_id") == session_id

    events = body2.get("recent_events") or []
    user_events = [
        evt
        for evt in events
        if isinstance(evt, dict) and evt.get("role") == "user" and user_fact in str(evt.get("content", ""))
    ]
    assert user_events
    user_event_id = user_events[0].get("event_id")
    assert user_event_id
    assert meta.get("event_id") == user_event_id or meta.get("id") == user_event_id

    # Isolation: second session should not see the token.
    other_root = f"ladder-other-{uuid.uuid4().hex}"
    other_session = other_root
    other_agent = MicroAgent(other_root, other_session, function_url=function_url)
    isolation_probe = (
        f"Remember earlier you heard someone mention token {user_fact}? What exactly was that token?"
    )
    r_iso = other_agent.step(isolation_probe)
    iso_body = r_iso.turn_response

    iso_telemetry = iso_body.get("memory_telemetry")
    assert isinstance(iso_telemetry, dict)
    assert iso_telemetry.get("semantic_search_ran") is True

    iso_hits = iso_body.get("semantic_hits")
    assert isinstance(iso_hits, list)
    assert all(user_fact not in str(hit.get("text", "")) if isinstance(hit, dict) else True for hit in iso_hits)
