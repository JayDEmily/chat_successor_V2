"""Specification-style tests for semantic memory backends.

OpenAI vector store is the primary/target backend; `none` is dev/safe.
"""

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from app import semantic_memory
from app.models import SemanticHit


def _settings(backend: str):
    # Minimal settings object; semantic_memory only needs attributes used
    # by the respective backend path.
    return SimpleNamespace(
        semantic_backend=backend,
        openai_vector_store_id="vs_dummy_for_tests",
        openai_api_key="sk-test",
        semantic_search_scope="root",
        semantic_chunk_size_tokens=800,
        semantic_chunk_overlap_tokens=0,
    )


def test_search_memory_returns_empty_when_backend_none(monkeypatch):
    settings = _settings("none")
    llm = MagicMock()
    openai_ctor = MagicMock()
    monkeypatch.setattr(semantic_memory, "OpenAI", openai_ctor)
    # If the backend is none, we should bypass any external semantic search entirely.
    hits = semantic_memory.search_memory(settings, llm, "query")
    assert hits == []
    openai_ctor.assert_not_called()


def test_index_memory_skips_openai_when_backend_none(monkeypatch):
    settings = _settings("none")
    llm = MagicMock()
    openai_ctor = MagicMock()
    monkeypatch.setattr(semantic_memory, "OpenAI", openai_ctor)

    doc = semantic_memory.SemanticDoc(
        id="evt",
        root_session_id="root",
        session_id="sess",
        sequence=1,
        role="assistant",
        text="hello world",
        embedding=[],
        created_at="2024-01-01T00:00:00Z",
    )

    semantic_memory.index_memory(settings, llm, doc)
    openai_ctor.assert_not_called()


def test_index_memory_openai_calls_vector_store(monkeypatch):
    settings = _settings("openai")
    llm = MagicMock()

    # Stub OpenAI client pieces
    fake_vs = MagicMock()
    fake_vs.files.create_and_poll = MagicMock()
    fake_client = MagicMock(vector_stores=fake_vs, files=MagicMock())
    monkeypatch.setattr(semantic_memory, "OpenAI", MagicMock(return_value=fake_client))

    doc = semantic_memory.SemanticDoc(
        id="evt",
        root_session_id="root",
        session_id="sess",
        sequence=1,
        role="assistant",
        text="hello world",
        embedding=[],
        created_at="2024-01-01T00:00:00Z",
    )

    semantic_memory.index_memory(settings, llm, doc)
    fake_vs.files.create_and_poll.assert_called_once()
    _, kwargs = fake_vs.files.create_and_poll.call_args
    assert kwargs["vector_store_id"] == settings.openai_vector_store_id
    attrs = kwargs["attributes"]
    assert attrs["id"] == doc.id
    assert attrs["root_session_id"] == doc.root_session_id
    assert attrs["session_id"] == doc.session_id
    assert attrs["sequence"] == doc.sequence
    assert attrs["role"] == doc.role
    assert attrs["created_at"] == doc.created_at
    assert attrs["kind"] == doc.kind


def test_index_memory_plain_text_and_event_id(monkeypatch):
    settings = _settings("openai")
    llm = MagicMock()

    captured = {}

    class FakeFiles:
        def create(self, file=None, purpose=None):
            captured["payload"] = file.read()
            return SimpleNamespace(id="file-1")

    class FakeVectorStoreFiles:
        def create_and_poll(self, **kwargs):
            captured["attributes"] = kwargs["attributes"]
            return MagicMock()

    client = SimpleNamespace(
        files=FakeFiles(),
        vector_stores=SimpleNamespace(files=FakeVectorStoreFiles()),
    )
    monkeypatch.setattr(semantic_memory, "OpenAI", MagicMock(return_value=client))

    doc = semantic_memory.SemanticDoc(
        id="evt",
        root_session_id="root",
        session_id="sess",
        sequence=1,
        role="assistant",
        text="assistant text",
        embedding=[],
        created_at="2024-01-01T00:00:00Z",
    )

    semantic_memory.index_memory(settings, llm, doc)

    assert captured["payload"] == b"assistant text"
    attrs = captured["attributes"]
    assert attrs["id"] == doc.id
    assert attrs["event_id"] == doc.id


def test_index_memory_passes_chunk_settings(monkeypatch):
    settings = SimpleNamespace(
        semantic_backend="openai",
        openai_vector_store_id="vs_dummy_for_tests",
        openai_api_key="sk-test",
        semantic_chunk_size_tokens=512,
        semantic_chunk_overlap_tokens=16,
    )
    llm = MagicMock()

    class FakeFiles:
        def create(self, file=None, purpose=None):
            return SimpleNamespace(id="file-1")

    captured = {}

    class FakeVectorStoreFiles:
        def create_and_poll(self, **kwargs):
            captured["chunking"] = kwargs["chunking_strategy"]
            return MagicMock()

    client = SimpleNamespace(
        files=FakeFiles(),
        vector_stores=SimpleNamespace(files=FakeVectorStoreFiles()),
    )
    monkeypatch.setattr(semantic_memory, "OpenAI", MagicMock(return_value=client))

    doc = semantic_memory.SemanticDoc(
        id="evt",
        root_session_id="root",
        session_id="sess",
        sequence=1,
        role="assistant",
        text="assistant text",
        embedding=[],
        created_at="2024-01-01T00:00:00Z",
    )

    semantic_memory.index_memory(settings, llm, doc)

    chunking = captured["chunking"]["static"]
    assert chunking["max_chunk_size_tokens"] == settings.semantic_chunk_size_tokens
    assert chunking["chunk_overlap_tokens"] == settings.semantic_chunk_overlap_tokens


def test_search_memory_openai_uses_filters(monkeypatch):
    settings = _settings("openai")
    llm = MagicMock()

    search_return = MagicMock(data=[
        MagicMock(
            content=[],
            score=0.9,
            attributes={"root_session_id": "root", "session_id": "sess"},
        )
    ])
    fake_vs = MagicMock(search=MagicMock(return_value=search_return))
    fake_client = MagicMock(vector_stores=fake_vs)
    monkeypatch.setattr(semantic_memory, "OpenAI", MagicMock(return_value=fake_client))

    hits = semantic_memory.search_memory(
        settings,
        llm,
        "query text",
        root_session_id="root",
        session_id="sess",
        k=2,
    )
    assert isinstance(hits, list)
    assert hits and isinstance(hits[0], SemanticHit)
    fake_vs.search.assert_called_once()
    _, kwargs = fake_vs.search.call_args
    assert kwargs["vector_store_id"] == settings.openai_vector_store_id
    assert kwargs["max_num_results"] == 2
    filters = kwargs["filters"]
    assert filters["type"] == "and"
    assert {f["key"]: f["value"] for f in filters["filters"]} == {
        "root_session_id": "root",
        "session_id": "sess",
    }


def test_search_memory_openai_maps_hits(monkeypatch):
    settings = _settings("openai")
    llm = MagicMock()

    text_chunk = SimpleNamespace(type="text", text="hit text")
    search_return = MagicMock(
        data=[
            SimpleNamespace(
                content=[text_chunk],
                score="0.75",
                attributes={
                    "root_session_id": "root",
                    "session_id": "sess",
                    "sequence": 3,
                    "role": "assistant",
                    "created_at": "2024-01-01T00:00:00Z",
                },
            )
        ]
    )
    fake_vs = MagicMock(search=MagicMock(return_value=search_return))
    fake_client = MagicMock(vector_stores=fake_vs)
    monkeypatch.setattr(semantic_memory, "OpenAI", MagicMock(return_value=fake_client))

    hits = semantic_memory.search_memory(
        settings,
        llm,
        "query",
        root_session_id="root",
    )

    assert hits and isinstance(hits[0], SemanticHit)
    hit = hits[0]
    assert hit.text == "hit text"
    assert hit.score == 0.75
    assert hit.metadata["root_session_id"] == "root"
    assert hit.metadata["sequence"] == 3
    assert hit.metadata["created_at"] == "2024-01-01T00:00:00Z"


def test_search_memory_returns_empty_for_blank_query(monkeypatch):
    settings = _settings("openai")
    llm = MagicMock()

    openai_mock = MagicMock()
    monkeypatch.setattr(semantic_memory, "OpenAI", openai_mock)

    hits = semantic_memory.search_memory(settings, llm, "   ")
    assert hits == []
    openai_mock.assert_not_called()
