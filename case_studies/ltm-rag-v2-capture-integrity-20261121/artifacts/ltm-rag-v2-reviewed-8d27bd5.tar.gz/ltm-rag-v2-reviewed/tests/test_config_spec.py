"""Config contract tests (spec-level).

These encode expected behaviour for environment validation and embedding model
dimension checks. They are offline and use dummy env values.
"""

import os

import pytest

from app import config


def _set_minimal_env(monkeypatch, **overrides):
    # Canonical defaults: openai backend, GPT-5.1 summaries, text-embedding-3-large embeddings.
    base = {
        "AWS_REGION": "ap-southeast-2",
        "TRANSCRIPT_BUCKET": "my-memory-transcripts",
        "STATE_TABLE": "my-memory-state",
        "OPENAI_API_KEY": "sk-test",
        "OPENAI_VECTOR_STORE_ID": "vs_dummy",
        "EMBEDDING_MODEL_NAME": "text-embedding-3-large",
        "SUMMARY_MODEL_NAME": "gpt-5.1",
        "SEMANTIC_BACKEND": "openai",
    }
    base.update(overrides)
    for k, v in base.items():
        if v is None:
            monkeypatch.delenv(k, raising=False)
        else:
            monkeypatch.setenv(k, v)


def test_load_settings_raises_for_missing_env(monkeypatch):
    # Ensure no accidental leakage from the real environment.
    for key in list(os.environ.keys()):
        if key.startswith(("AWS_REGION", "TRANSCRIPT_BUCKET", "STATE_TABLE", "OPENSEARCH", "OPENAI", "EMBEDDING_MODEL_NAME", "SUMMARY_MODEL_NAME")):
            monkeypatch.delenv(key, raising=False)

    with pytest.raises(config.ConfigError):
        config.load_settings()


@pytest.mark.parametrize(
    "missing_key",
    [
        "AWS_REGION",
        "TRANSCRIPT_BUCKET",
        "STATE_TABLE",
        "OPENAI_API_KEY",
        "EMBEDDING_MODEL_NAME",
        "SUMMARY_MODEL_NAME",
    ],
)
def test_load_settings_raises_for_missing_required_env(monkeypatch, missing_key):
    _set_minimal_env(monkeypatch)
    monkeypatch.delenv(missing_key, raising=False)
    with pytest.raises(config.ConfigError):
        config.load_settings()


def test_load_settings_raises_for_unknown_embedding_model(monkeypatch):
    _set_minimal_env(monkeypatch, EMBEDDING_MODEL_NAME="unknown-model")
    with pytest.raises(config.ConfigError) as excinfo:
        config.load_settings()

    message = str(excinfo.value)
    for model_name in config.EMBEDDING_DIMS:
        assert model_name in message


@pytest.mark.parametrize(
    "embedding_model, expected_dim",
    list(config.EMBEDDING_DIMS.items()),
)
def test_load_settings_succeeds_with_known_models(monkeypatch, embedding_model, expected_dim):
    _set_minimal_env(monkeypatch, EMBEDDING_MODEL_NAME=embedding_model)
    settings = config.load_settings()
    assert settings.embedding_model == embedding_model
    assert settings.summary_model == "gpt-5.1"
    assert settings.embedding_dim == expected_dim
    assert settings.openai_vector_store_id == "vs_dummy"


def test_semantic_backend_must_be_allowed_value(monkeypatch):
    _set_minimal_env(monkeypatch, SEMANTIC_BACKEND="opensearch")
    with pytest.raises(config.ConfigError):
        config.load_settings()


def test_vector_store_required_for_openai_backend(monkeypatch):
    _set_minimal_env(
        monkeypatch,
        OPENAI_VECTOR_STORE_ID="",
        SEMANTIC_BACKEND="openai",
        EMBEDDING_MODEL_NAME="text-embedding-3-large",
        SUMMARY_MODEL_NAME="gpt-5.1",
    )
    with pytest.raises(config.ConfigError):
        config.load_settings()


def test_vector_store_required_when_backend_default_openai(monkeypatch):
    _set_minimal_env(
        monkeypatch,
        OPENAI_VECTOR_STORE_ID=None,
        SEMANTIC_BACKEND=None,
    )
    with pytest.raises(config.ConfigError):
        config.load_settings()


def test_vector_store_optional_when_backend_none(monkeypatch):
    _set_minimal_env(
        monkeypatch,
        SEMANTIC_BACKEND="none",
        OPENAI_VECTOR_STORE_ID=None,
    )
    settings = config.load_settings()
    assert settings.semantic_backend == "none"
    assert settings.openai_vector_store_id is None


def test_semantic_backend_defaults_to_openai_when_unset(monkeypatch):
    _set_minimal_env(
        monkeypatch,
        SEMANTIC_BACKEND=None,
    )
    settings = config.load_settings()
    assert settings.semantic_backend == "openai"
