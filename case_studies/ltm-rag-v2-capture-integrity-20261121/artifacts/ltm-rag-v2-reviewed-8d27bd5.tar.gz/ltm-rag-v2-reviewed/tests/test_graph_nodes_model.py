"""V3 data model round-trip and basic invariants for memory_nodes/edges."""

from __future__ import annotations

from datetime import datetime, timezone, timedelta
from types import SimpleNamespace

import pytest


def _utc(ts: str) -> datetime:
    return datetime.fromisoformat(ts.replace("Z", "+00:00")).astimezone(timezone.utc)


@pytest.fixture
def node_factory():
    def _make(
        *,
        node_id: str = "node-1",
        root_session_id: str = "root",
        entity: str = "python_version",
        type: str = "config",
        fact: str = "3.11",
        state: str = "active",
        confidence: float = 0.9,
        updated_at: datetime | None = None,
        valid_from: datetime | None = None,
        valid_to: datetime | None = None,
        source_event_ids: list[str] | None = None,
        source_session_ids: list[str] | None = None,
        supersedes: list[str] | None = None,
        superseded_by: str | None = None,
        history_reason: str | None = None,
        tags: list[str] | None = None,
    ):
        updated_at = updated_at or datetime.now(timezone.utc)
        valid_from = valid_from or updated_at
        return SimpleNamespace(
            node_id=node_id,
            root_session_id=root_session_id,
            entity=entity,
            type=type,
            fact=fact,
            state=state,
            confidence=confidence,
            updated_at=updated_at,
            valid_from=valid_from,
            valid_to=valid_to,
            source_event_ids=source_event_ids or [],
            source_session_ids=source_session_ids or [],
            supersedes=supersedes or [],
            superseded_by=superseded_by,
            history_reason=history_reason,
            tags=tags or [],
        )

    return _make


def test_memory_node_to_from_item_round_trip(monkeypatch, node_factory):
    """Round-trip should preserve all fields including timeline and links."""
    from app import graph_models  # type: ignore[import-not-found]

    node = node_factory(
        fact="3.12.1",
        state="superseded",
        valid_to=datetime.now(timezone.utc) + timedelta(days=1),
        source_event_ids=["evt-1", "evt-2"],
        supersedes=["node-old"],
        superseded_by="node-new",
        history_reason="Upgraded runtime",
        tags=["runtime", "python"],
    )
    item = node.__class__  # satisfy mypy
    item = graph_models.MemoryNode(**node.__dict__).to_item()

    restored = graph_models.MemoryNode.from_item(item)
    assert restored.node_id == node.node_id
    assert restored.entity == node.entity
    assert restored.type == node.type
    assert restored.fact == node.fact
    assert restored.state == node.state
    assert restored.confidence == node.confidence
    assert restored.valid_from.replace(microsecond=0) == node.valid_from.replace(microsecond=0)
    assert restored.valid_to.replace(microsecond=0) == node.valid_to.replace(microsecond=0)
    assert restored.source_event_ids == node.source_event_ids
    assert restored.supersedes == node.supersedes
    assert restored.superseded_by == node.superseded_by
    assert restored.history_reason == node.history_reason
    assert restored.tags == node.tags


def test_memory_edge_to_from_item_round_trip():
    """Edges serialize/deserialize all key fields."""
    from app import graph_models  # type: ignore[import-not-found]

    edge = graph_models.MemoryEdge(
        root_session_id="root",
        from_node_id="a",
        to_node_id="b",
        relation="depends_on",
        created_at=datetime.now(timezone.utc),
        tags=["dep"],
    )
    item = edge.to_item()
    restored = graph_models.MemoryEdge.from_item(item)
    assert restored.root_session_id == edge.root_session_id
    assert restored.from_node_id == edge.from_node_id
    assert restored.to_node_id == edge.to_node_id
    assert restored.relation == edge.relation
    assert restored.tags == edge.tags


def test_superseded_nodes_capture_valid_to_and_superseded_by(node_factory):
    """Superseded nodes must carry valid_to and superseded_by for audit."""
    from app import graph_models  # type: ignore[import-not-found]

    now = datetime.now(timezone.utc)
    node = graph_models.MemoryNode(
        **node_factory(
            state="superseded",
            valid_to=now,
            superseded_by="node-new",
        ).__dict__
    )
    assert node.state == "superseded"
    assert node.valid_to == now
    assert node.superseded_by == "node-new"


def test_only_one_active_node_per_entity_type_enforced_by_query_filter(node_factory):
    """Given mixed states, filtering for active should yield a single active node."""
    from app import graph_models  # type: ignore[import-not-found]

    active = graph_models.MemoryNode(**node_factory(node_id="active", state="active").__dict__)
    superseded = graph_models.MemoryNode(
        **node_factory(node_id="old", state="superseded", superseded_by="active").__dict__
    )
    reopened = graph_models.MemoryNode(
        **node_factory(node_id="reopened", state="reopened").__dict__
    )
    nodes = [active, superseded, reopened]

    actives = [n for n in nodes if n.state == "active"]
    assert len(actives) == 1
    assert actives[0].node_id == "active"

