from __future__ import annotations

from datetime import datetime, timezone, timedelta
from types import SimpleNamespace

from app.graph_models import MemoryNode, make_node_id
from app.graph_retrieval import load_graph_memory


class FakeTable:
    def __init__(self, items):
        self._items = items

    def query(self, KeyConditionExpression=None, ConsistentRead=False):
        return {"Items": [item.to_item() if hasattr(item, "to_item") else item for item in self._items]}


def _node(root: str, session: str | None, entity: str, fact: str, ts: datetime):
    return MemoryNode(
        node_id=make_node_id(root, entity, "config", fact),
        root_session_id=root,
        entity=entity,
        type="config",
        fact=fact,
        state="active",
        confidence=1.0,
        source_event_ids=[f"{session or 'legacy'}-evt"],
        source_session_ids=[session] if session else [],
        created_at=ts,
        updated_at=ts,
    )


def test_load_graph_memory_filters_by_session_id(monkeypatch):
    """Graph retrieval should exclude nodes tied to other sessions, but keep legacy nodes with no session provenance."""
    root = "root"
    now = datetime.now(timezone.utc)
    n1 = _node(root, "sess-1", "python_version", "3.11", now)
    n2 = _node(root, "sess-2", "python_version", "3.12", now + timedelta(minutes=1))
    legacy = _node(root, None, "tooling", "bash", now)

    fake_table = FakeTable([n1, n2, legacy])
    monkeypatch.setattr("app.graph_retrieval.get_memory_nodes_table", lambda settings: fake_table)

    facts, history = load_graph_memory(settings=SimpleNamespace(), root_session_id=root, session_id="sess-1", entity_hint=None)

    assert isinstance(facts, list) and isinstance(history, dict)
    # Only the session-scoped node (and legacy) should be present for python_version.
    py_facts = [f for f in facts if f.get("entity") == "python_version"]
    assert len(py_facts) == 1
    assert py_facts[0]["fact"] == "3.11"
    assert "sess-2" not in py_facts[0].get("source_session_ids", [])

    # Legacy node without session provenance should remain available.
    legacy_facts = [f for f in facts if f.get("entity") == "tooling"]
    assert legacy_facts and legacy_facts[0]["fact"] == "bash"
