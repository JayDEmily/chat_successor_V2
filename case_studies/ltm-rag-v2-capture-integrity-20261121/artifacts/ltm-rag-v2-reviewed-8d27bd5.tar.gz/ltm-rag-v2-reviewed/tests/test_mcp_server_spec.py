"""Specs for MCP server tool wiring (request/response shapes)."""

import pytest
from mcp.server import Server  # type: ignore[import]

# Older MCP versions expose `tool` as a decorator on Server; skip if unavailable.
if not hasattr(Server, "tool"):
    pytest.skip("mcp.Server missing tool decorator; skipping MCP tool specs", allow_module_level=True)

from app import mcp_server
from app.models import (
    Event,
    PostPhaseRequest,
    PostPhaseResponse,
    PrePhaseRequest,
    PrePhaseResponse,
    SemanticHit,
    utc_now,
)


@pytest.mark.asyncio
async def test_memory_pre_tool_wraps_handle_pre(monkeypatch):
    captured_req = {}
    event = Event(
        event_id="e1",
        root_session_id="root",
        session_id="sess",
        sequence=0,
        role="user",
        created_at=utc_now(),
        content="hi",
    )
    hit = SemanticHit(text="hit", score=1.0, metadata={"marker": "m"})

    def fake_handle_pre(req: PrePhaseRequest):
        captured_req["req"] = req
        return PrePhaseResponse(short_summary="summary", recent_events=[event], semantic_hits=[hit])

    monkeypatch.setattr(mcp_server, "handle_pre", fake_handle_pre)

    result = await mcp_server.memory_pre(
        root_session_id="root",
        session_id="sess",
        user_message="hello",
    )

    assert isinstance(captured_req["req"], PrePhaseRequest)
    assert captured_req["req"].root_session_id == "root"
    assert captured_req["req"].session_id == "sess"
    assert captured_req["req"].user_message == "hello"

    assert result["short_summary"] == "summary"
    assert result["recent_events"][0]["event_id"] == event.event_id
    assert result["semantic_hits"][0]["metadata"]["marker"] == "m"


@pytest.mark.asyncio
async def test_memory_post_tool_wraps_handle_post(monkeypatch):
    captured_req = {}

    def fake_handle_post(req: PostPhaseRequest):
        captured_req["req"] = req
        return PostPhaseResponse(ok=True)

    monkeypatch.setattr(mcp_server, "handle_post", fake_handle_post)

    result = await mcp_server.memory_post(
        root_session_id="root",
        session_id="sess",
        user_message="hi",
        assistant_message="there",
    )

    assert isinstance(captured_req["req"], PostPhaseRequest)
    assert captured_req["req"].root_session_id == "root"
    assert captured_req["req"].session_id == "sess"
    assert captured_req["req"].user_message == "hi"
    assert captured_req["req"].assistant_message == "there"

    assert result["ok"] is True


def test_run_mcp_healthcheck_calls_healthcheck(monkeypatch):
    called = False

    def fake_healthcheck():
        nonlocal called
        called = True

    monkeypatch.setattr(mcp_server, "run_healthcheck", fake_healthcheck)

    mcp_server.run_mcp_healthcheck()

    assert called is True
