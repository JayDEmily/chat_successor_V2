"""HTTP contract tests for lambda_handler.

These define the Function URL / Custom GPT Actions HTTP contract. They use
fake API Gateway-style events but do not depend on a specific front door,
and they mock handlers to avoid real AWS/OpenAI calls. Treat this as the
local harness example for driving `lambda_handler` directly.
"""

import json
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

import lambda_handler as lh
from app.config import ConfigError
from app.models import MemoryTelemetry, PostPhaseResponse, PrePhaseResponse, TurnResponse
from app.response_budget import enforce_response_budget


@pytest.fixture(autouse=True)
def reset_healthcheck(monkeypatch):
    # Prevent real healthcheck work in tests.
    monkeypatch.setattr(lh, "run_healthcheck", lambda: None)
    lh._HEALTHCHECK_RAN = False


def test_healthcheck_runs_once_then_is_skipped(monkeypatch):
    """Cold-start guard should only run healthcheck on first invocation."""
    run_hc = MagicMock()
    monkeypatch.setattr(lh, "run_healthcheck", run_hc)

    pre_resp = PrePhaseResponse(
        short_summary=None,
        recent_events=[],
        semantic_hits=[],
        memory_telemetry=MemoryTelemetry(),
    )
    enforce_response_budget(pre_resp, budget_bytes=200000)
    post_resp = PostPhaseResponse(ok=True)
    monkeypatch.setattr(lh, "handle_pre", MagicMock(return_value=pre_resp))
    monkeypatch.setattr(lh, "handle_post", MagicMock(return_value=post_resp))

    pre_event = {
        "rawPath": "/pre",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "user_message": "hi",
            }
        ),
    }
    post_event = {
        "rawPath": "/post",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "user_message": "hi",
                "assistant_message": "hello",
            }
        ),
    }

    lh.lambda_handler(pre_event, context=None)
    lh.lambda_handler(post_event, context=None)

    assert run_hc.call_count == 1
    lh.handle_pre.assert_called_once()
    lh.handle_post.assert_called_once()


def test_lambda_handler_pre_happy_path(monkeypatch):
    fake_resp = PrePhaseResponse(
        short_summary="sum",
        recent_events=[],
        semantic_hits=[],
        memory_telemetry=MemoryTelemetry(),
    )
    enforce_response_budget(fake_resp, budget_bytes=200000)
    monkeypatch.setattr(lh, "handle_pre", MagicMock(return_value=fake_resp))

    event = {
        "rawPath": "/pre",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "user_message": "hi",
            }
        ),
    }
    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 200
    body = json.loads(resp["body"])
    assert body["short_summary"] == "sum"
    assert body["recent_events"] == []
    assert body["semantic_hits"] == []
    assert body.get("response_truncated") is False
    assert isinstance(body.get("bytes_total"), int)


def test_healthcheck_failure_short_circuits(monkeypatch):
    run_hc = MagicMock(side_effect=ConfigError("boom"))
    monkeypatch.setattr(lh, "run_healthcheck", run_hc)

    handle_pre = MagicMock()
    monkeypatch.setattr(lh, "handle_pre", handle_pre)

    event = {
        "rawPath": "/pre",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "user_message": "hi",
            }
        ),
    }

    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 500
    body = json.loads(resp["body"])
    assert body.get("error") == "boom"
    handle_pre.assert_not_called()
    # Healthcheck should not mark the guard when it fails.
    assert lh._HEALTHCHECK_RAN is False


def test_lambda_handler_post_happy_path(monkeypatch):
    fake_resp = PostPhaseResponse(ok=True)
    monkeypatch.setattr(lh, "handle_post", MagicMock(return_value=fake_resp))

    event = {
        "rawPath": "/post",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "user_message": "hi",
                "assistant_message": "hello",
            }
        ),
    }
    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 200
    body = json.loads(resp["body"])
    assert body["ok"] is True


def test_lambda_handler_turn_happy_path(monkeypatch):
    fake_resp = TurnResponse(
        short_summary=None,
        recent_events=[],
        semantic_hits=[],
        persisted_last_turn=True,
        memory_telemetry=MemoryTelemetry(),
    )
    enforce_response_budget(fake_resp, budget_bytes=200000)
    monkeypatch.setattr(lh, "handle_turn", MagicMock(return_value=fake_resp))

    event = {
        "rawPath": "/turn",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "last_user_message": "prev user",
                "last_assistant_message": "prev asst",
                "current_user_message": "hi",
            }
        ),
    }
    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 200
    body = json.loads(resp["body"])
    assert body["persisted_last_turn"] is True
    assert "semantic_hits" in body
    assert "recent_events" in body


def test_lambda_handler_missing_field_returns_400(monkeypatch):
    monkeypatch.setattr(lh, "handle_pre", MagicMock())

    event = {
        "rawPath": "/pre",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(
            {
                # root_session_id missing on purpose
                "session_id": "sess1",
                "user_message": "hi",
            }
        ),
    }
    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 400
    body = json.loads(resp["body"])
    assert "Missing field" in body["error"]


def test_lambda_handler_rejects_wrong_method(monkeypatch):
    monkeypatch.setattr(lh, "handle_pre", MagicMock())

    event = {
        "rawPath": "/pre",
        "requestContext": {"http": {"method": "GET"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "user_message": "hi",
            }
        ),
    }
    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 404
    body = json.loads(resp["body"])
    assert "error" in body


def test_lambda_handler_unknown_path_returns_404(monkeypatch):
    event = {
        "rawPath": "/foo",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "user_message": "hi",
                "assistant_message": "hello",
            }
        ),
    }
    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 404
    body = json.loads(resp["body"])
    assert body.get("error") == "Not found"


def test_lambda_handler_internal_error_returns_500(monkeypatch):
    def boom(*_args, **_kwargs):
        raise RuntimeError("fail")

    monkeypatch.setattr(lh, "handle_pre", boom)

    event = {
        "rawPath": "/pre",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "user_message": "hi",
            }
        ),
    }
    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 500
    body = json.loads(resp["body"])
    # Errors bubble straight to the caller (no rollback/compensation).
    assert body.get("error") == "fail"


def test_lambda_handler_post_missing_assistant_returns_400(monkeypatch):
    monkeypatch.setattr(lh, "handle_post", MagicMock())

    event = {
        "rawPath": "/post",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "user_message": "hi",
                # assistant_message intentionally missing
            }
        ),
    }
    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 400
    body = json.loads(resp["body"])
    assert isinstance(body.get("error"), str) and body["error"]


def test_lambda_handler_malformed_json_returns_400():
    event = {
        "rawPath": "/pre",
        "requestContext": {"http": {"method": "POST"}},
        "body": "{not-json}",
    }
    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 400
    body = json.loads(resp["body"])
    assert isinstance(body.get("error"), str) and body["error"]


def test_lambda_handler_post_rejects_wrong_method(monkeypatch):
    monkeypatch.setattr(lh, "handle_post", MagicMock())

    event = {
        "rawPath": "/post",
        "requestContext": {"http": {"method": "GET"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "user_message": "hi",
                "assistant_message": "hello",
            }
        ),
    }
    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 404
    body = json.loads(resp["body"])
    assert "error" in body


def test_lambda_handler_post_internal_error_returns_500(monkeypatch):
    def boom(*_args, **_kwargs):
        raise RuntimeError("fail")

    monkeypatch.setattr(lh, "handle_post", boom)

    event = {
        "rawPath": "/post",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(
            {
                "root_session_id": "root1",
                "session_id": "sess1",
                "user_message": "hi",
                "assistant_message": "hello",
            }
        ),
    }
    resp = lh.lambda_handler(event, context=None)
    assert resp["statusCode"] == 500
    body = json.loads(resp["body"])
    assert body.get("error") == "fail"
