"""In-process integration test that hits real AWS/OpenAI resources.

Layer 1: local process, real dependencies (S3/Dynamo/OpenAI) without packaging
or redeploying Lambda. Skipped unless LIVE_AWS=1 is set to avoid accidental IO.
"""

from __future__ import annotations

import json
import os
import uuid

import boto3
import pytest

from app import handler
from app.models import PostPhaseRequest, PrePhaseRequest
from app.transcript_logger import _transcript_key


pytestmark = [
    pytest.mark.local_real,
    pytest.mark.skipif(
        os.getenv("LIVE_AWS") != "1",
        reason="Set LIVE_AWS=1 with real AWS/OpenAI env to run local-real integration",
    ),
]


def _fresh_settings():
    """Force handler to reload Settings/LLM from the current environment."""
    handler._settings = None
    handler._llm_client = None
    return handler._get_settings()


def test_pre_post_round_trip_hits_real_io():
    """End-to-end /pre + /post using real S3/Dynamo/OpenAI in-process."""
    settings = _fresh_settings()
    root_session_id = f"live-root-{uuid.uuid4()}"
    session_id = f"live-session-{uuid.uuid4()}"

    post_req = PostPhaseRequest(
        root_session_id=root_session_id,
        session_id=session_id,
        user_message="hello from local-real test",
        assistant_message="acknowledged",
    )

    # Write events and state to real backing services.
    s3 = boto3.client("s3", region_name=settings.aws_region)
    table = boto3.resource("dynamodb", region_name=settings.aws_region).Table(
        settings.state_table
    )
    key = _transcript_key(root_session_id, session_id)

    try:
        post_resp = handler.handle_post(post_req)
        assert post_resp.ok is True

        # Read back via handle_pre to validate persisted state.
        pre_req = PrePhaseRequest(
            root_session_id=root_session_id,
            session_id=session_id,
            user_message="context please",
        )
        pre_resp = handler.handle_pre(pre_req)
        recent = pre_resp.recent_events
        assert (
            len(recent) >= 2
        ), "Expected at least the user+assistant events we just wrote"
        assert [recent[-2].role, recent[-1].role] == ["user", "assistant"]
        assert [recent[-2].sequence, recent[-1].sequence] == [0, 1]

        # Validate the transcript landed in S3.
        obj = s3.get_object(Bucket=settings.transcript_bucket, Key=key)
        lines = obj["Body"].read().decode("utf-8").strip().splitlines()
        assert len(lines) >= 2
        body = [json.loads(line) for line in lines]
        assert body[-2]["role"] == "user" and body[-1]["role"] == "assistant"

        # Validate Dynamo branch state saved the next sequence.
        item = table.get_item(Key={"PK": root_session_id, "SK": session_id}).get("Item")
        assert item, "Branch state missing from DynamoDB"
        assert item.get("next_sequence", 0) >= 2
    finally:
        # Cleanup to keep live resources tidy.
        s3.delete_object(Bucket=settings.transcript_bucket, Key=key)
        table.delete_item(Key={"PK": root_session_id, "SK": session_id})
