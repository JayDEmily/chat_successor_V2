import io
import json
import logging

from app.logging_utils import (
    JsonFormatter,
    get_logger,
    redact_payload,
    request_context,
)


def _capture_log(logger: logging.Logger, message: str = "hello") -> dict:
    """Emit one log line to a string buffer and return parsed JSON."""
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(JsonFormatter())
    logger.handlers = [handler]
    logger.setLevel(logging.INFO)
    logger.propagate = False
    logger.info(message)
    handler.flush()
    line = stream.getvalue().strip()
    return json.loads(line)


def test_json_formatter_includes_context_and_message():
    logger = get_logger("test.logging.json")
    with request_context(request_id="req-123", path="/pre"):
        data = _capture_log(logger, "formatted")

    assert data["message"] == "formatted"
    assert data["level"] == "INFO"
    assert data["request_id"] == "req-123"
    assert data["path"] == "/pre"


def test_redaction_hides_common_secret_patterns():
    payload = {
        "openai_api_key": "sk-secret",
        "token": "my-token",
        "nested": {"api_key": "sk-abc123", "other": "clean"},
        "normal": "value",
        "maybe_secret": "contains sk-123",
    }
    redacted = redact_payload(payload)

    assert redacted["openai_api_key"] == "[REDACTED]"
    assert redacted["token"] == "[REDACTED]"
    assert redacted["nested"]["api_key"] == "[REDACTED]"
    assert redacted["normal"] == "value"
    assert redacted["maybe_secret"] == "[REDACTED]"


def test_request_context_merges_nested_fields():
    logger = get_logger("test.logging.context")
    with request_context(request_id="req-outer"):
        with request_context(path="/post", root_session_id="root-1"):
            data = _capture_log(logger, "nested")

    assert data["request_id"] == "req-outer"
    assert data["path"] == "/post"
    assert data["root_session_id"] == "root-1"
