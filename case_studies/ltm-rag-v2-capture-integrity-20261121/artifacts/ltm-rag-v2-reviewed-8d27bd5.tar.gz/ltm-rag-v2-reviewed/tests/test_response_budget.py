from __future__ import annotations

from app.models import Event, MemoryTelemetry, PrePhaseResponse, SemanticHit, utc_now
from app.response_budget import (
    MAX_RECENT_EVENT_CHARS,
    MAX_SEMANTIC_HIT_CHARS,
    enforce_response_budget,
)


def _make_event(root: str, session: str, sequence: int, content: str) -> Event:
    return Event(
        event_id=f"evt-{sequence}",
        root_session_id=root,
        session_id=session,
        sequence=sequence,
        role="user",
        created_at=utc_now(),
        content=content,
        metadata={},
    )


def test_enforce_response_budget_truncates_and_sets_flags():
    root = "root-budget"
    session = "session-budget"
    events = [
        _make_event(root, session, idx, "u" * 9000) for idx in range(6)
    ]
    hits = [SemanticHit(text="h" * 5000, score=0.5, metadata={}) for _ in range(3)]
    resp = PrePhaseResponse(
        short_summary="s" * 5000,
        recent_events=events,
        semantic_hits=hits,
        graph_memory_history={"history": ["too big"]},
        memory_telemetry=MemoryTelemetry(),
    )

    report = enforce_response_budget(resp, budget_bytes=20000)

    assert report.total_bytes <= 20000
    assert resp.response_truncated is True
    assert resp.graph_memory_history is None
    assert all(len(hit.text) <= MAX_SEMANTIC_HIT_CHARS for hit in resp.semantic_hits)
    assert all(len(evt.content) <= MAX_RECENT_EVENT_CHARS for evt in resp.recent_events)
    assert resp.bytes_total == report.total_bytes


def test_enforce_response_budget_noop_when_under_budget():
    resp = PrePhaseResponse(
        short_summary="ok",
        recent_events=[],
        semantic_hits=[],
        memory_telemetry=MemoryTelemetry(),
    )

    report = enforce_response_budget(resp, budget_bytes=500000)

    assert resp.response_truncated is False
    assert report.total_bytes == resp.bytes_total
    assert report.total_bytes <= 500000
