"""Consolidation invariants and scenarios for V3 graph memory."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest


class FakeNodeStore:
    """In-memory stand-in for the memory_nodes table."""

    def __init__(self):
        self.nodes: dict[str, SimpleNamespace] = {}
        self.history: list[SimpleNamespace] = []

    def upsert(self, node: SimpleNamespace):
        self.nodes[node.node_id] = node
        self.history.append(node)

    def get_by_entity(self, root_session_id: str, entity: str, type: str):
        return [
            n
            for n in self.nodes.values()
            if n.root_session_id == root_session_id and n.entity == entity and n.type == type
        ]

    def get_active(self, root_session_id: str, entity: str, type: str):
        return [
            n
            for n in self.get_by_entity(root_session_id, entity, type)
            if n.state in ("active", "reopened")
        ]


def _candidate(fact: str, source_ids: list[str], entity: str = "python_version", type: str = "config"):
    return {
        "entity": entity,
        "type": type,
        "fact": fact,
        "confidence": 0.9,
        "source_event_ids": source_ids,
    }


def _run_consolidation(store: FakeNodeStore, candidates: list[dict], now: datetime | None = None):
    """Invoke the consolidation entrypoint under test."""
    import app.graph_consolidation as gc  # type: ignore[import-not-found]

    now = now or datetime.now(timezone.utc)
    if hasattr(gc, "process_consolidation"):
        return gc.process_consolidation(
            store=store,
            candidates=candidates,
            root_session_id="root",
            session_id="sess",
            now=now,
        )
    if hasattr(gc, "apply_consolidation_actions"):
        return gc.apply_consolidation_actions(store=store, candidates=candidates, now=now)
    raise AttributeError("No consolidation entrypoint found")


def test_python_version_flapping_yields_single_active_node():
    """Flapping across versions should leave only the final version active with proper supersedence."""
    store = FakeNodeStore()
    timeline = ["3.10", "3.11", "3.12", "3.11"]
    now = datetime.now(timezone.utc)

    for i, version in enumerate(timeline):
        _run_consolidation(
            store,
            [_candidate(version, [f"evt-{i}"])],
            now=now + timedelta(minutes=i),
        )

    actives = store.get_active("root", "python_version", "config")
    assert len(actives) == 1
    active = actives[0]
    assert active.fact == "3.11"
    # All prior nodes should be superseded and point to the active node as superseded_by
    for n in store.get_by_entity("root", "python_version", "config"):
        if n.node_id == active.node_id:
            continue
        assert n.state == "superseded"
        assert n.superseded_by == active.node_id
        assert n.valid_to is not None


def test_reopen_superseded_fact_marks_reopened_active():
    """A reopen action should activate the reopened fact and supersede conflicting actives."""
    store = FakeNodeStore()
    now = datetime.now(timezone.utc)
    # seed an old fact that was superseded
    _run_consolidation(store, [_candidate("bug-open", ["evt-1"], entity="issue", type="state")], now=now)
    _run_consolidation(
        store,
        [_candidate("bug-closed", ["evt-2"], entity="issue", type="state")],
        now=now + timedelta(minutes=1),
    )
    # reopen same fact
    _run_consolidation(
        store,
        [_candidate("bug-open", ["evt-3"], entity="issue", type="state")],
        now=now + timedelta(minutes=2),
    )

    actives = store.get_active("root", "issue", "state")
    assert len(actives) == 1
    active = actives[0]
    assert active.fact == "bug-open"
    assert active.state in ("active", "reopened")
    assert active.history_reason is not None and active.history_reason != ""
    for n in store.get_by_entity("root", "issue", "state"):
        if n.node_id == active.node_id:
            continue
        assert n.state == "superseded"
        assert n.superseded_by == active.node_id


def test_duplicate_evidence_no_extra_active_node():
    """Same fact with overlapping source_event_ids should not create another active node."""
    store = FakeNodeStore()
    now = datetime.now(timezone.utc)
    _run_consolidation(store, [_candidate("3.11", ["evt-1", "evt-2"])], now=now)
    _run_consolidation(store, [_candidate("3.11", ["evt-2"])], now=now + timedelta(minutes=1))

    actives = store.get_active("root", "python_version", "config")
    assert len(actives) == 1
    active = actives[0]
    assert active.fact == "3.11"
    # evidence should include the merged IDs or at least not duplicate nodes
    assert set(active.source_event_ids) >= {"evt-1", "evt-2"}
    assert len(store.get_by_entity("root", "python_version", "config")) == 1


def test_idempotent_reprocessing_same_message():
    """Reprocessing identical input should not create duplicate nodes."""
    store = FakeNodeStore()
    now = datetime.now(timezone.utc)
    cand = _candidate("3.11", ["evt-1"])
    _run_consolidation(store, [cand], now=now)
    _run_consolidation(store, [cand], now=now)  # replay

    nodes = store.get_by_entity("root", "python_version", "config")
    assert len(nodes) == 1
    assert nodes[0].fact == "3.11"


def test_multiple_actives_all_superseded_by_new_fact():
    """If multiple actives exist, a new fact must supersede all of them."""
    from app.graph_models import MemoryNode, make_node_id  # type: ignore[import-not-found]

    store = FakeNodeStore()
    now = datetime.now(timezone.utc)
    # Seed two (invalid) active nodes for the same entity/type.
    n1 = MemoryNode(
        node_id=make_node_id("root", "python_version", "config", "3.10", ["evt-1"]),
        root_session_id="root",
        entity="python_version",
        type="config",
        fact="3.10",
        state="active",
        source_event_ids=["evt-1"],
        source_session_ids=["sess"],
        created_at=now,
        updated_at=now,
    )
    n2 = MemoryNode(
        node_id=make_node_id("root", "python_version", "config", "3.10.1", ["evt-2"]),
        root_session_id="root",
        entity="python_version",
        type="config",
        fact="3.10.1",
        state="active",
        source_event_ids=["evt-2"],
        source_session_ids=["sess"],
        created_at=now,
        updated_at=now,
    )
    store.nodes[n1.node_id] = n1
    store.nodes[n2.node_id] = n2

    # Superseding fact
    _run_consolidation(store, [_candidate("3.11", ["evt-3"])], now=now + timedelta(minutes=1))

    nodes = store.get_by_entity("root", "python_version", "config")
    active = [n for n in nodes if n.state == "active"]
    superseded = [n for n in nodes if n.state == "superseded"]
    assert len(active) == 1
    assert active[0].fact == "3.11"
    # Both prior actives should now be superseded_by the new node.
    superseded_ids = {n.node_id for n in superseded}
    assert superseded_ids == {n1.node_id, n2.node_id}
    for n in superseded:
        assert n.superseded_by == active[0].node_id
        assert n.valid_to is not None
    assert set(active[0].supersedes) == superseded_ids


def test_supersedes_links_and_validity_windows_set_on_update():
    """When superseding, prior active gains valid_to/superseded_by and new node records supersedes."""
    store = FakeNodeStore()
    now = datetime.now(timezone.utc)
    _run_consolidation(store, [_candidate("3.10", ["evt-1"])], now=now)
    _run_consolidation(store, [_candidate("3.11", ["evt-2"])], now=now + timedelta(minutes=1))

    nodes = store.get_by_entity("root", "python_version", "config")
    active = [n for n in nodes if n.state == "active"][0]
    superseded = [n for n in nodes if n.state == "superseded"][0]
    assert superseded.valid_to is not None
    assert superseded.superseded_by == active.node_id
    assert active.supersedes and superseded.node_id in active.supersedes


def test_supersession_chain_preserves_links_and_skips_old_superseded():
    """New facts supersede only active/reopened nodes and do not rewrite older superseded_by links."""
    store = FakeNodeStore()
    now = datetime.now(timezone.utc)

    # v1 active
    _run_consolidation(store, [_candidate("v1", ["evt-1"], entity="pkg", type="ver")], now=now)
    # v2 supersedes v1
    _run_consolidation(store, [_candidate("v2", ["evt-2"], entity="pkg", type="ver")], now=now + timedelta(minutes=1))
    # v3 supersedes v2 only
    _run_consolidation(store, [_candidate("v3", ["evt-3"], entity="pkg", type="ver")], now=now + timedelta(minutes=2))

    nodes = store.get_by_entity("root", "pkg", "ver")
    by_fact = {n.fact: n for n in nodes}

    assert by_fact["v1"].state == "superseded"
    assert by_fact["v2"].state == "superseded"
    assert by_fact["v3"].state == "active"

    # Chain integrity: v1→v2→v3 without v1 being rewritten to v3
    assert by_fact["v1"].superseded_by == by_fact["v2"].node_id
    assert by_fact["v2"].superseded_by == by_fact["v3"].node_id
    assert by_fact["v1"].superseded_by != by_fact["v3"].node_id

    # Only active/reopened nodes are superseded on new arrival
    assert set(by_fact["v3"].supersedes) == {by_fact["v2"].node_id}


def test_reopen_sets_reopened_state_and_history_reason():
    """Reopen should mark state=reopened (or active with reason) and set history_reason describing the reopen."""
    store = FakeNodeStore()
    now = datetime.now(timezone.utc)
    _run_consolidation(store, [_candidate("closed", ["evt-1"], entity="issue", type="state")], now=now)
    _run_consolidation(
        store,
        [_candidate("open", ["evt-2"], entity="issue", type="state")],
        now=now + timedelta(minutes=1),
    )
    _run_consolidation(
        store,
        [_candidate("open", ["evt-3"], entity="issue", type="state")],
        now=now + timedelta(minutes=2),
    )

    active = store.get_active("root", "issue", "state")[0]
    assert active.fact == "open"
    assert active.state in ("active", "reopened")
    assert active.history_reason is not None and active.history_reason != ""
    for n in store.get_by_entity("root", "issue", "state"):
        if n.node_id != active.node_id:
            assert n.superseded_by == active.node_id


def test_reopen_reactivates_original_node_and_supersedes_current_active():
    """Reopening a prior fact reuses the original node_id, supersedes the current active, and merges evidence."""
    store = FakeNodeStore()
    now = datetime.now(timezone.utc)

    # v1 active then superseded by v2
    _run_consolidation(store, [_candidate("v1", ["evt-1"], entity="pkg", type="ver")], now=now)
    _run_consolidation(
        store,
        [_candidate("v2", ["evt-2"], entity="pkg", type="ver")],
        now=now + timedelta(minutes=1),
    )
    nodes = store.get_by_entity("root", "pkg", "ver")
    v1_id = [n for n in nodes if n.fact == "v1"][0].node_id
    v2_id = [n for n in nodes if n.fact == "v2"][0].node_id

    # v1 reappears -> should reactivate original node_id and supersede v2
    _run_consolidation(
        store,
        [_candidate("v1", ["evt-3"], entity="pkg", type="ver")],
        now=now + timedelta(minutes=2),
    )

    nodes = store.get_by_entity("root", "pkg", "ver")
    v1 = [n for n in nodes if n.fact == "v1"][0]
    v2 = [n for n in nodes if n.fact == "v2"][0]

    assert v1.node_id == v1_id
    assert v1.state in ("reopened", "active")
    assert set(v1.source_event_ids) >= {"evt-1", "evt-3"}
    assert v2.node_id == v2_id
    assert v2.state == "superseded"
    assert v2.superseded_by == v1.node_id
    assert set(v1.supersedes) == {v2.node_id}
