"""Contract checks for the tool spec vs lambda /pre responses."""

import json

import pytest

try:
    import yaml  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    yaml = None

import lambda_handler
from app.models import Event, MemoryTelemetry, PrePhaseResponse, SemanticHit, utc_now
from app.response_budget import enforce_response_budget


def _fake_event(body: dict) -> dict:
    return {
        "rawPath": "/pre",
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(body),
        "isBase64Encoded": False,
    }


def test_tool_spec_includes_graph_fields():
    if yaml is None:
        pytest.skip("PyYAML not installed")
    with open("custom_gpt_actions.yaml", "r", encoding="utf-8") as f:
        spec = yaml.safe_load(f)

    props = (
        spec["paths"]["/pre"]["post"]["responses"]["200"]["content"]["application/json"][
            "schema"
        ]["properties"]
    )
    assert "graph_memory_facts" in props
    assert "graph_memory_history" in props
    assert "rehydrated_s3_windows" in props
    assert props["graph_memory_facts"].get("nullable") is True
    assert props["graph_memory_history"].get("nullable") is True


def test_lambda_pre_omits_graph_fields_when_none(monkeypatch):
    def _noop_healthcheck():
        return None

    def _fake_handle_pre(_req):
        resp = PrePhaseResponse(
            short_summary=None,
            recent_events=[],
            semantic_hits=[],
            graph_memory_facts=None,
            graph_memory_history=None,
            memory_telemetry=MemoryTelemetry(),
        )
        enforce_response_budget(resp, budget_bytes=200000)
        return resp

    monkeypatch.setattr(lambda_handler, "run_healthcheck", _noop_healthcheck)
    monkeypatch.setattr(lambda_handler, "handle_pre", _fake_handle_pre)

    event = _fake_event(
        {"root_session_id": "r1", "session_id": "s1", "user_message": "hi"}
    )
    resp = lambda_handler.lambda_handler(event, context={})
    body = json.loads(resp["body"])

    assert "graph_memory_facts" not in body
    assert "graph_memory_history" not in body
    assert set(body.keys()) == {
        "short_summary",
        "recent_events",
        "semantic_hits",
        "response_truncated",
        "bytes_total",
        "memory_telemetry",
    }


def test_lambda_pre_includes_graph_fields_when_present(monkeypatch):
    def _noop_healthcheck():
        return None

    def _fake_handle_pre(_req):
        evt = Event(
            event_id="e1",
            root_session_id="r1",
            session_id="s1",
            sequence=0,
            role="user",
            created_at=utc_now(),
            content="hello",
            metadata={},
        )
        resp = PrePhaseResponse(
            short_summary="sum",
            recent_events=[evt],
            semantic_hits=[SemanticHit(text="t", score=0.5, metadata={})],
            graph_memory_facts=[{"entity": "project", "type": "config", "fact": "f", "state": "active", "confidence": 0.9, "updated_at": "2024-01-01T00:00:00Z"}],
            graph_memory_history={"project": [{"fact": "f", "state": "active", "updated_at": "2024-01-01T00:00:00Z"}]},
            memory_telemetry=MemoryTelemetry(),
        )
        enforce_response_budget(resp, budget_bytes=200000)
        return resp

    monkeypatch.setattr(lambda_handler, "run_healthcheck", _noop_healthcheck)
    monkeypatch.setattr(lambda_handler, "handle_pre", _fake_handle_pre)

    event = _fake_event(
        {"root_session_id": "r1", "session_id": "s1", "user_message": "hi"}
    )
    resp = lambda_handler.lambda_handler(event, context={})
    body = json.loads(resp["body"])

    assert "graph_memory_facts" in body
    assert "graph_memory_history" in body
    assert body["graph_memory_facts"][0]["entity"] == "project"
    assert body["graph_memory_history"]["project"][0]["state"] == "active"


def test_tool_spec_includes_turn_action():
    if yaml is None:
        pytest.skip("PyYAML not installed")
    with open("custom_gpt_actions.yaml", "r", encoding="utf-8") as f:
        spec = yaml.safe_load(f)

    turn_path = spec["paths"].get("/turn", {}).get("post", {})
    assert turn_path, "missing /turn in tool spec"
    resp_props = (
        turn_path["responses"]["200"]["content"]["application/json"]["schema"]["properties"]
    )
    assert "persisted_last_turn" in resp_props
    assert "graph_memory_facts" in resp_props
    assert "graph_memory_history" in resp_props
    assert "rehydrated_s3_windows" in resp_props
