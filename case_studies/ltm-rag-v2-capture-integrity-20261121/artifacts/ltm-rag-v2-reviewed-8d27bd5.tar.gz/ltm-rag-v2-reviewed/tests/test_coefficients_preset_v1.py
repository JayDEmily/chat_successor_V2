import pytest

from app import config
from app.coefficients import loader


def _set_minimal_env(monkeypatch, **overrides):
    base = {
        "AWS_REGION": "us-east-1",
        "TRANSCRIPT_BUCKET": "test-bucket",
        "STATE_TABLE": "test-table",
        "OPENAI_API_KEY": "sk-test",
        "OPENAI_VECTOR_STORE_ID": "vs_dummy",
        "EMBEDDING_MODEL_NAME": "text-embedding-3-large",
        "SUMMARY_MODEL_NAME": "gpt-5.1",
        "SEMANTIC_BACKEND": "openai",
        "COEFFICIENTS_PRESET": "v1",
        # Ensure the preset is the source of truth for these knobs.
        "SEMANTIC_CHUNK_SIZE_TOKENS": None,
        "SEMANTIC_CHUNK_OVERLAP_TOKENS": None,
        "SEMANTIC_SEARCH_TOP_K": None,
        "SEMANTIC_RETURN_HITS_CAP": None,
        "SEMANTIC_INDEX_ROLES": None,
        "S3_REHYDRATION_WINDOW_EVENTS": None,
        "MAX_REHYDRATED_WINDOWS": None,
        "REHYDRATION_MAX_TOTAL_EVENTS": None,
        "RESPONSE_BUDGET_BYTES": None,
        "RECENT_EVENTS_RETURN_CAP": None,
        "SUMMARY_RETURN_MAX_CHARS": None,
    }
    base.update(overrides)
    for k, v in base.items():
        if v is None:
            monkeypatch.delenv(k, raising=False)
        else:
            monkeypatch.setenv(k, v)


def test_preset_loading_is_deterministic():
    a = loader.load_coefficients_preset("v1")
    b = loader.load_coefficients_preset("v1")
    assert a == b


def test_config_uses_v1_preset_values(monkeypatch):
    _set_minimal_env(monkeypatch, COEFFICIENTS_PRESET="v1")
    settings = config.load_settings()

    assert settings.coefficients_preset == "v1"

    assert settings.semantic_chunk_size_tokens == 512
    assert settings.semantic_chunk_overlap_tokens == 192
    assert settings.semantic_search_top_k == 12
    assert settings.semantic_return_hits_cap == 8
    assert settings.semantic_index_roles == ["user", "assistant"]

    assert settings.max_rehydrated_windows == 2
    assert settings.s3_rehydration_window_events == 3
    assert settings.rehydration_max_total_events == 14

    assert settings.response_budget_bytes == 220000

    assert settings.recent_events_return_cap == 12
    assert settings.summary_return_max_chars == 900


def test_loader_errors_when_preset_missing():
    with pytest.raises(loader.CoefficientsPresetError) as excinfo:
        loader.load_coefficients_preset("does_not_exist")
    assert "not found" in str(excinfo.value).lower()


def test_loader_errors_when_preset_malformed_json(monkeypatch, tmp_path):
    bad = tmp_path / "bad.json"
    bad.write_text("{not json", encoding="utf-8")
    monkeypatch.setattr(loader, "_preset_path", lambda _preset: ("bad", bad))
    with pytest.raises(loader.CoefficientsPresetError) as excinfo:
        loader.load_coefficients_preset("bad")
    assert "invalid json" in str(excinfo.value).lower()


def test_config_errors_clearly_when_preset_missing(monkeypatch):
    _set_minimal_env(monkeypatch, COEFFICIENTS_PRESET="does_not_exist")
    with pytest.raises(config.ConfigError) as excinfo:
        config.load_settings()
    message = str(excinfo.value).lower()
    assert "coefficients_preset" in message
    assert "not found" in message

