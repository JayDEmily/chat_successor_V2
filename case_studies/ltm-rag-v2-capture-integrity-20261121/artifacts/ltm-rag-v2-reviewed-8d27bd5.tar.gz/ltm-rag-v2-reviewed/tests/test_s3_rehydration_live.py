"""Live acceptance test for S3 rehydration windows."""

from __future__ import annotations

import os
import uuid

import pytest

from app.micro_agent.env_loader import load_env
from app.micro_agent.micro_agent import MicroAgent
from app.micro_agent.turn_client import resolve_function_url


load_env()


@pytest.mark.skipif(os.getenv("LIVE_RAG") != "1", reason="Set LIVE_RAG=1 to run live rehydration test")
def test_s3_rehydration_live():
    function_url = resolve_function_url()

    root_session_id = f"s3-rehydrate-{uuid.uuid4().hex}"
    session_id = root_session_id
    agent = MicroAgent(root_session_id, session_id, function_url=function_url)

    user_fact = f"USER_FACT_{uuid.uuid4().hex}"
    seed_message = (
        f"Please store this token exactly: {user_fact}. Reply only with 'ACK' "
        "and do not repeat the token."
    )

    r1 = agent.step(seed_message)
    assert r1.http_status == 200
    assert r1.turn_response.get("persisted_last_turn") is False
    assert user_fact not in r1.assistant_text

    probe_message = "Earlier I gave you an exact token. What was it? Reply with the token only."
    r2 = agent.step(probe_message)
    body = r2.turn_response

    assert r2.http_status == 200
    assert body.get("persisted_last_turn") is True

    telemetry = body.get("memory_telemetry")
    assert isinstance(telemetry, dict)
    assert telemetry.get("semantic_search_ran") is True
    assert telemetry.get("s3_rehydration_ran") is True

    windows = body.get("rehydrated_s3_windows")
    assert isinstance(windows, list) and windows

    target = None
    for window in windows:
        events = window.get("window_events") or []
        for evt in events:
            if (
                isinstance(evt, dict)
                and evt.get("role") == "user"
                and user_fact in str(evt.get("content", ""))
            ):
                target = window
                break
        if target:
            break

    assert target is not None
    events = target.get("window_events") or []
    user_events = [
        evt
        for evt in events
        if isinstance(evt, dict)
        and evt.get("role") == "user"
        and user_fact in str(evt.get("content", ""))
    ]
    assert user_events
    user_event = user_events[0]
    assert user_event.get("event_id")
    for key in ("event_id", "role", "content", "sequence"):
        assert key in user_event

    assert len(events) >= 2
    seqs = [evt.get("sequence") for evt in events if isinstance(evt, dict)]
    assert seqs == sorted(seqs)

    assert isinstance(target.get("anchor"), dict)
    assert isinstance(target.get("source"), dict)
    assert isinstance(target.get("hit_ref"), dict)

    bytes_total = body.get("bytes_total")
    assert isinstance(bytes_total, int)
    cap = int(os.getenv("RESPONSE_BUDGET_BYTES", "200000"))
    assert bytes_total <= cap

    assert isinstance(telemetry.get("s3_rehydration_truncated"), bool)
    assert telemetry.get("s3_rehydration_windows_returned") == len(windows)
    if telemetry.get("s3_rehydration_truncated"):
        assert body.get("response_truncated") is True
