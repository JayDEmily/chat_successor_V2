"""Live test that emulates the custom GPT calling /turn only.

Flows through multiple turns, persisting prior messages via `last_*`,
then waits for the async graph pipeline to surface graph facts via /pre.
Requires LIVE_SMOKE=1 and a configured function URL.
"""

from __future__ import annotations

import json
import os
import time
import socket
import urllib.error
import urllib.request
import uuid

import pytest


FUNCTION_URL = (
    os.getenv("LIVE_LAMBDA_URL")
    or os.getenv("LIVE_FUNCTION_URL")
    or os.getenv("MEMORY_AGENT_URL")
    or "https://example.invalid"
)

pytestmark = [
    pytest.mark.smoke,
    pytest.mark.release,
    pytest.mark.skipif(
        os.getenv("LIVE_SMOKE") != "1",
        reason="Set LIVE_SMOKE=1 to hit the deployed Lambda",
    ),
    pytest.mark.skipif(not FUNCTION_URL, reason="LIVE_LAMBDA_URL is not configured"),
]


def _post(path: str, body: dict, timeout: int = 90) -> dict:
    url = FUNCTION_URL.rstrip("/") + path
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    for attempt in range(2):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                status = resp.getcode()
                payload = json.loads(resp.read().decode("utf-8"))
                return {"status": status, "body": payload}
        except urllib.error.HTTPError as exc:
            err_body = exc.read().decode("utf-8")
            raise AssertionError(f"HTTP {exc.code} hitting {url}: {err_body}") from exc
        except TimeoutError:
            if attempt == 1:
                raise
            time.sleep(2)
        except urllib.error.URLError as exc:
            if isinstance(exc.reason, (TimeoutError, socket.timeout)) and attempt == 0:
                time.sleep(2)
                continue
            raise


def _wait_for_graph_facts(root_session_id: str, session_id: str) -> list[dict]:
    """Poll /pre for graph facts to allow async graph worker to finish."""
    last_facts: list[dict] | None = None
    for attempt in range(4):
        pre = _post(
            "/pre",
            {
                "root_session_id": root_session_id,
                "session_id": session_id,
                "user_message": "graph fact check",
            },
        )
        assert pre["status"] == 200
        facts = pre["body"].get("graph_memory_facts") or []
        last_facts = facts
        if isinstance(facts, list) and facts:
            return facts
        time.sleep(5)
    assert last_facts is not None
    assert isinstance(last_facts, list)
    assert last_facts, "Expected graph_memory_facts after waiting for graph pipeline"
    return last_facts


def test_custom_gpt_turn_flow_live():
    root_session_id = f"gpt-live-{uuid.uuid4().hex}"
    session_id = root_session_id

    script = [
        {
            "user": "I am Alice Example. I live in Sydney, Australia. "
            "I work at ExampleCorp as a data engineer and primarily use Python 3.10.",
            "assistant": "Acknowledged: Alice Example in Sydney, data engineer at ExampleCorp using Python 3.10.",
        },
        {
            "user": "I manage the Orion project and rely on PostgreSQL 14 for analytics.",
            "assistant": "Got it, you run the Orion project and use PostgreSQL 14 for analytics.",
        },
        {
            "user": "Our infra is in AWS ap-southeast-2 and we use Lambda plus SQS for async work.",
            "assistant": "Noted: AWS ap-southeast-2, using Lambda and SQS for async processing.",
        },
        {
            "user": "We are rolling out a RAG graph that tracks entities and facts across sessions.",
            "assistant": "Logged: you are rolling out a RAG graph to track entities and facts.",
        },
    ]

    last_user = None
    last_assistant = None

    for idx, turn in enumerate(script):
        resp = _post(
            "/turn",
            {
                "root_session_id": root_session_id,
                "session_id": session_id,
                "last_user_message": last_user,
                "last_assistant_message": last_assistant,
                "current_user_message": turn["user"],
            },
        )
        assert resp["status"] == 200
        body = resp["body"]
        assert "persisted_last_turn" in body
        if idx == 0:
            assert body["persisted_last_turn"] is False
        else:
            assert body["persisted_last_turn"] is True
        assert isinstance(body.get("recent_events"), list)
        assert isinstance(body.get("semantic_hits"), list)

        last_user = turn["user"]
        last_assistant = turn["assistant"]

    facts = _wait_for_graph_facts(root_session_id, session_id)
    assert len(facts) >= 1
    assert all("entity" in f and "fact" in f for f in facts)
