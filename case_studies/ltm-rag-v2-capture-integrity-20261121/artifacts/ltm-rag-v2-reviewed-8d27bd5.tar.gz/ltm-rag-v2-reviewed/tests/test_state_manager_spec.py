"""Specs for state_manager persistence helpers (Dynamo-bound logic only)."""

import json
from types import SimpleNamespace
from unittest.mock import MagicMock

from app import state_manager
from app.models import BranchState, Event, utc_now
from app.reconcile_state import reconcile_branch_state_from_transcript


def test_save_then_load_round_trip(monkeypatch):
    table = MagicMock()
    captured_tables = []

    def fake_get_table(settings):
        captured_tables.append(settings.state_table)
        return table

    monkeypatch.setattr(state_manager, "get_dynamodb_table", fake_get_table)

    state = BranchState(
        root_session_id="root",
        session_id="sess",
        short_summary="summary",
        next_sequence=5,
        summary_turns_since_update=2,
    )
    settings = SimpleNamespace(state_table="state-table")

    table.get_item.return_value = {"Item": state.to_item()}

    state_manager.save_branch_state(settings, state)
    table.put_item.assert_called_once()
    item_written = table.put_item.call_args.kwargs["Item"]
    assert item_written["PK"] == "root"
    assert item_written["SK"] == "sess"

    loaded = state_manager.load_branch_state(settings, "root", "sess")
    table.get_item.assert_called_once_with(Key={"PK": "root", "SK": "sess"})
    assert loaded.root_session_id == state.root_session_id
    assert loaded.session_id == state.session_id
    assert loaded.short_summary == state.short_summary
    assert loaded.next_sequence == state.next_sequence
    assert loaded.summary_turns_since_update == state.summary_turns_since_update
    assert captured_tables == ["state-table", "state-table"]


def test_load_branch_state_returns_default_when_missing(monkeypatch):
    table = MagicMock()
    table.get_item.return_value = {}
    monkeypatch.setattr(state_manager, "get_dynamodb_table", lambda settings: table)

    settings = object()
    state = state_manager.load_branch_state(settings, "root-new", "sess-new")

    assert state.root_session_id == "root-new"
    assert state.session_id == "sess-new"
    assert state.short_summary is None
    assert state.next_sequence == 0


def test_branch_state_round_trip_with_events_and_counters():
    events = [
        Event(
            event_id="e1",
            root_session_id="root",
            session_id="sess",
            sequence=5,
            role="user",
            created_at=utc_now(),
            content="hi",
        ),
        Event(
            event_id="e2",
            root_session_id="root",
            session_id="sess",
            sequence=6,
            role="assistant",
            created_at=utc_now(),
            content="yo",
        ),
    ]
    state = BranchState(
        root_session_id="root",
        session_id="sess",
        short_summary="summary",
        recent_events=events,
        next_sequence=7,
        summary_turns_since_update=3,
    )

    item = state.to_item()
    assert item["PK"] == "root"
    assert item["SK"] == "sess"
    assert item["short_summary"] == "summary"
    assert item["next_sequence"] == 7
    assert item["summary_turns_since_update"] == 3
    assert [e["event_id"] for e in item["recent_events"]] == ["e1", "e2"]

    restored = BranchState.from_item(item)
    assert restored.root_session_id == state.root_session_id
    assert restored.session_id == state.session_id
    assert restored.short_summary == state.short_summary
    assert restored.next_sequence == state.next_sequence
    assert restored.summary_turns_since_update == state.summary_turns_since_update
    assert [e.event_id for e in restored.recent_events] == ["e1", "e2"]


def test_branch_state_from_item_defaults_when_fields_missing():
    events = [
        Event(
            event_id="e1",
            root_session_id="root",
            session_id="sess",
            sequence=0,
            role="user",
            created_at=utc_now(),
            content="hi",
        ).to_dict(),
        Event(
            event_id="e2",
            root_session_id="root",
            session_id="sess",
            sequence=1,
            role="assistant",
            created_at=utc_now(),
            content="yo",
        ).to_dict(),
    ]

    item = {
        "PK": "root",
        "SK": "sess",
        "short_summary": None,
        "recent_events": events,
        # intentionally omit next_sequence and summary_turns_since_update
    }

    restored = BranchState.from_item(item)
    assert restored.next_sequence == len(events)
    assert restored.summary_turns_since_update == 0
    assert [e.sequence for e in restored.recent_events] == [0, 1]


def test_branch_state_recent_events_order_preserved():
    events = [
        Event(
            event_id="first",
            root_session_id="root",
            session_id="sess",
            sequence=10,
            role="user",
            created_at=utc_now(),
            content="one",
        ),
        Event(
            event_id="second",
            root_session_id="root",
            session_id="sess",
            sequence=11,
            role="assistant",
            created_at=utc_now(),
            content="two",
        ),
        Event(
            event_id="third",
            root_session_id="root",
            session_id="sess",
            sequence=12,
            role="assistant",
            created_at=utc_now(),
            content="three",
        ),
    ]

    state = BranchState(
        root_session_id="root",
        session_id="sess",
        recent_events=events,
        next_sequence=13,
    )

    round_tripped = BranchState.from_item(state.to_item())
    assert [e.event_id for e in round_tripped.recent_events] == ["first", "second", "third"]


def test_reconcile_branch_state_from_transcript_with_summary():
    root = "root"
    session = "sess"
    events = [
        Event(
            event_id="e1",
            root_session_id=root,
            session_id=session,
            sequence=0,
            role="user",
            created_at=utc_now(),
            content="hello",
        ),
        Event(
            event_id="e2",
            root_session_id=root,
            session_id=session,
            sequence=1,
            role="assistant",
            created_at=utc_now(),
            content="hi there",
        ),
        # different session should be ignored
        Event(
            event_id="e3",
            root_session_id=root,
            session_id="other",
            sequence=0,
            role="assistant",
            created_at=utc_now(),
            content="ignore",
        ),
    ]
    transcript = [json.dumps(e.to_dict()) for e in events]

    class FakeLLM:
        def summarise(self, history_text):
            return "SUMMARY"

    state = reconcile_branch_state_from_transcript(
        root, session, transcript, llm=FakeLLM(), summarise=True
    )

    assert [e.event_id for e in state.recent_events] == ["e1", "e2"]
    assert state.next_sequence == 2
    assert state.short_summary == "SUMMARY"


def test_reconcile_branch_state_without_llm_leaves_summary_none():
    root = "root"
    session = "sess"
    events = [
        Event(
            event_id="e1",
            root_session_id=root,
            session_id=session,
            sequence=0,
            role="user",
            created_at=utc_now(),
            content="hello",
        )
    ]
    transcript = [json.dumps(e.to_dict()) for e in events]

    state = reconcile_branch_state_from_transcript(
        root, session, transcript, llm=None, summarise=True
    )
    assert state.short_summary is None
    assert state.next_sequence == 1
