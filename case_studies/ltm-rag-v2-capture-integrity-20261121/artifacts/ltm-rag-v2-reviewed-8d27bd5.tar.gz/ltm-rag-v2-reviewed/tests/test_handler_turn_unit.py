"""Unit specs for handle_turn composition logic."""

from unittest.mock import MagicMock

from app import handler
from app.models import (
    PostPhaseRequest,
    PostPhaseResponse,
    PrePhaseRequest,
    PrePhaseResponse,
    TurnRequest,
)


def test_handle_turn_skips_post_when_no_last(monkeypatch, settings_factory):
    pre_resp = PrePhaseResponse(short_summary="s", recent_events=[], semantic_hits=[])
    handle_pre = MagicMock(return_value=pre_resp)
    handle_post = MagicMock()
    monkeypatch.setattr(handler, "handle_pre", handle_pre)
    monkeypatch.setattr(handler, "handle_post", handle_post)
    handler._settings = settings_factory()

    req = TurnRequest(
        root_session_id="root-a",
        session_id="sess-a",
        last_user_message=None,
        last_assistant_message=None,
        current_user_message="hi",
    )

    resp = handler.handle_turn(req)

    assert resp.persisted_last_turn is False
    assert resp.short_summary == "s"
    assert resp.response_truncated is False
    handle_post.assert_not_called()
    handle_pre.assert_called_once()
    pre_arg: PrePhaseRequest = handle_pre.call_args[0][0]
    assert pre_arg.user_message == "hi"
    assert pre_arg.root_session_id == "root-a"
    assert pre_arg.session_id == "sess-a"


def test_handle_turn_persists_then_runs_pre(monkeypatch, settings_factory):
    pre_resp = PrePhaseResponse(short_summary=None, recent_events=["evt"], semantic_hits=[])
    post_resp = PostPhaseResponse(ok=True)
    handle_pre = MagicMock(return_value=pre_resp)
    handle_post = MagicMock(return_value=post_resp)
    monkeypatch.setattr(handler, "handle_pre", handle_pre)
    monkeypatch.setattr(handler, "handle_post", handle_post)
    handler._settings = settings_factory()

    req = TurnRequest(
        root_session_id="root-b",
        session_id="sess-b",
        last_user_message="previous user",
        last_assistant_message="previous assistant",
        current_user_message="next",
    )

    resp = handler.handle_turn(req)

    assert resp.persisted_last_turn is True
    assert resp.response_truncated is False
    handle_post.assert_called_once()
    post_arg: PostPhaseRequest = handle_post.call_args[0][0]
    assert post_arg.user_message == "previous user"
    assert post_arg.assistant_message == "previous assistant"
    assert post_arg.root_session_id == "root-b"
    assert post_arg.session_id == "sess-b"

    handle_pre.assert_called_once()
    pre_arg: PrePhaseRequest = handle_pre.call_args[0][0]
    assert pre_arg.user_message == "next"
    assert pre_arg.root_session_id == "root-b"
    assert pre_arg.session_id == "sess-b"
