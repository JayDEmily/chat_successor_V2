"""Pipeline integration around /post and SQS emission for V3 graph pipeline."""

from __future__ import annotations

import json
from types import SimpleNamespace

import pytest


class FakeSQS:
    def __init__(self):
        self.messages = []

    def send_message(self, **kwargs):
        self.messages.append(kwargs)
        return {"MessageId": f"msg-{len(self.messages)}"}


@pytest.fixture
def fake_sqs(monkeypatch):
    sqs = FakeSQS()

    def fake_enqueue(settings, payload):
        return sqs.send_message(
            MessageBody=payload,
            MessageGroupId=payload["root_session_id"],
            MessageDeduplicationId=payload["dedupe_key"],
        )

    monkeypatch.setattr("app.graph_pipeline.enqueue_graph_job", fake_enqueue)
    return sqs


def _post_event(root="root", session="sess", user="hi", assistant="hello"):
    return SimpleNamespace(
        root_session_id=root,
        session_id=session,
        user_message=user,
        assistant_message=assistant,
    )


def _run_post(req, monkeypatch, success=True, graph_enabled=True):
    from app import handler
    from app.models import BranchState

    monkeypatch.setattr(
        handler,
        "_get_settings",
        lambda: SimpleNamespace(
            semantic_backend="none",
            graph_enabled=graph_enabled,
            graph_events_queue_url="https://sqs.example/graph",
            aws_region="us-east-1",
        ),
    )
    monkeypatch.setattr(handler, "_get_llm", lambda: SimpleNamespace())
    monkeypatch.setattr(
        handler,
        "load_branch_state",
        lambda *_: BranchState(root_session_id=req.root_session_id, session_id=req.session_id),
    )
    monkeypatch.setattr(handler, "append_events", lambda *args, **kwargs: None if success else (_ for _ in ()).throw(RuntimeError("append_fail")))
    monkeypatch.setattr(handler, "save_branch_state", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "update_branch_state_with_events", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "index_memory", lambda *args, **kwargs: None)
    # graph pipeline hook should be in handler.handle_post; rely on enqueue_graph_job stub
    return handler.handle_post(req)


def test_post_emits_sqs_only_after_transcript_and_state_success(monkeypatch, fake_sqs):
    """SQS message emitted only when transcript append + state save succeed."""
    from app import handler

    req = _post_event()
    resp = _run_post(req, monkeypatch, success=True)
    assert resp.ok is True
    assert fake_sqs.messages, "Expected SQS enqueue on success"

    # Failure path: append throws, ensure no SQS
    fake_sqs.messages.clear()
    def boom_append(*_args, **_kwargs):
        raise RuntimeError("append_fail")
    monkeypatch.setattr(handler, "append_events", boom_append)
    with pytest.raises(RuntimeError):
        handler.handle_post(req)
    assert fake_sqs.messages == []


def test_post_does_not_emit_on_handler_exception(monkeypatch, fake_sqs):
    """If handler bails, no SQS message should be sent."""
    from app import handler
    from app.models import BranchState

    req = _post_event()
    def boom_save(*_args, **_kwargs):
        raise RuntimeError("save_fail")
    monkeypatch.setattr(handler, "_get_settings", lambda: SimpleNamespace(semantic_backend="none", aws_region="us-east-1"))
    monkeypatch.setattr(handler, "_get_llm", lambda: SimpleNamespace())
    monkeypatch.setattr(handler, "load_branch_state", lambda *_: BranchState(root_session_id=req.root_session_id, session_id=req.session_id))
    monkeypatch.setattr(handler, "append_events", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "update_branch_state_with_events", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "save_branch_state", boom_save)
    monkeypatch.setattr(handler, "index_memory", lambda *args, **kwargs: None)

    with pytest.raises(RuntimeError):
        handler.handle_post(req)
    assert fake_sqs.messages == []


def test_sqs_payload_contains_minimal_identifiers(monkeypatch, fake_sqs):
    """Emitted payload should carry root/session, event_ids, sequence range, transcript key, dedupe token."""
    from app import handler
    from app.models import Event, BranchState, utc_now

    state = BranchState(root_session_id="root", session_id="sess")
    def fake_load(_settings, root_session_id, session_id):
        return state

    events = []
    def fake_append(settings, root, session, evts):
        events.extend(evts)

    monkeypatch.setattr(handler, "load_branch_state", fake_load)
    monkeypatch.setattr(handler, "append_events", fake_append)
    monkeypatch.setattr(handler, "update_branch_state_with_events", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "save_branch_state", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "index_memory", lambda *args, **kwargs: None)
    monkeypatch.setattr(
        handler,
        "_get_settings",
        lambda: SimpleNamespace(
            semantic_backend="none",
            graph_enabled=True,
            graph_events_queue_url="https://sqs.example/graph",
            aws_region="us-east-1",
        ),
    )
    monkeypatch.setattr(handler, "_get_llm", lambda: SimpleNamespace())

    req = _post_event()
    handler.handle_post(req)

    assert fake_sqs.messages, "Expected SQS enqueue"
    body = fake_sqs.messages[0].get("MessageBody") or fake_sqs.messages[0].get("message_body")
    assert body, "Message body missing"
    payload = json.loads(body) if isinstance(body, str) else body
    assert payload["root_session_id"] == "root"
    assert payload["session_id"] == "sess"
    assert "user_event_id" in payload and "assistant_event_id" in payload
    assert "sequence_start" in payload and "sequence_end" in payload
    assert "transcript_key" in payload
    assert "timestamp" in payload
    assert "dedupe_key" in payload


def test_post_response_body_unchanged_with_graph_pipeline_enabled(monkeypatch, fake_sqs):
    """handle_post response should match V2 shape even when graph pipeline hook is enabled."""
    from app import handler

    req = _post_event()
    resp = _run_post(req, monkeypatch, success=True, graph_enabled=True)
    assert resp.ok is True
    # V4 telemetry may be present; tolerate extras.
    assert resp.ok is True


def test_sqs_message_attributes_include_group_and_dedupe(monkeypatch, fake_sqs):
    """SQS FIFO attributes should carry MessageGroupId (root) and MessageDeduplicationId (deterministic)."""
    from app import handler

    req = _post_event(root="root-123")
    # avoid real Dynamo calls
    monkeypatch.setattr(
        handler,
        "load_branch_state",
        lambda *_args, **_kwargs: SimpleNamespace(root_session_id="root-123", session_id="sess", recent_events=[], short_summary=None, next_sequence=0, summary_turns_since_update=0),
    )
    monkeypatch.setattr(handler, "append_events", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "save_branch_state", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "update_branch_state_with_events", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "index_memory", lambda *args, **kwargs: None)
    _run_post(req, monkeypatch, success=True, graph_enabled=True)

    assert fake_sqs.messages, "Expected message"
    msg = fake_sqs.messages[0]
    group_id = msg.get("MessageGroupId") or msg.get("message_group_id")
    dedupe_id = msg.get("MessageDeduplicationId") or msg.get("message_deduplication_id")
    body = msg.get("MessageBody") or msg.get("message_body")
    payload = json.loads(body) if isinstance(body, str) else body
    assert group_id == "root-123"
    assert dedupe_id == payload["dedupe_key"]
