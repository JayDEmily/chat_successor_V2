"""Failure modes for graph pipeline."""

from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace

import pytest


def test_extraction_llm_error_is_logged_and_no_nodes_written(monkeypatch):
    """LLM failure should be logged and avoid mutating memory_nodes."""
    import app.graph_extraction_worker as worker  # type: ignore[import-not-found]

    calls = {"error": 0}
    fake_logger = SimpleNamespace(
        info=lambda *args, **kwargs: None,
        warning=lambda *args, **kwargs: None,
        error=lambda *args, **kwargs: calls.__setitem__("error", calls["error"] + 1),
    )

    def boom_llm(**kwargs):
        raise RuntimeError("llm_fail")

    monkeypatch.setattr(worker, "logger", fake_logger)
    monkeypatch.setattr(worker, "call_extraction_llm", boom_llm)
    with pytest.raises(RuntimeError):
        worker.handle_extraction_message(
            message={"root_session_id": "root", "session_id": "sess", "user_event_id": "evt-1", "assistant_event_id": "evt-2"},
            s3_client=None,
            branch_state=None,
            llm_client=None,
        )
    assert calls["error"] == 1


def test_consolidation_malformed_json_handled_defensively(monkeypatch):
    """Malformed consolidation payload should log and avoid writing nodes."""
    import app.graph_consolidation_worker as worker  # type: ignore[import-not-found]

    store = SimpleNamespace(nodes_written=0)

    def fake_persist(*args, **kwargs):
        store.nodes_written += 1

    def parse_malformed(*args, **kwargs):
        raise ValueError("bad-json")

    monkeypatch.setattr(worker, "persist_node", fake_persist)
    monkeypatch.setattr(worker, "parse_consolidation_payload", parse_malformed)
    monkeypatch.setattr(worker, "logger", SimpleNamespace(error=lambda *args, **kwargs: None))

    with pytest.raises(ValueError):
        worker.handle_consolidation_message(
            message={"root_session_id": "root", "session_id": "sess", "candidates": "not-json"},
            node_store=None,
            vector_store=None,
            logger=worker.logger,
            now=datetime.now(timezone.utc),
        )
    assert store.nodes_written == 0


def test_missing_candidate_memories_noop(monkeypatch):
    """No candidates should result in no writes and no vector uploads."""
    import app.graph_consolidation_worker as worker  # type: ignore[import-not-found]

    store = SimpleNamespace(nodes=[])
    vector_uploads = []

    monkeypatch.setattr(worker, "persist_node", lambda *args, **kwargs: store.nodes.append(kwargs))
    monkeypatch.setattr(worker, "upload_graph_fact", lambda *args, **kwargs: vector_uploads.append(kwargs))

    worker.handle_consolidation_message(
        message={"root_session_id": "root", "session_id": "sess", "candidates": [], "transcript_events": []},
        node_store=None,
        vector_store=None,
        logger=SimpleNamespace(info=lambda *args, **kwargs: None),
        now=datetime.now(timezone.utc),
    )
    assert store.nodes == []
    assert vector_uploads == []


def test_partial_failure_no_sqs_emit_from_post(monkeypatch):
    """If persistence fails in /post, SQS should not be enqueued."""
    from app import handler

    sent = []

    def fake_enqueue(*args, **kwargs):
        sent.append(kwargs)

    def boom_save(*args, **kwargs):
        raise RuntimeError("save_fail")

    req = SimpleNamespace(root_session_id="root", session_id="sess", user_message="hi", assistant_message="ok")
    monkeypatch.setattr(handler, "_get_settings", lambda: SimpleNamespace(semantic_backend="none", aws_region="us-east-1"))
    monkeypatch.setattr(handler, "_get_llm", lambda: SimpleNamespace())
    monkeypatch.setattr(handler, "load_branch_state", lambda *_: SimpleNamespace(root_session_id="root", session_id="sess", recent_events=[], short_summary=None, next_sequence=0, summary_turns_since_update=0))
    monkeypatch.setattr(handler, "append_events", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "update_branch_state_with_events", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "index_memory", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "save_branch_state", boom_save)
    monkeypatch.setattr("app.graph_pipeline.enqueue_graph_job", fake_enqueue)

    with pytest.raises(RuntimeError):
        handler.handle_post(req)
    assert sent == []


def test_reprocessing_after_failure_respects_idempotency(monkeypatch):
    """After partial failure, reprocessing the same message should still result in single active node."""
    import app.graph_consolidation_worker as worker  # type: ignore[import-not-found]

    store = {"nodes": {}, "writes": 0}

    def persist_node(node_store, node):
        key = node.node_id
        if key in store["nodes"]:
            return
        store["writes"] += 1
        store["nodes"][key] = node

    monkeypatch.setattr(worker, "persist_node", persist_node)
    monkeypatch.setattr(worker, "logger", SimpleNamespace(info=lambda *args, **kwargs: None))

    msg = {
        "root_session_id": "root",
        "session_id": "sess",
        "sequence_start": 0,
        "sequence_end": 1,
        "candidates": [{"entity": "python_version", "type": "config", "fact": "3.11", "source_event_ids": ["evt-1"]}],
        "transcript_events": [{"event_id": "evt-1"}],
    }

    worker.handle_consolidation_message(
        message=msg,
        node_store=None,
        vector_store=None,
        logger=worker.logger,
        now=datetime.now(timezone.utc),
    )
    # replay after "failure"
    worker.handle_consolidation_message(
        message=msg,
        node_store=None,
        vector_store=None,
        logger=worker.logger,
        now=datetime.now(timezone.utc),
    )
    assert store["writes"] == 1
