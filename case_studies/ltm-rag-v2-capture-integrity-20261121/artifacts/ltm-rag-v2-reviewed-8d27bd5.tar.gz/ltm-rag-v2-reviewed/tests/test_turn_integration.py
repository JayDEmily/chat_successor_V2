"""Integration-style tests for handle_turn composition."""

from app import handler
from app.models import BranchState, TurnRequest


def test_turn_first_call_no_persist(monkeypatch, settings_factory, fake_llm):
    state = BranchState(root_session_id="turn-root-1", session_id="turn-root-1")
    monkeypatch.setattr(handler, "load_branch_state", lambda settings, root, session: state)
    monkeypatch.setattr(handler, "search_memory", lambda *args, **kwargs: [])
    monkeypatch.setattr(handler, "append_events", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "save_branch_state", lambda *args, **kwargs: None)

    handler._settings = settings_factory(semantic_backend="none")
    handler._llm_client = fake_llm

    req = TurnRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        last_user_message=None,
        last_assistant_message=None,
        current_user_message="First message.",
    )
    resp = handler.handle_turn(req)

    assert resp.persisted_last_turn is False
    assert resp.recent_events == []
    assert resp.semantic_hits == []


def test_turn_persists_previous_pair(monkeypatch, settings_factory, fake_llm):
    state = BranchState(root_session_id="turn-root-2", session_id="turn-root-2")
    appended_events = []

    monkeypatch.setattr(handler, "load_branch_state", lambda settings, root, session: state)
    monkeypatch.setattr(handler, "search_memory", lambda *args, **kwargs: [])

    def _fake_append(_settings, root, session, events):
        appended_events.extend(events)

    monkeypatch.setattr(handler, "append_events", _fake_append)
    monkeypatch.setattr(handler, "save_branch_state", lambda *args, **kwargs: None)
    monkeypatch.setattr(handler, "index_memory", lambda *args, **kwargs: None)

    handler._settings = settings_factory(semantic_backend="none")
    handler._llm_client = fake_llm

    first_req = TurnRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        last_user_message=None,
        last_assistant_message=None,
        current_user_message="Hi, this is the first message.",
    )
    first_resp = handler.handle_turn(first_req)
    assert first_resp.persisted_last_turn is False
    assert state.next_sequence == 0

    second_req = TurnRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        last_user_message="Hi, this is the first message.",
        last_assistant_message="Assistant reply for first message.",
        current_user_message="Second message that should see history.",
    )
    second_resp = handler.handle_turn(second_req)

    assert second_resp.persisted_last_turn is True
    assert len(appended_events) == 2
    assert [e.role for e in appended_events] == ["user", "assistant"]
    assert state.next_sequence == 2
    assert len(second_resp.recent_events) >= 2
    assert [second_resp.recent_events[0].role, second_resp.recent_events[1].role] == [
        "user",
        "assistant",
    ]
