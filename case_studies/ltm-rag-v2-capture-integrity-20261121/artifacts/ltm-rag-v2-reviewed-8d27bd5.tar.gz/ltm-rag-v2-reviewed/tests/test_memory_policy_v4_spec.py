"""V4 AUTO memory policy expectations (tests-first).

These specs capture the desired behaviour described in
`Canonical implementationV4 — Memory Policy.md`. They are written
ahead of implementation and will initially fail until the runtime
supports gating, telemetry, and marker/idempotency rules.
"""

from unittest.mock import MagicMock

import pytest

from app import handler
from app.memory_policy import is_memory_dependent, is_salient_assistant_message
from app.models import BranchState, Event, MemoryTelemetry, PostPhaseRequest, PrePhaseRequest, SemanticHit, utc_now


def _make_state(root="root-v4", session="sess-v4"):
    return BranchState(root_session_id=root, session_id=session, short_summary="stub-summary")


def _settings_with_overrides(settings_factory, **overrides):
    base = dict(
        semantic_backend="openai",
        graph_enabled=False,
        graph_vector_index_enabled=False,
        memory_nodes_table="memory-nodes",
        graph_events_queue_url="https://example.com/graph-queue",
    )
    base.update(overrides)
    return settings_factory(**base)


def test_pre_skips_semantic_when_not_memory_dependent(monkeypatch, settings_factory, fake_llm):
    state = _make_state()
    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)
    search_mock = MagicMock(return_value=[SemanticHit(text="hit", score=0.9, metadata={})])
    monkeypatch.setattr(handler, "search_memory", search_mock)
    monkeypatch.setattr(handler, "is_memory_dependent", lambda msg: False)

    handler._settings = _settings_with_overrides(settings_factory)
    handler._llm_client = fake_llm

    req = PrePhaseRequest(root_session_id=state.root_session_id, session_id=state.session_id, user_message="hello there")
    resp = handler.handle_pre(req)

    assert resp.semantic_hits == []
    load_mock.assert_called_once()
    search_mock.assert_not_called()
    assert isinstance(resp.memory_telemetry, MemoryTelemetry)
    assert resp.memory_telemetry.memory_dependent is False
    assert resp.memory_telemetry.semantic_search_ran is False
    assert resp.memory_telemetry.graph_read_ran is False


def test_pre_runs_semantic_when_memory_dependent(monkeypatch, settings_factory, fake_llm):
    state = _make_state()
    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)
    hits = [SemanticHit(text="recall", score=0.8, metadata={"kind": "message"})]
    search_mock = MagicMock(return_value=hits)
    monkeypatch.setattr(handler, "search_memory", search_mock)
    monkeypatch.setattr(handler, "is_memory_dependent", lambda msg: True)

    handler._settings = _settings_with_overrides(settings_factory)
    handler._llm_client = fake_llm

    req = PrePhaseRequest(root_session_id=state.root_session_id, session_id=state.session_id, user_message="what did we decide?")
    resp = handler.handle_pre(req)

    assert resp.semantic_hits == hits
    search_mock.assert_called_once()
    assert isinstance(resp.memory_telemetry, MemoryTelemetry)
    assert resp.memory_telemetry.memory_dependent is True
    assert resp.memory_telemetry.semantic_search_ran is True


def test_post_indexes_only_when_salient(monkeypatch, settings_factory, fake_llm):
    state = _make_state()
    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)
    append_mock = MagicMock()
    save_mock = MagicMock()
    update_mock = MagicMock()
    monkeypatch.setattr(handler, "append_events", append_mock)
    monkeypatch.setattr(handler, "save_branch_state", save_mock)
    monkeypatch.setattr(handler, "update_branch_state_with_events", update_mock)
    index_mock = MagicMock()
    monkeypatch.setattr(handler, "index_memory", index_mock)
    monkeypatch.setattr(handler, "is_salient_assistant_message", lambda msg: False)
    monkeypatch.setattr(handler, "semantic_marker_exists", lambda *args, **kwargs: False)
    monkeypatch.setattr(handler, "write_semantic_marker", MagicMock())

    handler._settings = _settings_with_overrides(settings_factory)
    handler._llm_client = fake_llm

    req = PostPhaseRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        user_message="hello",
        assistant_message="ok",
    )
    resp = handler.handle_post(req)

    assert resp.ok is True
    append_mock.assert_called_once()  # Tier 0 always runs
    update_mock.assert_called_once()
    save_mock.assert_called_once()
    index_mock.assert_called_once()
    assert index_mock.call_args[0][2].role == "user"
    assert isinstance(resp.memory_telemetry, MemoryTelemetry)
    assert resp.memory_telemetry.salient_last_turn is False
    assert resp.memory_telemetry.semantic_index_ran is True


def test_post_indexes_when_salient_and_writes_marker(monkeypatch, settings_factory, fake_llm):
    state = _make_state()
    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)
    append_mock = MagicMock()
    save_mock = MagicMock()
    update_mock = MagicMock()
    monkeypatch.setattr(handler, "append_events", append_mock)
    monkeypatch.setattr(handler, "save_branch_state", save_mock)
    monkeypatch.setattr(handler, "update_branch_state_with_events", update_mock)
    index_mock = MagicMock()
    monkeypatch.setattr(handler, "index_memory", index_mock)
    monkeypatch.setattr(handler, "is_salient_assistant_message", lambda msg: True)
    marker_exists = MagicMock(return_value=False)
    write_marker = MagicMock()
    monkeypatch.setattr(handler, "semantic_marker_exists", marker_exists)
    monkeypatch.setattr(handler, "write_semantic_marker", write_marker)

    handler._settings = _settings_with_overrides(settings_factory)
    handler._llm_client = fake_llm

    req = PostPhaseRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        user_message="user",
        assistant_message="We will standardise on Python 3.12 and STATE_TABLE=foo",
    )
    resp = handler.handle_post(req)

    assert resp.ok is True
    assert index_mock.call_count == 2  # user + assistant
    assert write_marker.call_count == 2
    roles = [call_args[0][2].role for call_args in index_mock.call_args_list]
    assert roles == ["user", "assistant"]
    assert isinstance(resp.memory_telemetry, MemoryTelemetry)
    assert resp.memory_telemetry.salient_last_turn is True
    assert resp.memory_telemetry.semantic_index_ran is True


def test_post_semantic_failure_isolated(monkeypatch, settings_factory, fake_llm):
    """Semantic index failure should not block Tier-0 writes."""
    state = _make_state()
    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)
    append_mock = MagicMock()
    save_mock = MagicMock()
    update_mock = MagicMock()
    monkeypatch.setattr(handler, "append_events", append_mock)
    monkeypatch.setattr(handler, "save_branch_state", save_mock)
    monkeypatch.setattr(handler, "update_branch_state_with_events", update_mock)
    monkeypatch.setattr(handler, "is_salient_assistant_message", lambda msg: True)
    marker_exists = MagicMock(return_value=False)
    write_marker = MagicMock()
    monkeypatch.setattr(handler, "semantic_marker_exists", marker_exists)
    monkeypatch.setattr(handler, "write_semantic_marker", write_marker)

    def _index_failure(*args, **kwargs):
        raise RuntimeError("vector store timeout")

    monkeypatch.setattr(handler, "index_memory", _index_failure)

    handler._settings = _settings_with_overrides(settings_factory)
    handler._llm_client = fake_llm

    req = PostPhaseRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        user_message="u",
        assistant_message="We will deploy to lambda.",
    )
    resp = handler.handle_post(req)

    # Tier-0 should succeed even when semantic indexing fails.
    assert resp.ok is True
    append_mock.assert_called_once()
    update_mock.assert_called_once()
    save_mock.assert_called_once()
    write_marker.assert_not_called()
    assert isinstance(resp.memory_telemetry, MemoryTelemetry)
    assert resp.memory_telemetry.semantic_index_ran is False
