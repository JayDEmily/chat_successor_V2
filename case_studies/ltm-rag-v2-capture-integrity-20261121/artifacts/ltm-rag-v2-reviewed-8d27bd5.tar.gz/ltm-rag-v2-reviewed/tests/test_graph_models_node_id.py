"""Unit tests for stable graph node IDs and consolidation dedupe."""

from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace

import pytest

from app.graph_models import make_node_id, MemoryNode
import app.graph_consolidation as gc  # type: ignore[import-not-found]


def test_make_node_id_stable_without_source_event_ids():
    """Node id must not change when evidence changes."""
    id1 = make_node_id("root", "entity", "type", "fact", ["a", "b"])
    id2 = make_node_id("root", "entity", "type", "fact", ["c"])
    id3 = make_node_id("root", "entity", "type", "fact", [])
    assert id1 == id2 == id3


class FakeStore:
    """Minimal store for consolidation tests."""

    def __init__(self):
        self.nodes: dict[str, MemoryNode] = {}

    def get_by_entity(self, root_session_id: str, entity: str, type: str):
        return [
            n
            for n in self.nodes.values()
            if n.root_session_id == root_session_id and n.entity == entity and n.type == type
        ]

    def upsert(self, node: MemoryNode):
        self.nodes[node.node_id] = node


def _cand(fact: str, source_ids: list[str]):
    return {
        "entity": "python_version",
        "type": "config",
        "fact": fact,
        "confidence": 0.9,
        "source_event_ids": source_ids,
    }


def test_consolidation_replay_does_not_create_new_node_on_evidence_growth():
    """Reprocessing the same fact with extra evidence should merge, not create a new node."""
    store = FakeStore()
    now = datetime.now(timezone.utc)

    # First ingestion
    gc.process_consolidation(
        store=store,
        candidates=[_cand("3.11", ["evt-1"])],
        root_session_id="root",
        session_id="sess",
        now=now,
    )
    assert len(store.nodes) == 1
    node_id = next(iter(store.nodes.keys()))
    assert store.nodes[node_id].source_event_ids == ["evt-1"]

    # Replay with additional evidence
    gc.process_consolidation(
        store=store,
        candidates=[_cand("3.11", ["evt-1", "evt-2"])],
        root_session_id="root",
        session_id="sess",
        now=now,
    )
    assert len(store.nodes) == 1
    node = store.nodes[node_id]
    assert set(node.source_event_ids) == {"evt-1", "evt-2"}
