"""Unit tests for short-term memory update logic.

Offline tests using fake LLM to assert summarisation and buffer behaviour.
"""

from datetime import datetime, timezone

from app import short_term_memory as stm
from app.models import BranchState, Event


class FakeLLM:
    def __init__(self, summary="SUMMARY"):
        self.summary = summary
        self.calls = 0
        self.last_history = None

    def summarise(self, history_text: str) -> str:
        self.calls += 1
        self.last_history = history_text
        return self.summary

    def embed(self, text: str):
        return [0.1, 0.2]


def _event(role="assistant", content="hi", seq=0):
    return Event(
        event_id=f"e{seq}",
        root_session_id="root",
        session_id="sess",
        sequence=seq,
        role=role,  # type: ignore[arg-type]
        created_at=datetime.now(timezone.utc),
        content=content,
    )


def test_update_branch_state_triggers_summary_after_threshold():
    state = BranchState(root_session_id="root", session_id="sess")
    llm = FakeLLM(summary="NEW SUMMARY")

    new_events = [_event(seq=i) for i in range(stm.SUMMARY_MIN_TURNS)]
    stm.update_branch_state_with_events(llm, state, new_events)

    assert state.short_summary == "NEW SUMMARY"
    assert llm.calls == 1
    # summary_turns_since_update reset
    assert state.summary_turns_since_update == 0
    # buffer trimmed to RECENT_EVENTS_MAX (here only SUMMARY_MIN_TURNS events)
    assert len(state.recent_events) == len(new_events)


def test_update_branch_state_no_summary_when_threshold_not_met():
    state = BranchState(root_session_id="root", session_id="sess")
    llm = FakeLLM()

    new_events = [_event(role="user", seq=0)]
    stm.update_branch_state_with_events(llm, state, new_events)

    assert state.short_summary is None
    assert llm.calls == 0
    assert state.summary_turns_since_update == 0  # user turns do not increment counter
    assert len(state.recent_events) == 1


def test_recent_events_trimmed_when_exceeding_max():
    state = BranchState(root_session_id="root", session_id="sess")
    llm = FakeLLM()

    # push beyond RECENT_EVENTS_MAX with assistant events so summary is refreshed
    many_events = [_event(seq=i) for i in range(stm.RECENT_EVENTS_MAX + 5)]
    stm.update_branch_state_with_events(llm, state, many_events)

    assert len(state.recent_events) == stm.RECENT_EVENTS_MAX
    assert state.short_summary == llm.summary
    assert llm.calls == 1
    expected_tail = many_events[-stm.RECENT_EVENTS_MAX :]
    assert [e.sequence for e in state.recent_events] == [
        e.sequence for e in expected_tail
    ]


def test_update_branch_state_existing_summary_threshold_crosses_and_trims():
    state = BranchState(
        root_session_id="root",
        session_id="sess",
        short_summary="OLD",
        summary_turns_since_update=2,
    )
    # Pre-populate near the buffer limit to exercise trimming after refresh.
    state.recent_events = [
        _event(seq=i) for i in range(stm.RECENT_EVENTS_MAX - 2)
    ]

    llm = FakeLLM(summary="NEW")

    # Add enough assistant events to cross the summary threshold.
    new_events = [_event(seq=i) for i in range(100, 104)]
    stm.update_branch_state_with_events(llm, state, new_events)

    assert llm.calls == 1
    assert state.short_summary == "NEW"
    assert state.summary_turns_since_update == 0
    assert len(state.recent_events) == stm.RECENT_EVENTS_MAX


def test_history_text_passed_to_summariser_matches_events():
    state = BranchState(
        root_session_id="root",
        session_id="sess",
        summary_turns_since_update=stm.SUMMARY_MIN_TURNS,
    )
    llm = FakeLLM(summary="SUMMARY TEXT")

    user_event = _event(role="user", content="hello", seq=0)
    assistant_event = _event(role="assistant", content="world", seq=1)

    stm.update_branch_state_with_events(
        llm,
        state,
        [user_event, assistant_event],
    )

    expected_history = "USER: hello\nASSISTANT: world"
    assert llm.calls == 1
    assert llm.last_history == expected_history


def test_user_only_events_do_not_increment_summary_counter():
    state = BranchState(root_session_id="root", session_id="sess")
    llm = FakeLLM()

    user_events = [_event(role="user", seq=i) for i in range(3)]
    stm.update_branch_state_with_events(llm, state, user_events)

    assert state.summary_turns_since_update == 0
    assert state.short_summary is None
    assert llm.calls == 0


def test_empty_summary_does_not_clobber_existing_summary():
    state = BranchState(
        root_session_id="root",
        session_id="sess",
        short_summary="OLD",
        summary_turns_since_update=stm.SUMMARY_MIN_TURNS,
    )

    class EmptySummaryLLM(FakeLLM):
        def summarise(self, history_text: str) -> str:
            self.calls += 1
            self.last_history = history_text
            return ""

    llm = EmptySummaryLLM()

    events = [_event(seq=i) for i in range(stm.SUMMARY_MIN_TURNS)]
    stm.update_branch_state_with_events(llm, state, events)

    assert state.short_summary == "OLD"
    assert state.summary_turns_since_update == 0
    assert llm.calls == 1
