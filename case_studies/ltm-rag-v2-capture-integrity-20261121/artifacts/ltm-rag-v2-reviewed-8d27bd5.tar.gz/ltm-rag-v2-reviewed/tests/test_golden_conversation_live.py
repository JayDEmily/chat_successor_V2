"""Live golden conversation runner test (deployed /turn + OpenAI Responses).

Guarded by LIVE_AGENT=1 to avoid accidental live calls.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

from app.micro_agent.env_loader import load_env
from app.micro_agent.turn_client import resolve_function_url


# Ensure OPENAI_API_KEY and any local overrides are loaded from the root .env.
load_env()

try:
    FUNCTION_URL = resolve_function_url()
except RuntimeError:
    FUNCTION_URL = None


pytestmark = [
    pytest.mark.smoke,
    pytest.mark.skipif(
        os.getenv("LIVE_AGENT") != "1",
        reason="Set LIVE_AGENT=1 to run the golden conversation live test",
    ),
    pytest.mark.skipif(
        not FUNCTION_URL,
        reason="LIVE_LAMBDA_URL/LIVE_FUNCTION_URL/MEMORY_AGENT_URL must be set to hit the deployed Lambda",
    ),
    pytest.mark.skipif(
        not os.getenv("OPENAI_API_KEY"),
        reason="OPENAI_API_KEY must be set to run the golden conversation live test",
    ),
]


def _read_jsonl(path: Path) -> list[dict]:
    lines: list[dict] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        if not raw.strip():
            continue
        lines.append(json.loads(raw))
    return lines


def test_golden_runner_live_subset(tmp_path: Path):
    out_dir = tmp_path / "golden"
    base = "golden_nvda_desk_v1"

    cmd = [
        sys.executable,
        "scripts/run_golden_conversation.py",
        "--scenario",
        "nvda_desk_v1",
        "--output-dir",
        str(out_dir),
        "--output-base",
        base,
        "--max-turns",
        "5",
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    assert proc.returncode == 0, proc.stderr

    jsonl_path = out_dir / f"{base}.jsonl"
    manifest_path = out_dir / f"{base}.manifest.json"
    assert jsonl_path.exists()
    assert manifest_path.exists()

    lines = _read_jsonl(jsonl_path)
    assert len(lines) == 5

    for idx, row in enumerate(lines, start=1):
        assert row["turn_index"] == idx
        assert row["turn_http_status"] == 200
        assert isinstance(row["assistant_text"], str) and row["assistant_text"].strip()
        assert isinstance(row.get("bytes_total"), int) and row["bytes_total"] > 0
        assert isinstance(row.get("memory_telemetry"), dict)

    telemetries = [row["memory_telemetry"] for row in lines]
    assert any(t.get("memory_dependent") is True for t in telemetries)

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert manifest["scenario_name"] == "nvda_desk_v1"
    assert isinstance(manifest.get("root_session_id"), str) and manifest["root_session_id"]
    assert isinstance(manifest.get("session_id"), str) and manifest["session_id"]
    assert isinstance(manifest.get("function_url"), str) and manifest["function_url"]
    assert isinstance(manifest.get("transcript_key"), str) and manifest["transcript_key"]
    assert isinstance(manifest.get("assistant_instructions"), str) and manifest["assistant_instructions"]

