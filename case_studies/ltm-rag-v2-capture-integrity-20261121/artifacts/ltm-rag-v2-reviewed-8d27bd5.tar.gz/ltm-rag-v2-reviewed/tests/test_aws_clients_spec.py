"""Specs for aws_clients helpers (session wiring only)."""

from types import SimpleNamespace
from unittest.mock import MagicMock

from botocore.config import Config as BotoConfig

from app import aws_clients


def test_get_dynamodb_table_uses_settings(monkeypatch):
    table_mock = MagicMock()
    resource_obj = MagicMock(Table=MagicMock(return_value=table_mock))
    session_mock = MagicMock(resource=MagicMock(return_value=resource_obj))

    session_cls = MagicMock(return_value=session_mock)
    monkeypatch.setattr(aws_clients.boto3, "Session", session_cls)

    settings = SimpleNamespace(aws_region="ap-southeast-2", state_table="state-table")

    table = aws_clients.get_dynamodb_table(settings)

    session_cls.assert_called_once_with(region_name=settings.aws_region)
    resource_call = session_mock.resource
    resource_call.assert_called_once()
    args, kwargs = resource_call.call_args
    assert args[0] == "dynamodb"
    assert isinstance(kwargs.get("config"), BotoConfig)

    resource_obj.Table.assert_called_once_with(settings.state_table)
    assert table is resource_obj.Table.return_value


def test_get_s3_client_uses_settings(monkeypatch):
    s3_client = MagicMock()
    session_mock = MagicMock(client=MagicMock(return_value=s3_client))
    session_cls = MagicMock(return_value=session_mock)
    monkeypatch.setattr(aws_clients.boto3, "Session", session_cls)

    settings = SimpleNamespace(aws_region="us-east-1")

    client = aws_clients.get_s3_client(settings)

    session_cls.assert_called_once_with(region_name=settings.aws_region)
    session_mock.client.assert_called_once()
    args, kwargs = session_mock.client.call_args
    assert args[0] == "s3"
    assert isinstance(kwargs.get("config"), BotoConfig)
    assert client is s3_client
