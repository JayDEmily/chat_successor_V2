from __future__ import annotations

import pytest

from app.micro_agent.context_pack import build_context_pack
from app.micro_agent.golden_metrics import (
    ANCHORS_NVDA_DESK_V2,
    compute_anchor_report,
    enforce_quality_gates,
)
from app.micro_agent.response_text import ResponseTextError, extract_output_text_strict


def test_context_pack_includes_headers_when_empty():
    pack = build_context_pack({})
    for header in [
        "SHORT_SUMMARY:",
        "RECENT_EVENTS:",
        "SEMANTIC_HITS:",
        "REHYDRATED_S3_WINDOWS:",
        "GRAPH_MEMORY_FACTS:",
        "TELEMETRY:",
    ]:
        assert header in pack


class _DummyBlock:
    def __init__(self, text: str | None):
        self.text = text


class _DummyItem:
    def __init__(self, content):
        self.content = content


class _DummyResp:
    def __init__(self, *, output_text=None, output=None):
        self.output_text = output_text
        self.output = output


def test_strict_responses_text_extraction_object_output_text():
    resp = _DummyResp(output_text=" hello ")
    assert extract_output_text_strict(resp, label="x") == "hello"


def test_strict_responses_text_extraction_object_output_blocks():
    resp = _DummyResp(output=[_DummyItem([_DummyBlock("hi")])])
    assert extract_output_text_strict(resp, label="x") == "hi"


def test_strict_responses_text_extraction_dict_forms():
    assert extract_output_text_strict({"output_text": "yo"}, label="x") == "yo"
    assert (
        extract_output_text_strict(
            {"output": [{"content": [{"text": "ok"}]}]},
            label="x",
        )
        == "ok"
    )


def test_strict_responses_text_extraction_raises_on_empty():
    with pytest.raises(ResponseTextError):
        extract_output_text_strict({"output_text": "   "}, label="x")


def test_no_ack_and_no_empty_enforced_by_quality_gates():
    rows = [
        {"turn_index": 1, "user_agent_text": "u", "desk_agent_text": "ACK"},
    ]
    with pytest.raises(ValueError):
        enforce_quality_gates(rows)

    rows = [
        {"turn_index": 1, "user_agent_text": "u", "desk_agent_text": "   "},
    ]
    with pytest.raises(ValueError):
        enforce_quality_gates(rows)


def test_anchor_detection_and_requote():
    # Anchors first appear at turn 1, then are re-quoted at turn 4 after a quote cue.
    anchor_block = "\n".join(ANCHORS_NVDA_DESK_V2)
    rows = [
        {"turn_index": 1, "user_agent_text": "start", "desk_agent_text": anchor_block},
        {"turn_index": 2, "user_agent_text": "more rules", "desk_agent_text": "ok"},
        {"turn_index": 3, "user_agent_text": "setup", "desk_agent_text": "ok"},
        {
            "turn_index": 4,
            "user_agent_text": "quote exactly what you said earlier",
            "desk_agent_text": anchor_block,
        },
    ]
    report = compute_anchor_report(rows)
    assert all(report.seen.values())
    assert all(report.requoted_later.values())

