from __future__ import annotations

from app.models import MemoryTelemetry, PrePhaseResponse
from app.rehydration import select_window_events
from copy import deepcopy

from app.response_budget import enforce_response_budget
from app.response_utils import build_body_and_measure


def _event(seq: int, *, content: str = "hello") -> dict:
    return {
        "event_id": f"evt-{seq}",
        "root_session_id": "root",
        "session_id": "sess",
        "sequence": seq,
        "role": "user",
        "created_at": "2024-01-01T00:00:00Z",
        "content": content,
        "metadata": {},
    }


def test_select_window_by_event_id():
    events = [_event(i) for i in range(5)]
    window, anchor = select_window_events(
        events,
        anchor_event_id="evt-2",
        anchor_sequence=None,
        window_radius=1,
    )

    assert anchor and anchor.get("event_id") == "evt-2"
    assert [evt.get("event_id") for evt in window] == ["evt-1", "evt-2", "evt-3"]


def test_select_window_handles_edges():
    events = [_event(i) for i in range(5)]

    window_start, anchor_start = select_window_events(
        events,
        anchor_event_id="evt-0",
        anchor_sequence=None,
        window_radius=2,
    )
    assert anchor_start and anchor_start.get("event_id") == "evt-0"
    assert [evt.get("event_id") for evt in window_start] == ["evt-0", "evt-1", "evt-2"]

    window_end, anchor_end = select_window_events(
        events,
        anchor_event_id="evt-4",
        anchor_sequence=None,
        window_radius=2,
    )
    assert anchor_end and anchor_end.get("event_id") == "evt-4"
    assert [evt.get("event_id") for evt in window_end] == ["evt-2", "evt-3", "evt-4"]


def test_budget_truncation_keeps_anchor():
    events = [_event(i, content="x" * 200) for i in range(5)]
    window_events, anchor = select_window_events(
        events,
        anchor_event_id="evt-2",
        anchor_sequence=None,
        window_radius=2,
    )
    assert anchor

    window = {
        "anchor": {
            "event_id": anchor["event_id"],
            "role": anchor["role"],
            "content": anchor["content"],
            "sequence": anchor["sequence"],
        },
        "window_events": window_events,
        "source": {"transcript_key": "sessions/root/sess.log.jsonl", "bucket": "bucket"},
        "hit_ref": {"event_id": anchor["event_id"], "sequence": anchor["sequence"]},
    }

    resp = PrePhaseResponse(
        short_summary=None,
        recent_events=[],
        semantic_hits=[],
        rehydrated_s3_windows=[window],
        memory_telemetry=MemoryTelemetry(),
    )

    full_report = build_body_and_measure(resp, set_bytes_total=True)[1]
    anchor_only = deepcopy(resp)
    anchor_only.rehydrated_s3_windows[0]["window_events"] = [anchor]
    anchor_only.response_truncated = True
    anchor_report = build_body_and_measure(anchor_only, set_bytes_total=True)[1]
    assert anchor_report.total_bytes < full_report.total_bytes
    budget = anchor_report.total_bytes + 5

    report = enforce_response_budget(resp, budget_bytes=budget)

    assert report.total_bytes <= budget
    assert resp.rehydrated_s3_windows
    final_events = resp.rehydrated_s3_windows[0].get("window_events") or []
    assert any(evt.get("event_id") == "evt-2" for evt in final_events)
    assert resp.memory_telemetry.s3_rehydration_truncated is True
    assert resp.memory_telemetry.s3_rehydration_windows_returned == 1
