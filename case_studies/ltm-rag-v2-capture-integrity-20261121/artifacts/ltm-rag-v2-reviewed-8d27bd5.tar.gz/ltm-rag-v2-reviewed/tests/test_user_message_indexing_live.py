"""Live probe to prove user messages are indexed and retrievable via /turn.

Uses the MicroAgent to generate a real assistant reply (no synthetic ack).
Fails hard when LIVE_RAG or function URL env vars are missing.
"""

from __future__ import annotations

import json
import os
import uuid

import pytest

from app.micro_agent import MicroAgent
from app.micro_agent.env_loader import load_env
from app.micro_agent.turn_client import resolve_function_url


load_env()

if os.getenv("LIVE_RAG") != "1":
    pytest.skip("Set LIVE_RAG=1 to run the live user-indexing probe", allow_module_level=True)

FUNCTION_URL = resolve_function_url()
MICRO_AGENT_MODEL = os.getenv("MICRO_AGENT_MODEL") or "gpt-5-nano"


def _dump(data: dict) -> str:
    return json.dumps(data, indent=2, sort_keys=True, default=str)


def test_user_message_semantic_indexing_live():
    root_session_id = f"user-index-{uuid.uuid4().hex}"
    session_id = root_session_id

    fact_uuid = uuid.uuid4().hex
    fact_suffix = uuid.uuid4().hex[:8]
    user_fact = f"USER_FACT: user_index_probe={fact_uuid} value=cerulean-frog-{fact_suffix}"

    seed_user_message = (
        f"Remember this exact fact for later recall: {user_fact}. "
        "Reply with a brief ACK only; do not repeat the USER_FACT string."
    )
    probe_prompt = "What was the USER_FACT I told you earlier? Repeat it exactly."

    agent = MicroAgent(
        root_session_id=root_session_id,
        session_id=session_id,
        function_url=FUNCTION_URL,
        model=MICRO_AGENT_MODEL,
    )

    r1 = agent.step(seed_user_message)
    assert r1.http_status == 200
    assert r1.turn_response.get("persisted_last_turn") is False, _dump(r1.turn_response)
    assert isinstance(r1.assistant_text, str) and r1.assistant_text.strip(), _dump(r1.turn_response)
    assert len(r1.assistant_text) <= 200
    assert user_fact not in r1.assistant_text

    r2 = agent.step(probe_prompt)
    body_dump = _dump(r2.turn_response)

    assert r2.http_status == 200, body_dump
    assert r2.turn_response.get("persisted_last_turn") is True, body_dump

    telemetry = r2.turn_response.get("memory_telemetry")
    assert isinstance(telemetry, dict), body_dump
    assert telemetry.get("semantic_search_ran") is True, body_dump
    assert telemetry.get("semantic_index_ran") is True, body_dump
    assert isinstance(telemetry.get("policy_applied"), str) and telemetry.get("policy_applied"), body_dump

    hits = r2.turn_response.get("semantic_hits")
    assert isinstance(hits, list) and hits, body_dump
    fact_hits = [
        hit for hit in hits if isinstance(hit, dict) and user_fact in str(hit.get("text", ""))
    ]
    assert fact_hits, body_dump
    hit = fact_hits[0]
    meta = hit.get("metadata")
    assert isinstance(meta, dict), body_dump
    assert meta.get("role") == "user", body_dump
    assert meta.get("root_session_id") == root_session_id, body_dump
    assert meta.get("session_id") == session_id, body_dump

    events = r2.turn_response.get("recent_events") or []
    user_events = [
        evt
        for evt in events
        if isinstance(evt, dict) and evt.get("role") == "user" and user_fact in str(evt.get("content", ""))
    ]
    assert user_events, body_dump
    user_event_id = user_events[0].get("event_id")
    assert user_event_id, body_dump
    assert meta.get("event_id") == user_event_id or meta.get("id") == user_event_id, body_dump
