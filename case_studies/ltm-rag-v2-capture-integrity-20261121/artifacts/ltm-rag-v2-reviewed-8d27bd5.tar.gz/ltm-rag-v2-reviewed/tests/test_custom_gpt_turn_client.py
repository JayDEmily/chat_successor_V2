from __future__ import annotations

import pytest

from custom_gpt_turn_client import CustomGPTTurnClient


def make_stub_http(responses):
    """responses: list of callables or exceptions per call."""
    calls = []

    def _http(path, body):
        calls.append((path, body))
        if not responses:
            return {"status": 200, "body": {"persisted_last_turn": True}}
        result = responses.pop(0)
        if isinstance(result, Exception):
            raise result
        return result

    return _http, calls


def test_first_turn_allows_no_last_and_marks_write_false():
    http, calls = make_stub_http(
        [{"status": 200, "body": {"persisted_last_turn": False}}]
    )
    client = CustomGPTTurnClient(
        function_url="https://example.com",
        root_session_id="root",
        session_id="sess",
        http_post=http,
    )
    body, marker = client.send_turn(
        current_user_message="msg1",
        last_user_message=None,
        last_assistant_message=None,
    )
    assert marker == "turn=0001 write=false"
    assert body["persisted_last_turn"] is False
    assert calls[0][1]["last_user_message"] is None
    assert client.turn_number == 2  # advanced


def test_retry_pending_last_on_failure_then_success():
    http, calls = make_stub_http(
        [
            RuntimeError("network down"),
            {"status": 200, "body": {"persisted_last_turn": True}},
        ]
    )
    client = CustomGPTTurnClient(
        function_url="https://example.com",
        root_session_id="root",
        session_id="sess",
        http_post=http,
    )
    # First attempt fails; pending last_* should be stored.
    with pytest.raises(RuntimeError):
        client.send_turn(
            current_user_message="msg2",
            last_user_message="prev user",
            last_assistant_message="prev bot",
        )
    assert client._pending_last == ("prev user", "prev bot")

    # Next attempt should resend the pending last_*.
    body, marker = client.send_turn(
        current_user_message="msg3",
        last_user_message="should be ignored",
        last_assistant_message="ignored too",
    )
    assert marker == "turn=0001 write=true"
    assert calls[-1][1]["last_user_message"] == "prev user"
    assert calls[-1][1]["last_assistant_message"] == "prev bot"
    assert client._pending_last is None
    assert body["persisted_last_turn"] is True


def test_reject_unpaired_last_fields():
    client = CustomGPTTurnClient(
        function_url="https://example.com",
        root_session_id="root",
        session_id="sess",
        http_post=lambda p, b: {"status": 200, "body": {"persisted_last_turn": False}},
    )
    with pytest.raises(ValueError):
        client.send_turn(
            current_user_message="msg",
            last_user_message="only user",
            last_assistant_message=None,
        )


def test_enforces_persisted_when_last_provided():
    http, calls = make_stub_http(
        [{"status": 200, "body": {"persisted_last_turn": False}}]
    )
    client = CustomGPTTurnClient(
        function_url="https://example.com",
        root_session_id="root",
        session_id="sess",
        http_post=http,
    )
    with pytest.raises(AssertionError):
        client.send_turn(
            current_user_message="msg2",
            last_user_message="prev user",
            last_assistant_message="prev bot",
        )
    assert client._pending_last == ("prev user", "prev bot")
