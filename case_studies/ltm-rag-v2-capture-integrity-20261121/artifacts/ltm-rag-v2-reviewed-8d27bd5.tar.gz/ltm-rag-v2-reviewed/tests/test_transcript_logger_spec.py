"""Specs for transcript_logger append semantics (JSONL + S3 keying)."""

import io
import json
from types import SimpleNamespace
from unittest.mock import MagicMock

from botocore.exceptions import ClientError

from app import transcript_logger
from app.models import Event, utc_now


def _event(event_id: str, role: str, seq: int, content: str, metadata=None) -> Event:
    return Event(
        event_id=event_id,
        root_session_id="root",
        session_id="sess",
        sequence=seq,
        role=role,  # type: ignore[arg-type]
        created_at=utc_now(),
        content=content,
        metadata=metadata or {},
    )


def test_append_events_writes_expected_jsonl(monkeypatch):
    client = MagicMock()

    def raise_no_such_key(**_kwargs):
        raise ClientError({"Error": {"Code": "NoSuchKey"}}, "GetObject")

    client.get_object.side_effect = raise_no_such_key
    captured = {}

    def capture_put(**kwargs):
        captured.update(kwargs)

    client.put_object.side_effect = capture_put
    monkeypatch.setattr(transcript_logger, "get_s3_client", lambda settings: client)

    settings = SimpleNamespace(transcript_bucket="bucket")
    events = [
        _event("e1", "user", 0, "hi", metadata={"foo": "bar"}),
        _event("e2", "assistant", 1, "yo", metadata={"num": 2}),
    ]

    transcript_logger.append_events(settings, "root", "sess", events)

    assert captured["Bucket"] == settings.transcript_bucket
    assert captured["Key"] == "sessions/root/sess.log.jsonl"

    body = captured["Body"].decode("utf-8")
    lines = [json.loads(line) for line in body.splitlines() if line]
    assert len(lines) == 2
    assert [line["event_id"] for line in lines] == ["e1", "e2"]
    assert all(line["root_session_id"] == "root" for line in lines)
    assert all(line["session_id"] == "sess" for line in lines)
    assert all(isinstance(line["created_at"], str) for line in lines)
    assert lines[0]["metadata"] == {"foo": "bar"}
    assert lines[1]["metadata"] == {"num": 2}


def test_append_events_preserves_existing_body(monkeypatch):
    existing_event = _event("old", "user", 0, "before")
    existing_body = json.dumps(existing_event.to_dict()) + "\n"

    client = MagicMock()
    client.get_object.return_value = {"Body": io.BytesIO(existing_body.encode("utf-8"))}
    captured = {}
    client.put_object.side_effect = lambda **kwargs: captured.update(kwargs)
    monkeypatch.setattr(transcript_logger, "get_s3_client", lambda settings: client)

    settings = SimpleNamespace(transcript_bucket="bucket")
    new_events = [_event("new", "assistant", 1, "after")]

    transcript_logger.append_events(settings, "root", "sess", new_events)

    body = captured["Body"].decode("utf-8")
    lines = [json.loads(line) for line in body.splitlines() if line]
    assert len(lines) == 2
    assert lines[0]["event_id"] == "old"
    assert lines[1]["event_id"] == "new"


def test_append_events_is_append_only_across_calls(monkeypatch):
    """Two sequential appends for the same branch accumulate JSONL lines."""

    class FakeS3:
        def __init__(self):
            self.body = None
            self.puts = []

        def get_object(self, *, Bucket, Key):
            if self.body is None:
                raise ClientError({"Error": {"Code": "NoSuchKey"}}, "GetObject")
            return {"Body": io.BytesIO(self.body)}

        def put_object(self, *, Bucket, Key, Body):
            self.body = Body
            self.puts.append({"Bucket": Bucket, "Key": Key})

    fake = FakeS3()
    monkeypatch.setattr(transcript_logger, "get_s3_client", lambda settings: fake)
    settings = SimpleNamespace(transcript_bucket="bucket")

    transcript_logger.append_events(
        settings,
        "root",
        "sess",
        [_event("e1", "user", 0, "first")],
    )
    transcript_logger.append_events(
        settings,
        "root",
        "sess",
        [_event("e2", "assistant", 1, "second")],
    )

    body = (fake.body or b"").decode("utf-8")
    lines = [json.loads(line) for line in body.splitlines() if line]
    assert [line["event_id"] for line in lines] == ["e1", "e2"]
    assert fake.puts == [
        {"Bucket": "bucket", "Key": "sessions/root/sess.log.jsonl"},
        {"Bucket": "bucket", "Key": "sessions/root/sess.log.jsonl"},
    ]
