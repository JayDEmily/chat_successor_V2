"""Additional lambda_handler validation and routing tests."""

import json
from types import SimpleNamespace
from unittest.mock import MagicMock

import lambda_handler as lh
from app.models import MemoryTelemetry, PrePhaseResponse, TurnResponse
from app.response_budget import enforce_response_budget


def _call_lambda(body: dict, path: str) -> dict:
    event = {
        "rawPath": path,
        "requestContext": {"http": {"method": "POST"}},
        "body": json.dumps(body),
    }
    return lh.lambda_handler(event, context=SimpleNamespace(aws_request_id="req-1"))


def test_pre_rejects_non_string_fields(monkeypatch):
    monkeypatch.setattr(lh, "run_healthcheck", lambda: None)
    lh._HEALTHCHECK_RAN = False

    for field in ["root_session_id", "session_id", "user_message"]:
        body = {
            "root_session_id": "root",
            "session_id": "sess",
            "user_message": "hi",
        }
        body[field] = 123
        resp = _call_lambda(body, path="/pre")
        assert resp["statusCode"] == 400
        assert "Invalid field" in json.loads(resp["body"])["error"]


def test_pre_rejects_empty_string_fields(monkeypatch):
    monkeypatch.setattr(lh, "run_healthcheck", lambda: None)
    lh._HEALTHCHECK_RAN = False

    for field in ["root_session_id", "session_id", "user_message"]:
        body = {
            "root_session_id": "root",
            "session_id": "sess",
            "user_message": "hi",
        }
        body[field] = "   "
        resp = _call_lambda(body, path="/pre")
        assert resp["statusCode"] == 400
        assert "Invalid field" in json.loads(resp["body"])["error"]


def test_post_rejects_non_string_fields(monkeypatch):
    monkeypatch.setattr(lh, "run_healthcheck", lambda: None)
    lh._HEALTHCHECK_RAN = False

    for field in ["root_session_id", "session_id", "user_message", "assistant_message"]:
        body = {
            "root_session_id": "root",
            "session_id": "sess",
            "user_message": "hi",
            "assistant_message": "hello",
        }
        body[field] = 123
        resp = _call_lambda(body, path="/post")
        assert resp["statusCode"] == 400
        assert "Invalid field" in json.loads(resp["body"])["error"]


def test_post_rejects_empty_string_fields(monkeypatch):
    monkeypatch.setattr(lh, "run_healthcheck", lambda: None)
    lh._HEALTHCHECK_RAN = False

    for field in ["root_session_id", "session_id", "user_message", "assistant_message"]:
        body = {
            "root_session_id": "root",
            "session_id": "sess",
            "user_message": "hi",
            "assistant_message": "hello",
        }
        body[field] = ""
        resp = _call_lambda(body, path="/post")
        assert resp["statusCode"] == 400
        assert "Invalid field" in json.loads(resp["body"])["error"]


def test_lambda_handler_logs_pre_request(monkeypatch):
    fake_logger = MagicMock()
    monkeypatch.setattr(lh, "logger", fake_logger)
    monkeypatch.setattr(lh, "run_healthcheck", lambda: None)
    resp = PrePhaseResponse(
        short_summary=None,
        recent_events=[],
        semantic_hits=[],
        memory_telemetry=MemoryTelemetry(),
    )
    enforce_response_budget(resp, budget_bytes=200000)
    monkeypatch.setattr(lh, "handle_pre", MagicMock(return_value=resp))
    lh._HEALTHCHECK_RAN = False

    body = {"root_session_id": "root", "session_id": "sess", "user_message": "hi"}
    resp = _call_lambda(body, path="/pre")
    assert resp["statusCode"] == 200
    assert any(
        call.kwargs.get("extra", {}).get("status_code") == 200
        for call in fake_logger.info.call_args_list
        if call.args and call.args[0] == "request_success"
    )


def test_lambda_handler_logs_not_found(monkeypatch):
    fake_logger = MagicMock()
    monkeypatch.setattr(lh, "logger", fake_logger)
    monkeypatch.setattr(lh, "run_healthcheck", lambda: None)
    lh._HEALTHCHECK_RAN = False

    body = {"root_session_id": "root", "session_id": "sess", "user_message": "hi"}
    resp = _call_lambda(body, path="/unknown")
    assert resp["statusCode"] == 404
    assert any(
        call.kwargs.get("extra", {}).get("status_code") == 404
        for call in fake_logger.info.call_args_list
        if call.args and call.args[0] == "request_not_found"
    )


def test_lambda_handler_accepts_stage_prefixed_pre(monkeypatch):
    monkeypatch.setattr(lh, "run_healthcheck", lambda: None)
    lh._HEALTHCHECK_RAN = False
    resp = PrePhaseResponse(
        short_summary=None,
        recent_events=[],
        semantic_hits=[],
        memory_telemetry=MemoryTelemetry(),
    )
    enforce_response_budget(resp, budget_bytes=200000)
    monkeypatch.setattr(
        lh,
        "handle_pre",
        MagicMock(return_value=resp),
    )

    body = {"root_session_id": "root", "session_id": "sess", "user_message": "hi"}
    resp = _call_lambda(body, path="/prod/pre")
    assert resp["statusCode"] == 200


def test_lambda_handler_accepts_stage_prefixed_post(monkeypatch):
    monkeypatch.setattr(lh, "run_healthcheck", lambda: None)
    lh._HEALTHCHECK_RAN = False
    monkeypatch.setattr(
        lh,
        "handle_post",
        MagicMock(return_value=SimpleNamespace(ok=True)),
    )

    body = {
        "root_session_id": "root",
        "session_id": "sess",
        "user_message": "hi",
        "assistant_message": "hello",
    }
    resp = _call_lambda(body, path="/v1/post")
    assert resp["statusCode"] == 200


def test_turn_rejects_mismatched_nulls(monkeypatch):
    monkeypatch.setattr(lh, "run_healthcheck", lambda: None)
    lh._HEALTHCHECK_RAN = False
    turn_resp = TurnResponse(
        short_summary=None,
        recent_events=[],
        semantic_hits=[],
        persisted_last_turn=False,
        memory_telemetry=MemoryTelemetry(),
    )
    enforce_response_budget(turn_resp, budget_bytes=200000)
    monkeypatch.setattr(
        lh,
        "handle_turn",
        MagicMock(return_value=turn_resp),
    )

    body = {
        "root_session_id": "root",
        "session_id": "sess",
        "last_user_message": None,
        "last_assistant_message": "assistant",
        "current_user_message": "hi",
    }
    resp = _call_lambda(body, path="/turn")
    assert resp["statusCode"] == 400


def test_turn_accepts_null_last_fields(monkeypatch):
    monkeypatch.setattr(lh, "run_healthcheck", lambda: None)
    lh._HEALTHCHECK_RAN = False
    fake_resp = TurnResponse(
        short_summary=None,
        recent_events=[],
        semantic_hits=[],
        persisted_last_turn=False,
        memory_telemetry=MemoryTelemetry(),
    )
    enforce_response_budget(fake_resp, budget_bytes=200000)
    handle_turn = MagicMock(return_value=fake_resp)
    monkeypatch.setattr(lh, "handle_turn", handle_turn)

    body = {
        "root_session_id": "root",
        "session_id": "sess",
        "last_user_message": None,
        "last_assistant_message": None,
        "current_user_message": "hi",
    }
    resp = _call_lambda(body, path="/turn")
    assert resp["statusCode"] == 200
    handle_turn.assert_called_once()
