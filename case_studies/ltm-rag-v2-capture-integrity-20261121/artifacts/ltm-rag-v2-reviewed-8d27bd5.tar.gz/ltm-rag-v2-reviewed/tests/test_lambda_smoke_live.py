"""Minimal deployed-Lambda smoke tests (Function URL /pre and /post).

Layer 2: verifies wiring/env of the deployed Lambda without re-packaging.
Skipped unless LIVE_SMOKE=1 and LIVE_LAMBDA_URL are set.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
import uuid

import pytest

from app.micro_agent.turn_client import TurnClientError, resolve_function_url

_FUNCTION_URL = os.getenv("LIVE_LAMBDA_URL") or os.getenv("LIVE_FUNCTION_URL")
if not _FUNCTION_URL and os.getenv("LIVE_SMOKE") == "1":
    try:
        _FUNCTION_URL = resolve_function_url()
    except TurnClientError as exc:  # pragma: no cover - live wiring guard
        _FUNCTION_URL = None
        _RESOLUTION_ERROR = str(exc)
    else:
        _RESOLUTION_ERROR = None
else:
    _RESOLUTION_ERROR = None

pytestmark = [
    pytest.mark.smoke,
    pytest.mark.release,
    pytest.mark.skipif(
        os.getenv("LIVE_SMOKE") != "1" or not _FUNCTION_URL,
        reason=_RESOLUTION_ERROR or "Set LIVE_SMOKE=1 to hit the deployed Lambda",
    ),
]


def _post(path: str, body: dict) -> dict:
    url = _FUNCTION_URL.rstrip("/") + path
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            status = resp.getcode()
            payload = json.loads(resp.read().decode("utf-8"))
            return {"status": status, "body": payload}
    except urllib.error.HTTPError as exc:  # pragma: no cover - live wiring guard
        err_body = exc.read().decode("utf-8")
        raise AssertionError(
            f"HTTP {exc.code} hitting {url}: {err_body}"
        ) from exc


def test_function_url_pre_and_post_roundtrip():
    root_session_id = f"smoke-root-{uuid.uuid4()}"
    session_id = f"smoke-session-{uuid.uuid4()}"

    pre = _post(
        "/pre",
        {
            "root_session_id": root_session_id,
            "session_id": session_id,
            "user_message": "smoke: hello?",
        },
    )
    assert pre["status"] == 200
    assert "recent_events" in pre["body"]

    post = _post(
        "/post",
        {
            "root_session_id": root_session_id,
            "session_id": session_id,
            "user_message": "smoke: user says hi",
            "assistant_message": "smoke: ack",
        },
    )
    assert post["status"] == 200
    assert post["body"].get("ok") is True
