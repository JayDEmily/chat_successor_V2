"""Healthcheck coverage for V3 graph components."""

from __future__ import annotations

from types import SimpleNamespace

import pytest


def test_healthcheck_verifies_memory_nodes_table(monkeypatch):
    """Healthcheck should load/check the memory_nodes table exists."""
    import app.graph_healthcheck as hc  # type: ignore[import-not-found]

    table = SimpleNamespace(load=lambda: True)
    called = {}

    monkeypatch.setattr(hc, "get_memory_nodes_table", lambda settings: table)
    monkeypatch.setattr(hc, "get_settings", lambda: SimpleNamespace())
    monkeypatch.setattr(hc, "logger", SimpleNamespace(info=lambda *args, **kwargs: called.setdefault("info", True)))

    hc.run_graph_healthcheck()
    assert called.get("info")


def test_healthcheck_optionally_checks_graph_fact_vector_store(monkeypatch):
    """When enabled, healthcheck should exercise graph_fact vector store upload/search."""
    import app.graph_healthcheck as hc  # type: ignore[import-not-found]

    settings = SimpleNamespace(check_graph_vector=True)
    calls = {"upload": 0}

    class FakeOpenAI:
        def __init__(self, *args, **kwargs):
            self.files = SimpleNamespace(create=self._create_file)
            self.vector_stores = SimpleNamespace(files=SimpleNamespace(create_and_poll=self._upload))
            self._next_id = 0

        def _create_file(self, **kwargs):
            self._next_id += 1
            return SimpleNamespace(id=f"file-{self._next_id}")

        def _upload(self, **kwargs):
            calls["upload"] += 1
            return SimpleNamespace(status="completed")

    monkeypatch.setattr(hc, "get_settings", lambda: settings)
    monkeypatch.setattr(hc, "get_memory_nodes_table", lambda settings: SimpleNamespace(load=lambda: True))
    monkeypatch.setattr(hc, "OpenAI", FakeOpenAI)

    hc.run_graph_healthcheck()
    assert calls["upload"] == 1
