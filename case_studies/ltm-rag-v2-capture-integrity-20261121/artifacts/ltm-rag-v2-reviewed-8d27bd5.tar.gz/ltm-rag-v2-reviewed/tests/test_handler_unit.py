"""Unit-level specs for handle_pre/handle_post with mocked dependencies.

Target Phase 1 config: OpenAI vector store backend. `none` is dev/safe.
This file doubles as a local harness example for calling handlers in-memory.
"""

from unittest.mock import MagicMock

import pytest

from app import handler
from app.models import (
    BranchState,
    PostPhaseRequest,
    PrePhaseRequest,
    SemanticHit,
)


def _make_branch_state(root="root-1", session="session-1"):
    return BranchState(root_session_id=root, session_id=session, short_summary="summary")


def test_handle_pre_skips_semantic_when_backend_none(
    monkeypatch, settings_factory, fake_llm
):
    """Section 9.2: /pre should load state once and skip semantic search when backend=none."""
    state = _make_branch_state()
    from app.models import Event, utc_now

    state.recent_events = [
        Event(
            event_id="e1",
            root_session_id=state.root_session_id,
            session_id=state.session_id,
            sequence=0,
            role="user",
            created_at=utc_now(),
            content="hi",
        )
    ]
    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)

    search_mock = MagicMock(return_value=[SemanticHit(text="hit", score=1.0, metadata={})])
    monkeypatch.setattr(handler, "search_memory", search_mock)
    append_mock = MagicMock()
    save_mock = MagicMock()
    monkeypatch.setattr(handler, "append_events", append_mock)
    monkeypatch.setattr(handler, "save_branch_state", save_mock)
    monkeypatch.setattr(handler, "is_memory_dependent", lambda msg: True)

    handler._settings = settings_factory(semantic_backend="none")
    handler._llm_client = fake_llm

    req = PrePhaseRequest(root_session_id=state.root_session_id, session_id=state.session_id, user_message="hi")
    resp = handler.handle_pre(req)

    # Expected future behaviour: semantic search is bypassed when disabled.
    assert resp.semantic_hits == []
    assert resp.short_summary == state.short_summary
    assert resp.recent_events == state.recent_events
    load_mock.assert_called_once_with(
        handler._settings, state.root_session_id, state.session_id
    )
    search_mock.assert_not_called()
    append_mock.assert_not_called()
    save_mock.assert_not_called()


def test_handle_pre_invokes_semantic_when_backend_openai(
    monkeypatch, settings_factory, fake_llm
):
    """Section 9.2: /pre should load state once and issue one semantic search when backend=openai."""
    state = _make_branch_state()
    from app.models import Event, utc_now

    state.recent_events = [
        Event(
            event_id="e2",
            root_session_id=state.root_session_id,
            session_id=state.session_id,
            sequence=1,
            role="assistant",
            created_at=utc_now(),
            content="response",
        )
    ]
    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)

    hits = [SemanticHit(text="hit", score=0.9, metadata={"session_id": state.session_id})]
    search_mock = MagicMock(return_value=hits)
    monkeypatch.setattr(handler, "search_memory", search_mock)
    append_mock = MagicMock()
    save_mock = MagicMock()
    monkeypatch.setattr(handler, "append_events", append_mock)
    monkeypatch.setattr(handler, "save_branch_state", save_mock)
    monkeypatch.setattr(handler, "is_memory_dependent", lambda msg: True)

    handler._settings = settings_factory(semantic_backend="openai")
    handler._llm_client = fake_llm

    req = PrePhaseRequest(root_session_id=state.root_session_id, session_id=state.session_id, user_message="hello")
    resp = handler.handle_pre(req)

    assert resp.semantic_hits == hits
    assert resp.short_summary == state.short_summary
    assert resp.recent_events == state.recent_events
    search_mock.assert_called_once()
    args, kwargs = search_mock.call_args
    assert args[2] == req.user_message
    assert kwargs["root_session_id"] == state.root_session_id
    assert kwargs.get("session_id") in (None, state.session_id)
    load_mock.assert_called_once_with(
        handler._settings, state.root_session_id, state.session_id
    )
    append_mock.assert_not_called()
    save_mock.assert_not_called()


def test_handle_pre_default_scope_root_only(monkeypatch, settings_factory, fake_llm):
    state = _make_branch_state()
    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)
    search_mock = MagicMock(return_value=[])
    monkeypatch.setattr(handler, "search_memory", search_mock)
    monkeypatch.setattr(handler, "is_memory_dependent", lambda msg: True)

    handler._settings = settings_factory(
        semantic_backend="openai", semantic_search_scope="root"
    )
    handler._llm_client = fake_llm

    req = PrePhaseRequest(
        root_session_id=state.root_session_id, session_id=state.session_id, user_message="hi"
    )
    handler.handle_pre(req)

    _, kwargs = search_mock.call_args
    assert kwargs["root_session_id"] == state.root_session_id
    assert kwargs.get("session_id") is None


def test_handle_pre_session_scope_includes_session_id(monkeypatch, settings_factory, fake_llm):
    state = _make_branch_state()
    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)
    search_mock = MagicMock(return_value=[])
    monkeypatch.setattr(handler, "search_memory", search_mock)
    monkeypatch.setattr(handler, "is_memory_dependent", lambda msg: True)

    handler._settings = settings_factory(
        semantic_backend="openai", semantic_search_scope="session"
    )
    handler._llm_client = fake_llm

    req = PrePhaseRequest(
        root_session_id=state.root_session_id, session_id=state.session_id, user_message="hi"
    )
    handler.handle_pre(req)

    _, kwargs = search_mock.call_args
    assert kwargs["root_session_id"] == state.root_session_id
    assert kwargs.get("session_id") == state.session_id


def test_handle_post_openai_backend_avoids_local_embed_and_indexes_once(
    monkeypatch, settings_factory, fake_llm
):
    """OpenAI vector store embeds server-side; no local embed call."""
    state = _make_branch_state()
    monkeypatch.setattr(handler, "load_branch_state", MagicMock(return_value=state))
    monkeypatch.setattr(handler, "append_events", MagicMock())
    monkeypatch.setattr(handler, "update_branch_state_with_events", MagicMock())
    monkeypatch.setattr(handler, "save_branch_state", MagicMock())
    monkeypatch.setattr(handler, "semantic_marker_exists", MagicMock(return_value=False))
    monkeypatch.setattr(handler, "write_semantic_marker", MagicMock())

    index_memory = MagicMock()
    monkeypatch.setattr(handler, "index_memory", index_memory)

    handler._settings = settings_factory(semantic_backend="openai")
    handler._llm_client = fake_llm

    req = PostPhaseRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        user_message="user",
        assistant_message="We will standardise on Python 3.12 and STATE_TABLE=test",
    )
    resp = handler.handle_post(req)

    assert resp.ok is True
    # Expected future behaviour: OpenAI vector store should embed server-side.
    assert fake_llm.embed_called == 0
    assert index_memory.call_count == 2
    docs = [call_args[0][2] for call_args in index_memory.call_args_list]
    roles = [doc.role for doc in docs]
    assert roles == ["user", "assistant"]
    assert any(doc.text == req.user_message for doc in docs)
    assert any(doc.text == req.assistant_message for doc in docs)
    assert any(doc.session_id == state.session_id for doc in docs)


def test_handle_post_none_backend_skips_semantic_indexing(
    monkeypatch, settings_factory, fake_llm
):
    """Expected future behaviour: semantic indexing disabled when backend is none."""
    state = _make_branch_state()
    monkeypatch.setattr(handler, "load_branch_state", MagicMock(return_value=state))
    monkeypatch.setattr(handler, "append_events", MagicMock())
    monkeypatch.setattr(handler, "update_branch_state_with_events", MagicMock())
    monkeypatch.setattr(handler, "save_branch_state", MagicMock())

    index_memory = MagicMock()
    monkeypatch.setattr(handler, "index_memory", index_memory)

    handler._settings = settings_factory(semantic_backend="none")
    handler._llm_client = fake_llm

    req = PostPhaseRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        user_message="user",
        assistant_message="assistant",
    )
    resp = handler.handle_post(req)

    assert resp.ok is True
    # Expected future behaviour: semantic indexing is disabled.
    index_memory.assert_not_called()
    assert state.next_sequence == 2  # two events (user + assistant) were allocated


def test_handle_post_pipeline_calls_dependencies_openai(monkeypatch, settings_factory, fake_llm):
    state = BranchState(root_session_id="root-openai", session_id="sess-openai")

    load_mock = MagicMock(return_value=state)
    append_mock = MagicMock()
    update_mock = MagicMock()
    index_mock = MagicMock()
    save_mock = MagicMock()
    marker_exists = MagicMock(return_value=False)
    write_marker = MagicMock()

    monkeypatch.setattr(handler, "load_branch_state", load_mock)
    monkeypatch.setattr(handler, "append_events", append_mock)
    monkeypatch.setattr(handler, "update_branch_state_with_events", update_mock)
    monkeypatch.setattr(handler, "index_memory", index_mock)
    monkeypatch.setattr(handler, "save_branch_state", save_mock)
    monkeypatch.setattr(handler, "semantic_marker_exists", marker_exists)
    monkeypatch.setattr(handler, "write_semantic_marker", write_marker)

    handler._settings = settings_factory(semantic_backend="openai")
    handler._llm_client = fake_llm

    req = PostPhaseRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        user_message="user msg",
        assistant_message="We will standardise on Python 3.12",
    )

    resp = handler.handle_post(req)

    assert resp.ok is True
    append_mock.assert_called_once()
    settings_arg, root_arg, session_arg, events_arg = append_mock.call_args[0]
    assert settings_arg == handler._settings
    assert root_arg == state.root_session_id
    assert session_arg == state.session_id
    assert len(events_arg) == 2
    assert [e.sequence for e in events_arg] == [0, 1]
    assert [e.role for e in events_arg] == ["user", "assistant"]

    update_mock.assert_called_once()
    update_args = update_mock.call_args[0]
    assert update_args[0] is fake_llm
    assert update_args[1] is state
    assert update_args[2] is events_arg
    assert len(update_args[2]) == 2

    assert index_mock.call_count == 2
    user_doc = index_mock.call_args_list[0][0][2]
    assistant_doc = index_mock.call_args_list[1][0][2]
    assert user_doc.text == req.user_message
    assert user_doc.sequence == 0
    assert user_doc.root_session_id == state.root_session_id
    assert user_doc.session_id == state.session_id
    assert user_doc.id == events_arg[0].event_id

    assert assistant_doc.text == req.assistant_message
    assert assistant_doc.sequence == 1
    assert assistant_doc.root_session_id == state.root_session_id
    assert assistant_doc.session_id == state.session_id
    assert assistant_doc.id == events_arg[1].event_id

    save_mock.assert_called_once_with(handler._settings, state)
    assert state.next_sequence == 2


def test_handle_post_pipeline_calls_dependencies_none(monkeypatch, settings_factory, fake_llm):
    state = BranchState(root_session_id="root-none", session_id="sess-none")

    load_mock = MagicMock(return_value=state)
    append_mock = MagicMock()
    update_mock = MagicMock()
    index_mock = MagicMock()
    save_mock = MagicMock()

    monkeypatch.setattr(handler, "load_branch_state", load_mock)
    monkeypatch.setattr(handler, "append_events", append_mock)
    monkeypatch.setattr(handler, "update_branch_state_with_events", update_mock)
    monkeypatch.setattr(handler, "index_memory", index_mock)
    monkeypatch.setattr(handler, "save_branch_state", save_mock)

    handler._settings = settings_factory(semantic_backend="none")
    handler._llm_client = fake_llm

    req = PostPhaseRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        user_message="user msg",
        assistant_message="assistant msg",
    )

    resp = handler.handle_post(req)

    assert resp.ok is True
    append_mock.assert_called_once()
    settings_arg, root_arg, session_arg, events_arg = append_mock.call_args[0]
    assert settings_arg == handler._settings
    assert root_arg == state.root_session_id
    assert session_arg == state.session_id
    assert len(events_arg) == 2
    assert [e.sequence for e in events_arg] == [0, 1]
    assert [e.role for e in events_arg] == ["user", "assistant"]

    update_mock.assert_called_once()
    update_args = update_mock.call_args[0]
    assert update_args[0] is fake_llm
    assert update_args[1] is state
    assert update_args[2] is events_arg
    assert len(update_args[2]) == 2

    index_mock.assert_not_called()
    save_mock.assert_called_once_with(handler._settings, state)
    assert state.next_sequence == 2


def test_handle_pre_and_post_new_branch_sequences_and_calls(monkeypatch, settings_factory, fake_llm):
    state = BranchState(root_session_id="root-new", session_id="sess-new")

    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)

    append_mock = MagicMock()
    update_mock = MagicMock()
    save_mock = MagicMock()
    index_mock = MagicMock()
    monkeypatch.setattr(handler, "append_events", append_mock)
    monkeypatch.setattr(handler, "update_branch_state_with_events", update_mock)
    monkeypatch.setattr(handler, "save_branch_state", save_mock)
    monkeypatch.setattr(handler, "index_memory", index_mock)

    handler._settings = settings_factory(semantic_backend="none")
    handler._llm_client = fake_llm

    pre_req = PrePhaseRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        user_message="hi",
    )
    resp = handler.handle_pre(pre_req)
    assert resp.short_summary == state.short_summary
    assert resp.recent_events == state.recent_events
    assert state.next_sequence == 0

    post_req = PostPhaseRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        user_message="user msg",
        assistant_message="assistant msg",
    )
    post_resp = handler.handle_post(post_req)

    assert post_resp.ok is True
    assert state.next_sequence == 2

    append_mock.assert_called_once()
    append_args = append_mock.call_args[0]
    assert append_args[1] == state.root_session_id
    assert append_args[2] == state.session_id
    appended_events = append_args[3]
    assert len(appended_events) == 2
    assert [e.sequence for e in appended_events] == [0, 1]

    save_mock.assert_called_once_with(handler._settings, state)
    index_mock.assert_not_called()


def test_handle_post_is_non_idempotent_for_retries(monkeypatch, settings_factory, fake_llm):
    state = BranchState(root_session_id="root-retry", session_id="sess-retry")

    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)

    append_mock = MagicMock()
    update_mock = MagicMock()
    save_mock = MagicMock()
    index_mock = MagicMock()
    monkeypatch.setattr(handler, "append_events", append_mock)
    monkeypatch.setattr(handler, "update_branch_state_with_events", update_mock)
    monkeypatch.setattr(handler, "save_branch_state", save_mock)
    monkeypatch.setattr(handler, "index_memory", index_mock)

    handler._settings = settings_factory(semantic_backend="none")
    handler._llm_client = fake_llm

    post_req = PostPhaseRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        user_message="user msg",
        assistant_message="assistant msg",
    )

    handler.handle_post(post_req)
    handler.handle_post(post_req)

    assert state.next_sequence == 4  # two events per call, no deduplication
    assert append_mock.call_count == 2

    first_append_events = append_mock.call_args_list[0][0][3]
    second_append_events = append_mock.call_args_list[1][0][3]
    assert [e.sequence for e in first_append_events] == [0, 1]
    assert [e.sequence for e in second_append_events] == [2, 3]

    index_mock.assert_not_called()


def test_handle_post_sequences_monotonic_across_calls(monkeypatch, settings_factory, fake_llm):
    state = BranchState(root_session_id="root-seq", session_id="sess-seq")

    load_mock = MagicMock(return_value=state)
    monkeypatch.setattr(handler, "load_branch_state", load_mock)

    append_mock = MagicMock()
    update_mock = MagicMock()
    save_mock = MagicMock()
    index_mock = MagicMock()

    monkeypatch.setattr(handler, "append_events", append_mock)
    monkeypatch.setattr(handler, "update_branch_state_with_events", update_mock)
    monkeypatch.setattr(handler, "save_branch_state", save_mock)
    monkeypatch.setattr(handler, "index_memory", index_mock)

    handler._settings = settings_factory(semantic_backend="none")
    handler._llm_client = fake_llm

    req = PostPhaseRequest(
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        user_message="user msg",
        assistant_message="assistant msg",
    )

    handler.handle_post(req)
    handler.handle_post(req)
    handler.handle_post(req)

    all_sequences = []
    for call in append_mock.call_args_list:
        appended_events = call[0][3]
        all_sequences.extend([e.sequence for e in appended_events])

    assert all_sequences == [0, 1, 2, 3, 4, 5]
    assert state.next_sequence == 6
    index_mock.assert_not_called()
