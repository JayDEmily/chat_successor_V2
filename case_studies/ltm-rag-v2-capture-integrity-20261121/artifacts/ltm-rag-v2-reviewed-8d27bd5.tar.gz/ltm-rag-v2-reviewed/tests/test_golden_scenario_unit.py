from __future__ import annotations

from app.micro_agent.scenarios import get_scenario


def test_nvda_desk_v1_scenario_shape_and_anchors():
    scenario = get_scenario("nvda_desk_v1")
    assert len(scenario) == 20
    assert all(isinstance(turn.get("user"), str) and turn["user"].strip() for turn in scenario)

    corpus = "\n".join(turn["user"] for turn in scenario)
    required = [
        "PLAYBOOK_VERSION=NVDA_DESK_V1",
        "RISK_BUDGET_USD=7500",
        "REGIME_TAG=risk_off",
        "CATALYST=FOMC_2025_03",
        "RULE: if VWAP_reclaim then add",
        "LEVELS: buy=495.50 sell=510.25",
    ]
    for token in required:
        assert token in corpus

