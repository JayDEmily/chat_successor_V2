"""Live end-to-end RAG activation probe (semantic + optional graph).

Runs only when LIVE_RAG=1 is set. Requires LIVE_LAMBDA_URL/LIVE_FUNCTION_URL/
MEMORY_AGENT_URL to point at the deployed Function URL.
"""

from __future__ import annotations

import os
import uuid

import pytest

from scripts.turn_rag_probe import ProbeConfig, resolve_function_url, run_probe


pytestmark = [
    pytest.mark.skipif(
        os.getenv("LIVE_RAG") != "1",
        reason="Set LIVE_RAG=1 to hit the deployed Lambda",
    )
]


def test_rag_activation_live():
    function_url = resolve_function_url(None)
    root_session_id = f"rag-live-{uuid.uuid4().hex}"
    session_id = root_session_id
    require_graph = os.getenv("REQUIRE_GRAPH") == "1"

    result = run_probe(
        ProbeConfig(
            function_url=function_url,
            root_session_id=root_session_id,
            session_id=session_id,
            poll_seconds=60,
            poll_interval=5,
            require_graph=require_graph,
            policy="auto",
            timeout=90,
        )
    )

    assert result.semantic_ok is True
    assert all(result.semantic_matches.values())
    assert result.last_memory_telemetry is not None

    if require_graph:
        assert result.graph_ok is True
        assert all(result.graph_matches.values())
