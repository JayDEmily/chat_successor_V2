"""Logging expectations for graph pipeline stages."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest


class CaptureLogger:
    def __init__(self):
        self.records = []

    def info(self, msg, extra=None):
        self.records.append(("info", msg, extra or {}))

    def warning(self, msg, extra=None):
        self.records.append(("warning", msg, extra or {}))

    def error(self, msg, extra=None):
        self.records.append(("error", msg, extra or {}))


def test_extraction_and_consolidation_log_structured_events(monkeypatch):
    """Successful extraction + consolidation should emit stage/status markers; idempotent skip should be logged."""
    import app.graph_extraction_worker as extraction  # type: ignore[import-not-found]
    import app.graph_consolidation_worker as consolidation  # type: ignore[import-not-found]

    logger = CaptureLogger()

    # Extraction path
    monkeypatch.setattr(extraction, "logger", logger)
    monkeypatch.setattr(
        extraction,
        "build_context_window",
        lambda **kwargs: "context",
    )
    monkeypatch.setattr(
        extraction,
        "call_extraction_llm",
        lambda **kwargs: [{"entity": "python_version", "type": "config", "fact": "3.11", "source_event_ids": ["evt-1"]}],
    )
    extraction.handle_extraction_message(
        message={"root_session_id": "root", "session_id": "sess", "user_event_id": "evt-1", "assistant_event_id": "evt-2"},
        s3_client=None,
        branch_state=None,
        llm_client=None,
    )

    assert any(rec for rec in logger.records if rec[1] and "extraction" in rec[1])

    # Consolidation path
    logger.records.clear()
    monkeypatch.setattr(consolidation, "logger", logger)
    consolidation.handle_consolidation_message(
        message={
            "root_session_id": "root",
            "session_id": "sess",
            "sequence_start": 0,
            "sequence_end": 1,
            "candidates": [{"entity": "python_version", "type": "config", "fact": "3.11", "source_event_ids": ["evt-1"]}],
            "transcript_events": [{"event_id": "evt-1"}],
        },
        node_store=None,
        vector_store=None,
        logger=logger,
        now=datetime.now(timezone.utc),
    )
    assert any("stage" in rec[2] for rec in logger.records), "Expected structured stage/status logs"
