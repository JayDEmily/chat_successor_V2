from __future__ import annotations

import io
from types import SimpleNamespace
from unittest.mock import MagicMock

from app import semantic_memory


def test_index_memory_uses_single_named_file(monkeypatch, settings_factory, fake_llm):
    settings = settings_factory(
        semantic_backend="openai",
        semantic_chunk_size_tokens=800,
        semantic_chunk_overlap_tokens=0,
    )
    doc = semantic_memory.SemanticDoc(
        id="evt-1",
        root_session_id="root",
        session_id="sess",
        sequence=1,
        role="assistant",
        text="assistant payload",
        embedding=[],
        created_at="2025-01-01T00:00:00Z",
    )

    create_calls = []

    class FakeFiles:
        def create(self, file=None, purpose=None):
            create_calls.append((file, purpose))
            filename, file_obj = file
            # Capture the payload bytes for assertion.
            payload = file_obj.read()
            return SimpleNamespace(id="file-1", filename=filename, payload=payload)

    class FakeVectorStoreFiles:
        def create_and_poll(self, **kwargs):
            return MagicMock()

    client = SimpleNamespace(
        files=FakeFiles(),
        vector_stores=SimpleNamespace(files=FakeVectorStoreFiles()),
    )
    monkeypatch.setattr(semantic_memory, "OpenAI", lambda api_key=None: client)

    semantic_memory.index_memory(settings, fake_llm, doc)

    assert len(create_calls) == 1
    file_arg, purpose = create_calls[0]
    assert purpose == "assistants"
    assert isinstance(file_arg, tuple) and len(file_arg) == 2
    filename, file_obj = file_arg
    assert filename.endswith(".txt")
    assert isinstance(file_obj, io.BytesIO)
    assert file_obj.getvalue() == b"assistant payload"
