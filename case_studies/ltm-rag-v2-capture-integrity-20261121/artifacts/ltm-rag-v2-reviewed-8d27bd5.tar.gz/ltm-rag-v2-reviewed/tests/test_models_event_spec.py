"""Specs for Event serialization and validation."""

from datetime import datetime, timezone

import pytest

from app.models import Event


def test_event_to_dict_serialises_iso_timestamp_and_roundtrips_metadata():
    created = datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    event = Event(
        event_id="evt-1",
        root_session_id="root",
        session_id="sess",
        sequence=3,
        role="assistant",
        created_at=created,
        content="hello",
        metadata={"tool": "calc", "nested": {"a": 1}},
    )

    data = event.to_dict()
    assert isinstance(data["created_at"], str)
    assert data["created_at"] == created.isoformat()
    # metadata should be preserved verbatim
    assert data["metadata"] == event.metadata

    restored = Event.from_dict(data)
    assert restored.created_at == created
    assert restored.metadata == event.metadata
    assert restored.role == event.role
    assert restored.sequence == event.sequence


def test_event_rejects_invalid_role():
    with pytest.raises(ValueError):
        Event(
            event_id="bad-role",
            root_session_id="root",
            session_id="sess",
            sequence=0,
            role="invalid",  # type: ignore[arg-type]
            created_at=datetime.now(timezone.utc),
            content="oops",
        )

    with pytest.raises(ValueError):
        Event.from_dict(
            {
                "event_id": "bad-role",
                "root_session_id": "root",
                "session_id": "sess",
                "sequence": 0,
                "role": "bad",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "content": "oops",
            }
        )
