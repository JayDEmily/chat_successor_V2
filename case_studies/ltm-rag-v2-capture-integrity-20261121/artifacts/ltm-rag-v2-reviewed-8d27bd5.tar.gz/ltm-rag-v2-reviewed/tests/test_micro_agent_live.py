"""Live micro-agent harness test that exercises /turn plus GPT-5 nano.

Guarded by LIVE_AGENT=1 to avoid accidental live calls.
"""

from __future__ import annotations

import os
import uuid

import pytest

from app.micro_agent.env_loader import load_env
from app.micro_agent.micro_agent import MicroAgent
from app.micro_agent.scenarios import get_scenario
from app.micro_agent.turn_client import resolve_function_url


# Ensure OPENAI_API_KEY and any local overrides are loaded from the root .env.
load_env()

try:
    FUNCTION_URL = resolve_function_url()
except RuntimeError:
    FUNCTION_URL = None


pytestmark = [
    pytest.mark.smoke,
    pytest.mark.skipif(
        os.getenv("LIVE_AGENT") != "1",
        reason="Set LIVE_AGENT=1 to run the micro-agent live test",
    ),
    pytest.mark.skipif(
        not FUNCTION_URL,
        reason="LIVE_LAMBDA_URL/LIVE_FUNCTION_URL/MEMORY_AGENT_URL must be set to hit the deployed Lambda",
    ),
]


def _expected_model() -> str:
    """Return the expected model id for the micro agent."""
    return os.getenv("MICRO_AGENT_MODEL") or "gpt-5-nano"


def test_micro_agent_live_three_turns():
    """Run a short animals scenario through the micro agent harness."""
    root_session_id = f"micro-agent-{uuid.uuid4().hex}"
    session_id = root_session_id

    agent = MicroAgent(
        root_session_id=root_session_id,
        session_id=session_id,
        scenario_name="animals",
        function_url=FUNCTION_URL,
    )

    scenario = get_scenario("animals")
    assert len(scenario) >= 3

    expected_model = _expected_model()

    for index, turn in enumerate(scenario[:3], start=1):
        result = agent.step(turn["user"])

        # HTTP 200 each step.
        assert result.http_status == 200

        # /turn response contains bounded fields and telemetry.
        body = result.turn_response
        assert isinstance(body, dict)
        assert "recent_events" in body
        assert isinstance(body["recent_events"], list)
        assert "semantic_hits" in body
        assert isinstance(body["semantic_hits"], list)

        telemetry = body.get("memory_telemetry")
        assert isinstance(telemetry, dict)
        assert "semantic_search_ran" in telemetry
        assert "graph_read_ran" in telemetry

        # persisted_last_turn semantics: first call is a seed, later calls persist the last turn.
        if index == 1:
            assert body.get("persisted_last_turn") is False
        else:
            assert body.get("persisted_last_turn") is True

        # assistant_text is non-empty and under a hard character cap.
        assistant_text = result.assistant_text
        assert isinstance(assistant_text, str)
        trimmed = assistant_text.strip()
        assert trimmed != ""
        assert len(trimmed) <= 800

        # model_used proves GPT-5 nano was used.
        assert result.model_used == expected_model

