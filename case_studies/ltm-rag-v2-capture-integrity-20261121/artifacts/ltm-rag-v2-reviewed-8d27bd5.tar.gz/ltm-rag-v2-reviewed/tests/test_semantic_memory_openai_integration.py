"""Optional integration test against a real OpenAI vector store.

Guarded by OPENAI_INTEGRATION=1 to avoid accidental token usage.
Requires OPENAI_API_KEY and OPENAI_VECTOR_STORE_ID in the environment.
"""

import io
import os
import uuid
from datetime import datetime, timezone

import pytest
from openai import OpenAI


VECTOR_STORE_ID = os.getenv("OPENAI_VECTOR_STORE_ID")

pytestmark = [
    pytest.mark.release,
    pytest.mark.openai_integration,
    pytest.mark.skipif(
        os.getenv("OPENAI_INTEGRATION", "0") != "1" or not VECTOR_STORE_ID,
        reason="Set OPENAI_INTEGRATION=1, OPENAI_VECTOR_STORE_ID, and OPENAI_API_KEY to run OpenAI integration tests",
    ),
]


def test_openai_vector_store_round_trip():
    client = OpenAI()  # picks up OPENAI_API_KEY from env

    marker = f"integration-{uuid.uuid4()}"
    root_session_id = f"integration-root-{uuid.uuid4()}"
    session_id = f"integration-session-{uuid.uuid4()}"
    event_id = f"integration-event-{uuid.uuid4()}"
    created_at = datetime.now(timezone.utc).isoformat()

    text = f"assistant message {marker}"

    payload = text.encode("utf-8")
    # Per current OpenAI examples, use the files API with a text payload and the "assistants" purpose.
    # Provide a filename so OpenAI treats the payload as a supported text file.
    file_obj = client.files.create(
        file=("integration.txt", io.BytesIO(payload)), purpose="assistants"
    )

    try:
        vs_file = client.vector_stores.files.create_and_poll(
            vector_store_id=VECTOR_STORE_ID,
            file_id=file_obj.id,
            attributes={
                "marker": marker,
                "root_session_id": root_session_id,
                "session_id": session_id,
                "id": event_id,
                "event_id": event_id,
                "sequence": 1,
                "role": "assistant",
                "kind": "assistant_turn",
                "created_at": created_at,
            },
        )
        assert vs_file.status == "completed"

        filters = {
            "type": "and",
            "filters": [
                {"type": "eq", "key": "root_session_id", "value": root_session_id},
                {"type": "eq", "key": "session_id", "value": session_id},
            ],
        }
        resp = client.vector_stores.search(
            vector_store_id=VECTOR_STORE_ID,
            query=text,
            filters=filters,
            max_num_results=3,
        )
        assert resp.data, "Expected at least one search hit"
        texts = [
            chunk.text for hit in resp.data for chunk in hit.content if chunk.type == "text"
        ]
        assert any(marker in t for t in texts)
        meta = resp.data[0].attributes or {}
        assert meta.get("root_session_id") == root_session_id
        assert meta.get("session_id") == session_id
    finally:
        client.vector_stores.files.delete(
            vector_store_id=VECTOR_STORE_ID, file_id=file_obj.id
        )
        client.files.delete(file_obj.id)
