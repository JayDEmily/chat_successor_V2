from __future__ import annotations

import sys

import pytest


def test_env_python_has_openai() -> None:
    try:
        import openai  # noqa: F401
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"Failed to import openai under sys.executable={sys.executable!r}: {exc!r}")
