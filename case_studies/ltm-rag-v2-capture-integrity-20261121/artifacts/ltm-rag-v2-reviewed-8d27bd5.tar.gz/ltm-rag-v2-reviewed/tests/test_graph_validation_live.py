"""Live graph validation: enqueue, materialise facts, supersede, and provenance."""

from __future__ import annotations

import json
import os
import time
import uuid

import pytest

from app.micro_agent import MicroAgent
from app.micro_agent.env_loader import load_env
from app.micro_agent.turn_client import TurnClientError, post_turn, resolve_function_url


load_env()

pytestmark = [
    pytest.mark.skipif(
        os.getenv("LIVE_GRAPH") != "1",
        reason="Set LIVE_GRAPH=1 to run live graph validation",
    )
]


def _json_dump(data: dict) -> str:
    return json.dumps(data, indent=2, sort_keys=True, default=str)


def _wait_for_graph_fact(
    function_url: str,
    root_session_id: str,
    session_id: str,
    version: str,
    *,
    timeout_s: int = 60,
    interval_s: int = 3,
) -> tuple[list[dict], dict]:
    deadline = time.time() + timeout_s
    last_snapshot: dict | None = None
    while True:
        snapshot = post_turn(
            function_url,
            {
                "root_session_id": root_session_id,
                "session_id": session_id,
                "last_user_message": None,
                "last_assistant_message": None,
                "current_user_message": "graph check: python version?",
            },
            timeout=90,
        )
        body = snapshot.get("body") or {}
        last_snapshot = body
        telemetry = body.get("memory_telemetry") or {}
        assert telemetry.get("graph_read_ran") is True, _json_dump(body)

        facts = body.get("graph_memory_facts") or []
        history = body.get("graph_memory_history") or {}
        for fact in facts:
            if (
                isinstance(fact, dict)
                and fact.get("entity") == "python_version"
                and version in str(fact.get("fact", ""))
            ):
                return facts, history

        if time.time() >= deadline:
            raise AssertionError(f"Graph fact for version {version} not found: {_json_dump(last_snapshot)}")
        time.sleep(interval_s)


def test_graph_supersession_and_provenance_live():
    try:
        function_url = resolve_function_url()
    except TurnClientError as exc:
        pytest.skip(str(exc))

    root_session_id = f"graph-{uuid.uuid4().hex}"
    session_id = root_session_id
    agent = MicroAgent(root_session_id, session_id, function_url=function_url)

    v1 = f"3.12.{uuid.uuid4().hex[:2]}"
    v2 = f"3.12.{uuid.uuid4().hex[2:4]}"

    seed_v1 = (
        f"Graph fact: entity=python_version type=config fact=python_version={v1}. "
        "Reply with 'ACK' only and do not repeat the version string."
    )
    r1 = agent.step(seed_v1)
    assert r1.http_status == 200
    assert v1 not in r1.assistant_text

    r2 = agent.step("next")
    body2 = r2.turn_response
    assert r2.http_status == 200
    assert body2.get("persisted_last_turn") is True
    t2 = body2.get("memory_telemetry")
    assert isinstance(t2, dict)
    assert t2.get("graph_enqueue_ran") is True
    assert t2.get("graph_read_ran") is True

    events2 = body2.get("recent_events") or []
    user_events_v1 = [
        evt
        for evt in events2
        if isinstance(evt, dict) and evt.get("role") == "user" and v1 in str(evt.get("content", ""))
    ]
    assert user_events_v1
    user_event_id_v1 = user_events_v1[0].get("event_id")
    assert user_event_id_v1

    facts1, history1 = _wait_for_graph_fact(function_url, root_session_id, session_id, v1)
    assert isinstance(facts1, list)
    assert isinstance(history1, dict)
    assert all(not str(k).startswith("_marker") for k in history1.keys())
    python_history = history1.get("python_version")
    assert isinstance(python_history, list)

    active_fact_v1 = [
        f
        for f in facts1
        if isinstance(f, dict)
        and f.get("entity") == "python_version"
        and v1 in str(f.get("fact", ""))
    ]
    assert active_fact_v1
    assert user_event_id_v1 in active_fact_v1[0].get("source_event_ids", [])

    history_entry_v1 = [
        h
        for h in python_history
        if isinstance(h, dict) and v1 in str(h.get("fact", "")) and h.get("state") in {"active", "reopened"}
    ]
    assert history_entry_v1
    assert user_event_id_v1 in history_entry_v1[0].get("source_event_ids", [])

    seed_v2 = (
        f"Graph fact update: entity=python_version type=config fact=python_version={v2}. "
        "Reply with 'ACK' only and do not repeat the version string."
    )
    r3 = agent.step(seed_v2)
    assert r3.http_status == 200
    assert v2 not in r3.assistant_text

    r4 = agent.step("next")
    body4 = r4.turn_response
    assert r4.http_status == 200
    assert body4.get("persisted_last_turn") is True
    t4 = body4.get("memory_telemetry")
    assert isinstance(t4, dict)
    assert t4.get("graph_enqueue_ran") is True

    events4 = body4.get("recent_events") or []
    user_events_v2 = [
        evt
        for evt in events4
        if isinstance(evt, dict) and evt.get("role") == "user" and v2 in str(evt.get("content", ""))
    ]
    assert user_events_v2
    user_event_id_v2 = user_events_v2[0].get("event_id")
    assert user_event_id_v2

    facts2, history2 = _wait_for_graph_fact(function_url, root_session_id, session_id, v2)
    assert isinstance(facts2, list)
    assert isinstance(history2, dict)
    assert all(not str(k).startswith("_marker") for k in history2.keys())
    python_history2 = history2.get("python_version")
    assert isinstance(python_history2, list)

    active_v2 = [
        f
        for f in facts2
        if isinstance(f, dict)
        and f.get("entity") == "python_version"
        and v2 in str(f.get("fact", ""))
        and f.get("state") in {"active", "reopened", None}
    ]
    assert active_v2
    assert user_event_id_v2 in active_v2[0].get("source_event_ids", [])

    hist_v1 = [
        h
        for h in python_history2
        if isinstance(h, dict) and v1 in str(h.get("fact", "")) and h.get("state") == "superseded"
    ]
    assert hist_v1
    assert hist_v1[0].get("superseded_by")

    hist_v2 = [
        h
        for h in python_history2
        if isinstance(h, dict)
        and v2 in str(h.get("fact", ""))
        and h.get("state") in {"active", "reopened"}
    ]
    assert hist_v2
    assert hist_v2[0].get("supersedes")
    assert user_event_id_v2 in hist_v2[0].get("source_event_ids", [])
