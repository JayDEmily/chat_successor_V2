# Tests Overview

Layered regime (markers in `pytest.ini`):

- **Fast (default)** — mocked/isolated tests only. `make test` or `.venv/bin/python -m pytest -m "not local_real and not smoke and not release"` runs everything except live IO.
- **Layer 1 – local-but-real** — in-process `/pre` + `/post` hitting real S3/Dynamo/OpenAI. Set `LIVE_AWS=1` and run `make test-local-real` (or `.venv/bin/python -m pytest -m local_real`). Uses unique branch IDs and cleans up the transcript object and Dynamo item it creates.
- **Layer 2 – deployed-Lambda smoke** — minimal wiring checks against the Function URL. Set `LIVE_SMOKE=1` and `LIVE_LAMBDA_URL=<https://...lambda-url...>` then run `make test-smoke` (or `.venv/bin/python -m pytest -m smoke`). Verifies `/pre` and `/post` succeed in the deployed stack.
- **Layer 3 – release exam** — live-dependency checks run on demand: `make test-release` (or `.venv/bin/python -m pytest -m release`). Currently includes the Lambda smoke test plus the OpenAI vector store round-trip (requires `OPENAI_INTEGRATION=1` and `OPENAI_VECTOR_STORE_ID`).

Environment posture: Python 3.12 with deps from `pyproject.toml` inside `.venv`. Load settings from a `.env` file or runner config before invoking pytest. Canonical region is `ap-southeast-2`. If you're unsure which interpreter will run, use `./scripts/venv_python.sh -m pytest ...`.

## Fast suite (default)

- Handler contract via in-memory calls (`tests/test_handler_unit.py`, `tests/test_lambda_handler_e2e.py`, `tests/test_lambda_handler_additional.py`); AWS/OpenAI are mocked.
- Composite turn path coverage (`tests/test_handler_turn_unit.py`, `tests/test_turn_integration.py`) ensures `/turn` composes `/post` + `/pre` semantics.
- Graph pipeline hooks and SQS payload shape are stubbed (`tests/test_graph_pipeline_integration.py`), graph enrichment contract is mocked (`tests/test_graph_pre_integration.py`), and graph healthcheck/vector-store probing is covered (`tests/test_graph_healthcheck.py`).
- Logging/config/healthcheck/spec coverage (`tests/test_logging_spec.py`, `tests/test_healthcheck_mode.py`, `tests/test_config_spec.py`, etc.).
- Semantic memory backends use stubbed OpenAI clients (`tests/test_semantic_memory_backends_spec.py`); no live calls.
- MCP surface mirrors `/pre` and `/post` (`tests/test_mcp_server_spec.py`).
- Data model invariants enforced: Events serialize `created_at` as ISO-8601 strings and stay immutable; BranchState persists PK/SK and recent_events order with defaults (`next_sequence=len(recent_events)` when absent, `summary_turns_since_update=0`); SemanticHit metadata surfaces identifiers/timestamps attached at indexing.

## Layer 1 – local-but-real integration

- Test: `tests/test_local_real_integration.py` (`@pytest.mark.local_real`).
- Gate: `LIVE_AWS=1` plus real env vars for `AWS_REGION`, `TRANSCRIPT_BUCKET`, `STATE_TABLE`, `OPENAI_API_KEY`, `SUMMARY_MODEL_NAME`, `EMBEDDING_MODEL_NAME`, and `SEMANTIC_BACKEND` (`OPENAI_VECTOR_STORE_ID` when backend is `openai`).
- Behaviour: runs `handle_post` + `handle_pre` in-process, writes to the real S3 transcript and Dynamo branch state, exercises OpenAI if configured. Cleans up the transcript object and Dynamo item after assertions.

## Layer 2 – deployed-Lambda smoke

- Test: `tests/test_lambda_smoke_live.py` (`@pytest.mark.smoke` + `@pytest.mark.release`).
- Gate: `LIVE_SMOKE=1` and `LIVE_LAMBDA_URL` (or `LIVE_FUNCTION_URL`) pointing at the deployed Function URL.
- Behaviour: POSTs `/pre` and `/post` over HTTPS and expects 200 + `{ok: true}`. This is wiring/env validation only; logic is covered in the fast suite.

## Golden set runner (NVDA desk)

- Runner: `scripts/run_golden_conversation.py` (live `/turn` + OpenAI Responses API) writes deterministic artefacts under `golden_sets/`.
- Scenario: `app/micro_agent/scenarios.py` → `nvda_desk_v1` (20 turns, fictional numbers, anchor tokens for quote-grade eval).
- Generate artefacts: `.venv/bin/python scripts/run_golden_conversation.py` (defaults to `golden_sets/golden_nvda_desk_v1.jsonl` + `.manifest.json`).
- Live runner test: `LIVE_AGENT=1 .venv/bin/python -m pytest -q tests/test_golden_conversation_live.py` (runs first 5 turns to a temp dir).

## Golden set v2 (two-agent dialogue)

- Runner: `scripts/run_golden_dialogue.py` (live `/turn` + two Responses calls per exchange) writes artefacts under `golden_sets_v2/`.
- Gate: `LIVE_AGENT=1` (runner and tests) plus `OPENAI_API_KEY` and a configured Function URL (env or discovery).
- Generate v2 artefacts: `LIVE_AGENT=1 .venv/bin/python scripts/run_golden_dialogue.py` (writes `golden_sets_v2/golden_nvda_desk_v2.*`).
- Live test subset: `LIVE_AGENT=1 .venv/bin/python -m pytest -q tests/test_golden_dialogue_live.py` (runs 5 exchanges to `tmp_path`).

## Layer 3 – release exam

- Tests: Lambda smoke (above) and OpenAI vector store round-trip (`tests/test_semantic_memory_openai_integration.py`, marked `release` + `openai_integration`).
- Gate: `LIVE_SMOKE=1`, `LIVE_LAMBDA_URL`, and for OpenAI also `OPENAI_INTEGRATION=1`, `OPENAI_VECTOR_STORE_ID`, `OPENAI_API_KEY`, model env vars, and `SEMANTIC_BACKEND=openai`.
- Behaviour: round-trips a small assistant-like document through the configured OpenAI vector store, asserting attributes are preserved; cleans up created files. Use this only when you accept real token spend and live Lambda calls.

## Coverage focus

- Storage:
  - S3 JSONL transcripts under `sessions/{root}/{session}.log.jsonl`, append-only via read–modify–write with a single-writer assumption.
  - DynamoDB BranchState keyed by `(PK=root_session_id, SK=session_id)`.
  - DynamoDB `memory_nodes` table for graph facts when graph is enabled (`PK=root_session_id`, `SK=entity#type#node_id`), plus optional vector index for `graph_fact` entries.
  - OpenAI vector store attributes and backend gating (`openai` vs `none`); OpenSearch is out of scope.
- Pipelines:
  - `/pre` is read-only: loads BranchState and conditionally calls semantic search; when graph is enabled it also fetches graph facts/history from DynamoDB with a vector fallback; it never appends transcripts or saves state.
  - `/post` is the non-idempotent write path: allocates sequences, appends transcripts, updates BranchState, conditionally indexes semantic memory, and (when graph is enabled) enqueues the graph extraction/consolidation job.
  - `/turn` is the agent-friendly composite: optional `/post` of the previous turn plus `/pre` for the current user message, with a `persisted_last_turn` flag in the response.
  - Error posture: handler exceptions bubble to HTTP 500; tests do not model rollback across services.
