"""Specs for LLMClient OpenAI wrapper behaviour (no real API calls)."""

from types import SimpleNamespace

from app.llm_client import LLMClient


class _FakeEmbeddings:
    def __init__(self):
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(data=[SimpleNamespace(embedding=[0.1, 0.2])])


class _FakeCompletions:
    def __init__(self):
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content="summary"))]
        )


class _FakeChat:
    def __init__(self):
        self.completions = _FakeCompletions()


class _FakeOpenAI:
    def __init__(self):
        self.embeddings = _FakeEmbeddings()
        self.chat = _FakeChat()


def test_embed_uses_configured_embedding_model(monkeypatch):
    fake_client = _FakeOpenAI()
    monkeypatch.setattr("app.llm_client.OpenAI", lambda api_key=None: fake_client)

    settings = SimpleNamespace(
        openai_api_key="sk-test",
        embedding_model="text-embedding-3-large",
        embedding_dim=2,
        summary_model="gpt-5.1",
    )
    llm = LLMClient(settings)

    vec = llm.embed("text to embed")

    assert vec == [0.1, 0.2]
    assert fake_client.embeddings.calls[0]["model"] == settings.embedding_model
    assert fake_client.embeddings.calls[0]["input"] == "text to embed"


def test_summarise_uses_configured_summary_model(monkeypatch):
    fake_client = _FakeOpenAI()
    monkeypatch.setattr("app.llm_client.OpenAI", lambda api_key=None: fake_client)

    settings = SimpleNamespace(
        openai_api_key="sk-test",
        embedding_model="text-embedding-3-large",
        embedding_dim=2,
        summary_model="gpt-5.1",
    )
    llm = LLMClient(settings)

    summary = llm.summarise("history text")

    call = fake_client.chat.completions.calls[0]
    assert call["model"] == settings.summary_model
    assert any(msg.get("content") == "history text" for msg in call["messages"])
    assert summary == "summary"


def test_extract_memories_parses_json_array(monkeypatch):
    class _FakeCompletionsExtract:
        def __init__(self):
            self.calls = []

        def create(self, **kwargs):
            self.calls.append(kwargs)
            payload = '[{"entity": "python_version", "type": "config", "fact": "3.11", "confidence": 0.9, "source_event_ids": ["evt-1"]}]'
            return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content=payload))])

    class _FakeChatExtract:
        def __init__(self):
            self.completions = _FakeCompletionsExtract()

    class _FakeOpenAIExtract:
        def __init__(self):
            self.embeddings = _FakeEmbeddings()
            self.chat = _FakeChatExtract()

    fake_client = _FakeOpenAIExtract()
    monkeypatch.setattr("app.llm_client.OpenAI", lambda api_key=None: fake_client)

    settings = SimpleNamespace(
        openai_api_key="sk-test",
        embedding_model="text-embedding-3-large",
        embedding_dim=2,
        summary_model="gpt-5.1",
    )
    llm = LLMClient(settings)

    results = llm.extract_memories("context window")

    assert results and results[0]["entity"] == "python_version"
    call = fake_client.chat.completions.calls[0]
    assert call["model"] == settings.summary_model
