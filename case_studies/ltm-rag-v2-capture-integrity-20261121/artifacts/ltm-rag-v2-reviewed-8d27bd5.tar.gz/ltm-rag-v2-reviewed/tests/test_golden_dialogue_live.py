"""Live Golden Set v2 dialogue test (deployed /turn + two Responses calls per exchange).

Guarded by LIVE_AGENT=1 to avoid accidental live calls.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

from app.micro_agent.env_loader import load_env
from app.micro_agent.turn_client import resolve_function_url


load_env()

try:
    FUNCTION_URL = resolve_function_url()
except RuntimeError:
    FUNCTION_URL = None


pytestmark = [
    pytest.mark.smoke,
    pytest.mark.skipif(
        os.getenv("LIVE_AGENT") != "1",
        reason="Set LIVE_AGENT=1 to run the golden dialogue live test",
    ),
    pytest.mark.skipif(
        not FUNCTION_URL,
        reason="LIVE_LAMBDA_URL/LIVE_FUNCTION_URL/MEMORY_AGENT_URL must be set to hit the deployed Lambda",
    ),
    pytest.mark.skipif(
        not os.getenv("OPENAI_API_KEY"),
        reason="OPENAI_API_KEY must be set to run the golden dialogue live test",
    ),
]


def _read_jsonl(path: Path) -> list[dict]:
    rows: list[dict] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        if not raw.strip():
            continue
        rows.append(json.loads(raw))
    return rows


def test_golden_dialogue_live_subset(tmp_path: Path):
    out_dir = tmp_path / "golden_sets_v2"
    base = "golden_nvda_desk_v2"

    cmd = [
        sys.executable,
        "scripts/run_golden_dialogue.py",
        "--exchanges",
        "5",
        "--output-dir",
        str(out_dir),
        "--output-base",
        base,
        "--attempts",
        "1",
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    assert proc.returncode == 0, proc.stderr

    jsonl_path = out_dir / f"{base}.jsonl"
    manifest_path = out_dir / f"{base}.manifest.json"
    dialogue_path = out_dir / f"{base}.dialogue.md"
    metrics_path = out_dir / f"{base}.metrics.json"

    assert jsonl_path.exists()
    assert manifest_path.exists()
    assert dialogue_path.exists()
    assert metrics_path.exists()

    rows = _read_jsonl(jsonl_path)
    assert len(rows) == 5

    substantive = 0
    any_retrieval_signal = False
    for row in rows:
        assert row["http_status"] == 200
        desk = str(row.get("desk_agent_text") or "").strip()
        assert desk
        assert desk.upper() != "ACK"
        if len(desk) > 200:
            substantive += 1

        telemetry = row.get("memory_telemetry") or {}
        if isinstance(telemetry, dict):
            if telemetry.get("semantic_search_ran") is True:
                any_retrieval_signal = True
            if telemetry.get("graph_read_ran") is True:
                any_retrieval_signal = True
        if int(row.get("rehydrated_windows_count") or 0) > 0:
            any_retrieval_signal = True

    assert substantive >= 3
    assert any_retrieval_signal

    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    assert metrics["ack_count"] == 0
    assert metrics["empty_output_count"] == 0

