"""Integration tests for /pre enrichment with graph memory."""

from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace

import pytest


def _state(short_summary=None, recent_events=None):
    from app.models import BranchState

    return BranchState(
        root_session_id="root",
        session_id="sess",
        short_summary=short_summary,
        recent_events=recent_events or [],
    )


def _patch_basics(monkeypatch, graph_enabled=True):
    from app import handler

    settings = SimpleNamespace(
        semantic_backend="none",
        graph_memory_enabled=graph_enabled,
        graph_enabled=graph_enabled,
        response_budget_bytes=200000,
    )
    monkeypatch.setattr(handler, "_get_settings", lambda: settings)
    monkeypatch.setattr(handler, "_get_llm", lambda: SimpleNamespace())
    monkeypatch.setattr(handler, "search_memory", lambda *args, **kwargs: [])
    monkeypatch.setattr(handler, "update_request_context", lambda *args, **kwargs: None)


def test_pre_enriches_with_graph_memory_fields_when_enabled(monkeypatch):
    """When enabled, handle_pre should add graph_memory_facts/history derived from nodes."""
    from app import handler
    from app.models import PrePhaseRequest

    graph_facts = [
        {
            "entity": "python_version",
            "type": "config",
            "fact": "3.11.9",
            "state": "active",
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "source_event_ids": ["evt-1"],
        }
    ]
    graph_history = {"python_version": [{"fact": "3.10", "state": "superseded"}]}

    _patch_basics(monkeypatch, graph_enabled=True)
    monkeypatch.setattr(handler, "load_branch_state", lambda *_: _state(short_summary="s"))
    monkeypatch.setattr(
        handler,
        "load_graph_memory",
        lambda settings, root_session_id, session_id, entity_hint=None: (graph_facts, graph_history),
    )

    req = PrePhaseRequest(root_session_id="root", session_id="sess", user_message="hi")
    resp = handler.handle_pre(req)
    assert resp.short_summary == "s"
    assert hasattr(resp, "graph_memory_facts")
    assert resp.graph_memory_facts == graph_facts
    assert resp.graph_memory_history == graph_history


def test_pre_omits_graph_fields_when_disabled_or_empty(monkeypatch):
    """With feature disabled or no data, response matches V2 shape."""
    from app import handler
    from app.models import PrePhaseRequest

    _patch_basics(monkeypatch, graph_enabled=False)
    monkeypatch.setattr(handler, "load_branch_state", lambda *_: _state(short_summary=None))
    monkeypatch.setattr(handler, "load_graph_memory", lambda *args, **kwargs: ([], {}))

    req = PrePhaseRequest(root_session_id="root", session_id="sess", user_message="hi")
    resp = handler.handle_pre(req)
    assert resp.short_summary is None
    assert not hasattr(resp, "graph_memory_facts") or resp.graph_memory_facts in (None, [])


def test_pre_graph_facts_consistent_with_active_nodes(monkeypatch):
    """Returned facts should mirror active nodes (one per entity/type)."""
    from app import handler
    from app.models import PrePhaseRequest

    facts = [
        {"entity": "python_version", "type": "config", "fact": "3.11", "state": "active"},
        {"entity": "ruff_version", "type": "tool", "fact": "0.5.0", "state": "active"},
    ]
    history = {"python_version": [{"fact": "3.10", "state": "superseded"}]}

    _patch_basics(monkeypatch, graph_enabled=True)
    monkeypatch.setattr(handler, "load_branch_state", lambda *_: _state(short_summary="s"))
    monkeypatch.setattr(handler, "load_graph_memory", lambda *args, **kwargs: (facts, history))

    req = PrePhaseRequest(root_session_id="root", session_id="sess", user_message="hi")
    resp = handler.handle_pre(req)
    assert resp.graph_memory_facts
    active_entities = {(f["entity"], f["type"]) for f in resp.graph_memory_facts}
    assert active_entities == {("python_version", "config"), ("ruff_version", "tool")}


def test_pre_semantic_fallback_for_graph_facts_optional(monkeypatch):
    """Vector search for graph facts should only run when no entity hint is available."""
    from app import handler
    from app.models import PrePhaseRequest

    _patch_basics(monkeypatch, graph_enabled=True)
    monkeypatch.setattr(handler, "load_branch_state", lambda *_: _state())

    calls = {"dynamo": 0, "vector": 0}

    def fake_load_graph_memory(settings, root_session_id, session_id, entity_hint=None):
        calls["dynamo"] += 1
        if entity_hint:
            return ([{"entity": entity_hint, "type": "config", "fact": "x", "state": "active"}], {})
        return ([], {})

    def fake_search_graph_vector(*args, **kwargs):
        calls["vector"] += 1
        return [{"entity": "python_version", "type": "config", "fact": "3.11", "state": "active"}], {}

    monkeypatch.setattr(handler, "load_graph_memory", fake_load_graph_memory)
    monkeypatch.setattr(handler, "search_graph_memory_vector", fake_search_graph_vector)

    # with entity hint
    req = PrePhaseRequest(root_session_id="root", session_id="sess", user_message="python version?")
    resp = handler.handle_pre(req)
    assert calls["dynamo"] == 1
    assert calls["vector"] == 0
    assert resp.graph_memory_facts

    # no hint -> vector search
    calls = {"dynamo": 0, "vector": 0}
    req2 = PrePhaseRequest(root_session_id="root", session_id="sess", user_message="help?")
    resp2 = handler.handle_pre(req2)
    assert calls["vector"] == 1
    assert resp2.graph_memory_facts


def test_pre_uses_dynamo_only_when_entity_hint_present(monkeypatch):
    """With a clear entity hint, handle_pre should fetch from Dynamo and avoid graph_fact vector search."""
    from app import handler
    from app.models import PrePhaseRequest

    _patch_basics(monkeypatch, graph_enabled=True)
    monkeypatch.setattr(handler, "load_branch_state", lambda *_: _state())

    calls = {"dynamo": 0, "vector": 0}

    def fake_load_graph_memory(settings, root_session_id, session_id, entity_hint=None):
        calls["dynamo"] += 1
        return ([{"entity": entity_hint or "python_version", "type": "config", "fact": "3.11", "state": "active"}], {})

    def fake_vector(*args, **kwargs):
        calls["vector"] += 1
        return ([], {})

    monkeypatch.setattr(handler, "load_graph_memory", fake_load_graph_memory)
    monkeypatch.setattr(handler, "search_graph_memory_vector", fake_vector)

    req = PrePhaseRequest(root_session_id="root", session_id="sess", user_message="python version?")
    handler.handle_pre(req)
    assert calls["dynamo"] == 1
    assert calls["vector"] == 0


def test_pre_graph_memory_history_orders_by_updated_at_and_includes_states(monkeypatch):
    """History entries should be ordered chronologically and include state (and reason if present)."""
    from app import handler
    from app.models import PrePhaseRequest

    _patch_basics(monkeypatch, graph_enabled=True)
    monkeypatch.setattr(handler, "load_branch_state", lambda *_: _state())

    history = {
        "python_version": [
            {"fact": "3.10", "state": "superseded", "updated_at": "2024-01-01T00:00:00Z"},
            {"fact": "3.11", "state": "active", "updated_at": "2024-02-01T00:00:00Z"},
        ]
    }
    monkeypatch.setattr(
        handler,
        "load_graph_memory",
        lambda *args, **kwargs: (
            [{"entity": "python_version", "type": "config", "fact": "3.11", "state": "active"}],
            history,
        ),
    )

    req = PrePhaseRequest(root_session_id="root", session_id="sess", user_message="hi")
    resp = handler.handle_pre(req)
    assert resp.graph_memory_history
    hist = resp.graph_memory_history["python_version"]
    assert [h["fact"] for h in hist] == ["3.10", "3.11"]
    assert all("state" in h for h in hist)
