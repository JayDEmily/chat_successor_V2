# memory-agent — Canonical Implementation Plan v1.0

This repo implements **one thing**:

> A personal long-term semantic memory backend for a single human, powered by OpenAI vector store, exposed via `/pre` and `/post` for Custom GPT Actions.


---

## 1. Scope & Goals

### 1.1 Scope

- Single-user, single-tenant.
- Phase 1 only: personal long-term semantic memory.
- No pattern mining, clustering, cross-topic analytics. Those ideas are explicitly **out of scope**.

### 1.2 Primary Goal

Make `memory-agent` a **personal, long-term semantic memory**:

- Store every conversational turn as raw text + metadata with stable IDs.
- Provide high-quality semantic recall over large histories using **OpenAI vector store**.
- Integrate cleanly with a Custom GPT via:
  - `POST /pre` → context for the next reply.
  - `POST /post` → record what was said.

### 1.3 Constraints & Non-Goals

- Python **3.12**.
- Packaging via `pyproject.toml` (PEP 621). 
- No UI, dashboards, or visualisations.
- No multi-tenant logic.
- No automated AWS provisioning (Terraform/CDK/CloudFormation may be generated but not executed here).

---

## 2. Architecture

### 2.1 Storage Layers

- **S3 (Transcripts)**  
  - Bucket: `TRANSCRIPT_BUCKET`.  
  - Key: `sessions/{root_session_id}/{session_id}.log.jsonl`.  
  - Each line: one `Event` as JSON.  
  - Implemented as whole-object updates under a **single-writer** assumption per `(root_session_id, session_id)`.

- **DynamoDB (Branch State)**  
  - Table: `STATE_TABLE`.  
  - Keys:  
    - `PK = root_session_id`  
    - `SK = session_id`  
  - Attributes:  
    - `short_summary: str | None`  
    - `recent_events: List[EventLike]`  
    - `next_sequence: int`  
    - `summary_turns_since_update: int`

- **OpenAI Vector Store (Semantic Memory)**  
  - Enabled when `SEMANTIC_BACKEND=openai`.  
  - Stores per-event (or batched) text as files with attributes:
    - `root_session_id`, `session_id`, `sequence`, `role`, `kind`, `created_at`, `id`.  
  - Vectorisation is handled server-side by OpenAI.  
  - Semantic search = vector store search filtered by `root_session_id` (topic-level).  
  - Branches under the same `root_session_id` **share semantic memory**.

### 2.2 LLM Layer

- `app/llm_client.py`:
  - `embed(text: str) -> list[float]` (used where needed).
  - `summarise(history_text: str) -> str` (for short summaries).
- OpenAI is the only LLM provider in scope.

### 2.3 Entrypoints

- `app/handler.py`:
  - `handle_pre(PrePhaseRequest) -> PrePhaseResponse`
  - `handle_post(PostPhaseRequest) -> PostPhaseResponse`

- `lambda_handler.py`:
  - `lambda_handler(event, context)`:
    - Routes `/pre` and `/post` HTTP requests to the handlers.
    - Returns JSON responses with the expected shape and status codes.

- `app/mcp_server.py`:
  - Wraps `handle_pre` / `handle_post` as MCP tools.

---

## 3. Data & Identity Model

### 3.1 Event

`Event` (in `models.py`):

- `event_id: str`
- `root_session_id: str`
- `session_id: str`       # branch
- `sequence: int`
- `role: Literal["user","assistant","system","tool"]`
- `created_at: datetime`  # UTC
- `content: str`
- `metadata: dict[str, Any]`

### 3.2 Identity Rules

- Events are never mutated once written.
- Every semantic memory item must be traceable back to one or more concrete `Event`s.
- `root_session_id` defines a **topic tree**; `session_id` defines branches under that root.
- **Semantic memory is root-scoped**:
  - semantic search uses `root_session_id` to avoid cross-topic bleed.
  - branches under the same root share semantic hits.

---

## 4. Config & Modes

### 4.1 Env-Driven Config (`app/config.py`)

Required env vars:

- AWS:
  - `AWS_REGION`
  - `TRANSCRIPT_BUCKET`
  - `STATE_TABLE`
- OpenAI:
  - `OPENAI_API_KEY`
  - `EMBEDDING_MODEL_NAME`
  - `SUMMARY_MODEL_NAME`
  - `OPENAI_VECTOR_STORE_ID` (for `SEMANTIC_BACKEND=openai`)
- Semantic backend:
  - `SEMANTIC_BACKEND` in `{openai, none}`
    - `openai` = intended deployment mode.
    - `none` = dev/safe mode (no semantic memory).
  - `SEMANTIC_CHUNK_SIZE_TOKENS` (default `800`)
  - `SEMANTIC_CHUNK_OVERLAP_TOKENS` (default `0`)
- Health:
  - `HEALTHCHECK_LLM_CALLS` in `{true,false}` (default `false`).

**Fail-fast rules:**

- Missing required env → `ConfigError`.
- Unknown `EMBEDDING_MODEL_NAME` (not in `EMBEDDING_DIMS`) → `ConfigError`.
- `SEMANTIC_BACKEND=openai` without `OPENAI_VECTOR_STORE_ID` → `ConfigError`.

### 4.2 Modes

- `SEMANTIC_BACKEND=openai` (normal mode):
  - Semantic memory ON (OpenAI vector store).
  - Short summaries ON (OpenAI).

- `SEMANTIC_BACKEND=none` (dev/safe mode):
  - Semantic memory OFF → `semantic_hits` is always `[]`.
  - Short summaries still ON (OpenAI).
  - This reduces cost (no vector store calls) but does **not** mean “no tokens”.

---

## 5. Core Modules & Flows

### 5.1 `short_term_memory.py`

- Maintains `recent_events` and `short_summary` per `(root_session_id, session_id)`.
- Triggers `llm_client.summarise(...)` after N turns or similar heuristic.
- Writes updates via `state_manager`.

### 5.2 `semantic_memory.py`

- `index_memory(settings, doc: SemanticDoc)`:
  - `SEMANTIC_BACKEND=openai`:
    - Build a JSON payload from `doc.text`.
    - Upload as file to OpenAI with identity attributes.
    - Attach file to the configured vector store with static chunking.
  - `SEMANTIC_BACKEND=none`:
    - No-op.

- `search_memory(settings, query_text: str, *, root_session_id: str, session_id: str | None, k: int) -> list[SemanticHit]`:
  - `SEMANTIC_BACKEND=openai`:
    - If `query_text` empty → return `[]`.
    - Build filter on `root_session_id` (and optionally `session_id` if we ever want stricter mode).
    - Call vector store search.
    - Map results into `SemanticHit(text, score, metadata)`.
  - `SEMANTIC_BACKEND=none`:
    - Always return `[]`.

### 5.3 `transcript_logger.py`

- `append_events(events: list[Event])`:
  - Load current JSONL object from S3 (if exists).
  - Append new events locally.
  - Write back as a single object.
- Documented assumption: **single writer** for each `(root_session_id, session_id)`.

### 5.4 `state_manager.py`

- Load and save `BranchState` objects to DynamoDB.
- Maintain monotonic `next_sequence` per `(root_session_id, session_id)`.

### 5.5 `handler.py`

- `handle_pre(PrePhaseRequest)`:

  1. Load state from DynamoDB.
  2. Determine whether to run semantic search based on `SEMANTIC_BACKEND`.
  3. When `openai`:
     - Use current user message and existing state to form the semantic query.
     - Call `semantic_memory.search_memory(...)` with `root_session_id` scope.
  4. Return `PrePhaseResponse` with:
     - `short_summary`
     - `recent_events`
     - `semantic_hits`.

- `handle_post(PostPhaseRequest)`:

  1. Load state.
  2. Allocate `sequence` numbers for user + assistant events.
  3. Append events to S3 transcripts.
  4. Update rolling summary and recent events.
  5. When `SEMANTIC_BACKEND=openai`:
     - Build a `SemanticDoc` for the assistant message (and optionally the user message).
     - Call `semantic_memory.index_memory(...)`.
  6. Save updated state.
  7. Return `{ok: true}`.

---

## 6. Healthcheck & Diagnostics

### 6.1 `healthcheck.py`

- `run_healthcheck()` should:

  1. Load settings (fail fast on missing/invalid env).
  2. Confirm S3 bucket and DynamoDB table exist (simple list/describe).
  3. If `SEMANTIC_BACKEND=openai`:
     - Retrieve the configured OpenAI vector store by ID.
  4. If `HEALTHCHECK_LLM_CALLS=true`:
     - Call `llm_client.embed("healthcheck")` and/or `summarise("User: hi\nAssistant: hi")`.

### 6.2 Lambda Cold Start

- `lambda_handler` must call `run_healthcheck()` once per cold start and cache the result.
- If healthcheck fails, subsequent requests should return 500 until the function is re-deployed.

---

## 7. Tests

Tests should cover at least:

- Config:
  - Missing envs -> `ConfigError`.
  - Unknown embedding model -> `ConfigError`.
  - `SEMANTIC_BACKEND=openai` with missing `OPENAI_VECTOR_STORE_ID` -> `ConfigError`.

- Handler:
  - `/pre` with `SEMANTIC_BACKEND=none` returns `semantic_hits=[]`.
  - `/pre` with `SEMANTIC_BACKEND=openai` calls `semantic_memory.search_memory` and propagates hits.
  - `/post` with `SEMANTIC_BACKEND=none` does not index semantic memory.
  - `/post` with `SEMANTIC_BACKEND=openai` calls `semantic_memory.index_memory` exactly once.

- Lambda wrapper:
  - Correct routing for `/pre` and `/post`.
  - 400 for missing/invalid body fields.
  - 404 for unknown path.

- Semantic memory:
  - `openai` path builds filters on `root_session_id`.
  - `none` path is a no-op and returns empty lists.

---

This plan replaces any previous “Phase 2” or “OpenSearch” wording.  
When working with Codex/codegen, treat **this** as the only source of truth.
