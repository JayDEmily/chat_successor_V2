# LTM-RAG V2 (public source snapshot)

This repository is a **new Git repository with no shared Git history** with the original private JayDEmily/LTM_RAG repository. Its starting source is a sanitised snapshot of the vNext governance R3 candidate (ff446d6057bef7e344bc1dd4c491941a53f8f928, 21 November 2026).

The original repository, its earlier private commits, historical deployment backups, third-party bundled deploy_build/ binaries, account-specific AWS reference documents, and live AWS Lambda URLs are **not** published here. Placeholder https://example.invalid addresses are intentionally non-operational. Do not treat these public files as a deployable production configuration.

On this public V2 repository, the synthetic GitHub Actions workflow runs on both pull requests and pushes to main. The existing GitHub workflow's PR-only trigger is adapted solely for public V2.

> Publication and internal release acceptance are separate. A passing public CI run checks the workflow and synthetic suite; it does not change the proposed status of the original technical ADR or certify original native ChatGPT evidence.

---

# memory-agent

Long-Term **Semantic Memory** Backend
*For a single user, across any topic, fronted by a Custom GPT Action.*

This repo implements one thing:

> A personal long-term **semantic memory** for one human, powered by **OpenAI vector store**, exposed via `/pre` and `/post` HTTP endpoints (typically called from a Custom GPT Action in ChatGPT).

For the forward-looking RAG-graph / long-term memory extension, see `Canonical ImplementationV3 - RAG Graph.md`, which builds on this canonical V2 design.

It is **not** a general analytics platform, not a multi-tenant service, and there is **no Phase 2** in scope. Any previous references to "Phase 2" or OpenSearch should be treated as historical and ignored. The service runs as a **single AWS Lambda function** (Python 3.12) with a **Lambda Function URL** as the canonical HTTP front door; API Gateway/ALB are optional wrappers if you need extra auth/routing. The scope is single-tenant for a single human user; multi-tenant partitioning/auth is out of scope for V2.

## Hygiene expectations

- **Python requirement:** Python **3.12.x** (currently 3.12.3) is the Lambda runtime and the only supported interpreter. `.python-version` pins this version for pyenv users while `pyproject.toml` uses `requires-python=">=3.12,<3.13"` to keep dependency tooling aligned. Python 3.13 is explicitly disallowed due to known black/ruff incompatibilities; the Makefile and hygiene tests will fail fast if you try.
- **Canonical runner:** All repo automation—packaging, scripts, tests, and tooling—must use `.venv/bin/python` (for example, `.venv/bin/python -m pip install ...`, `.venv/bin/python -m pytest`, `.venv/bin/python scripts/...`). The Makefile already calls `.venv/bin/python -m pytest`, and the new `tests/test_repo_hygiene.py` fails fast if a different interpreter is detected.
- **Single virtualenv:** Only `.venv/` is treated as canonical; additional virtualenv directories are ignored, and `.gitignore` prevents accidental commits. Everything that needs Python access should be run from `.venv/bin/python`.
- **Hygiene reporting:** `docs/hygiene_report.md` tracks the discovered interpreters, the new canonical choice, and why each change was made so the repo stays self-documenting.
- **Knobs registry:** `docs/knobs_and_dials.md` is the canonical list of tunable env vars/defaults/constants; `scripts/extract_knobs.py` can be used to re-audit code-discovered knobs.

### Guardrail documents and status

- `Canonical ImplementationV2.md` — locked baseline that matches the current code. Do not edit without explicit approval.
- `Canonical ImplementationV3 - RAG Graph.md` — locked graph extension layered on V2; current implementation is aligned with this design.
- `Canonical implementationV4 — Memory Policy.md` — guardrail defining AUTO memory gating/telemetry. Implemented via `app/memory_policy.py` + `memory_telemetry` in responses.

---

## 1. What this service does

At a high level, `memory-agent`:

1. **Records every turn** of a conversation as a durable event (who said what, when, in which branch).
2. **Stores raw text** in S3, branch state in DynamoDB, and semantic memory in an OpenAI vector store.
3. **Exposes HTTP endpoints**:

   * `POST /pre` — returns context for the next reply (`short_summary`, `recent_events`, `semantic_hits`, optional `rehydrated_s3_windows`, and when graph is enabled `graph_memory_facts` + `graph_memory_history`), plus `memory_telemetry` and response size metadata (`response_truncated`, `bytes_total`).
   * `POST /post` — records what was just said and updates memory; returns `{ ok: true }` plus `memory_telemetry`.
   * `POST /turn` — optional composite for agents/Custom GPTs: persist the previous user+assistant pair (when provided) and return the same context payload as `/pre` for the current user message, plus `persisted_last_turn`.
4. Is designed to be driven primarily by a **Custom GPT Action** (or any HTTP client) that follows this pattern:

   1. Call `/pre` before replying.
   2. Use the response to shape the reply.
   3. Call `/post` after replying.

Everything else in the repo is just plumbing to make that work reliably.

### Canonical client loop (HTTP or Custom GPT Action)

For each conversational turn, clients follow this fixed sequence:

1. Call `POST /pre` with `root_session_id`, `session_id`, and the current `user_message`.
2. Use the returned `short_summary`, `recent_events`, `semantic_hits`, `rehydrated_s3_windows` (when present), and any `graph_memory_facts`/`graph_memory_history` present when graph is enabled to prompt the model and generate the assistant reply.
3. Call `POST /post` with the same IDs, the original `user_message`, and the final `assistant_message` to persist the turn.

There is **no arbitrary write API**: `/post` is the only path that updates transcripts, branch state, and semantic memory.

### Custom GPT Actions

Custom GPTs call the Lambda Function URL (e.g. `https://<function-id>.lambda-url...`) via three Actions that mirror the HTTP contract:

1. **memory_pre** — `POST /pre`
   * Request JSON: `{ root_session_id: string, session_id: string, user_message: string }`
   * Response JSON: same as `POST /pre` (see Section 5.1).
   * Usage: invoked **before** the model replies; feed the returned summary, recent events, semantic hits, and any rehydrated/graph context into the prompt.
2. **memory_post** — `POST /post`
   * Request JSON: `{ root_session_id: string, session_id: string, user_message: string, assistant_message: string }`
   * Response JSON: same as `POST /post` (see Section 5.2).
   * Usage: invoked **after** the model replies to persist the turn; this is the only write/update path.
3. **memory_turn** — `POST /turn`
   * Request JSON: `{ root_session_id: string, session_id: string, current_user_message: string, last_user_message: string|null, last_assistant_message: string|null }`
   * Response JSON: same as `/pre` (Section 5.1) plus `persisted_last_turn: boolean`.
   * Usage: single-call wrapper for agents/Custom GPTs. If `last_user_message` and `last_assistant_message` are provided, it first performs the `/post` work for that pair, then returns `/pre` context for `current_user_message`. When both are null, it behaves like `/pre` without persisting anything.

The GPT turn loop is therefore: either call `/pre` then `/post`, or call `/turn` once per user message (supplying the previous user/assistant pair when present). No other actions or write APIs exist.

### Custom GPT assets in this repo

- `custom_gpt_actions.yaml` — OpenAPI spec for the deployed Lambda Function URL (`https://example.invalid`); import directly into Custom GPT Actions to get `/pre`, `/post`, `/turn`.
- `custom_instructions_GPT.md` — the full Custom GPT prompt/usage guide (turn protocol, error handling, markers). Use it verbatim when configuring the GPT.
- `custom_gpt_turn_client.py` — minimal Python helper that wraps `/turn`, enforces paired last_* fields, retries pending turns, and appends a `turn=#### write=true|false` marker. Tests live in `tests/test_custom_gpt_turn_client.py` and `tests/test_turn_integration.py`.

#### Deterministic path (recommended for production/Custom GPT)

- Deploy and expose `POST /turn` on the same Function URL; this is the single-call, deterministic path expected by the Custom GPT instructions.
- Behaviour:
  1. If `last_user_message`/`last_assistant_message` are non-null, `/turn` internally performs the `/post` write for that pair (transcript + state + semantic index), sets `persisted_last_turn=true`, then prepares context for `current_user_message`.
  2. If both are null, `/turn` skips persistence and acts like `/pre`, returning context for the current user message with `persisted_last_turn=false`.
- Clients must **always** send both `last_*` fields as either null or populated together. Mixing null/non-null is invalid.
- If `/turn` is not deployed, the endpoint will return a 404; in that case use the two-call flow (`/pre` then `/post`). For production parity with the Custom GPT instructions, ensure `/turn` is enabled on the Function URL.

### MCP tools

For MCP-aware clients, two tools are exposed (see `app/mcp_server.py`):

- `memory_pre(root_session_id, session_id, user_message)` — returns the same JSON body as `POST /pre` (Section 5.1).
- `memory_post(root_session_id, session_id, user_message, assistant_message)` — returns `{ ok: bool }` (write semantics match `POST /post`, but the MCP tool currently returns only `ok`).

They mirror the HTTP semantics but swap transport and bypass the Lambda healthcheck guard + HTTP error mapping (errors surface directly). Use `run_mcp_healthcheck()` from `app/mcp_server.py` at process start if you want the same startup validation for MCP hosts.

---

## 2. Repository layout & runtime

Repo root:

````text
repo-root/
├── README.md
├── Canonical ImplementationV2.md
├── Canonical ImplementationV3 - RAG Graph.md
├── Canonical implementationV4 — Memory Policy.md
├── project_overview.md
├── custom_instructions_GPT.md
├── custom_gpt_actions.yaml
├── custom_gpt_turn_client.py
├── infra_resources.md
├── aws_login_info.md
├── Makefile
├── pyproject.toml
├── pytest.ini
├── lambda_handler.py
├── sitecustomize.py
├── docs/
│   ├── README.md
│   ├── hygiene_report.md
│   └── knobs_and_dials.md
├── scripts/
│   ├── extract_knobs.py
│   ├── graph_live_diag_conversation.py
│   ├── phase2_aws_sanity.py
│   ├── phase3_openai_sanity.py
│   ├── run_micro_agent.py
│   ├── turn_rag_probe.py
│   ├── turn_size_probe.py
│   └── venv_python.sh
├── tests/
│   ├── README_tests.md
│   └── ...
├── build-lambda/             # Lambda packaging (vendored deps + app code)
├── app/
│   ├── __init__.py
│   ├── models.py             # Events, requests, responses, branch state
│   ├── config.py             # Env-driven Settings
│   ├── coefficients/         # versioned coefficient presets (defaults)
│   ├── llm_client.py         # OpenAI client (embeddings, summaries)
│   ├── aws_clients.py        # boto3 clients
│   ├── state_manager.py      # Dynamo state load/save
│   ├── transcript_logger.py  # S3 JSONL transcripts
│   ├── semantic_memory.py    # OpenAI vector store integration
│   ├── semantic_markers.py   # Dynamo markers for semantic idempotency
│   ├── memory_policy.py      # AUTO gating heuristics (memory-dependent/salience)
│   ├── short_term_memory.py  # rolling summary + recent window
│   ├── rehydration.py        # S3 transcript window rehydration for semantic hits
│   ├── handler.py            # handle_pre / handle_post (graph enqueue hook)
│   ├── healthcheck.py        # startup checks
│   ├── response_utils.py     # response JSON shaping + size measurement
│   ├── response_budget.py    # deterministic response truncation to byte budget
│   ├── graph_pipeline.py     # SQS payload builder for graph jobs
│   ├── graph_worker_handler.py  # Graph worker Lambda entrypoint
│   ├── graph_extraction_worker.py  # structured/LLM extraction
│   ├── graph_consolidation.py     # supersession/reopen logic
│   ├── graph_consolidation_worker.py  # consolidation + markers + vector uploads
│   ├── graph_models.py       # MemoryNode/Edge schemas
│   ├── graph_store.py        # Dynamo adapter + markers
│   ├── graph_retrieval.py    # graph_memory_facts/history retrieval
│   ├── graph_vector_store.py # optional graph fact uploads to OpenAI vector store
│   ├── micro_agent/          # live harness client + scenarios
│   └── mcp_server.py         # MCP tools wrapping the handlers
├── legacy_files_do_not_reference/
├── build/
└── memory_agent.egg-info/
````

- `build/`, `build-lambda/`, `memory_agent.egg-info/`, and `__pycache__/` are generated artifacts.
- `legacy_files_do_not_reference/` holds archived material and should not be used.

Runtime:

- **Python**: 3.12 (single Lambda runtime)
- **AWS scope**: single account, primary region `ap-southeast-2`
- **Packaging**: `pyproject.toml` (PEP 621 via setuptools) is the source of truth.

Installation (from repo root):

```bash
python3.12 -m venv .venv
source .venv/bin/activate
.venv/bin/python -m pip install -e .
# For local dev/tests:
.venv/bin/python -m pip install -e ".[dev]"
````

Environment references:

- Account-specific AWS resource names are omitted from this public snapshot for account `000000000000` in `ap-southeast-2`.
- Account-specific login/reference material is intentionally excluded; retain it privately.

---

## 3. Core concepts

### 3.1 Events, sessions, branches

Every turn in the conversation is an `Event`:

* `event_id` — stable ID
* `root_session_id` — topic root (one per high-level conversation)
* `session_id` — branch under a root (may equal `root_session_id` for the main branch)
* `sequence` — monotonic integer per `(root_session_id, session_id)`
* `role` — `user | assistant | system | tool`
* `created_at` — UTC timestamp (ISO-8601 string)
* `content` — raw text
* `metadata` — extra info (tool names, etc.)

You control `root_session_id` and `session_id` from the caller (Custom GPT / client). The backend never mutates events once written.

### 3.2 Storage layers

Single-tenant storage triad: S3 JSONL transcripts, DynamoDB branch state, and OpenAI vector store (no OpenSearch path in V2).

* **S3 transcripts** (`TRANSCRIPT_BUCKET`)

  * Single bucket per environment named by the `TRANSCRIPT_BUCKET` setting.
  * Key: `sessions/{root_session_id}/{session_id}.log.jsonl`.
  * Each line: full `Event` as JSON.
  * Append-only implemented as whole-object read–modify–write with a **single-writer assumption** per `(root_session_id, session_id)`; no in-place edits or deletions.

* **DynamoDB state** (`STATE_TABLE`)

  * Single table named by `STATE_TABLE`.
  * Partition key: `PK = root_session_id`
  * Sort key: `SK = session_id`
  * Attributes per branch:

    * `short_summary: str | None`
    * `recent_events: list[EventLike]` (chronological, bounded buffer)
    * `next_sequence: int` (next integer to allocate)
    * `summary_turns_since_update: int` (assistant turns since last summary)
  * Simple key-value get/put access only; no secondary indexes are used.

* **OpenAI vector store** (semantic memory)

  * Enabled when `SEMANTIC_BACKEND=openai`; when `SEMANTIC_BACKEND=none`, indexing and search are skipped.
  * Store ID is `OPENAI_VECTOR_STORE_ID` provisioned with the embedding model named by `EMBEDDING_MODEL_NAME` (canonical `text-embedding-3-large`); embeddings are computed inside the store, not in this service.
  * Semantic indexing is policy-driven:
    * Event roles eligible for indexing are controlled by `SEMANTIC_INDEX_ROLES` (defaults to `["user","assistant"]` via `COEFFICIENTS_PRESET`).
    * User messages are indexed every turn as `kind="user_message"` (unless `SEMANTIC_INDEX_ROLES` excludes `user`).
    * Assistant messages are indexed as `kind="assistant_message"` only when `app/memory_policy.is_salient_assistant_message()` returns true.
    * Each successful upload writes a Dynamo marker so retries don’t duplicate vector store files.
  * Each upload sets attributes that later surface as `SemanticHit.metadata`: `root_session_id`, `session_id`, `event_id` (stored as `id`), `sequence`, `role`, `kind`, `created_at`, and optional transcript pointers (`transcript_bucket`, `transcript_key`).
  * OpenAI handles chunking and vectorisation server-side using the store’s embedding model.
  * Semantic search is a vector store search filtered by `root_session_id` using the current user message as the query text. Branches under the same root share semantic memory. Session-level filtering is optional; set `SEMANTIC_SEARCH_SCOPE=session` to include `session_id` in the filter (default is root-only).
  * Search results surface as `SemanticHit` objects carrying `text`, `score`, and the same identifier/timestamp metadata attached at index time.
  * **Branches under the same `root_session_id` share semantic memory.**

There is **no OpenSearch path** in the intended configuration.

---

## 4. Configuration

All configuration is env-driven via `app/config.py` and loaded into a single `Settings` structure. Infrastructure (or a local `.env`) should provide the environment variables; canonical values are examples only and not hard-coded.

### 4.1 Settings surface (env vars)

- **AWS**
  - `AWS_REGION` — region for AWS calls.
  - `TRANSCRIPT_BUCKET` — S3 bucket for transcripts.
  - `STATE_TABLE` — DynamoDB table for `BranchState`.
  - `MEMORY_NODES_TABLE` — DynamoDB table for graph facts (V3).
  - `GRAPH_EVENTS_QUEUE_URL` — SQS FIFO queue for graph pipeline work items.
  - `GRAPH_ENABLED` in `{true,false}` — enable graph enqueue + read path.
  - `GRAPH_VECTOR_INDEX_ENABLED` in `{true,false}` — optionally upload consolidated graph facts to the OpenAI vector store.

- **OpenAI**
  - `OPENAI_API_KEY` — injected secret.
  - `SUMMARY_MODEL_NAME` — canonical example `gpt-5.1`.
  - `EMBEDDING_MODEL_NAME` — canonical example `text-embedding-3-large`; must exist in the internal dimension map or config fails fast.
  - `OPENAI_VECTOR_STORE_ID` — required when semantic backend is `openai`.

- **Semantic backend selection**
  - `COEFFICIENTS_PRESET` — selects a versioned baseline preset (default `v1`) that provides defaults for semantic/rehydration/budget knobs.
  - `SEMANTIC_BACKEND` in `{openai, none}` (defaults to `openai` when unset).
  - `SEMANTIC_CHUNK_SIZE_TOKENS` (optional; default comes from `COEFFICIENTS_PRESET`).
  - `SEMANTIC_CHUNK_OVERLAP_TOKENS` (optional; default comes from `COEFFICIENTS_PRESET`).
  - `SEMANTIC_SEARCH_TOP_K` (optional; default comes from `COEFFICIENTS_PRESET`).
  - `SEMANTIC_RETURN_HITS_CAP` (optional; default comes from `COEFFICIENTS_PRESET`).
  - `SEMANTIC_INDEX_ROLES` (optional; default comes from `COEFFICIENTS_PRESET`).
  - `SEMANTIC_SEARCH_SCOPE` in `{root, session}` (defaults to `root`); set to `session` to include `session_id` in semantic search filters.
  - When `SEMANTIC_BACKEND=openai`, a vector store ID must be supplied; when `none`, semantic search is disabled and the ID may be omitted. `OPENAI_API_KEY` is still required in `none` mode for summary generation.

- **Healthcheck**
  - `HEALTHCHECK_LLM_CALLS` in `{true,false}` (default `false`): toggles whether the healthcheck makes small LLM/embed calls vs. only config/connectivity checks.
  - `HEALTHCHECK_WRITE_PROBES` in `{true,false}` (default `false`): optionally performs lightweight write/delete probes against S3 and DynamoDB during healthcheck.
  - Healthcheck always validates S3/DynamoDB; OpenAI vector store validation runs only when `SEMANTIC_BACKEND=openai`.
- **Logging**
  - `LOG_LEVEL` controls verbosity for structured JSON logs emitted to stdout/stderr (default `INFO`). Logs carry correlation fields (request_id, path, root_session_id, session_id) suitable for CloudWatch filtering.
- **Canonical AWS resources**
  - See `infra_resources.md` for canonical resources in `ap-southeast-2`: `TRANSCRIPT_BUCKET`, `STATE_TABLE`, `MEMORY_NODES_TABLE`, `GRAPH_EVENTS_QUEUE_URL`, and the shared OpenAI vector store ID.
- **Full knob surface**
  - See `docs/knobs_and_dials.md` for the complete knob surface + exact defaults (response budget, S3 rehydration, semantic caps, presets, and live-test gates).

### Resource creation prerequisites

- The S3 transcript bucket and DynamoDB BranchState table must be pre-created in `ap-southeast-2`.
- See `infra_resources.md` for the canonical names and AWS CLI commands to create them before running the AWS harness or deploying Lambda.

- **Tests**
  - `OPENAI_INTEGRATION=1` enables the gated live vector store round-trip test.

### 4.2 Model evolution

- Model names are configuration-driven, not hard-coded. Canonical defaults: `SUMMARY_MODEL_NAME=gpt-5.1`, `EMBEDDING_MODEL_NAME=text-embedding-3-large`.
- Changing the summary model is a configuration-only change; no storage migration required.
- Changing the embedding model requires a new semantic memory generation:
  - Provision a new OpenAI vector store configured with the new embedding model.
  - Point `OPENAI_VECTOR_STORE_ID` at that new store for indexing/search.
  - Treat the prior store as a legacy generation; do not mix embeddings across stores.
- `config.load_settings()` fails fast on missing required envs, unknown embedding models/dimensions, or semantic backend values outside `{openai, none}`.

---

## 5. Core flows: /pre, /post, /turn

The core logic lives in `app/handler.py` and is exposed over HTTP via the Lambda Function URL. The contract is JSON-only:

- `POST /pre` — fetch context for the next reply.
- `POST /post` — record the latest turn (only write/update path).
- `POST /turn` — composite: optionally persist the previous turn, then return the same context payload as `/pre` for the current user message.

All successful responses return HTTP 200 with JSON bodies shown below. Error handling is described in **5.4 Error contract**.

### 5.1 `/pre` — fetch context for the next reply

**HTTP endpoint**: `POST /pre`

**Required request body** (`PrePhaseRequest`):

```jsonc
{
  "root_session_id": "string",
  "session_id": "string",
  "user_message": "string"
}
```

**Response body** (`PrePhaseResponse`):

```jsonc
{
  "short_summary": "string or null",
  "recent_events": [ /* list of Event-like dicts with event_id/root_session_id/session_id/sequence/role/created_at/content/metadata */ ],
  "semantic_hits": [ /* list of { text: string, score: number, metadata: object } */ ],
  "rehydrated_s3_windows": [ /* optional windows of raw transcript events around semantic hits */ ],
  "graph_memory_facts": [ /* list of active/reopened graph facts when graph is enabled */ ],
  "graph_memory_history": { /* per-entity history with state/supersedes/superseded_by/source_event_ids */ },
  "memory_telemetry": { /* policy_applied, memory_dependent, semantic_search_ran, s3_rehydration_ran, graph_read_ran, ... */ },
  "response_truncated": false,
  "bytes_total": 12345
}
```

**Behaviour** (simplified):

1. On cold start the Lambda wrapper runs a one-time healthcheck (config + connectivity).
2. Load `Settings` (validates required env, embedding model name, and vector store ID when backend=openai).
3. Load branch state (`BranchState`) from DynamoDB (or construct a default when missing).
4. Apply AUTO memory policy:

   * Compute `memory_dependent = is_memory_dependent(user_message)` (see `app/memory_policy.py`).
   * When `memory_dependent=true` and `SEMANTIC_BACKEND=openai`, call `semantic_memory.search_memory(...)` filtered by `root_session_id` (and optionally `session_id`).
   * When `semantic_hits` are non-empty, rehydrate small raw transcript windows from S3 into `rehydrated_s3_windows`.
5. When `GRAPH_ENABLED=true`, load `graph_memory_facts`/`graph_memory_history` from DynamoDB (entity-hinted when possible); optional vector fallback if no Dynamo facts are found.
6. Enforce `RESPONSE_BUDGET_BYTES` with a deterministic truncation order, setting `response_truncated` and `bytes_total`.
7. Return:

```jsonc
{
  "short_summary": "..." | null,
  "recent_events": [/* most recent turns for this branch */],
  "semantic_hits": [/* from OpenAI vector store or empty */],
  "rehydrated_s3_windows": [/* optional transcript windows around hits */],
  "graph_memory_facts": [/* active facts per entity/type when graph enabled */],
  "graph_memory_history": { /* per-entity timeline including supersedes/superseded_by/history_reason */ },
  "memory_telemetry": { /* includes policy + what ran */ },
  "response_truncated": false,
  "bytes_total": 12345
}
```

This is what a Custom GPT should feed into its prompt context before replying.
The path is read-only; it never appends transcripts or writes BranchState.

### 5.2 `/post` — record the latest turn

**HTTP endpoint**: `POST /post`

**Required request body** (`PostPhaseRequest`):

```jsonc
{
  "root_session_id": "string",
  "session_id": "string",
  "user_message": "string",
  "assistant_message": "string"
}
```

**Response body** (`PostPhaseResponse`):

```jsonc
{
  "ok": true,
  "memory_telemetry": { /* policy_applied, semantic_index_ran, graph_enqueue_ran, salient_last_turn, ... */ }
}
```

**Behaviour** (simplified):

1. Load `Settings` and branch state from DynamoDB.
2. Allocate `sequence` numbers for the new `user` and `assistant` events (advances `next_sequence`).
3. Build two `Event` objects and append them to the S3 JSONL transcript (read–modify–write) at `sessions/{root}/{session}.log.jsonl`.
4. Update short-term memory (extend `recent_events`, bump `summary_turns_since_update`, refresh `short_summary` when thresholds hit, trim buffer).
5. If `SEMANTIC_BACKEND=openai`:

   * Index the user message (eligible roles controlled by `SEMANTIC_INDEX_ROLES`) as `kind="user_message"`.
   * Index the assistant message as `kind="assistant_message"` only when it’s salient per `app/memory_policy.is_salient_assistant_message()`.
   * Write a Dynamo marker per indexed event to prevent duplicate uploads on retries.
6. If `SEMANTIC_BACKEND=none`:

   * Skip semantic indexing entirely.
   * Graph enqueue still runs when `GRAPH_ENABLED=true`.
7. Save updated state to DynamoDB via simple upsert.
8. Return the `{"ok": true}` response body.

### 5.3 `/turn` — composite (persist last turn + fetch context)

**HTTP endpoint**: `POST /turn`

**Required request body** (`TurnRequest`):

```jsonc
{
  "root_session_id": "string",
  "session_id": "string",
  "current_user_message": "string",
  "last_user_message": "string or null",
  "last_assistant_message": "string or null"
}
```

**Response body** (`TurnResponse`):

- Same as `POST /pre` (Section 5.1), plus `persisted_last_turn: boolean`.

**Behaviour** (simplified):

1. If `last_user_message`/`last_assistant_message` are both present, perform the `/post` work for that pair.
2. Perform the `/pre` work for `current_user_message`.
3. Merge `/post` telemetry into the response, set `persisted_last_turn`, and enforce `RESPONSE_BUDGET_BYTES`.

### 5.4 Error contract

- `200`: success with the response shapes above.
- `400`: missing required fields, invalid types, or empty/whitespace-only strings for required fields, or malformed JSON; body `{"error": "<message>"}`.
- `404`: wrong path or unsupported method; body `{"error": "<message>"}`.
- `500`: unexpected internal errors; body `{"error": "<message>"}`.

Any other path or method returns a 404; there is no support for query-string variants or additional endpoints.
Suffix-based routing allows stage prefixes like `/prod/pre` or `/v1/post` to resolve correctly.

Notes:
- `/post` is non-idempotent: every call appends two events and advances sequence numbers. Client retries will duplicate events.
- `/turn` is non-idempotent when `last_*` fields are provided: it performs the same `/post` work internally and will duplicate events on retries.
- Transcript append is a naive read–modify–write; assume a single writer per `(root_session_id, session_id)` branch to avoid races.

### Auth expectations

- **Canonical minimal deployment:** the Lambda Function URL is treated as an internal secret URL; no additional HTTP auth is enforced by the code.
- **Optional extensions (deployment-time only, not implemented here):** you may front the Function URL with API Gateway/ALB and enforce API keys, IAM/OAuth, or a simple static header (e.g. `X-API-Key`) at the edge. The Lambda itself does not parse or require auth headers by default.
- The HTTP contract (paths, bodies, error shapes) is independent of any front-door auth you choose to add.

---

## 6. Graph memory (V3)

- **Enablement:** set `GRAPH_ENABLED=true` and provide `MEMORY_NODES_TABLE`, `GRAPH_EVENTS_QUEUE_URL`, `TRANSCRIPT_BUCKET`, and `STATE_TABLE` (canonical names in `infra_resources.md`). Optional `GRAPH_VECTOR_INDEX_ENABLED=true` uploads consolidated facts to the shared OpenAI vector store.
- **Pipeline:** `/post` enqueues a graph job to SQS with root/session IDs, event IDs, transcript key, and sequence range. The worker Lambda (`app.graph_worker_handler.lambda_handler`) loads recent/transcript events, runs deterministic structured extraction (`entity= type= fact=` with trailing punctuation stripped, confidence=1.0, preserving `fact` verbatim and `source_event_ids`), and consolidates nodes with supersession/reopen rules. Markers (`_marker#{session_id}`) prevent reprocessing.
- **Supersession:** A new fact for the same entity/type supersedes all active/reopened nodes, setting their `state="superseded"`, `superseded_by`, and `valid_to`, and recording their node_ids in the new node’s `supersedes`. Reopens set `state="reopened"` with a `history_reason` and supersede any conflicting actives.
- **Retrieval:** `/pre`/`/turn` return `graph_memory_facts` (latest active/reopened per entity/type) and `graph_memory_history` (per-entity timelines with state/supersedes/superseded_by/source_event_ids/history_reason), filtered to exclude `_marker*`. `memory_telemetry.graph_read_ran` is true on successful graph fetch; `/turn` merges `graph_enqueue_ran` from `/post`.
- **Optional vector:** When `GRAPH_VECTOR_INDEX_ENABLED=true`, consolidated nodes upload to OpenAI vector store with metadata (entity/type/state/source_event_ids/supersedes/superseded_by) for vector fallback in retrieval.
- **Live tests:** `LIVE_GRAPH=1` runs `tests/test_graph_validation_live.py`, which asserts enqueue/read telemetry, verbatim fact strings (e.g., `python_version=3.12.xx`), provenance via `source_event_ids`, supersession fields, and no `_marker*` keys in history.

---

## 7. AUTO memory policy (V4)

`Canonical implementationV4 — Memory Policy.md` defines deterministic AUTO gating for long-term reads/writes to keep latency predictable. The current implementation is in `app/memory_policy.py`, surfaced via `memory_telemetry` in `/pre`, `/post`, and `/turn` responses.

- **Tier 2 reads on `/pre` (semantic):** run semantic retrieval only when the user message is memory-dependent (recall cues like “remember/earlier/last time/what did we decide”, state/config cues like “python/lambda/version/config/aws/dynamo/s3/vector store/mcp”, or generic references like “the plan/doc/repo/workflow” that are not pleasantries).
- **Tier 1 writes on `/post`:** always persist transcript + BranchState; index the user message each turn, and index the assistant message only when salient (commit/decision language, env var assignments, version strings, structured lists/headings, or length ≥ 800 chars).
- **Graph:** when `GRAPH_ENABLED=true`, always enqueue the graph job after Tier 0 succeeds and expose `graph_memory_*` on `/pre` and `/turn` (marker rows are filtered from history).
- **Telemetry:** responses include `memory_telemetry` with `policy_applied:"auto"` plus flags like `memory_dependent`, `semantic_search_ran`, `s3_rehydration_ran`, `graph_read_ran`, `salient_last_turn`, `semantic_index_ran`, and `graph_enqueue_ran`.
- **Idempotency:** semantic indexing writes a Dynamo marker per indexed event to avoid duplicate vector uploads on retries.

---

## 8. Local development and testing

- **Environment:** Python 3.12 inside WSL Ubuntu. Open the repo root in VS Code, create `.venv` via `python3.12 -m venv .venv`, and install dependencies through `.venv/bin/python -m pip install -e ".[dev]"`. Always invoke tooling through `.venv/bin/python`.
- **Configuration:** Provide env vars matching the Configuration section (AWS region/resources, OpenAI key/models, semantic backend choice, vector store ID when `SEMANTIC_BACKEND=openai`). A `.env` file loaded by your runner or VS Code launch config is typical.
- **Testing:** Layered pytest regime (see `tests/README_tests.md`). Default (`make test`) runs the fast mocked suite. `make test-local-real` hits real AWS/OpenAI in-process (`LIVE_AWS=1`). `make test-smoke` hits the deployed Function URL (`LIVE_SMOKE=1`, `LIVE_LAMBDA_URL`). `make test-release` runs live checks including the OpenAI vector store round-trip. The Makefile wrappers call `.venv/bin/python -m pytest`, and manual test runs must also go through `.venv/bin/python -m pytest` to stay aligned.
- **Local harness patterns:** Call `handle_pre` / `handle_post` directly with constructed request objects or invoke `lambda_handler.lambda_handler` with live events. 
- **V3 graph tests:** See `tests/README_tests.md` for the combined V2/V3 test suite coverage and environment expectations. V3 remains an additive layer; V2 contracts and behaviours stay canonical.

---

## 9. Deployment (Lambda + Custom GPT)

Canonical front door: use the Lambda Function URL. API Gateway is optional if you need extra auth/routing.

### Infrastructure checklist (pre-deploy)

- Create an S3 transcript bucket in `ap-southeast-2` (`TRANSCRIPT_BUCKET`, public access blocked, server-side encryption on; enable versioning if you want audit/recovery).
- Create a DynamoDB BranchState table in `ap-southeast-2` (`STATE_TABLE`) with `PK`/`SK` keys, on-demand billing, no secondary indexes.
- Create an IAM role trusted by Lambda with CloudWatch Logs permissions plus R/W access to the transcript bucket and state table.
- Provision an OpenAI vector store configured with the embedding model named by `EMBEDDING_MODEL_NAME`; capture its ID as `OPENAI_VECTOR_STORE_ID`.
- Set Lambda environment variables for: `AWS_REGION`, `TRANSCRIPT_BUCKET`, `STATE_TABLE`, `OPENAI_API_KEY`, `SUMMARY_MODEL_NAME`, `EMBEDDING_MODEL_NAME`, `OPENAI_VECTOR_STORE_ID`, `SEMANTIC_BACKEND`, `HEALTHCHECK_LLM_CALLS`, and any other `Settings` fields you use.
- Attach a Lambda Function URL as the canonical HTTP entrypoint for `/pre`, `/post`, and `/turn` (auth type None in the minimal deployment; add a front door later if you want stronger auth).

### Deployment steps

1. **AWS resources** (manual/IaC, not created by this repo):

   * S3 transcript bucket (`TRANSCRIPT_BUCKET`, e.g. `my-memory-transcripts`) in `ap-southeast-2`; block public access, enable server-side encryption, and (optionally) enable versioning for audit/recovery.
   * DynamoDB state table (`STATE_TABLE`, e.g. `my-memory-state`) in `ap-southeast-2` with `PK`/`SK` as the partition/sort keys; on-demand billing, no secondary indexes required.
   * OpenAI vector store created in your OpenAI account; set `OPENAI_VECTOR_STORE_ID`.
   * IAM role for Lambda trusted by the Lambda service with permissions for CloudWatch logs, read/write to the transcript bucket, and read/write to the state table.
   * Lambda function running Python 3.12 with handler `lambda_handler.lambda_handler`, environment variables set per `Settings` (Section 4), and a Function URL as the canonical HTTP entrypoint for `/pre`, `/post`, and `/turn` (auth type None in the minimal deployment; front it with API Gateway/ALB only if you want stronger auth).

2. **Build deployment package** (simplified example):

   ```bash
   python3.12 -m venv .venv
   source .venv/bin/activate            # optional but helpful for manual shell work
   .venv/bin/python -m pip install --upgrade pip
   rm -rf build-lambda
   mkdir -p build-lambda
   .venv/bin/python -m pip install . --target build-lambda
   cd build-lambda
   zip -r ../memory-agent.zip .
   ```

3. **Create/Update Lambda** (pseudo-CLI):

   ```bash
   aws lambda create-function \
     --function-name memory-agent \
     --runtime python3.12 \
     --role arn:aws:iam::<ACCOUNT_ID>:role/<LambdaExecutionRole> \
     --handler lambda_handler.lambda_handler \
     --region <YOUR_REGION> \
     --timeout 15 \
     --memory-size 512 \
     --environment "Variables={...env vars from section 4...}" \
     --zip-file fileb://memory-agent.zip
   ```

4. **Expose an HTTP endpoint**:

   * Attach a Lambda Function URL (canonical path) to the function.
   * Optionally front it with API Gateway HTTP API if you need additional auth/routing.
   * Ensure `/pre`, `/post`, and `/turn` are routed to the same Lambda.

5. **Wire up Custom GPT Action**:

   * Base URL: the Function URL (or API Gateway if you added that front door).
   * Action endpoints:

     * `POST /turn` — recommended single-call path; returns the same context as `/pre` plus `persisted_last_turn`.
     * `POST /pre` — called before replying; response contract in Section 5.1.
     * `POST /post` — called after replying; response contract in Section 5.2.
   * Document in the GPT instructions how/when to call them (either `/turn` once per user message, or `/pre` → model reply → `/post`). No other Actions are needed.

---

## 10. Healthcheck and runtime expectations

### Startup healthcheck

`app/healthcheck.py` exposes `run_healthcheck()`, which:

- Loads configuration via `load_settings()` (required env vars, embedding model dimension map, semantic backend + vector store rules).
- Asserts DynamoDB is reachable (`table.load()`).
- Asserts the transcript S3 bucket is reachable (lightweight list/head).
- When `HEALTHCHECK_WRITE_PROBES=true`, performs a lightweight write/delete probe against DynamoDB and S3 using temporary items/keys.
- When `SEMANTIC_BACKEND=openai`, retrieves the configured vector store ID to confirm reachability and logs a warning if the store’s embedding model differs from `EMBEDDING_MODEL_NAME` (best-effort, non-fatal).
- When `HEALTHCHECK_LLM_CALLS=true`, makes minimal embedding and summarisation calls through `LLMClient`.

`lambda_handler` caches a successful run via `_HEALTHCHECK_RAN` so the first invocation per cold start runs it exactly once; failures bubble to HTTP 500 and skip handler execution.

### Normal runtime expectations

- `/post`: builds two events (user then assistant), appends via `append_events` (S3 JSONL), updates short-term memory with `update_branch_state_with_events`, indexes semantic memory when enabled (policy-gated), then persists one `BranchState` item via `save_branch_state`.
- `/pre`: loads at most one `BranchState` via `load_branch_state`, runs policy-gated semantic search (and S3 rehydration) plus optional graph retrieval, then returns `PrePhaseResponse`.
- Observability relies on CloudWatch logs, S3 transcript objects, DynamoDB `BranchState` items, and vector store contents visible via OpenAI tools.

### Operational hygiene and observability

- **Current code:** structured JSON logs to stdout/stderr with correlation fields (request_id, path, root_session_id, session_id) suitable for CloudWatch; no in-code metrics or alarms; no automated lifecycle management (transcripts/state are never deleted); no reconciliation tooling beyond inspecting transcripts and DynamoDB.
- **Recommended for production:** CloudWatch metrics and alarms on 4xx/5xx rates, duration, `/pre`/`/post` counts, and dependency failures (S3/DynamoDB/OpenAI); lifecycle policies for S3 transcripts and DynamoDB retention; runbook to rebuild `BranchState` from transcripts if S3 and Dynamo drift using `app/reconcile_state.reconcile_branch_state_from_transcript`.

---

## 11. What is *not* in scope

To avoid any confusion:

* No Phase 2, no pattern-mining layer, no cross-topic analytics.
* No OpenSearch integrations in the intended configuration.
* No multi-tenant features.
* No UI — this is a backend + protocol surface to sit behind a Custom GPT or other client.

If you see references to Phase 2 or OpenSearch in older docs or comments, treat them as historical notes only. The current scope is **Phase 1: personal long-term semantic memory via OpenAI vector store**.
