# Guardrail — Canonical Behaviour V4: Memory Policy (Selective Long‑Term Reads/Writes)

**Status:** Authoritative guardrail for production behaviour. No optional branches.

## 1. Purpose

Reduce per‑turn latency for casual chat while preserving deterministic durability and correctness.

This is achieved by:

* Keeping **Tier 0** (durable transcript + short‑term state) **always on**.
* Running long‑term **retrieval only when needed** (Tier 2 reads).
* Running long‑term **writes only when salient** (Tier 1 writes).

This follows the established AWS pattern for memory‑augmented agents: synchronous short‑term memory is cheap and always written; long‑term processing is decoupled; retrieval is performed only when it improves the answer.

---

## 2. Non‑negotiable invariants

1. **S3 transcript is the canonical log**

* Append‑only JSONL at `sessions/{root_session_id}/{session_id}.log.jsonl`.
* Each line is an immutable `Event`.

2. **Dynamo BranchState is short‑term memory**

* One item per `(PK=root_session_id, SK=session_id)`.
* Stores `short_summary`, bounded `recent_events`, `next_sequence`, `summary_turns_since_update`.
* Must be rebuildable from transcripts.

3. **/post is the only mutation surface**

* `/turn` may invoke `/post` internally, but no other path mutates transcripts, branch state, semantic memory, or graph memory.

4. **Tier 0 always runs**

* Every persisted turn writes to S3 + updates BranchState.
* No policy may disable Tier 0.

5. **No dependence on ChatGPT UI “compression”**

* All memory behaviour is governed by this backend policy, not by client/orchestrator summarisation.

---

## 3. Surfaces and the canonical client loop

### 3.1 Canonical client call

* The Custom GPT calls **`POST /turn` exactly once per user message**.
* Request:

  * `{ root_session_id, session_id, current_user_message, last_user_message|null, last_assistant_message|null }`
  * `last_user_message` and `last_assistant_message` must be both null (first turn) or both non‑null (subsequent turns).

### 3.2 `/turn` semantics

* If `last_*` present: execute `/post` for that pair (Tier 0 always; Tier 1 conditional per this policy).
* Always execute `/pre` for `current_user_message` (Tier 0 read always; Tier 2 conditional per this policy).
* Response includes `persisted_last_turn` and the standard context fields.

---

## 4. Memory policy (single rule set)

**Production policy is always AUTO.**

* There are no request‑level policy overrides.
* Behaviour is deterministic from inputs + stored state.

AUTO governs:

* **Tier 2 reads** (semantic search + graph retrieval) on `/pre`.
* **Tier 1 writes** (semantic indexing) on `/post`.

Tier 0 is never gated.

---

## 5. Tier behaviour under AUTO

### 5.1 Tier 2 reads — when `/pre` performs semantic/graph retrieval

`/pre` runs long‑term retrieval **only** when the current user message is classified as **memory‑dependent**.

**Memory‑dependent trigger (deterministic, case‑insensitive):**
The message is memory‑dependent if it contains any of the following cue families:

1. **Recall cues:** “remind”, “remember”, “earlier”, “previous”, “last time”, “we said”, “you said”, “as discussed”, “again”, “what did we decide”, “did we decide”.
2. **State/config cues:** “version”, “config”, “setting”, “preference”, “default”, “runtime”, “python”, “aws”, “lambda”, “dynamo”, “s3”, “vector store”, “mcp”.
3. **Reference cues:** “that thing”, “the plan”, “the doc”, “the repo”, “the workflow” **and** it is not a greeting/pleasantry.

**If memory‑dependent = true:**

* Run semantic search when `SEMANTIC_BACKEND=openai`.
* Run graph retrieval when `GRAPH_ENABLED=true`.

**If memory‑dependent = false:**

* Skip semantic search.
* Skip graph retrieval.
* Return `semantic_hits=[]` and omit graph fields.

### 5.2 Tier 1 writes — when `/post` indexes semantic memory

`/post` indexes semantic memory **only** when the assistant message is classified as **salient**.

**Salience trigger (deterministic):**
The assistant message is salient if any of the following hold:

* Contains explicit commitment/decision language (e.g., “we will”, “decide”, “standardise”, “canonical”, “policy”, “guardrail”).
* Contains configuration or identifiers likely to be reused, including:

  * version strings (e.g., “3.12”, “3.11.9”),
  * environment variable names (ALL CAPS with underscores) near an equals sign,
  * AWS identifiers (ARNs), function URLs, or similarly stable IDs.
* Contains structured content likely to be referenced later (headings, checklists, numbered steps, tables).
* Exceeds a density proxy: **800+ characters**.

**If salient = true and `SEMANTIC_BACKEND=openai`:**

* Index the assistant message into the OpenAI vector store.

**If salient = false:**

* Do not index semantic memory.

### 5.3 Graph pipeline trigger (async)

When `GRAPH_ENABLED=true`:

* `/post` **always enqueues** the graph SQS job after Tier 0 success.
* Graph extraction/consolidation remains asynchronous; it never blocks the hot path.

---

## 6. Summary and short‑term memory (Tier 0)

* `recent_events` remains bounded (max 40 events).
* `short_summary` refreshes inline on `/post` when:

  * assistant turns since last refresh ≥ 6, or
  * `recent_events` reaches capacity.
* Summary behaviour is governed by the `LLMClient.summarise` prompt (preserve stable facts/decisions/config/preferences; drop filler).

---

## 7. Telemetry (always present)

Every `/pre` and `/turn` response includes:

```json
"memory_telemetry": {
  "policy_applied": "auto",
  "memory_dependent": true,
  "semantic_search_ran": true,
  "graph_read_ran": true,
  "salient_last_turn": true,
  "semantic_index_ran": true,
  "graph_enqueue_ran": true
}
```

* Booleans are coarse; no internal IDs.
* `salient_last_turn` applies to the persisted pair (when present).

---

## 8. Correctness guardrails (idempotency and filtering)

### 8.1 Semantic indexing idempotency (required)

Do **not** assume vector store uploads are idempotent.

**Required dedupe mechanism:**

* Write a DynamoDB marker for each indexed assistant event keyed by `(root_session_id, session_id, assistant_event_id)`.
* Store `semantic_indexed=true` and a timestamp.
* Before indexing, check the marker; if present, skip indexing.

### 8.2 Graph marker rows must never appear in retrieval

Graph processing uses per‑session marker items in the graph table.

**Required retrieval filter:**

* `/pre` graph retrieval must exclude marker items (for example, rows whose sort key starts with `_marker#`).

---

## 9. Backfill (mandatory, scheduled)

Backfill exists to populate semantic memory for turns where indexing was skipped.

**Schedule:** hourly.

**Backfill behaviour:**

* For each active branch, scan the S3 transcript (or a bounded recent range) for assistant events.
* Apply the same **salience trigger** to each assistant event.
* If salient and not yet indexed (per the Dynamo marker), index into the semantic store and set the marker.

Graph backfill is not required for correctness because graph enqueue is always on; if operationally needed, re‑enqueue by transcript range using existing graph idempotency markers.

---

## 10. Acceptance criteria

1. Casual chat:

* `/turn` returns with long‑term reads skipped (telemetry confirms), and latency is materially lower.

2. Memory‑dependent question:

* `/turn` runs semantic search and graph retrieval (telemetry confirms) and returns relevant context.

3. Durable correctness:

* S3 transcript and BranchState always reflect every persisted turn.
* Semantic store contains only salient turns (immediately or via hourly backfill).
* Graph facts converge asynchronously without blocking responses.

4. No pollution:

* Graph retrieval never emits marker rows.
* Semantic indexing never duplicates the same assistant event.
