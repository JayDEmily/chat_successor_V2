"""Test-time shims to smooth over optional dependencies.

If the installed `mcp` package lacks the `Server.tool` decorator attribute,
add a no-op decorator to allow MCP tool wiring tests to run instead of skip.
This runs automatically because the repo root is on `sys.path`.
"""

try:
    from mcp.server import Server  # type: ignore

    if not hasattr(Server, "tool"):
        def _noop_tool(*args, **kwargs):
            def _decorator(fn):
                return fn
            return _decorator

        Server.tool = staticmethod(_noop_tool)  # type: ignore[attr-defined]
except Exception:
    # If mcp is not installed, do nothing; relevant tests will handle absence.
    pass
