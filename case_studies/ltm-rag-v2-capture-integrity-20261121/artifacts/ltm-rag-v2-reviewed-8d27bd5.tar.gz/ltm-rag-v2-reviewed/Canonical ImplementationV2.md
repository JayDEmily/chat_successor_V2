# memory-agent — Canonical Implementation & Deployment Plan (Final)

This document is the **single source of truth** for how `memory-agent` works and how it is deployed. It is anchored to the current Python codebase in this repo and to the actual AWS + OpenAI setup.

It deliberately avoids implementation code, CLI commands, and concrete scripts. Tools like Codex can translate this plan into code, tests, and automation.

For the next-step RAG-graph / long-term memory extension that builds on this baseline, see `Canonical ImplementationV3 - RAG Graph.md`.

---

## 0. Scope and fixed decisions

### 0.1 Purpose

`memory-agent` is a **single-tenant long‑term memory backend** for one human user. It is designed to sit behind a Custom GPT (via Actions) or an MCP client and provide three capabilities:

1. Persistent, append‑only transcripts of conversations.
2. Per‑branch rolling context (short summary and recent turns).
3. Semantic recall over past assistant messages using an OpenAI vector store.

### 0.2 Fixed technical decisions

These are canonical unless explicitly revised in a later version of this document:

* **Runtime:** Python 3.12.
* **Hosting:** A single AWS Lambda function.
* **Front door:** Lambda **Function URL** is the canonical HTTP entrypoint. The code can accept API Gateway–shaped events, but API Gateway is optional and not assumed.
* **Storage:**

  * Amazon S3 for JSONL transcripts.
  * Amazon DynamoDB for per‑branch state.
  * OpenAI vector store for semantic memory (no OpenSearch path in this version).
* **AWS account and region:** Single AWS account, primary region `ap-southeast-2`.

### 0.3 Model defaults and configurability

Model choices are **configuration, not code**. They are controlled via environment variables so they can be changed without editing Python files.

Canonical defaults (late 2025):

* **Summary model**

  * Env var: `SUMMARY_MODEL_NAME`.
  * Canonical default: `gpt-5.1` (current high‑end general model).
  * Usage: generate and refresh the short summary string in `BranchState`. Changing this value does **not** require data migration.

* **Embedding model**

  * Env var: `EMBEDDING_MODEL_NAME`.
  * Canonical default: `text-embedding-3-large`.
  * Usage: semantic memory embeddings inside the OpenAI vector store; the service validates the model name and assumes the store is provisioned with it.

* **Embedding dimensionality**

  * The code maintains a map from model name to embedding dimension.
  * If an `EMBEDDING_MODEL_NAME` is not present in this map, configuration fails at startup to avoid silently mismatched embeddings.

* **Semantic backend selection**

  * Env var: `SEMANTIC_BACKEND`.
  * Allowed values: `openai` or `none` (anything else is rejected at startup; no OpenSearch path).
  * Canonical default when unset: `openai`.

Model evolution rules:

* Changing `SUMMARY_MODEL_NAME` is always allowed and requires no migration.
* Changing `EMBEDDING_MODEL_NAME` is treated as a breaking change for semantic memory and should be paired with a new OpenAI vector store. Old stores become legacy and are not mixed with new embeddings.

### 0.4 Operating assumptions and constraints

* **Single writer / low throughput.** `/post` is assumed to be called by a single orchestrator per branch; transcript append is a naive read–modify–write and will race if multiple writers target the same branch concurrently.
* **Non‑idempotent writes.** `/post` does not deduplicate; client retries can produce duplicate events. Retries should therefore be avoided unless the orchestration layer tracks success.
* **Minimal auth by default.** Function URL is initially unauthenticated and treated as an internal endpoint; tighten via headers or a front door when needed.

---

## 1. External contract and client behaviour

### 1.1 Conceptual client flow

Every conversational turn is split into two phases:

1. **Pre‑phase**: the client asks `memory-agent` for memory/context before generating a reply.
2. **Post‑phase**: the client notifies `memory-agent` of what actually happened so memory can be updated.

The canonical pattern for each turn is:

1. Call **pre‑phase** with the user message and identifiers to obtain:
   `short_summary`, `recent_events`, and `semantic_hits`.
2. Let the model (Custom GPT or other client) generate the assistant reply using this context.
3. Call **post‑phase** with the original user message and the final assistant reply.

There is no separate API for writing arbitrary memory objects; all memory is created or updated via the post‑phase.

### 1.2 HTTP interface (Lambda Function URL)

The Lambda Function URL exposes two logical endpoints distinguished by path and method:

* **`POST /pre`**
  Request body fields:

  * `root_session_id` (string) — logical topic or project identifier.
  * `session_id` (string) — branch identifier beneath the root.
  * `user_message` (string) — the user’s current message.

  Response body fields:

  * `short_summary` (string or null) — branch summary from `BranchState`.
  * `recent_events` (list of events) — recent turns for the branch.
  * `semantic_hits` (list of semantic hits) — results from semantic memory (may be empty).
  * `graph_memory_facts` (optional list) — present only when graph memory is enabled; active facts for the root/session.
  * `graph_memory_history` (optional object) — present only when graph memory is enabled; per-entity timelines of facts/states.

* **`POST /post`**
  Request body fields:

  * `root_session_id` (string).
  * `session_id` (string).
  * `user_message` (string).
  * `assistant_message` (string) — the reply actually sent to the user.

  Response body fields:

  * `ok` (boolean) — indicates successful processing.

Success responses use HTTP 200 with the shapes above. Errors use `{ "error": "<message>" }` with these status codes:

* **400** — missing or invalid required fields, or malformed JSON bodies.
* **404** — wrong path or unsupported method.
* **500** — unexpected internal errors.

Any other path or method returns a 404.

### 1.3 Custom GPT Actions mapping

This section describes how Custom GPT Actions integrate with the HTTP interface (descriptive only; the actual Action spec is defined in the GPT builder).

* Base URL: the Lambda Function URL.
* Actions: two only — `POST /pre` and `POST /post`.
* Schemas: identical to the HTTP contract in section 1.2.

Endpoint schemas:

* `/pre` request: `root_session_id`, `session_id`, `user_message` (strings). Response: `short_summary`, `recent_events`, `semantic_hits`.
* `/post` request: `root_session_id`, `session_id`, `user_message`, `assistant_message` (strings). Response: `ok` boolean.

Turn loop for the GPT:

1. Call **pre‑phase** (`/pre`) with `root_session_id`, `session_id`, `user_message`; use `short_summary`, `recent_events`, `semantic_hits` in the prompt.
2. Generate the assistant reply.
3. Call **post‑phase** (`/post`) with the same IDs, the `user_message`, and the `assistant_message`. `/post` is the only write/update path; there is no other “write memory” Action.

### 1.4 Auth expectations for Actions

Auth is used to control which callers can reach the Lambda Function URL.

Canonical assumption: the Function URL uses **no additional HTTP auth** (auth type "None") and is treated as an internal URL. The spec does not define or rely on auth headers.

Optional extensions (deployment-time only, not part of this spec):

1. **API key header enforced at the front door** (API Gateway/ALB) with only authorised requests forwarded.
2. **External front door** handling OAuth/IAM or similar before invoking the Lambda.

Auth choices do not change the HTTP contract (paths, bodies, or error shapes) of `/pre` and `/post`.

### 1.5 MCP tools

Two MCP tools (`memory_pre`, `memory_post`) mirror `/pre` and `/post` and call `handle_pre` / `handle_post` directly. They bypass the Lambda cold-start healthcheck and HTTP error mapping; errors surface directly to the MCP client. An optional helper `run_mcp_healthcheck()` in `app/mcp_server.py` can be invoked at process start to mirror the Lambda guard.

---

## 2. Logical data model

### 2.1 Core identifiers

Two string identifiers define each conversational branch:

* `root_session_id` — identifies a long‑running topic or project. All related branches share this value and therefore share a semantic memory pool.
* `session_id` — identifies a specific branch under the root. Branches can diverge but still access the same root‑level semantic memory.

Within each `(root_session_id, session_id)` pair, a monotonically increasing integer `sequence` orders events.

### 2.2 Event

An `Event` represents a single immutable conversational turn or similar unit.

Key fields:

* `event_id` — globally unique identifier.
* `root_session_id`, `session_id`, `sequence`.
* `role` — one of `user`, `assistant`, `system`, or `tool`.
* `content` — string payload, typically text.
* `created_at` — UTC timestamp as an ISO 8601 string.
* Additional metadata for future use (optional).

Events are never edited in place by the system.

### 2.3 BranchState

`BranchState` captures the current rolling context for a branch:

* `short_summary` — concise LLM‑generated summary of the branch, or null when not yet generated.
* `recent_events` — list of the most recent events for this branch, kept in chronological order and limited in size.
* `next_sequence` — the next integer sequence number to assign.
* `summary_turns_since_update` — count of assistant turns since the last summary refresh.

### 2.4 SemanticHit

A `SemanticHit` is the result of a semantic search:

* `text` — retrieved content snippet.
* `score` — numeric relevance score.
* `metadata` — attributes attached at index time, including identifiers and timestamps.

Immutability and ordering are realised operationally: Events are written
append-only to S3 transcripts, and BranchState update logic appends in
sequence order while trimming `recent_events` to a bounded, chronological
buffer.

---

## 3. Physical storage design

### 3.1 S3 transcript bucket

Purpose: persistent, append‑only log of events per branch.

* A single S3 bucket (name via `TRANSCRIPT_BUCKET`) holds all transcripts.
* For each branch, there is a JSONL file at:
  `sessions/{root_session_id}/{session_id}.log.jsonl`.
* Each line in the file is one serialised `Event`, in order of append.

Assumptions:

* Only this Lambda function appends to each branch’s file.
* Append is implemented as read–modify–write (not a true atomic append), so concurrent writers to the same branch are not supported.
* The system does not modify or delete existing lines; deletion, if ever needed, is a separate operational concern. Enable bucket versioning if auditability is required.

### 3.2 DynamoDB branch state table

Purpose: fast access to current branch state.

* A single DynamoDB table (name via `STATE_TABLE`) stores `BranchState` records.
* Primary key is composite:

  * Partition key `PK`: `root_session_id`.
  * Sort key `SK`: `session_id`.
* Each item’s body is a serialised `BranchState`.

Access patterns are simple key‑value reads and writes; no secondary indexes are required.

### 3.3 OpenAI vector store

Purpose: semantic recall over past assistant messages.

* A single OpenAI vector store (ID via `OPENAI_VECTOR_STORE_ID`) is dedicated to `memory-agent`.
* Its embedding model corresponds to `EMBEDDING_MODEL_NAME` (canonical `text-embedding-3-large`).

Indexing rules:

* On each post‑phase, the assistant message is uploaded as a file to the vector store. OpenAI handles chunking and embedding server‑side using the store’s configured embedding model.
* Only assistant messages are indexed; user turns are not uploaded.
* A static chunking strategy is used, governed by token size and overlap settings from configuration (defaults: 800 tokens, 0 overlap).
* The upload sets attributes including: `root_session_id`, `session_id`, `id` (event ID), `event_id` (duplicate of `id` for clarity), `sequence`, `role`, `created_at`, and a `kind` field (for example, `assistant_turn`).

Search rules:

* Queries are based on the current `user_message`.
* Searches are filtered by `root_session_id` to avoid cross‑topic contamination. This is the **default/current behaviour**; all branches under the same root share semantic memory.
* Optionally, searches may also filter by `session_id` for more narrow recall; enable via `SEMANTIC_SEARCH_SCOPE=session`.
* The service returns the top results as `SemanticHit` objects.

When `SEMANTIC_BACKEND` is `none`, indexing and search are disabled, and semantic recall is not used.

---

## 4. Request pipelines

### 4.1 `/pre` pipeline

Summary: given a new user message and branch identifiers, return the current summary, recent transcript, and semantic hits.

High‑level steps:

1. **Startup guard**
   On cold start, the Lambda runs a one‑time healthcheck to validate configuration and basic connectivity. Subsequent invocations skip this step.

2. **Configuration load**
   Environment variables are loaded into a `Settings` structure. Checks include:

   * Required variables are present.
   * The embedding model name is recognised.
   * If semantic backend is `openai`, a vector store ID is configured.
   * Optional chunking parameters for semantic memory are parsed.

3. **Branch state load**
   The system reads `BranchState` for the `(root_session_id, session_id)` from DynamoDB. If no item exists, an in‑memory default state is constructed.

4. **Semantic search (conditional)**
   If `SEMANTIC_BACKEND` is `openai`, the system:

   * Sends a search request to the vector store. The service embeds the query using the store’s embedding model.
   * Applies a filter that includes the `root_session_id` (and optionally `session_id`).
   * Collects the top results as `semantic_hits`.

   If `SEMANTIC_BACKEND` is `none`, semantic search is skipped and `semantic_hits` is an empty list.

5. **Response**
   The system returns a `PrePhaseResponse` with:

   * `short_summary` from the branch state.
   * `recent_events` from the branch state.
   * `semantic_hits` as computed above (currently filtered by `root_session_id` only; branches under the same root share semantic memory).
   This pipeline is read-only; it does not write transcripts or branch state.

### 4.2 `/post` pipeline

Summary: given user and assistant messages for a branch, log the events, update rolling memory, and index semantic memory.

High‑level steps:

1. **Configuration and state load**
   As in `/pre`, the system loads `Settings` and then loads the corresponding `BranchState`.

2. **Sequence allocation**
   The `next_sequence` value in `BranchState` is used to assign sequence numbers to:

   * A new user event.
   * A new assistant event.
     The `next_sequence` counter is advanced accordingly.

3. **Event construction**
   Two `Event` objects are created, using the identifiers, assigned sequences, current timestamps, roles, and contents.

4. **Transcript append (S3)**
   Both events are serialised and appended to the branch’s JSONL transcript file in S3, under the key derived from `root_session_id` and `session_id`.
   Append is a read–modify–write per branch; concurrent writers are not supported.

5. **Short‑term memory update**
   The events are passed to the short‑term memory logic, which:

   * Extends the `recent_events` list.
   * Increments the `summary_turns_since_update` counter on assistant events.
   * When thresholds are reached (current defaults: at least 6 assistant turns since last summary or buffer at 40 events), regenerates the `short_summary` using the summary model.
   * Trims `recent_events` to an upper bound (default: last 40 events).

6. **Semantic indexing (conditional)**
   If `SEMANTIC_BACKEND` is `openai`, the system:

   * Uploads the assistant message as a file to the vector store with metadata (root/session IDs, event IDs, timestamps, etc.).
   * OpenAI performs chunking and embedding based on the configured store settings; no embeddings are produced locally.

   If `SEMANTIC_BACKEND` is `none`, semantic indexing is skipped.

7. **Branch state persistence**
   The updated `BranchState` is written back to DynamoDB (simple upsert, no conditional write), replacing the previous state for that branch.

8. **Response**
   The system returns a simple object indicating success.

### 4.3 Error handling and retry posture

* Failures bubble as 500s; there is no partial rollback. If the transcript append succeeds but DynamoDB or semantic indexing fails, the transcript may contain events that are not reflected in `BranchState` or semantic memory.
* Client retries of `/post` will create duplicate events because the service does not deduplicate. Prefer at‑least‑once delivery at the orchestrator level with manual inspection if failures occur.

---

## 5. Configuration model

### 5.1 Settings surface

Configuration is centralised in a `Settings` structure populated from environment variables so environments can change without code edits. Canonical model names are examples (`gpt-5.1`, `text-embedding-3-large`); they remain configurable rather than hard-coded.

Key configuration items (env-driven):

* **AWS region and resources** — `AWS_REGION`, `TRANSCRIPT_BUCKET`, `STATE_TABLE`.
  * Account-specific resource names are omitted from this public snapshot (account `000000000000`, region `ap-southeast-2`).
* **OpenAI access and models**

  * `OPENAI_API_KEY` (secret injected by infra).
  * `SUMMARY_MODEL_NAME` (example: `gpt-5.1`).
  * `EMBEDDING_MODEL_NAME` (example: `text-embedding-3-large`) validated against the internal dimension map.
  * `OPENAI_VECTOR_STORE_ID` (semantic memory store ID).

* **Semantic backend control**

  * `SEMANTIC_BACKEND` in `{openai, none}` (defaults to `openai` when unset).
  * `SEMANTIC_SEARCH_SCOPE` in `{root, session}` (defaults to `root`); when set to `session`, `/pre` includes `session_id` in semantic search filters.
  * Optional chunking controls: `SEMANTIC_CHUNK_SIZE_TOKENS` (default 800), `SEMANTIC_CHUNK_OVERLAP_TOKENS` (default 0).
  * When `SEMANTIC_BACKEND=openai`, a vector store ID must be supplied.

* **Healthcheck behaviour** — `HEALTHCHECK_LLM_CALLS` flag controls whether healthcheck makes test LLM/embedding calls vs. config/connectivity-only checks. `HEALTHCHECK_WRITE_PROBES` (default false) enables lightweight write/read probes to S3 and DynamoDB.
* **Logging** — `LOG_LEVEL` controls verbosity of structured JSON logs emitted to stdout/stderr (default `INFO`).

Secrets (OpenAI key, any future API keys) are injected via environment variables by infrastructure (for example, AWS Secrets Manager or SSM parameters wired to Lambda environment).

### 5.2 Validation behaviour

When `Settings` are loaded:

* Missing required variables cause a configuration error.
* An unknown embedding model name (not in the internal dimension map) causes a configuration error listing supported models.
* Selecting `openai` as semantic backend while omitting a vector store ID causes a configuration error.

Configuration errors are surfaced at startup (for example, during Lambda cold start) so misconfiguration is detected early.

---

## 6. Local development model (conceptual)

This section describes what must exist for local development and testing, without prescribing commands.

* Python 3.12 is available inside the WSL Ubuntu instance (Python 3.13 is not supported due to current black/ruff incompatibilities).
* The repo root (containing the `app` package and Lambda entrypoint) is opened in VS Code.
* Dependencies from `pyproject.toml` are installed into an isolated virtualenv (for example, `.venv`).
* All commands that touch the repo (pip, pytest, scripts, packaging) are executed via `.venv/bin/python`; `.python-version` and `pyproject.toml` keep that interpreter pinned to 3.12.x.
* A local configuration mechanism (such as a `.env` file loaded by a runner or VS Code config) supplies the environment variables consumed by `Settings` (Section 5).
* Tests live under `tests/` and run locally with `.venv/bin/python -m pytest`; AWS and OpenAI calls are live (no mocks) and the gated vector store test must run when `OPENAI_INTEGRATION=1` and `OPENAI_VECTOR_STORE_ID` are set.
* Local harness patterns:

  * Construct request objects for `/pre` and `/post` and call `handle_pre` / `handle_post` directly.
  * Optionally call `lambda_handler.lambda_handler` with fake events to mirror the Lambda entrypoint.
  * For any exploratory/offline prototyping you may stub dependencies, but acceptance and the canonical test runs assume live AWS/OpenAI connectivity.

---

## 7. AWS infrastructure model

This section defines which AWS resources must exist, not how they are created.

### 7.1 S3

* One S3 bucket in `ap-southeast-2` is dedicated to transcript storage (name via `TRANSCRIPT_BUCKET`).
* Public access is blocked.
* Server‑side encryption is enabled. Enable bucket versioning if auditability or recovery of prior transcript versions is required; the code does not enforce versioning.

### 7.2 DynamoDB

* One DynamoDB table in `ap-southeast-2` stores `BranchState` records (name via `STATE_TABLE`).
* Primary key: partition key `PK` and sort key `SK`.
* On‑demand billing mode is sufficient for typical usage.
* No secondary indexes are required.

### 7.3 Lambda execution role

* An IAM role is created for the Lambda function.
* It is trusted by the Lambda service and granted:

  * Logging permissions (e.g. CloudWatch logs).
  * Read/write access to the transcript bucket.
  * Read/write access to the DynamoDB state table.

### 7.4 Lambda function

* A single Lambda function contains the `memory-agent` code (`lambda_handler.lambda_handler` entrypoint) and routes `/pre` and `/post`.
* Runtime: Python 3.12.
* Environment variables are set according to the `Settings` model (Section 5).

### 7.5 Lambda Function URL

* A Function URL is attached to the Lambda as the canonical HTTP entrypoint for `/pre` and `/post`.
* Auth mode is set according to the chosen security model (none initially, with the option to introduce stronger auth later).
* The Custom GPT Actions use this Function URL as their base URL.

API Gateway can be introduced later if additional features are required, but it is not part of the canonical minimal architecture.

---

## 8. OpenAI vector store model

* A single OpenAI vector store is provisioned for `memory-agent` (ID via `OPENAI_VECTOR_STORE_ID`).
* The store’s embedding model matches `EMBEDDING_MODEL_NAME`; embeddings are computed inside the store, not by the service.
* Only assistant messages (or their chunks) are indexed. Each upload includes metadata: `root_session_id`, `session_id`, `event_id`, `sequence`, `role`, `created_at`, `kind`, and any other existing attributes needed to reconstruct context and filter by root/session.

Search behaviour:

* Query text is derived from the current user message.
* Searches are filtered by `root_session_id` (and may also filter by `session_id`).
* Results are returned as `SemanticHit` objects with text, score, and metadata.

If `SEMANTIC_BACKEND` is `none`, indexing and search are not performed.

---

## 9. Health and operations

### 9.1 Startup healthcheck

On Lambda cold start, `lambda_handler` uses a cold-start guard (`_HEALTHCHECK_RAN`) to run `run_healthcheck()` exactly once per process. The check:

* Loads configuration via `load_settings()` (required env vars, embedding model dimension map, semantic backend + vector store rules).
* Verifies the DynamoDB table exists and is reachable (simple describe/load call).
* Verifies the transcript S3 bucket exists and is reachable (for example, a lightweight list/head).
* When `HEALTHCHECK_WRITE_PROBES=true`, performs a lightweight write/delete probe against both DynamoDB and S3 using temporary keys to exercise IAM permissions.
* When `SEMANTIC_BACKEND=openai`, retrieves the configured vector store by ID to ensure reachability and logs a warning if the store’s embedding model does not match `EMBEDDING_MODEL_NAME` (best-effort, non-fatal).
* When `HEALTHCHECK_LLM_CALLS=true`, makes minimal embedding and summarisation calls via the LLM client.

Any failure causes the cold start to fail fast and surface a 500 on that first invocation.

### 9.2 Normal runtime expectations

Under normal operation:

* Each `/post` call:

  * Constructs two events (user then assistant) and appends them to the branch transcript via `append_events` (S3 JSONL).
  * Updates branch memory with `update_branch_state_with_events` (recent events and summary heuristics).
  * When `SEMANTIC_BACKEND=openai`, indexes the assistant message into the vector store via `index_memory`.
  * Persists the updated branch state as exactly one `BranchState` item in DynamoDB via `save_branch_state`.

* Each `/pre` call:

  * Reads at most one `BranchState` item from DynamoDB via `load_branch_state`.
  * Performs at most one semantic search via `search_memory` when enabled; skipped when `SEMANTIC_BACKEND=none`.
  * Returns a `PrePhaseResponse` with `short_summary`, `recent_events`, and `semantic_hits`.

Observability and debugging rely on:

* Lambda logs in CloudWatch.
* The presence and contents of branch transcript objects in S3.
* Items in the DynamoDB table for selected branches.
* Vector store contents visible via OpenAI tools.

### 9.3 Operational hygiene and instrumentation

*Current code posture:*

* Structured JSON logging to stdout/stderr with correlation fields (request_id, path, method, status_code, root/session IDs).
* No in-code metrics or alarms.
* No automated lifecycle management; transcripts and state are retained indefinitely.
* No reconciliation tooling beyond inspecting transcripts and DynamoDB state.

*Recommended for production hardening:*

* Structured logs around `/pre` and `/post` carrying path, request IDs, root/session IDs, and event IDs to ease partial-write diagnosis.
* CloudWatch metrics and alarms on 4xx/5xx rates, duration, and counts of `/pre` and `/post`, plus dependency failure counters (S3/DynamoDB/OpenAI).
* Lifecycle policies for S3 transcripts and DynamoDB retention according to your data hygiene requirements.
* An operational runbook to rebuild `BranchState` from transcripts if S3 and DynamoDB drift (for example, S3 append succeeds but Dynamo write fails) using the helper in `app/reconcile_state.py`.

Reconciliation runbook (manual):
1. Read the transcript object from S3 at `sessions/{root_session_id}/{session_id}.log.jsonl`.
2. Feed the JSONL lines into `reconcile_branch_state_from_transcript` (library-only helper) with the desired root/session IDs; optionally provide `LLMClient` to refresh `short_summary`.
3. Persist the returned `BranchState` back to DynamoDB (PK=`root_session_id`, SK=`session_id`) via `save_branch_state`.

---

## 10. Model evolution rules

The system is designed to tolerate model evolution without structural changes:

* Model names are configuration-driven, not hard-coded.
* Canonical defaults: `SUMMARY_MODEL_NAME=gpt-5.1`, `EMBEDDING_MODEL_NAME=text-embedding-3-large`.
* Changing the summary model is a configuration-only change; no storage migration is needed.
* Changing the embedding model creates a new semantic memory generation:
  * Provision a new vector store configured with the new embedding model.
  * Point `OPENAI_VECTOR_STORE_ID` at that new store for all subsequent indexing/search.
  * Older stores become legacy generations and are not mixed with new embeddings.
* Tests enforce that `EMBEDDING_MODEL_NAME` exists in the internal embedding dimension map; unknown models fail fast at startup.

This keeps the architecture stable while allowing model upgrades with deliberate vector store rotation.

---

## 11. Testing and validation ladder

This ladder is now live-first: every phase touches real dependencies (AWS and/or OpenAI). Mock-only validation is out of scope for acceptance; the steps below are executed against real resources with the configured environment.

### 11.1 Environment and healthcheck

* Use `.venv` with dependencies installed from `pyproject.toml`.
* Load real env (`AWS_REGION`, `TRANSCRIPT_BUCKET`, `STATE_TABLE`, `OPENAI_API_KEY`, model names, `OPENAI_VECTOR_STORE_ID`, `SEMANTIC_BACKEND`).
* Run `run_healthcheck()` locally; it must reach DynamoDB, S3, and the OpenAI vector store, and pass optional LLM probes when enabled.

### 11.2 AWS connectivity with semantic backend disabled (live S3/Dynamo)

* Set `SEMANTIC_BACKEND=none`.
* Perform one `/post` and one `/pre` locally (lambda_handler or handler) with real AWS resources.
* Verify S3 has `sessions/{root}/{session}.log.jsonl` and Dynamo has `PK=root, SK=session` with correct fields. No OpenAI calls should occur.

### 11.3 OpenAI + vector store integration (live)

* Set `SEMANTIC_BACKEND=openai` with real `OPENAI_VECTOR_STORE_ID`.
* Run the OpenAI/vector store integration test gated by `OPENAI_INTEGRATION=1`.
* Drive a small conversation through post/pre locally; confirm semantic_hits returns the indexed assistant text. S3/Dynamo should be updated.

### 11.4 Lambda/Function URL parity (live)

* Deploy Lambda with the same config (region, bucket, table, models, backend, vector store ID).
* Call `POST /pre` and `POST /post` via the Function URL; confirm responses match local, S3/Dynamo contents match expectations, and semantic search works.
* Healthcheck should run once per cold start and fail fast on misconfig.

### 11.5 Custom GPT Actions end-to-end (live)

* Configure exactly two Actions mapping to `POST /pre` and `POST /post` against the Function URL.
* Run a controlled conversation; verify GPT uses returned context and memory updates persist across turns (transcripts, BranchState, semantic hits).

### 11.6 Observability and logging (live)

* Confirm structured JSON logs include request_id, path, method, root_session_id, session_id, status_code/stage fields for `/pre` and `/post`.
* Inspect logs during live runs (local, Lambda, MCP if applicable) to ensure they match `tests/test_logging_spec.py` expectations.

### 11.7 MCP surface (live)

* Run `run_mcp_healthcheck()` and exercise `memory_pre`/`memory_post` via the MCP server entrypoints with real AWS/OpenAI backing.
* Validate S3/Dynamo updates and semantic search via MCP paths mirror the HTTP/Lambda behaviour.

### 11.8 Ongoing audit and hardening (live validation)

* When behaviour or config changes, rerun the live phases above (at minimum 11.1–11.3; include 11.4–11.7 when deployment surfaces or MCP/Actions are affected).
* Keep tests, code, and docs aligned with this live-first ladder; acceptance requires the applicable live phases to pass.
