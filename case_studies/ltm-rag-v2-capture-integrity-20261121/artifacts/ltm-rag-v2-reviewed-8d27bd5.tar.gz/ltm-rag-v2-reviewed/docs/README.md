# Docs index

## Live RAG activation ladder

Run against the deployed Function URL from repo root with a configured virtualenv:

```bash
LIVE_RAG=1 LIVE_LAMBDA_URL=<function-url> .venv/bin/python scripts/turn_rag_probe.py --require-graph=true
LIVE_RAG=1 LIVE_LAMBDA_URL=<function-url> .venv/bin/python -m pytest -q tests/test_rag_activation_live.py -rs
```

Notes:
- `LIVE_LAMBDA_URL` (or `LIVE_FUNCTION_URL`/`MEMORY_AGENT_URL`) must point at the live Lambda Function URL.
- `REQUIRE_GRAPH=1` forces the pytest wrapper to fail if graph facts are absent; otherwise graph is best-effort.
