# Hygiene Summary

## Observed interpreters
- `.venv/bin/python` — Python 3.12.3 inside the repo-root virtualenv. This interpreter now powers every automation gate (tests, scripts, packaging).
- `python` (a pyenv shim) and `python3.12` — both resolve to Python 3.12.3 on this machine and are the installers used to bootstrap `.venv`, but they are not allowed to run repo automation directly.

## Canonical interpreter
- `.venv/bin/python` (3.12.3) is the single source of truth for the repository. The new `.python-version` file pins this patch release for pyenv users and guards `pyproject.toml`’s `requires-python` range. README/README_tests/Canonical ImplementationV2/docs/README now document that every command—pip installs, pytest runs, scripts, packaging—must be executed via `.venv/bin/python`.

## Changes made (files + rationale)
- `.python-version`: pins Python 3.12.3 so pyenv automatically matches the Lambda runtime and the `.venv` interpreter.
- `README.md`: added a hygiene section, clarified that Python 3.12.x is required, documented that every command goes through `.venv/bin/python`, updated installation/deployment snippets, and pointed to this hygiene report.
- `README_tests.md`: rewrote the “How to run” commands to explicitly call `.venv/bin/python -m pytest` and noted that `make test-*` uses the same runner (and that Python 3.13 is blocked due to black/ruff conflicts).
- `Canonical ImplementationV2.md`: reinforced that `.venv/bin/python` is the interpreter for every repo action, that the tests invoke `.venv/bin/python -m pytest`, and that Python 3.13 is not supported.
- `docs/README.md`: updated the live RAG commands so the pytest invocation goes through `.venv/bin/python -m pytest`, fixing a stray `.venv/bin/pytest`.
- `scripts/turn_rag_probe.py`: aligned the hard-coded Python version facts with the pinned 3.12.3 target.
- `scripts/turn_size_probe.py`: updated the usage example to show `.venv/bin/python` as the invoker.
- `Makefile`: introduced a `PYTHON` variable pointing at `.venv/bin/python`, added a version gate that errors if `.venv/bin/python` is not Python 3.12.x (to avoid black/ruff 3.13 issues), and made every pytest target call this interpreter.
- `tests/test_repo_hygiene.py`: new test that verifies `sys.executable`, `sys.version_info`, the `.venv/bin/python --version`, and the pytest module all come from `.venv`.

## Hygiene tests
- `tests/test_repo_hygiene.py` fails fast when the current process is not using `.venv/bin/python`, when the interpreter reports something other than Python 3.12.x, when the canonical runner reports a different `--version`, or when pytest lives outside the `.venv`. Run it with `.venv/bin/python -m pytest tests/test_repo_hygiene.py -q`.
