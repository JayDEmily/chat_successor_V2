# Knobs & Dials (Registry)

Single canonical registry of every tunable variable in this repo that affects memory behaviour, retrieval, S3 rehydration, graph memory, response budgets/truncation, gating/heuristics, and live-test operation. Every entry below is grounded in code (env var names, defaults, and constants) with the defining file + symbol.

## Coefficient presets

- `COEFFICIENTS_PRESET` selects a versioned baseline preset (default `v1`).
- Preset files live at `app/coefficients/presets/{preset}.json`.
- Preset defines baseline knob values; per-env overrides should be avoided unless explicitly recorded.

## Registry table (core)

| Knob name | Code key / env var | Default (exact from code) | Type | Scope | Effect | Failure mode | Where defined (file + symbol) |
|---|---:|---:|---|---|---|---|---|
| AWS region | `AWS_REGION` | `None` | `str` | infra | Selects AWS region for all boto3 clients (S3/DynamoDB/SQS). | Startup fails with `ConfigError` when missing/empty. | `app/config.py:load_settings()` via `_require_env()` |
| Transcript bucket | `TRANSCRIPT_BUCKET` | `None` | `str` | infra | S3 bucket that stores JSONL transcripts (`sessions/{root}/{session}.log.jsonl`). | Startup fails with `ConfigError` when missing/empty; runtime S3 errors if bucket wrong. | `app/config.py:load_settings()` via `_require_env()`, `app/transcript_logger.py:_transcript_key()` |
| Branch state table | `STATE_TABLE` | `None` | `str` | infra | DynamoDB table for `BranchState` and semantic index markers. | Startup fails with `ConfigError` when missing/empty; runtime Dynamo errors if table wrong. | `app/config.py:load_settings()` via `_require_env()`, `app/state_manager.py` |
| OpenAI API key | `OPENAI_API_KEY` | `None` | `str` | infra | Auth for OpenAI calls (summaries, vector store search/index, graph extraction). | Startup fails with `ConfigError` when missing/empty; OpenAI calls fail if invalid. | `app/config.py:load_settings()` via `_require_env()` |
| Summary model id | `SUMMARY_MODEL_NAME` | `None` | `str` | turn, graph | Model used for rolling summaries and graph extraction calls. | Startup fails with `ConfigError` when missing/empty; OpenAI call fails if invalid model id. | `app/config.py:load_settings()` via `_require_env()`, `app/llm_client.py:LLMClient.summarise()` / `extract_memories()` |
| Embedding model id | `EMBEDDING_MODEL_NAME` | `None` | `str` | retrieval | Model used for embeddings (must match known dims map). | Startup fails with `ConfigError` if model not in `EMBEDDING_DIMS`; OpenAI call fails if invalid. | `app/config.py:EMBEDDING_DIMS`, `app/config.py:Settings.embedding_dim` |
| Semantic backend | `SEMANTIC_BACKEND` | `"openai"` | `str` | retrieval, turn | Selects semantic memory backend (`openai` enables vector store, `none` disables semantic search/index). | Startup fails with `ConfigError` if not in `{"openai","none"}`. | `app/config.py:SEMANTIC_BACKENDS`, `app/config.py:load_settings()` |
| OpenAI vector store id | `OPENAI_VECTOR_STORE_ID` | `None` | `str \| None` | retrieval, graph | Vector store used for semantic indexing/search and optional graph fact vector upload/search. | Startup fails with `ConfigError` if `SEMANTIC_BACKEND=openai` and missing; graph vector upload/search skips/warns if missing. | `app/config.py:load_settings()`, `app/semantic_memory.py`, `app/graph_vector_store.py:GraphFactVectorStore` |
| Coefficients preset | `COEFFICIENTS_PRESET` | `"v1"` | `str` | config | Selects a versioned coefficient preset loaded from `app/coefficients/presets/{preset}.json`. | Startup fails with `ConfigError` if preset is missing/malformed. | `app/config.py:load_settings()`, `app/coefficients/loader.py:load_coefficients_preset()` |
| Semantic chunk size (tokens) | `SEMANTIC_CHUNK_SIZE_TOKENS` | `512` | `int` | retrieval | Managed by coefficient presets; controls OpenAI vector store chunking (`max_chunk_size_tokens`) during semantic indexing. | Startup fails with `ValueError` if non-int; chunking behaviour changes recall/latency. | `app/config.py:load_settings()`, `app/semantic_memory.py:index_memory()` |
| Semantic chunk overlap (tokens) | `SEMANTIC_CHUNK_OVERLAP_TOKENS` | `192` | `int` | retrieval | Managed by coefficient presets; controls OpenAI vector store chunk overlap during semantic indexing. | Startup fails with `ValueError` if non-int. | `app/config.py:load_settings()`, `app/semantic_memory.py:index_memory()` |
| Semantic search scope | `SEMANTIC_SEARCH_SCOPE` | `"root"` | `str` | retrieval | Controls whether semantic search filters include `session_id` (`session`) or not (`root`). | Startup fails with `ConfigError` if not in `{"root","session"}`; mis-set changes recall surface across branches. | `app/config.py:SEMANTIC_SEARCH_SCOPES`, `app/handler.py:handle_pre()` |
| Healthcheck LLM calls | `HEALTHCHECK_LLM_CALLS` | `False` | `bool` | infra | Toggles healthcheck doing a real embedding + summary call. | Healthcheck fails (cold start fails) if OpenAI is unreachable/misconfigured. | `app/config.py:_get_bool_env()`, `app/healthcheck.py:run_healthcheck()` |
| Healthcheck write probes | `HEALTHCHECK_WRITE_PROBES` | `False` | `bool` | infra | Toggles healthcheck doing write/delete probes to DynamoDB + S3. | Healthcheck fails if IAM policies don’t allow write/delete. | `app/config.py:_get_bool_env()`, `app/healthcheck.py:run_healthcheck()` |
| Log level | `LOG_LEVEL` | `"INFO"` | `str` | infra | Logging verbosity; unknown values fall back to `"INFO"`. | Mis-set falls back silently to `"INFO"`. | `app/config.py:_get_log_level()`, `app/logging_utils.py:init_logging()` |
| Response budget (bytes) | `RESPONSE_BUDGET_BYTES` | `220000` | `int` | budgeting, turn | Managed by coefficient presets; caps JSON response size and triggers truncation/dropping in `enforce_response_budget()`. | Startup fails with `ValueError` if non-int; `<=0` disables truncation (response may exceed downstream limits). | `app/config.py:load_settings()`, `app/response_budget.py:enforce_response_budget()` |
| Rehydration window radius (events) | `S3_REHYDRATION_WINDOW_EVENTS` | `3` | `int` | rehydration | Managed by coefficient presets; window radius around a semantic hit anchor when loading S3 transcript context. | Startup fails with `ValueError` if non-int; negative coerces to `0` window radius in `select_window_events()`. | `app/config.py:load_settings()`, `app/rehydration.py:rehydrate_semantic_hits()` |
| Max rehydrated windows returned | `MAX_REHYDRATED_WINDOWS` | `2` | `int` | rehydration, budgeting | Managed by coefficient presets; caps returned `rehydrated_s3_windows`. | If set too low, rehydration context is missing; if set `<0`, startup fails with `ConfigError`. | `app/config.py:load_settings()`, `app/rehydration.py:rehydrate_semantic_hits()` |
| Rehydration max total events | `REHYDRATION_MAX_TOTAL_EVENTS` | `14` | `int` | rehydration, budgeting | Managed by coefficient presets; hard cap on total returned `window_events` across all S3 rehydration windows per turn. | If set too low, rehydration context is missing; if set `<0`, startup fails with `ConfigError`. | `app/config.py:load_settings()`, `app/rehydration.py:rehydrate_semantic_hits()` |
| Recent events return cap | `RECENT_EVENTS_RETURN_CAP` | `12` | `int` | turn, budgeting | Managed by coefficient presets; caps the number of `recent_events` returned in `/pre` and `/turn` (does not change the stored buffer). | If set too low, short-term context is missing; if set `<0`, startup fails with `ConfigError`. | `app/config.py:load_settings()`, `app/handler.py:handle_pre()` |
| Summary return max chars | `SUMMARY_RETURN_MAX_CHARS` | `900` | `int` | turn, budgeting | Managed by coefficient presets; truncates `short_summary` returned in `/pre` and `/turn` (does not change stored summary). | If set too low, summary loses signal; if set `<0`, startup fails with `ConfigError`. | `app/config.py:load_settings()`, `app/handler.py:handle_pre()` |
| Graph enable | `GRAPH_ENABLED` | `False` | `bool` | graph | Enables graph enqueue on `/post` and graph read path on `/pre`/`/turn`. | Startup fails with `ConfigError` if true without `MEMORY_NODES_TABLE`/`GRAPH_EVENTS_QUEUE_URL`. | `app/config.py:load_settings()`, `app/handler.py:handle_pre()` / `handle_post()` |
| Graph vector index enable | `GRAPH_VECTOR_INDEX_ENABLED` | `False` | `bool` | graph | Enables graph worker uploading consolidated facts to OpenAI vector store. | If true with missing `OPENAI_VECTOR_STORE_ID`, upload logs warning and skips. | `app/config.py:load_settings()`, `app/graph_worker_handler.py:lambda_handler()` |
| Graph facts table | `MEMORY_NODES_TABLE` | `None` | `str \| None` | graph, infra | DynamoDB table holding consolidated `MemoryNode` rows and markers. | Startup fails with `ConfigError` when `GRAPH_ENABLED=true` and missing. | `app/config.py:load_settings()`, `app/graph_store.py:get_memory_nodes_table()` |
| Graph events queue URL | `GRAPH_EVENTS_QUEUE_URL` | `None` | `str \| None` | graph, infra | SQS FIFO queue URL receiving graph pipeline work items from `/post`. | Startup fails with `ConfigError` when `GRAPH_ENABLED=true` and missing; enqueue fails at runtime if unset. | `app/config.py:load_settings()`, `app/graph_pipeline.py:enqueue_graph_job()` |
| Semantic search top‑K | `SEMANTIC_SEARCH_TOP_K` | `12` | `int` | retrieval | Managed by coefficient presets; number of vector store hits requested per semantic query. | Higher values increase response size and downstream truncation risk; lower values reduce recall. | `app/config.py:load_settings()`, `app/handler.py:handle_pre()`, `app/semantic_memory.py:search_memory()` |
| Semantic return hits cap | `SEMANTIC_RETURN_HITS_CAP` | `8` | `int` | retrieval, budgeting | Managed by coefficient presets; caps the number of `semantic_hits` returned in `/pre` and `/turn`. | If set too low, semantic evidence is missing; if set `<0`, startup fails with `ConfigError`. | `app/config.py:load_settings()`, `app/handler.py:handle_pre()` |
| Semantic index roles | `SEMANTIC_INDEX_ROLES` | `["user","assistant"]` | `list[str]` | retrieval, turn | Managed by coefficient presets; controls which event roles are eligible for semantic indexing on `/post`. | If mis-set, indexing skips roles or fails at startup if invalid JSON; can change recall surface. | `app/config.py:load_settings()`, `app/handler.py:handle_post()` |
| User message semantic indexing | `_maybe_index_event(user_event, salient=True, kind="user_message")` | `True` | `bool` | retrieval, turn | User events are treated as salient and indexed to semantic memory (deduped via semantic markers). | Increased indexing volume/cost; noisy user content can dilute semantic recall. | `app/handler.py:handle_post()` (`_maybe_index_event(...)`) |
| Graph vector search top‑K | `max_num_results` in `search_graph_memory_vector()` | `6` | `int` | graph | Number of vector store hits requested when graph facts fall back to vector search. | Higher values increase response size and truncation risk; lower values reduce graph recall. | `app/graph_retrieval.py:search_graph_memory_vector()` |
| Graph retrieval session scoping | `MemoryNode.source_session_ids` | `source_session_ids == [] ⇒ global` | `policy` | graph | Nodes with non-empty `source_session_ids` are returned only when the current `session_id` is included; nodes with empty `source_session_ids` are treated as applicable to all sessions. | Mis-scoping can leak facts across branches or hide relevant facts. | `app/graph_retrieval.py:load_graph_memory()` |
| Recent events cap | `RECENT_EVENTS_MAX` | `40` | `int` | turn | Bounds `BranchState.recent_events` buffer (also forces summary refresh when hit). | If too low, short-term context is lost; if too high, more state/response bytes. | `app/short_term_memory.py:RECENT_EVENTS_MAX` |
| Summary cadence (assistant turns) | `SUMMARY_MIN_TURNS` | `6` | `int` | turn | Minimum assistant turns between rolling summary refreshes. | If too low, extra LLM calls; if too high, summary stales. | `app/short_term_memory.py:SUMMARY_MIN_TURNS` |
| Summary max output tokens | `max_completion_tokens` | `512` | `int` | budgeting, turn | Caps summary length produced by the summary model. | If too low, summary quality may degrade; if too high, higher OpenAI cost/latency. | `app/llm_client.py:LLMClient.summarise()` |
| Semantic hit text cap (chars) | `MAX_SEMANTIC_HIT_CHARS` | `2000` | `int` | budgeting, retrieval | Truncates `SemanticHit.text` before dropping hits to fit response byte budget. | If too low, hits lose evidence; if too high, response truncation escalates earlier. | `app/response_budget.py:MAX_SEMANTIC_HIT_CHARS` |
| Recent event content cap (chars) | `MAX_RECENT_EVENT_CHARS` | `4000` | `int` | budgeting, turn | Truncates `Event.content` in `recent_events` before dropping events to fit budget. | If too low, context lost; if too high, response truncation escalates earlier. | `app/response_budget.py:MAX_RECENT_EVENT_CHARS` |
| Summary text cap (chars) | `MAX_SUMMARY_CHARS` | `2000` | `int` | budgeting, turn | Truncates `short_summary` before progressive shrinking to fit budget. | If too low, summary loses signal; if too high, response truncation escalates earlier. | `app/response_budget.py:MAX_SUMMARY_CHARS` |
| Response truncation order | fixed in `enforce_response_budget()` | `["drop graph_memory_history","truncate semantic hit text (2000) then drop tail hits","truncate recent event content (4000) then drop oldest events","truncate summary (2000) then progressively shrink","last resort clear hits/events/summary (+graph_history)","then truncate windows to anchors and drop tail windows"]` | `list[str]` | budgeting | Defines the order fields are removed/truncated to fit `RESPONSE_BUDGET_BYTES`. | Mis-match to client expectations if downstream assumes fields are always present. | `app/response_budget.py:enforce_response_budget()` |
| Long‑term retrieval gate (memory‑dependent cues) | `_RECALL_CUES` | `["remind","remember","earlier","previous","last time","we said","you said","as discussed","again","what did we decide","did we decide"]` | `list[str]` | retrieval | If user message contains any cue (case-insensitive substring), long-term retrieval is enabled. | False negatives skip retrieval; false positives do retrieval unnecessarily. | `app/memory_policy.py:_RECALL_CUES`, `app/memory_policy.py:is_memory_dependent()` |
| Long‑term retrieval gate (state cues) | `_STATE_CUES` | `["version","config","setting","preference","default","runtime","python","aws","lambda","dynamo","s3","vector store","mcp"]` | `list[str]` | retrieval | State-related cue substrings also trigger long-term retrieval. | Same as above. | `app/memory_policy.py:_STATE_CUES`, `app/memory_policy.py:is_memory_dependent()` |
| Long‑term retrieval gate (reference cues) | `_REFERENCE_CUES` | `["that thing","the plan","the doc","the repo","the workflow"]` | `list[str]` | retrieval | Reference-related cue substrings trigger long-term retrieval (except pleasantries). | Same as above. | `app/memory_policy.py:_REFERENCE_CUES`, `app/memory_policy.py:is_memory_dependent()` |
| Pleasantry skip list | hard-coded set | `{"hi","hello","hey","thanks","thank you"}` | `set[str]` | retrieval | Prevents trivial pleasantries from triggering long-term retrieval when only reference cues match. | If too broad, misses legitimate retrieval; if too narrow, retrieves on chit-chat. | `app/memory_policy.py:is_memory_dependent()` |
| Assistant salience terms | `_COMMITMENT_TERMS` | `["we will","decide","decided","decision","standardise","standardize","canonical","policy","guardrail"]` | `list[str]` | retrieval, turn | If assistant message contains any term, it is considered salient and eligible for semantic indexing. | Mis-set changes what assistant content is indexed. | `app/memory_policy.py:_COMMITMENT_TERMS`, `app/memory_policy.py:is_salient_assistant_message()` |
| Assistant env‑line salience regex | `_ENV_PATTERN` | `r"[A-Z][A-Z0-9_]{1,30}\\s*="` (compiled) | `regex` | retrieval, turn | If assistant contains env-like assignments, it is considered salient and eligible for indexing. | Over/under-matching changes indexing behaviour. | `app/memory_policy.py:_ENV_PATTERN`, `app/memory_policy.py:is_salient_assistant_message()` |
| Assistant version salience regex | `_VERSION_PATTERN` | `r"\\b\\d{1,2}\\.\\d{1,2}(\\.\\d{1,3})?\\b"` (compiled) | `regex` | retrieval, turn | If assistant contains a version-like string, it is considered salient and eligible for indexing. | Over/under-matching changes indexing behaviour. | `app/memory_policy.py:_VERSION_PATTERN`, `app/memory_policy.py:is_salient_assistant_message()` |
| Assistant structured-content salience | heading/list triggers | `["\\n-","\\n*","\\n1.","\\n# ","\\n## "]` | `list[str]` | retrieval, turn | If assistant message has basic structured markers, it is treated as salient. | Mis-set changes indexing behaviour. | `app/memory_policy.py:is_salient_assistant_message()` |
| Assistant length salience threshold | `len(msg) >= 800` | `800` | `int` | retrieval, turn | Assistant messages ≥800 chars are treated as salient for indexing. | If too low, indexes more noise; if too high, misses long content. | `app/memory_policy.py:is_salient_assistant_message()` |
| Graph structured extraction pattern | `_STRUCTURED_PATTERN` | `r'entity\\s*=\\s*(?P<entity>\\S+)\\s+type\\s*=\\s*(?P<type>\\S+)\\s+fact\\s*=\\s*(?P<fact>\"[^\"]+\"|\\S+)'` (compiled) | `regex` | graph | If any event matches the pattern, deterministic extraction runs and LLM extraction is skipped. | Over/under-matching changes whether graph extraction uses deterministic parse or LLM fallback. | `app/graph_extraction_worker.py:_STRUCTURED_PATTERN`, `_structured_candidates_from_events()` |
| Micro-agent model id | `MICRO_AGENT_MODEL` | `"gpt-5-nano"` | `str` | tests, infra | Model id used by the micro-agent harness (Responses API). | OpenAI call fails if invalid model id; non‑nano models force `temperature=0`. | `app/micro_agent/micro_agent.py:MICRO_AGENT_MODEL_ENV`, `DEFAULT_MODEL` |
| Micro-agent max output tokens | `max_output_tokens` ctor arg | `800` | `int` | tests | Output token cap for the micro-agent’s Responses call. | If too low, responses truncate early; if too high, higher latency/cost. | `app/micro_agent/micro_agent.py:MicroAgent.__init__()` |
| Micro-agent /turn timeout | `timeout_seconds` ctor arg | `90` | `int` | tests | Timeout for the micro-agent’s `/turn` HTTP call. | Too low causes `TurnClientError` timeouts; too high slows failure feedback. | `app/micro_agent/micro_agent.py:MicroAgent.__init__()` |
| Function URL (live) | `LIVE_LAMBDA_URL` | `None` | `str \| None` | tests, infra | Live Function URL resolution input for micro-agent/tests/scripts. | Live scripts/tests fail to resolve URL if all URL env vars absent. | `app/micro_agent/turn_client.py:ENV_URL_KEYS`, `resolve_function_url()` |
| Function URL (live alt) | `LIVE_FUNCTION_URL` | `None` | `str \| None` | tests, infra | Alternate live Function URL key (same semantics as above). | Same as above. | `app/micro_agent/turn_client.py:ENV_URL_KEYS`, `resolve_function_url()` |
| Function URL (live alt) | `MEMORY_AGENT_URL` | `None` | `str \| None` | tests, infra | Alternate live Function URL key (same semantics as above). | Same as above. | `app/micro_agent/turn_client.py:ENV_URL_KEYS`, `resolve_function_url()` |
| Function URL discovery (by function name) | `MEMORY_AGENT_FUNCTION_NAME` | `None` | `str \| None` | tests, infra | Preferred discovery mode: directly fetches the Function URL config for a named Lambda (optionally including qualifier). | Mis-set returns “missing URL”; AWS auth/region errors surface as `TurnClientError`. | `app/micro_agent/turn_client.py:DISCOVERY_FUNCTION_NAME_ENV`, `_get_function_url_by_name()` |
| Function URL discovery (by function name prefix) | `MEMORY_AGENT_FUNCTION_NAME_PREFIX` | `None` | `str \| None` | tests, infra | Optional discovery mode: scans `list_functions` and returns the first function whose name starts with the prefix and has a Function URL configured. | Can match the wrong function if prefix is too broad. | `app/micro_agent/turn_client.py:DISCOVERY_FUNCTION_NAME_PREFIX_ENV`, `_discover_function_url()` |
| Function URL discovery region | `MEMORY_AGENT_DISCOVERY_REGION` | `None` | `str \| None` | tests, infra | Region used for Lambda discovery calls (falls back to `AWS_REGION`, then `LEGACY_DISCOVERY_REGION`). | Discovery fails if the deployed Lambda is in a different region. | `app/micro_agent/turn_client.py:_discover_region()` |
| Function URL legacy env-match discovery | `LEGACY_ENV_MATCH` | `{"STATE_TABLE":"memory-agent-branch-state","TRANSCRIPT_BUCKET":"memory-agent-transcripts-000000000000-ap-southeast-2","MEMORY_NODES_TABLE":"memory-nodes","GRAPH_EVENTS_QUEUE_URL":"https://example.invalid/sqs-placeholder"}` | `dict[str,str]` | tests, infra | Last-resort discovery mode: scans `list_functions` and matches a function by exact env var map, then reads its Function URL. | Brittle to benign infra changes (renames/rotations). | `app/micro_agent/turn_client.py:LEGACY_ENV_MATCH`, `_discover_function_url()` |
| Live RAG gate | `LIVE_RAG` | `None` | `str \| None` | tests | Enables live RAG tests and scripts when set to `"1"`. | Tests/scripts are skipped when not set. | `tests/test_rag_activation_live.py`, `tests/test_user_message_indexing_live.py` |
| Live graph gate | `LIVE_GRAPH` | `None` | `str \| None` | tests | Enables live graph validation when set to `"1"`. | Test is skipped when not set. | `tests/test_graph_validation_live.py` |
| Live micro-agent gate | `LIVE_AGENT` | `None` | `str \| None` | tests | Enables micro-agent live test when set to `"1"`. | Test is skipped when not set. | `tests/test_micro_agent_live.py` |
| Live smoke gate | `LIVE_SMOKE` | `None` | `str \| None` | tests | Enables deployed-Lambda smoke tests when set to `"1"`. | Test is skipped when not set; URL discovery may fail. | `tests/test_lambda_smoke_live.py` |
| Local-real IO gate | `LIVE_AWS` | `None` | `str \| None` | tests | Enables local-but-real integration test when set to `"1"`. | Test is skipped when not set. | `tests/test_local_real_integration.py` |
| Require graph in live ladder | `REQUIRE_GRAPH` | `None` | `str \| None` | tests | Forces `test_rag_activation_live` to assert graph facts exist when set to `"1"`. | Mis-set causes live test to fail on missing graph readiness. | `tests/test_rag_activation_live.py` |
| OpenAI witness gate | `OPENAI_INTEGRATION` | `"0"` | `str` | tests | Enables opt-in OpenAI “witness” test when set to `"1"`. | Test is skipped when not set. | `tests/test_openai_integration_witness.py` |
| OpenAI witness token | `OPENAI_WITNESS_TOKEN` | `None` | `str \| None` | tests | Token used to name the witness file uploaded to the vector store. | Test is skipped when missing/empty (even if `OPENAI_INTEGRATION=1`). | `tests/test_openai_integration_witness.py` |
| `.env` auto-loader path | `load_env(path: str \| None = None)` | `Path(__file__).resolve().parents[2] / ".env"` | `path` | tests | Loads KEY=VALUE pairs into `os.environ` for micro-agent/tests; does not overwrite existing env vars. | Missing file is silently ignored; malformed lines are ignored. | `app/micro_agent/env_loader.py:load_env()` |
| Live probe poll seconds | `--poll-seconds` | `60` | `int` | tests | Total time budget to poll for graph facts in `turn_rag_probe`. | Too low causes false failures for slow graph pipeline. | `scripts/turn_rag_probe.py:main()` |
| Live probe poll interval | `--poll-interval` | `5` | `int` | tests | Delay between graph polls in `turn_rag_probe`. | Too low increases load; too high reduces sampling frequency. | `scripts/turn_rag_probe.py:main()` |
| Live probe per-request timeout | `--timeout` | `90` | `int` | tests | HTTP timeout per `/turn` request in `turn_rag_probe`. | Too low causes timeouts; too high slows failure feedback. | `scripts/turn_rag_probe.py:ProbeConfig.timeout` |
| Live probe “policy” field | `--policy` | `"auto"` | `str` | tests | Added to `/turn` payload by `turn_rag_probe`, but ignored by the Lambda handler/router. | Changing it has no effect on backend behaviour. | `scripts/turn_rag_probe.py:main()`, ignored by `lambda_handler.py:lambda_handler()` |
| Size probe default Function URL | `DEFAULT_FUNCTION_URL` | `"https://example.invalid"` | `str` | tests | Default base URL for `turn_size_probe` when no live URL env vars are set. | If stale/wrong, probe hits the wrong endpoint. | `scripts/turn_size_probe.py:DEFAULT_FUNCTION_URL` |
| Size probe turns | `--turns` | `30` | `int` | tests | Number of `/turn` calls to attempt in `turn_size_probe`. | Too high increases load/time. | `scripts/turn_size_probe.py:main()` |
| Size probe user bytes | `--user-bytes` | `13000` | `int` | tests | Approx bytes per synthetic user message in `turn_size_probe`. | Too high can trigger response truncation or HTTP errors. | `scripts/turn_size_probe.py:main()` |
| Size probe assistant bytes | `--assistant-bytes` | `200` | `int` | tests | Approx bytes per synthetic assistant message persisted on next call. | Too high grows transcripts/state faster and triggers truncation. | `scripts/turn_size_probe.py:main()` |

## Defaults snapshot

This snapshot is the repo’s current “operating point” as encoded in defaults (env fallbacks + constants).

```yaml
# Env defaults (when env var is unset)
COEFFICIENTS_PRESET: "v1"
SEMANTIC_BACKEND: "openai"
OPENAI_VECTOR_STORE_ID: null
SEMANTIC_CHUNK_SIZE_TOKENS: 512
SEMANTIC_CHUNK_OVERLAP_TOKENS: 192
SEMANTIC_SEARCH_TOP_K: 12
SEMANTIC_RETURN_HITS_CAP: 8
SEMANTIC_INDEX_ROLES: ["user","assistant"]
SEMANTIC_SEARCH_SCOPE: "root"
HEALTHCHECK_LLM_CALLS: false
HEALTHCHECK_WRITE_PROBES: false
LOG_LEVEL: "INFO"
GRAPH_ENABLED: false
GRAPH_VECTOR_INDEX_ENABLED: false
MEMORY_NODES_TABLE: null
GRAPH_EVENTS_QUEUE_URL: null
RESPONSE_BUDGET_BYTES: 220000
S3_REHYDRATION_WINDOW_EVENTS: 3
MAX_REHYDRATED_WINDOWS: 2
REHYDRATION_MAX_TOTAL_EVENTS: 14
RECENT_EVENTS_RETURN_CAP: 12
SUMMARY_RETURN_MAX_CHARS: 900
MEMORY_AGENT_FUNCTION_NAME: null
MEMORY_AGENT_FUNCTION_NAME_PREFIX: null
MEMORY_AGENT_DISCOVERY_REGION: null

# Required env vars (code default when unset is null, but startup fails)
AWS_REGION: null
TRANSCRIPT_BUCKET: null
STATE_TABLE: null
OPENAI_API_KEY: null
EMBEDDING_MODEL_NAME: null
SUMMARY_MODEL_NAME: null

# Code constants (no env wiring)
GRAPH_VECTOR_SEARCH_TOP_K: 6
RECENT_EVENTS_MAX: 40
SUMMARY_MIN_TURNS: 6
SUMMARY_MAX_COMPLETION_TOKENS: 512
MAX_SEMANTIC_HIT_CHARS: 2000
MAX_RECENT_EVENT_CHARS: 4000
MAX_SUMMARY_CHARS: 2000
MICRO_AGENT_MODEL_DEFAULT: "gpt-5-nano"
MICRO_AGENT_MAX_OUTPUT_TOKENS_DEFAULT: 800
MICRO_AGENT_TURN_TIMEOUT_SECONDS_DEFAULT: 90
```

## Tuning clusters (grouping only)

### Latency control

- `SEMANTIC_BACKEND`, `SEMANTIC_CHUNK_SIZE_TOKENS`, `SEMANTIC_CHUNK_OVERLAP_TOKENS`
- `SUMMARY_MIN_TURNS`, `SUMMARY_MAX_COMPLETION_TOKENS`
- `GRAPH_ENABLED`, `GRAPH_VECTOR_INDEX_ENABLED`
- `HEALTHCHECK_LLM_CALLS`, `HEALTHCHECK_WRITE_PROBES`
- `MICRO_AGENT_TURN_TIMEOUT_SECONDS_DEFAULT` (and script/test timeouts)

### Recall / precision trade‑off

- `SEMANTIC_SEARCH_SCOPE`, `SEMANTIC_SEARCH_TOP_K`
- `S3_REHYDRATION_WINDOW_EVENTS`
- `GRAPH_VECTOR_SEARCH_TOP_K`
- `is_memory_dependent()` cue lists (what counts as memory-dependent)

### Safety against response-too-large

- `RESPONSE_BUDGET_BYTES`
- `MAX_SEMANTIC_HIT_CHARS`, `MAX_RECENT_EVENT_CHARS`, `MAX_SUMMARY_CHARS`
- Response truncation order (fixed in `enforce_response_budget()`)

### Determinism / observability

- `LOG_LEVEL`
- `graph_structured` vs `llm_fallback` extraction mode (structured regex + tags)
- Live-test gates (`LIVE_*`, `OPENAI_INTEGRATION`)

## Telemetry map (/turn and /pre responses)

The HTTP response includes `memory_telemetry` (when present) plus size flags.

### `memory_telemetry` fields

- `policy_applied` (string)
- `memory_dependent` (bool|null)
- `semantic_search_ran` (bool)
- `semantic_index_ran` (bool)
- `s3_rehydration_ran` (bool)
- `s3_rehydration_max_windows` (int|null)
- `s3_rehydration_capped` (bool)
- `s3_rehydration_windows_returned` (int)
- `s3_rehydration_truncated` (bool)
- `graph_read_ran` (bool)
- `graph_enqueue_ran` (bool)
- `graph_structured_parse_used` (bool|null)
- `graph_llm_fallback_used` (bool|null)
- `salient_last_turn` (bool|null)

Where defined: `app/models.py:MemoryTelemetry`, updated in `app/handler.py` and `app/response_budget.py`.

### Size / truncation fields

- `bytes_total` (int|null): total JSON response byte size as computed by `build_body_and_measure()`.
- `response_truncated` (bool): whether the response was trimmed to fit `RESPONSE_BUDGET_BYTES`.
- `persisted_last_turn` (bool): present on `/turn` responses only; indicates whether the previous turn was persisted during this call.

Where defined: `app/response_utils.py`, `app/response_budget.py`.

## Where to change values

### Runtime-tunable via environment variables (loaded into `Settings`)

Change by setting env vars consumed by `app/config.py:load_settings()` (and redeploy/restart for Lambda; long-lived processes cache `Settings` in `app/handler.py`).

- Core infra + models: `AWS_REGION`, `TRANSCRIPT_BUCKET`, `STATE_TABLE`, `OPENAI_API_KEY`, `EMBEDDING_MODEL_NAME`, `SUMMARY_MODEL_NAME`
- Coefficient presets: `COEFFICIENTS_PRESET`
- Semantic: `SEMANTIC_BACKEND`, `OPENAI_VECTOR_STORE_ID`, `SEMANTIC_CHUNK_SIZE_TOKENS`, `SEMANTIC_CHUNK_OVERLAP_TOKENS`, `SEMANTIC_SEARCH_TOP_K`, `SEMANTIC_RETURN_HITS_CAP`, `SEMANTIC_INDEX_ROLES`, `SEMANTIC_SEARCH_SCOPE`
- Healthcheck/logging: `HEALTHCHECK_LLM_CALLS`, `HEALTHCHECK_WRITE_PROBES`, `LOG_LEVEL`
- Budgets/rehydration: `RESPONSE_BUDGET_BYTES`, `S3_REHYDRATION_WINDOW_EVENTS`, `MAX_REHYDRATED_WINDOWS`, `REHYDRATION_MAX_TOTAL_EVENTS`, `RECENT_EVENTS_RETURN_CAP`, `SUMMARY_RETURN_MAX_CHARS`
- Graph: `GRAPH_ENABLED`, `GRAPH_VECTOR_INDEX_ENABLED`, `MEMORY_NODES_TABLE`, `GRAPH_EVENTS_QUEUE_URL`
- Dev-only URL discovery: `MEMORY_AGENT_FUNCTION_NAME`, `MEMORY_AGENT_FUNCTION_NAME_PREFIX`, `MEMORY_AGENT_DISCOVERY_REGION`

### Code-constant (edit code to change)

- Retrieval/indexing heuristics: `app/memory_policy.py` (cue lists, salience rules)
- Short-term memory thresholds: `app/short_term_memory.py` (`RECENT_EVENTS_MAX`, `SUMMARY_MIN_TURNS`)
- Response truncation strategy: `app/response_budget.py` (char caps and truncation order)
- Graph retrieval top‑K: `app/graph_retrieval.py` (`max_num_results=6`)
- Micro-agent defaults: `app/micro_agent/micro_agent.py` (model fallback, token/timeout defaults)
- Live-script defaults: `scripts/turn_rag_probe.py`, `scripts/turn_size_probe.py`
