# Coefficients V1 — NVDA desk golden set baseline

git_sha: <filled by CI/manual>

## Values

| Area | Knob | Value |
|---|---|---:|
| Semantic indexing/retrieval | `SEMANTIC_CHUNK_SIZE_TOKENS` | `512` |
| Semantic indexing/retrieval | `SEMANTIC_CHUNK_OVERLAP_TOKENS` | `192` |
| Semantic indexing/retrieval | `SEMANTIC_RETRIEVE_TOP_K` | `12` |
| Semantic indexing/retrieval | `SEMANTIC_RETURN_HITS_CAP` | `8` |
| Semantic indexing/retrieval | `SEMANTIC_INDEX_ROLES` | `["user","assistant"]` |
| Rehydration (S3 window fetch around semantic anchors) | `REHYDRATION_MAX_WINDOWS` | `2` |
| Rehydration (S3 window fetch around semantic anchors) | `REHYDRATION_WINDOW_RADIUS_EVENTS` | `3` |
| Rehydration (S3 window fetch around semantic anchors) | `REHYDRATION_MAX_TOTAL_EVENTS` | `14` |
| Response budgeting | `RESPONSE_BUDGET_BYTES` | `220000` |
| Short-term return shaping | `RECENT_EVENTS_RETURN_CAP` | `12` |
| Short-term return shaping | `SUMMARY_RETURN_MAX_CHARS` | `900` |

## Rationale

Precision-first baseline: semantic retrieval is tuned for higher precision (top‑K 12, returned hits capped at 8) while still picking up nuanced themes across both `user` and `assistant` roles.
Quote-grade accuracy comes from bounded S3 rehydration around semantic anchors (±3 events) rather than overstuffing the semantic hits themselves.
Rehydration windows are capped (2 windows, 14 total events) to keep context focused and predictable while preventing runaway payload sizes.
Response budget is raised modestly (220KB) to preserve evidence/telemetry while maintaining headroom under the toolrunner limits.
Per-environment overrides should be avoided unless explicitly recorded; changes should be versioned via new coefficient presets for diffability.
Runtime wiring maps `SEMANTIC_RETRIEVE_TOP_K` → `SEMANTIC_SEARCH_TOP_K`, `REHYDRATION_WINDOW_RADIUS_EVENTS` → `S3_REHYDRATION_WINDOW_EVENTS`, and `REHYDRATION_MAX_WINDOWS` → `MAX_REHYDRATED_WINDOWS`.
