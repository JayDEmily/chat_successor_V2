"""memory-agent application package.

This package contains the core Phase-1 long-term memory backend:

* typed models for events and branch state,
* configuration and LLM abstraction,
* AWS resource clients (DynamoDB, S3),
* state and transcript management,
* semantic and short-term memory logic,
* transport-agnostic pre/post handlers,
* optional MCP server wrapper.
"""
