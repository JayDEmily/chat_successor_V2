from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class CoefficientsPresetError(ValueError):
    """Raised when a coefficients preset file is missing or invalid."""


_PRESET_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")
_ALLOWED_ROLES = {"user", "assistant", "system", "tool"}


@dataclass(frozen=True)
class SemanticCoefficients:
    chunk_size_tokens: int
    chunk_overlap_tokens: int
    retrieve_top_k: int
    return_hits_cap: int
    index_roles: list[str]


@dataclass(frozen=True)
class RehydrationCoefficients:
    max_windows: int
    window_radius_events: int
    max_total_events: int


@dataclass(frozen=True)
class ResponseBudgetCoefficients:
    budget_bytes: int


@dataclass(frozen=True)
class ShortTermCoefficients:
    recent_events_return_cap: int
    summary_return_max_chars: int


@dataclass(frozen=True)
class CoefficientsPreset:
    version: str
    name: str
    notes: str
    semantic: SemanticCoefficients
    rehydration: RehydrationCoefficients
    response_budget: ResponseBudgetCoefficients
    short_term: ShortTermCoefficients


def _expect_dict(value: Any, path: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise CoefficientsPresetError(
            f"Invalid preset field {path}: expected object, got {type(value).__name__}"
        )
    return value


def _expect_str(value: Any, path: str) -> str:
    if not isinstance(value, str):
        raise CoefficientsPresetError(
            f"Invalid preset field {path}: expected string, got {type(value).__name__}"
        )
    return value


def _expect_int(value: Any, path: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise CoefficientsPresetError(
            f"Invalid preset field {path}: expected int, got {type(value).__name__}"
        )
    return value


def _expect_roles(value: Any, path: str) -> list[str]:
    if not isinstance(value, list):
        raise CoefficientsPresetError(
            f"Invalid preset field {path}: expected list[str], got {type(value).__name__}"
        )
    roles: list[str] = []
    for idx, item in enumerate(value):
        if not isinstance(item, str):
            raise CoefficientsPresetError(
                f"Invalid preset field {path}[{idx}]: expected string, got {type(item).__name__}"
            )
        role = item.strip()
        if role not in _ALLOWED_ROLES:
            raise CoefficientsPresetError(
                f"Invalid preset field {path}[{idx}]: unknown role {role!r} (allowed: {sorted(_ALLOWED_ROLES)})"
            )
        roles.append(role)
    if not roles:
        raise CoefficientsPresetError(f"Invalid preset field {path}: must be non-empty")
    return roles


def _validate_non_negative(value: int, path: str) -> None:
    if value < 0:
        raise CoefficientsPresetError(f"Invalid preset field {path}: must be >= 0")


def _validate_positive(value: int, path: str) -> None:
    if value <= 0:
        raise CoefficientsPresetError(f"Invalid preset field {path}: must be > 0")


def _preset_path(preset: str) -> tuple[str, Path]:
    preset_id = (preset or "").strip()
    if preset_id.endswith(".json"):
        preset_id = preset_id[: -len(".json")]
    if not preset_id or not _PRESET_ID_RE.fullmatch(preset_id):
        raise CoefficientsPresetError(
            f"Invalid preset id {preset!r} (expected /{_PRESET_ID_RE.pattern}/)"
        )
    base = Path(__file__).resolve().parent / "presets"
    return preset_id, base / f"{preset_id}.json"


def load_coefficients_preset(preset: str) -> CoefficientsPreset:
    preset_id, path = _preset_path(preset)
    if not path.exists():
        raise CoefficientsPresetError(f"Preset {preset_id!r} not found at {path}")

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise CoefficientsPresetError(
            f"Preset {preset_id!r} contains invalid JSON: {exc}"
        ) from exc

    root = _expect_dict(data, "$")
    version = _expect_str(root.get("version"), "version")
    name = _expect_str(root.get("name"), "name")
    notes = _expect_str(root.get("notes"), "notes")

    semantic_raw = _expect_dict(root.get("semantic"), "semantic")
    semantic = SemanticCoefficients(
        chunk_size_tokens=_expect_int(
            semantic_raw.get("chunk_size_tokens"), "semantic.chunk_size_tokens"
        ),
        chunk_overlap_tokens=_expect_int(
            semantic_raw.get("chunk_overlap_tokens"),
            "semantic.chunk_overlap_tokens",
        ),
        retrieve_top_k=_expect_int(
            semantic_raw.get("retrieve_top_k"), "semantic.retrieve_top_k"
        ),
        return_hits_cap=_expect_int(
            semantic_raw.get("return_hits_cap"), "semantic.return_hits_cap"
        ),
        index_roles=_expect_roles(
            semantic_raw.get("index_roles"), "semantic.index_roles"
        ),
    )
    _validate_positive(semantic.chunk_size_tokens, "semantic.chunk_size_tokens")
    _validate_non_negative(semantic.chunk_overlap_tokens, "semantic.chunk_overlap_tokens")
    _validate_positive(semantic.retrieve_top_k, "semantic.retrieve_top_k")
    _validate_non_negative(semantic.return_hits_cap, "semantic.return_hits_cap")

    rehydration_raw = _expect_dict(root.get("rehydration"), "rehydration")
    rehydration = RehydrationCoefficients(
        max_windows=_expect_int(rehydration_raw.get("max_windows"), "rehydration.max_windows"),
        window_radius_events=_expect_int(
            rehydration_raw.get("window_radius_events"), "rehydration.window_radius_events"
        ),
        max_total_events=_expect_int(
            rehydration_raw.get("max_total_events"), "rehydration.max_total_events"
        ),
    )
    _validate_non_negative(rehydration.max_windows, "rehydration.max_windows")
    _validate_non_negative(rehydration.window_radius_events, "rehydration.window_radius_events")
    _validate_non_negative(rehydration.max_total_events, "rehydration.max_total_events")

    response_budget_raw = _expect_dict(root.get("response_budget"), "response_budget")
    response_budget = ResponseBudgetCoefficients(
        budget_bytes=_expect_int(response_budget_raw.get("budget_bytes"), "response_budget.budget_bytes")
    )
    _validate_positive(response_budget.budget_bytes, "response_budget.budget_bytes")

    short_term_raw = _expect_dict(root.get("short_term"), "short_term")
    short_term = ShortTermCoefficients(
        recent_events_return_cap=_expect_int(
            short_term_raw.get("recent_events_return_cap"),
            "short_term.recent_events_return_cap",
        ),
        summary_return_max_chars=_expect_int(
            short_term_raw.get("summary_return_max_chars"),
            "short_term.summary_return_max_chars",
        ),
    )
    _validate_non_negative(short_term.recent_events_return_cap, "short_term.recent_events_return_cap")
    _validate_non_negative(short_term.summary_return_max_chars, "short_term.summary_return_max_chars")

    return CoefficientsPreset(
        version=version,
        name=name,
        notes=notes,
        semantic=semantic,
        rehydration=rehydration,
        response_budget=response_budget,
        short_term=short_term,
    )

