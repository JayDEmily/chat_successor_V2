"""Coefficient presets and loaders.

Coefficient presets define a versioned baseline for key retrieval, rehydration,
and response budgeting knobs. They are loaded by `app.config.load_settings()`
via `COEFFICIENTS_PRESET`.
"""

