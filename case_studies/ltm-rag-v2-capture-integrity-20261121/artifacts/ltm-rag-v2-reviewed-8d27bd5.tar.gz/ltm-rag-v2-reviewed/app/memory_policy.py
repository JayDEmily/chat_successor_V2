from __future__ import annotations

import re
from typing import Iterable


_RECALL_CUES = [
    "remind",
    "remember",
    "earlier",
    "previous",
    "last time",
    "we said",
    "you said",
    "as discussed",
    "again",
    "what did we decide",
    "did we decide",
]

_STATE_CUES = [
    "version",
    "config",
    "setting",
    "preference",
    "default",
    "runtime",
    "python",
    "aws",
    "lambda",
    "dynamo",
    "s3",
    "vector store",
    "mcp",
]

_REFERENCE_CUES = [
    "that thing",
    "the plan",
    "the doc",
    "the repo",
    "the workflow",
]

_COMMITMENT_TERMS = [
    "we will",
    "decide",
    "decided",
    "decision",
    "standardise",
    "standardize",
    "canonical",
    "policy",
    "guardrail",
]

_ENV_PATTERN = re.compile(r"[A-Z][A-Z0-9_]{1,30}\s*=", re.MULTILINE)
_VERSION_PATTERN = re.compile(r"\b\d{1,2}\.\d{1,2}(\.\d{1,3})?\b")


def _contains_any(text: str, needles: Iterable[str]) -> bool:
    lower = text.lower()
    return any(n in lower for n in needles)


def is_memory_dependent(message: str) -> bool:
    """Return True when the user message should trigger long-term retrieval."""
    msg = (message or "").strip()
    if not msg:
        return False
    if _contains_any(msg, _RECALL_CUES):
        return True
    if _contains_any(msg, _STATE_CUES):
        return True
    if _contains_any(msg, _REFERENCE_CUES):
        # Treat simple pleasantries as non memory-dependent.
        if msg.lower() in {"hi", "hello", "hey", "thanks", "thank you"}:
            return False
        return True
    return False


def is_salient_assistant_message(message: str) -> bool:
    """Return True when the assistant reply should be indexed to semantic memory."""
    msg = (message or "").strip()
    if not msg:
        return False

    lower = msg.lower()
    if _contains_any(lower, _COMMITMENT_TERMS):
        return True
    if _ENV_PATTERN.search(msg):
        return True
    if _VERSION_PATTERN.search(msg):
        return True
    # Structured content: crude heuristic for headings/lists/tables.
    if any(prefix in lower for prefix in ["\n-", "\n*", "\n1.", "\n# ", "\n## "]):
        return True
    if len(msg) >= 800:
        return True
    return False
