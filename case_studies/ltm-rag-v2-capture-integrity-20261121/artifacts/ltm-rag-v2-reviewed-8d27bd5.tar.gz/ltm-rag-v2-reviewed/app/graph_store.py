from __future__ import annotations

from typing import Iterable, List, Optional

from boto3.dynamodb.conditions import Attr, Key  # type: ignore[import]

from .aws_clients import get_memory_nodes_table
from .config import Settings
from .graph_models import MemoryNode


def _marker_sk(session_id: str) -> str:
    return f"_marker#{session_id}"


def put_memory_node(settings: Settings, node: MemoryNode, *, condition: bool = False) -> None:
    """Persist a MemoryNode. Optionally enforce no-overwrite when condition=True."""
    table = get_memory_nodes_table(settings)
    kwargs = {"Item": node.to_item()}
    if condition:
        # Only write if the item does not already exist.
        kwargs["ConditionExpression"] = Attr("PK").not_exists()
    table.put_item(**kwargs)


def query_nodes_by_entity(settings: Settings, root_session_id: str, entity: str, type: Optional[str] = None) -> List[MemoryNode]:
    table = get_memory_nodes_table(settings)
    prefix = f"{entity}#"
    if type:
        prefix = f"{entity}#{type}#"
    resp = table.query(
        KeyConditionExpression=Key("PK").eq(root_session_id) & Key("SK").begins_with(prefix),
    )
    items = resp.get("Items") or []
    return [MemoryNode.from_item(i) for i in items]


def load_active_nodes(settings: Settings, root_session_id: str, entity: str, type: str) -> List[MemoryNode]:
    nodes = query_nodes_by_entity(settings, root_session_id, entity, type)
    return [n for n in nodes if n.state == "active"]


def save_marker(settings: Settings, root_session_id: str, session_id: str, last_sequence: int) -> None:
    table = get_memory_nodes_table(settings)
    table.put_item(Item={"PK": root_session_id, "SK": _marker_sk(session_id), "last_processed_sequence": last_sequence})


def load_marker(settings: Settings, root_session_id: str, session_id: str) -> int:
    table = get_memory_nodes_table(settings)
    resp = table.get_item(Key={"PK": root_session_id, "SK": _marker_sk(session_id)})
    item = resp.get("Item") or {}
    return int(item.get("last_processed_sequence", -1))


class DynamoNodeStore:
    """Lightweight adapter exposing the methods consolidation expects."""

    def __init__(self, settings: Settings):
        self._settings = settings
        self._table = get_memory_nodes_table(settings)

    def put_node(self, node: MemoryNode) -> None:
        put_memory_node(self._settings, node)

    def get_by_entity(self, root_session_id: str, entity: str, type: str):
        return query_nodes_by_entity(self._settings, root_session_id, entity, type)

    def get_marker(self, root_session_id: str, session_id: str):
        return load_marker(self._settings, root_session_id, session_id)

    def update_marker(self, root_session_id: str, session_id: str, last_sequence: int):
        save_marker(self._settings, root_session_id, session_id, last_sequence)
