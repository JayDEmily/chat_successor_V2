from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .graph_models import MemoryNode, make_node_id
from .logging_utils import get_logger

logger = get_logger(__name__)


def _now(dt: Optional[datetime] = None) -> datetime:
    return (dt or datetime.now(timezone.utc)).astimezone(timezone.utc)


def _merge_sources(existing: List[str], incoming: List[str]) -> List[str]:
    merged = list(set((existing or []) + (incoming or [])))
    merged.sort()
    return merged


def _merge_tags(existing: List[str], incoming: List[str]) -> List[str]:
    merged = list(set((existing or []) + (incoming or [])))
    merged.sort()
    return merged


def _legacy_scheme(node: MemoryNode) -> bool:
    """Return True when node_id does not match current deterministic scheme (legacy evidence-based ids)."""
    expected = make_node_id(node.root_session_id, node.entity, node.type, node.fact)
    return node.node_id != expected

def _get_nodes_for_entity(store: Any, root_session_id: str, entity: str, type: str) -> List[MemoryNode]:
    if hasattr(store, "get_by_entity"):
        return store.get_by_entity(root_session_id, entity, type)
    if hasattr(store, "nodes"):
        return [
            n
            for n in getattr(store, "nodes").values()
            if n.root_session_id == root_session_id and n.entity == entity and n.type == type
        ]
    return []


def _update_superseded(nodes: Iterable[MemoryNode], new_node_id: str, now: datetime) -> None:
    for node in nodes:
        node.state = "superseded"
        node.superseded_by = new_node_id
        node.valid_to = now
        node.updated_at = now


def _create_node(
    *,
    root_session_id: str,
    session_id: str,
    entity: str,
    type: str,
    fact: str,
    state: str,
    confidence: float,
    source_event_ids: List[str],
    supersedes: List[str],
    history_reason: Optional[str],
    now: datetime,
    tags: List[str] | None = None,
) -> MemoryNode:
    node_id = make_node_id(root_session_id, entity, type, fact, source_event_ids)
    return MemoryNode(
        node_id=node_id,
        root_session_id=root_session_id,
        entity=entity,
        type=type,
        fact=fact,
        state=state,
        confidence=confidence,
        valid_from=now,
        valid_to=None,
        history_reason=history_reason,
        source_event_ids=source_event_ids,
        source_session_ids=[session_id],
        supersedes=supersedes,
        superseded_by=None,
        created_at=now,
        updated_at=now,
        tags=list(tags or []),
    )


def consolidate_candidates(
    *,
    store: Any,
    candidates: List[Dict[str, Any]],
    root_session_id: str,
    session_id: str,
    now: Optional[datetime] = None,
) -> Tuple[List[MemoryNode], List[MemoryNode]]:
    """Apply consolidation rules; return (new_nodes, updated_nodes)."""
    ts = _now(now)
    new_nodes: List[MemoryNode] = []
    updated_nodes: List[MemoryNode] = []

    for cand in candidates:
        entity = cand.get("entity")
        type = cand.get("type")
        fact = cand.get("fact", "")
        confidence = float(cand.get("confidence", 0.0))
        source_event_ids = cand.get("source_event_ids") or []
        tags = cand.get("tags") or []

        existing = _get_nodes_for_entity(store, root_session_id, entity, type)
        active = [n for n in existing if n.state in ("active", "reopened")]
        superseded = [n for n in existing if n.state == "superseded"]

        # Identify legacy-scheme nodes (old ids hashed with evidence) to avoid cross-scheme supersession.
        legacy_nodes = [n for n in existing if _legacy_scheme(n)]
        legacy_ids = {n.node_id for n in legacy_nodes}

        # Duplicate evidence / same fact as active -> merge and continue.
        if active and active[0].fact == fact:
            node = active[0]
            node.source_event_ids = _merge_sources(node.source_event_ids, source_event_ids)
            node.tags = _merge_tags(getattr(node, "tags", []), tags)
            node.updated_at = ts
            if not node.history_reason:
                node.history_reason = "Reconfirmed fact"
            updated_nodes.append(node)
            continue

        # Reopen scenario: fact matches a superseded node.
        reopen_target = next((n for n in superseded if n.fact == fact), None)
        if reopen_target:
            supersedes_ids = [n.node_id for n in active] if active else []
            # Reuse the existing node (avoid collisions with stable node_id).
            reopen_target.state = "reopened"
            reopen_target.confidence = confidence
            reopen_target.source_event_ids = _merge_sources(reopen_target.source_event_ids, source_event_ids)
            reopen_target.source_session_ids = _merge_sources(reopen_target.source_session_ids, [session_id])
            reopen_target.supersedes = supersedes_ids
            reopen_target.history_reason = "Reopened fact"
            reopen_target.valid_to = None
            reopen_target.superseded_by = None
            reopen_target.updated_at = ts
            reopen_target.tags = _merge_tags(getattr(reopen_target, "tags", []), tags)
            # Do not supersede legacy-scheme nodes; leave them untouched as a safety guard.
            _update_superseded(
                [
                    n
                    for n in active
                    if n.node_id not in legacy_ids and n.node_id != reopen_target.node_id
                ],
                reopen_target.node_id,
                ts,
            )
            updated_nodes.append(reopen_target)
            updated_nodes.extend([n for n in active if n.node_id != reopen_target.node_id])
            updated_nodes.extend([n for n in superseded if n.node_id != reopen_target.node_id])
            continue

        # New fact supersedes current active.
        supersedes_ids = [n.node_id for n in active]
        node = _create_node(
            root_session_id=root_session_id,
            session_id=session_id,
            entity=entity,
            type=type,
            fact=fact,
            state="active",
            confidence=confidence,
            source_event_ids=source_event_ids,
            supersedes=supersedes_ids,
            history_reason=None,
            now=ts,
            tags=tags,
        )
        _update_superseded(
            [n for n in active if n.node_id not in legacy_ids],
            node.node_id,
            ts,
        )
        new_nodes.append(node)
        updated_nodes.extend(active)
        updated_nodes.extend(superseded)

    return new_nodes, updated_nodes


def process_consolidation(
    *,
    store: Any,
    candidates: List[Dict[str, Any]],
    root_session_id: str = "root",
    session_id: str = "sess",
    now: Optional[datetime] = None,
) -> List[MemoryNode]:
    new_nodes, updated_nodes = consolidate_candidates(
        store=store,
        candidates=candidates,
        root_session_id=root_session_id,
        session_id=session_id,
        now=now,
    )
    # Persist results for direct callers.
    for node in new_nodes + updated_nodes:
        if hasattr(store, "upsert"):
            store.upsert(node)
        elif hasattr(store, "put_node"):
            store.put_node(node)
        elif hasattr(store, "nodes"):
            store.nodes[node.node_id] = node
    return new_nodes


# Backward-compatible alias used in tests.
apply_consolidation_actions = process_consolidation
