from __future__ import annotations

import io
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

try:
    from openai import OpenAI
except ModuleNotFoundError:  # pragma: no cover
    OpenAI = None  # type: ignore[assignment]

from .config import Settings
from .llm_client import LLMClient
from .logging_utils import get_logger
from .models import SemanticHit


@dataclass
class SemanticDoc:
    """Representation of a semantic memory document to be indexed.

    Indexing targets the single OpenAI vector store configured by
    OPENAI_VECTOR_STORE_ID (provisioned with the embedding model named by
    EMBEDDING_MODEL_NAME). Assistant messages (or their chunks) are uploaded;
    embeddings are computed inside the store. The attributes set on the vector
    store file become SemanticHit.metadata on retrieval: identifiers
    (root_session_id, session_id, event_id stored as id, sequence, role),
    created_at, kind, and any other existing identifiers tracked by the code.
    """

    id: str
    root_session_id: str
    session_id: str
    sequence: int
    role: str
    text: str
    embedding: List[float]
    created_at: str
    kind: str = "message"
    transcript_key: Optional[str] = None
    transcript_bucket: Optional[str] = None


logger = get_logger(__name__)


def index_memory(settings: Settings, llm: LLMClient, doc: SemanticDoc) -> None:
    """Index a semantic memory document into the configured backend.

    When SEMANTIC_BACKEND is "none" this is a no-op. Otherwise the assistant
    message is uploaded to the single OpenAI vector store, letting OpenAI
    handle chunking/embeddings using the store's configured embedding model.
    We attach identifiers/timestamps (root/session IDs, event_id as id,
    sequence, role, created_at, kind) so they surface later as
    SemanticHit.metadata.
    """
    if settings.semantic_backend == "none":
        logger.info(
            "semantic_index_skipped",
            extra={"stage": "semantic_index", "backend": settings.semantic_backend},
        )
        return
    if OpenAI is None:
        raise ModuleNotFoundError("openai is required to index semantic memory")

    logger.info(
        "semantic_index_upload",
        extra={
            "stage": "semantic_index",
            "status": "start",
            "backend": settings.semantic_backend,
            "vector_store_id": settings.openai_vector_store_id,
            "event_id": doc.id,
            "text_length": len(doc.text or ""),
        },
    )
    client = OpenAI(api_key=settings.openai_api_key)
    payload = (doc.text or "").encode("utf-8")
    buf = io.BytesIO(payload)
    buf.name = f"{doc.id}.txt"  # type: ignore[attr-defined]

    class FilePayload(tuple):
        def __new__(cls, filename: str, buffer: io.BytesIO):
            return super().__new__(cls, (filename, buffer))

        def read(self):
            return self[1].read()

    file_payload = FilePayload(f"{doc.id}.txt", buf)
    # Provide a filename so OpenAI treats the payload as a supported text file.
    file_obj = client.files.create(file=file_payload, purpose="assistants")

    chunking = {
        "type": "static",
        "static": {
            "max_chunk_size_tokens": settings.semantic_chunk_size_tokens,
            "chunk_overlap_tokens": settings.semantic_chunk_overlap_tokens,
        },
    }
    attrs = {
        "id": doc.id,
        "event_id": doc.id,
        "root_session_id": doc.root_session_id,
        "session_id": doc.session_id,
        "sequence": doc.sequence,
        "role": doc.role,
        "kind": doc.kind,
        "created_at": doc.created_at,
    }
    if doc.transcript_key:
        attrs["transcript_key"] = doc.transcript_key
    if doc.transcript_bucket:
        attrs["transcript_bucket"] = doc.transcript_bucket
    # Block until ingestion completes so immediate recall can see fresh events.
    client.vector_stores.files.create_and_poll(
        vector_store_id=settings.openai_vector_store_id,
        file_id=file_obj.id,
        attributes=attrs,
        chunking_strategy=chunking,
    )
    logger.info(
        "semantic_index_complete",
        extra={
            "stage": "semantic_index",
            "status": "ok",
            "backend": settings.semantic_backend,
            "vector_store_id": settings.openai_vector_store_id,
            "event_id": doc.id,
        },
    )


def search_memory(
    settings: Settings,
    llm: LLMClient,
    query_text: str,
    *,
    root_session_id: Optional[str] = None,
    session_id: Optional[str] = None,
    k: int = 8,
) -> List[SemanticHit]:
    """Search semantic memory for items similar to the query_text.

    Queries are sent to the OpenAI vector store when SEMANTIC_BACKEND is
    "openai"; otherwise this returns [] without making API calls. Searches
    are filtered by root_session_id (current behaviour; all branches under
    the root share semantic memory) and may optionally include session_id
    when enabled by the caller. query_text typically comes from the current
    user message. Returned SemanticHit.metadata mirrors the attributes set
    during indexing (identifiers, role, created_at, kind).
    """
    query_text = (query_text or "").strip()
    if not query_text:
        logger.debug(
            "semantic_search_skipped_empty_query",
            extra={"stage": "semantic_search", "reason": "empty_query"},
        )
        return []

    if settings.semantic_backend == "none":
        logger.info(
            "semantic_search_skipped",
            extra={"stage": "semantic_search", "backend": settings.semantic_backend},
        )
        return []
    if OpenAI is None:
        raise ModuleNotFoundError("openai is required to search semantic memory")

    client = OpenAI(api_key=settings.openai_api_key)
    clauses: List[Dict[str, Any]] = []
    if root_session_id:
        clauses.append({"type": "eq", "key": "root_session_id", "value": root_session_id})
    if session_id:
        clauses.append({"type": "eq", "key": "session_id", "value": session_id})
    filters = {"type": "and", "filters": clauses} if clauses else None

    logger.info(
        "semantic_search_start",
        extra={
            "stage": "semantic_search",
            "status": "start",
            "backend": settings.semantic_backend,
            "root_session_id": root_session_id,
            "session_id": session_id,
        },
    )
    try:
        resp = client.vector_stores.search(
            vector_store_id=settings.openai_vector_store_id,
            query=query_text,
            filters=filters,
            max_num_results=k,
        )
    except Exception:
        logger.error(
            "semantic_search_error",
            extra={"stage": "semantic_search", "status": "error"},
            exc_info=True,
        )
        raise
    hits: List[SemanticHit] = []
    for item in resp.data:
        text = " ".join(
            c.text for c in item.content if getattr(c, "type", "") == "text"
        )
        meta = item.attributes or {}
        score = float(item.score or 0.0)
        hits.append(SemanticHit(text=text, score=score, metadata=meta))
    logger.info(
        "semantic_search_complete",
        extra={
            "stage": "semantic_search",
            "status": "ok",
            "backend": settings.semantic_backend,
            "hit_count": len(hits),
        },
    )
    return hits
