from __future__ import annotations

import uuid
from typing import List, Optional, Tuple

from .config import Settings, load_settings
from .llm_client import LLMClient
from . import graph_retrieval
from .logging_utils import get_logger, request_context, update_request_context
from .models import (
    BranchState,
    Event,
    MemoryTelemetry,
    PostPhaseRequest,
    PostPhaseResponse,
    PrePhaseRequest,
    PrePhaseResponse,
    TurnRequest,
    TurnResponse,
    utc_now,
)
from .memory_policy import is_memory_dependent, is_salient_assistant_message
from .semantic_markers import semantic_marker_exists, write_semantic_marker
from .semantic_memory import SemanticDoc, index_memory, search_memory
from . import graph_pipeline
from .transcript_logger import append_events, _transcript_key
from .short_term_memory import update_branch_state_with_events
from .state_manager import load_branch_state, save_branch_state
from .transcript_logger import append_events
from .response_budget import enforce_response_budget
from .rehydration import rehydrate_semantic_hits


# Settings and client can be initialised once in a long-lived process
_settings: Settings | None = None
_llm_client: LLMClient | None = None
logger = get_logger(__name__)
load_graph_memory = graph_retrieval.load_graph_memory
search_graph_memory_vector = graph_retrieval.search_graph_memory_vector


def _get_settings() -> Settings:
    """Return a cached Settings instance, loading from env on first use."""
    global _settings
    if _settings is None:
        _settings = load_settings()
    return _settings


def _get_llm() -> LLMClient:
    """Return a cached LLMClient instance."""
    global _llm_client
    if _llm_client is None:
        _llm_client = LLMClient(_get_settings())
    return _llm_client


def handle_pre(req: PrePhaseRequest) -> PrePhaseResponse:
    """Pre-phase entrypoint used by all transports.

    Steps:
        * load Settings (cached) and the BranchState for the branch
          from DynamoDB or a default in-memory state when missing,
        * optionally run semantic search against the OpenAI vector store
          (filtered by root_session_id, optionally session_id) when the
          backend is "openai"; otherwise skip and return [],
        * return the current short_summary, recent_events buffer, and
          semantic_hits (if any).

    The caller (e.g. Lambda wrapper or MCP server) is responsible for
    actually constructing the model prompt using this information. This
    path is read-only: it does not write transcripts or state.
    """
    with request_context(
        path="/pre",
        root_session_id=req.root_session_id,
        session_id=req.session_id,
    ):
        logger.info("handle_pre_start", extra={"stage": "handle_pre", "status": "start"})
        try:
            settings = _get_settings()
            llm = _get_llm()
            update_request_context({"backend": settings.semantic_backend})
            telemetry = MemoryTelemetry(policy_applied="auto")

            state: BranchState = load_branch_state(
                settings, req.root_session_id, req.session_id
            )
            state_found = bool(
                state.recent_events or state.short_summary or state.next_sequence
            )
            logger.info(
                "branch_state_loaded",
                extra={
                    "stage": "handle_pre",
                    "status": "state_loaded",
                    "state_found": state_found,
                    "recent_events_count": len(state.recent_events),
                },
            )

            semantic_hits = []
            memory_dependent = is_memory_dependent(req.user_message)
            telemetry.memory_dependent = memory_dependent
            rehydrated_windows = None

            graph_facts: Optional[List[dict]] = None
            graph_history: Optional[dict] = None
            graph_feature_enabled = getattr(settings, "graph_enabled", False) or getattr(
                settings, "graph_memory_enabled", False
            )

            if memory_dependent:
                if settings.semantic_backend != "none":
                    logger.info(
                        "semantic_search_start",
                        extra={
                            "stage": "semantic_search",
                            "backend": settings.semantic_backend,
                            "status": "start",
                        },
                    )
                    session_filter = (
                        req.session_id
                        if settings.semantic_search_scope == "session"
                        else None
                    )
                    try:
                        top_k = getattr(settings, "semantic_search_top_k", 8)
                        semantic_hits = search_memory(
                            settings,
                            llm,
                            req.user_message,
                            root_session_id=req.root_session_id,
                            session_id=session_filter,
                            k=top_k,
                        )
                        telemetry.semantic_search_ran = True
                    except Exception:
                        telemetry.semantic_search_ran = False
                        semantic_hits = []
                        logger.error(
                            "semantic_search_error",
                            extra={
                                "stage": "semantic_search",
                                "status": "error",
                                "root_session_id": req.root_session_id,
                                "session_id": req.session_id,
                            },
                            exc_info=True,
                        )
                else:
                    logger.info(
                        "semantic_search_skipped",
                        extra={
                            "stage": "semantic_search",
                            "backend": settings.semantic_backend,
                            "status": "skipped",
                        },
                    )

                pass
            else:
                logger.info(
                    "memory_dependent_false_skip_long_term",
                    extra={"stage": "handle_pre", "status": "skipped"},
                )

            if semantic_hits:
                hits_cap = getattr(settings, "semantic_return_hits_cap", None)
                if hits_cap is not None and hits_cap >= 0 and len(semantic_hits) > hits_cap:
                    semantic_hits = semantic_hits[:hits_cap]

                telemetry.s3_rehydration_ran = True
                try:
                    rehydrated_windows = rehydrate_semantic_hits(
                        settings,
                        semantic_hits,
                        window_radius=getattr(settings, "s3_rehydration_window_events", 2),
                    )
                except Exception:
                    rehydrated_windows = []
                    logger.error(
                        "s3_rehydration_error",
                        extra={
                            "stage": "s3_rehydration",
                            "status": "error",
                            "root_session_id": req.root_session_id,
                            "session_id": req.session_id,
                        },
                        exc_info=True,
                    )

            if graph_feature_enabled:
                def _entity_hint(msg: str) -> str | None:
                    if not msg:
                        return None
                    lower = msg.lower()
                    if "python" in lower:
                        return "python_version"
                    return None

                entity_hint = _entity_hint(req.user_message)
                try:
                    facts, history = load_graph_memory(
                        settings, req.root_session_id, req.session_id, entity_hint=entity_hint
                    )
                    graph_facts = facts or []
                    graph_history = history or {}
                    telemetry.graph_read_ran = True
                    if not graph_facts:
                        vfacts, vhistory = search_graph_memory_vector(
                            settings, req.root_session_id, req.session_id, req.user_message
                        )
                        if vfacts:
                            graph_facts = vfacts
                            graph_history = vhistory or {}
                except Exception:
                    telemetry.graph_read_ran = False
                    logger.error(
                        "graph_memory_error",
                        extra={
                            "stage": "graph_memory",
                            "status": "error",
                            "root_session_id": req.root_session_id,
                            "session_id": req.session_id,
                        },
                        exc_info=True,
                    )
                    graph_facts, graph_history = [], {}

            # Derive extraction telemetry from graph facts (tags record extraction mode).
            def _update_extraction_telemetry(facts: list[dict] | None) -> None:
                if facts is None:
                    return
                structured = False
                fallback = False
                for fact in facts:
                    tags = set(fact.get("tags") or [])
                    if "extraction:structured" in tags:
                        structured = True
                    if "extraction:llm_fallback" in tags:
                        fallback = True
                if structured or fallback:
                    telemetry.graph_structured_parse_used = structured if structured else False
                    telemetry.graph_llm_fallback_used = fallback if fallback else False

            _update_extraction_telemetry(graph_facts if graph_feature_enabled else [])

            logger.info(
                "handle_pre_success",
                extra={
                    "stage": "handle_pre",
                    "status": "success",
                    "recent_events_count": len(state.recent_events),
                    "semantic_hit_count": len(semantic_hits),
                },
            )

            short_summary = state.short_summary
            summary_cap = getattr(settings, "summary_return_max_chars", None)
            if summary_cap is not None and summary_cap >= 0:
                if not short_summary or summary_cap == 0:
                    short_summary = None
                elif len(short_summary) > summary_cap:
                    short_summary = short_summary[:summary_cap]

            recent_events = list(state.recent_events)
            events_cap = getattr(settings, "recent_events_return_cap", None)
            if events_cap is not None and events_cap >= 0:
                if events_cap == 0:
                    recent_events = []
                elif len(recent_events) > events_cap:
                    recent_events = recent_events[-events_cap:]

            pre_resp = PrePhaseResponse(
                short_summary=short_summary,
                recent_events=recent_events,
                semantic_hits=semantic_hits,
                graph_memory_facts=graph_facts,
                graph_memory_history=graph_history,
                rehydrated_s3_windows=rehydrated_windows,
                memory_telemetry=telemetry,
            )
            report = enforce_response_budget(pre_resp, settings.response_budget_bytes)
            logger.info(
                "handle_pre_response_size",
                extra={
                    "stage": "handle_pre",
                    "status": "response_size",
                    "response_bytes_total": report.total_bytes,
                    "response_field_bytes": report.field_bytes,
                    "recent_events_bytes": report.per_event_bytes,
                    "semantic_hits_bytes": report.per_hit_bytes,
                    "response_truncated": pre_resp.response_truncated,
                },
            )
            return pre_resp
        except Exception:
            logger.error(
                "handle_pre_error",
                extra={"stage": "handle_pre", "status": "error"},
                exc_info=True,
            )
            raise


def _allocate_sequence(state: BranchState) -> int:
    """Return the next sequence number for this branch and increment it."""
    seq = state.next_sequence
    state.next_sequence += 1
    return seq


def _make_event(
    state: BranchState,
    role: str,
    content: str,
) -> Event:
    """Helper to construct a new Event for this branch."""
    seq = _allocate_sequence(state)
    return Event(
        event_id=str(uuid.uuid4()),
        root_session_id=state.root_session_id,
        session_id=state.session_id,
        sequence=seq,
        role=role,  # type: ignore[arg-type]
        created_at=utc_now(),
        content=content,
    )


def handle_post(req: PostPhaseRequest) -> PostPhaseResponse:
    """Post-phase entrypoint used by all transports.

    Called *after* the model has produced a reply. Responsible for:
        * loading Settings and BranchState,
        * allocating sequence numbers for the new user + assistant turns,
        * constructing two Event objects,
        * appending them to the S3 transcript (read–modify–write per branch),
        * updating the per-branch BranchState (short-term memory/summary),
        * optionally indexing semantic memory when backend is "openai",
        * persisting BranchState back to DynamoDB via simple upsert.

    This is the sole path that writes transcripts, updates BranchState,
    and indexes semantic memory (when enabled). Errors bubble to the
    caller; retries are non-idempotent and will duplicate events.
    """
    with request_context(
        path="/post",
        root_session_id=req.root_session_id,
        session_id=req.session_id,
    ):
        logger.info(
            "handle_post_start", extra={"stage": "handle_post", "status": "start"}
        )
        try:
            settings = _get_settings()
            llm = _get_llm()
            update_request_context({"backend": settings.semantic_backend})
            telemetry = MemoryTelemetry(policy_applied="auto")

            state = load_branch_state(settings, req.root_session_id, req.session_id)
            state_found = bool(
                state.recent_events or state.short_summary or state.next_sequence
            )
            logger.info(
                "branch_state_loaded",
                extra={
                    "stage": "handle_post",
                    "status": "state_loaded",
                    "state_found": state_found,
                    "recent_events_count": len(state.recent_events),
                    "next_sequence": state.next_sequence,
                },
            )

            start_sequence = state.next_sequence
            user_event = _make_event(state, role="user", content=req.user_message)
            assistant_event = _make_event(
                state, role="assistant", content=req.assistant_message
            )
            new_events: List[Event] = [user_event, assistant_event]
            end_sequence = state.next_sequence - 1
            transcript_key = _transcript_key(req.root_session_id, req.session_id)
            logger.info(
                "sequence_allocation",
                extra={
                    "stage": "sequence_allocation",
                    "status": "ok",
                    "start_sequence": start_sequence,
                    "end_sequence": end_sequence,
                    "event_count": len(new_events),
                },
            )

            # Append to transcript first so we never lose history.
            append_events(settings, req.root_session_id, req.session_id, new_events)
            approx_bytes = sum(len(e.content or "") for e in new_events)
            logger.info(
                "transcript_append",
                extra={
                    "stage": "transcript_append",
                    "status": "ok",
                    "event_count": len(new_events),
                    "approx_bytes": approx_bytes,
                },
            )

            # Update short-term memory and rolling summary.
            update_branch_state_with_events(llm, state, new_events)
            logger.info(
                "short_term_memory_update",
                extra={
                    "stage": "short_term_memory",
                    "status": "ok",
                    "recent_events_count": len(state.recent_events),
                    "summary_turns_since_update": state.summary_turns_since_update,
                    "short_summary_present": bool(state.short_summary),
                },
            )

            salient = is_salient_assistant_message(req.assistant_message)
            telemetry.salient_last_turn = salient

            def _maybe_index_event(event: Event, *, salient: bool, kind: str) -> bool:
                """Index a single event to semantic memory when enabled."""
                if settings.semantic_backend != "openai":
                    logger.info(
                        "semantic_index_skipped",
                        extra={
                            "stage": "semantic_index",
                            "status": "skipped_backend",
                            "backend": settings.semantic_backend,
                            "role": event.role,
                        },
                    )
                    return False

                allowed_roles = set(
                    getattr(settings, "semantic_index_roles", ["user", "assistant"])
                )
                if event.role not in allowed_roles:
                    logger.info(
                        "semantic_index_skipped",
                        extra={
                            "stage": "semantic_index",
                            "status": "skipped_role",
                            "event_id": event.event_id,
                            "role": event.role,
                        },
                    )
                    return False
                if not salient:
                    logger.info(
                        "semantic_index_skipped",
                        extra={
                            "stage": "semantic_index",
                            "status": "skipped_salience",
                            "role": event.role,
                        },
                    )
                    return False

                already_indexed = semantic_marker_exists(
                    settings,
                    event.root_session_id,
                    event.session_id,
                    event.event_id,
                )
                if already_indexed:
                    logger.info(
                        "semantic_index_dedup_skip",
                        extra={
                            "stage": "semantic_index",
                            "status": "dedup_skip",
                            "event_id": event.event_id,
                            "role": event.role,
                        },
                    )
                    return False

                doc = SemanticDoc(
                    id=event.event_id,
                    root_session_id=event.root_session_id,
                    session_id=event.session_id,
                    sequence=event.sequence,
                    role=event.role,
                    text=event.content,
                    embedding=[],
                    created_at=event.created_at.isoformat(),
                    kind=kind,
                    transcript_key=transcript_key,
                    transcript_bucket=settings.transcript_bucket,
                )
                logger.info(
                    "semantic_index_start",
                    extra={
                        "stage": "semantic_index",
                        "status": "start",
                        "event_id": event.event_id,
                        "role": event.role,
                    },
                )
                try:
                    index_memory(settings, llm, doc)
                    telemetry.semantic_index_ran = True
                    write_semantic_marker(
                        settings,
                        event.root_session_id,
                        event.session_id,
                        event.event_id,
                    )
                    logger.info(
                        "semantic_index_complete",
                        extra={
                            "stage": "semantic_index",
                            "status": "ok",
                            "event_id": event.event_id,
                            "role": event.role,
                            "text_length": len(event.content or ""),
                        },
                    )
                    return True
                except Exception:
                    logger.error(
                        "semantic_index_error",
                        extra={
                            "stage": "semantic_index",
                            "status": "error",
                            "event_id": event.event_id,
                            "role": event.role,
                        },
                        exc_info=True,
                    )
                    return False

            # Index user content (always salient) and assistant content (only when salient).
            _maybe_index_event(user_event, salient=True, kind="user_message")
            _maybe_index_event(assistant_event, salient=salient, kind="assistant_message")

            # Persist updated branch state.
            save_branch_state(settings, state)
            logger.info(
                "state_save_complete",
                extra={
                    "stage": "state_save",
                    "status": "ok",
                    "next_sequence": state.next_sequence,
                },
            )

            # Enqueue graph pipeline work item when enabled.
            if getattr(settings, "graph_enabled", False):
                try:
                    payload = graph_pipeline.build_graph_payload(
                        root_session_id=req.root_session_id,
                        session_id=req.session_id,
                        user_event_id=user_event.event_id,
                        assistant_event_id=assistant_event.event_id,
                        sequence_start=start_sequence,
                        sequence_end=end_sequence,
                        transcript_key=transcript_key,
                    )
                    graph_pipeline.enqueue_graph_job(settings, payload)
                    telemetry.graph_enqueue_ran = True
                    logger.info(
                        "graph_enqueue",
                        extra={
                            "stage": "graph_enqueue",
                            "status": "ok",
                            "dedupe_key": payload["dedupe_key"],
                        },
                    )
                except Exception:
                    telemetry.graph_enqueue_ran = False
                    logger.error(
                        "graph_enqueue_error",
                        extra={
                            "stage": "graph_enqueue",
                            "status": "error",
                        },
                        exc_info=True,
                    )

            logger.info(
                "handle_post_success",
                extra={
                    "stage": "handle_post",
                    "status": "success",
                    "event_count": len(new_events),
                },
            )
            return PostPhaseResponse(ok=True, memory_telemetry=telemetry)
        except Exception:
            logger.error(
                "handle_post_error",
                extra={"stage": "handle_post", "status": "error"},
                exc_info=True,
            )
            raise


def handle_turn(req: TurnRequest) -> TurnResponse:
    """Composite entrypoint: optionally persist the previous turn, then fetch context.

    When last_user_message/last_assistant_message are provided, this mirrors a
    call to handle_post for that completed turn before executing handle_pre for
    the current_user_message. When they are both None, only the pre-phase runs.
    """
    with request_context(
        path="/turn",
        root_session_id=req.root_session_id,
        session_id=req.session_id,
    ):
        logger.info(
            "handle_turn_start", extra={"stage": "handle_turn", "status": "start"}
        )
        try:
            # Validate required string fields.
            for field_name in ("root_session_id", "session_id", "current_user_message"):
                value = getattr(req, field_name)
                if not isinstance(value, str) or not value.strip():
                    raise ValueError(f"Invalid field: {field_name}")

            last_user = req.last_user_message
            last_assistant = req.last_assistant_message
            if (last_user is None) != (last_assistant is None):
                raise ValueError(
                    "last_user_message and last_assistant_message must both be provided or both null"
                )
            for field_name, value in (
                ("last_user_message", last_user),
                ("last_assistant_message", last_assistant),
            ):
                if value is not None and (not isinstance(value, str) or not value.strip()):
                    raise ValueError(f"Invalid field: {field_name}")

            settings = _get_settings()
            update_request_context({"backend": settings.semantic_backend})
            persisted_last_turn = False
            post_resp: Optional[PostPhaseResponse] = None
            if last_user is not None and last_assistant is not None:
                logger.info(
                    "handle_turn_persist_start",
                    extra={
                        "stage": "handle_turn",
                        "status": "persist_start",
                    },
                )
                post_req = PostPhaseRequest(
                    root_session_id=req.root_session_id,
                    session_id=req.session_id,
                    user_message=last_user,
                    assistant_message=last_assistant,
                )
                post_resp = handle_post(post_req)
                if not getattr(post_resp, "ok", False):
                    raise RuntimeError("Post-phase returned ok=False")
                persisted_last_turn = True

            pre_req = PrePhaseRequest(
                root_session_id=req.root_session_id,
                session_id=req.session_id,
                user_message=req.current_user_message,
            )
            pre_resp = handle_pre(pre_req)
            logger.info(
                "handle_turn_success",
                extra={
                    "stage": "handle_turn",
                    "status": "success",
                    "persisted_last_turn": persisted_last_turn,
                },
            )
            combined_telemetry = pre_resp.memory_telemetry
            if persisted_last_turn and post_resp and getattr(post_resp, "memory_telemetry", None):
                pt = post_resp.memory_telemetry
                if combined_telemetry is None:
                    combined_telemetry = pt
                else:
                    combined_telemetry.salient_last_turn = pt.salient_last_turn
                    combined_telemetry.semantic_index_ran = pt.semantic_index_ran
                    combined_telemetry.graph_enqueue_ran = pt.graph_enqueue_ran
            if combined_telemetry is None:
                combined_telemetry = MemoryTelemetry()

            turn_resp = TurnResponse(
                short_summary=pre_resp.short_summary,
                recent_events=pre_resp.recent_events,
                semantic_hits=pre_resp.semantic_hits,
                graph_memory_facts=getattr(pre_resp, "graph_memory_facts", None),
                graph_memory_history=getattr(pre_resp, "graph_memory_history", None),
                rehydrated_s3_windows=getattr(pre_resp, "rehydrated_s3_windows", None),
                persisted_last_turn=persisted_last_turn,
                memory_telemetry=combined_telemetry,
            )
            report = enforce_response_budget(turn_resp, settings.response_budget_bytes)
            logger.info(
                "handle_turn_response_size",
                extra={
                    "stage": "handle_turn",
                    "status": "response_size",
                    "response_bytes_total": report.total_bytes,
                    "response_field_bytes": report.field_bytes,
                    "recent_events_bytes": report.per_event_bytes,
                    "semantic_hits_bytes": report.per_hit_bytes,
                    "response_truncated": turn_resp.response_truncated,
                },
            )
            return turn_resp
        except Exception:
            logger.error(
                "handle_turn_error",
                extra={"stage": "handle_turn", "status": "error"},
                exc_info=True,
            )
            raise
