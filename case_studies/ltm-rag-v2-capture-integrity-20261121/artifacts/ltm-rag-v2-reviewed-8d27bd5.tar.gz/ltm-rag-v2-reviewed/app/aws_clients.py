from __future__ import annotations

import boto3
from botocore.config import Config as BotoConfig

from .config import Settings


def get_boto_session(settings: Settings) -> boto3.Session:
    """Create a boto3 Session configured for the given AWS region."""
    return boto3.Session(region_name=settings.aws_region)


def get_dynamodb_table(settings: Settings):
    """Return a DynamoDB Table resource for the branch state table."""
    session = get_boto_session(settings)
    resource = session.resource(
        "dynamodb",
        config=BotoConfig(retries={"max_attempts": 5, "mode": "standard"}),
    )
    return resource.Table(settings.state_table)


def get_s3_client(settings: Settings):
    """Return an S3 client for transcript operations."""
    session = get_boto_session(settings)
    return session.client(
        "s3",
        config=BotoConfig(retries={"max_attempts": 5, "mode": "standard"}),
    )


def get_memory_nodes_table(settings: Settings):
    """Return a DynamoDB Table resource for the memory_nodes table."""
    session = get_boto_session(settings)
    resource = session.resource(
        "dynamodb",
        config=BotoConfig(retries={"max_attempts": 5, "mode": "standard"}),
    )
    if not settings.memory_nodes_table:
        raise ValueError("memory_nodes_table not configured")
    return resource.Table(settings.memory_nodes_table)
