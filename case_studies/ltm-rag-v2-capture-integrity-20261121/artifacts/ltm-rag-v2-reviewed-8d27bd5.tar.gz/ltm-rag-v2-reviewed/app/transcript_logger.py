from __future__ import annotations

import json
from typing import Iterable, List

from botocore.exceptions import ClientError

from .aws_clients import get_s3_client
from .config import Settings
from .logging_utils import get_logger
from .models import Event


def _transcript_key(root_session_id: str, session_id: str) -> str:
    """Return the S3 key for the given branch's transcript.

    Pattern: sessions/{root_session_id}/{session_id}.log.jsonl
    """
    return f"sessions/{root_session_id}/{session_id}.log.jsonl"


logger = get_logger(__name__)


def append_events(
    settings: Settings,
    root_session_id: str,
    session_id: str,
    events: Iterable[Event],
) -> None:
    """Append events to the S3 transcript for a branch.

    All transcripts live in the single bucket named by settings.transcript_bucket
    under keys shaped as sessions/{root_session_id}/{session_id}.log.jsonl. Each
    line is one serialized Event. S3 does not support true in-place append, so
    for this single-user, single-writer, low-volume use case we implement a
    naive read–modify–write:
        * read the existing object if it exists,
        * append new JSON lines,
        * write the result back.

    This keeps the implementation simple and consistent with the
    "append-only JSONL" model described in the docs.
    """
    client = get_s3_client(settings)
    bucket = settings.transcript_bucket
    key = _transcript_key(root_session_id, session_id)
    logger.debug(
        "transcript_read_start",
        extra={"stage": "transcript_read", "bucket": bucket, "key": key},
    )

    try:
        resp = client.get_object(Bucket=bucket, Key=key)
        existing_body = resp["Body"].read().decode("utf-8")
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code")
        if code in ("NoSuchKey", "404"):
            existing_body = ""
            logger.info(
                "transcript_missing",
                extra={"stage": "transcript_read", "bucket": bucket, "key": key},
            )
        else:
            raise

    new_lines: List[str] = []
    for e in events:
        new_lines.append(json.dumps(e.to_dict(), ensure_ascii=False) + "\n")

    body = existing_body + "".join(new_lines)
    logger.debug(
        "transcript_write",
        extra={
            "stage": "transcript_write",
            "bucket": bucket,
            "key": key,
            "event_count": len(new_lines),
            "body_bytes": len(body.encode("utf-8")),
        },
    )
    client.put_object(Bucket=bucket, Key=key, Body=body.encode("utf-8"))
