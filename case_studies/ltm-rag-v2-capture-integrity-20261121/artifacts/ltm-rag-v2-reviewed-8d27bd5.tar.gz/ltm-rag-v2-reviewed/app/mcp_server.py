"""MCP tools that mirror the Lambda `/pre` and `/post` endpoints.

These tools expose the same contract and field shapes as the HTTP
Function URL or Custom GPT Actions:
    * `memory_pre` -> POST /pre: requires root_session_id, session_id,
      user_message; returns short_summary, recent_events, semantic_hits.
    * `memory_post` -> POST /post: requires the same IDs plus
      assistant_message; returns {\"ok\": bool}.

Intended for the same single-tenant, single-user memory backend; useful
as local/MCP clients alongside the canonical Lambda Function URL front
door. Semantics are identical; this just bypasses HTTP transport and the
Lambda cold-start healthcheck. Errors surface directly to the MCP caller
instead of being mapped to HTTP status codes.
"""

from __future__ import annotations

import uuid
from typing import Any, Dict

from mcp.server import Server  # type: ignore[import]

from .handler import handle_post, handle_pre
from .healthcheck import run_healthcheck
from .logging_utils import get_logger, request_context
from .models import PostPhaseRequest, PrePhaseRequest
from .response_utils import response_to_body


server = Server("memory-agent")
logger = get_logger(__name__)


def run_mcp_healthcheck() -> None:
    """Optional startup helper to mirror the Lambda healthcheck in MCP hosts."""
    run_healthcheck()


async def memory_pre(
    root_session_id: str,
    session_id: str,
    user_message: str,
) -> Dict[str, Any]:
    """MCP tool: fetch context before an LLM call.

    This wraps the transport-agnostic handle_pre function and returns a
    JSON-serialisable dict suitable for MCP clients.
    """
    request_id = str(uuid.uuid4())
    with request_context(
        request_id=request_id,
        path="mcp/pre",
        root_session_id=root_session_id,
        session_id=session_id,
    ):
        logger.info(
            "mcp_pre_start",
            extra={"stage": "mcp_pre", "status": "start"},
        )
        try:
            req = PrePhaseRequest(
                root_session_id=root_session_id,
                session_id=session_id,
                user_message=user_message,
            )
            resp = handle_pre(req)
            logger.info(
                "mcp_pre_success",
                extra={"stage": "mcp_pre", "status": "success"},
            )
            return response_to_body(resp)
        except Exception:
            logger.error(
                "mcp_pre_error",
                extra={"stage": "mcp_pre", "status": "error"},
                exc_info=True,
            )
            raise


async def memory_post(
    root_session_id: str,
    session_id: str,
    user_message: str,
    assistant_message: str,
) -> Dict[str, Any]:
    """MCP tool: update memory after an LLM call.

    This wraps the transport-agnostic handle_post function.
    """
    request_id = str(uuid.uuid4())
    with request_context(
        request_id=request_id,
        path="mcp/post",
        root_session_id=root_session_id,
        session_id=session_id,
    ):
        logger.info(
            "mcp_post_start",
            extra={"stage": "mcp_post", "status": "start"},
        )
        try:
            req = PostPhaseRequest(
                root_session_id=root_session_id,
                session_id=session_id,
                user_message=user_message,
                assistant_message=assistant_message,
            )
            resp = handle_post(req)
            logger.info(
                "mcp_post_success",
                extra={"stage": "mcp_post", "status": "success"},
            )
            return {"ok": resp.ok}
        except Exception:
            logger.error(
                "mcp_post_error",
                extra={"stage": "mcp_post", "status": "error"},
                exc_info=True,
            )
            raise
# Backward-compat: allow callers to reach the underlying functions directly.
memory_pre.__wrapped__ = memory_pre
memory_post.__wrapped__ = memory_post
