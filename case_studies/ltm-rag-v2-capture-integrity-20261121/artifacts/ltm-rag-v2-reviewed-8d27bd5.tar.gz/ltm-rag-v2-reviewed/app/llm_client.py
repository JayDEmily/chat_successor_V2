from __future__ import annotations

import json
from typing import List

try:
    from openai import OpenAI
except ModuleNotFoundError:  # pragma: no cover
    OpenAI = None  # type: ignore[assignment]

from .config import Settings
from .logging_utils import get_logger


logger = get_logger(__name__)


class LLMClient:
    """Thin wrapper around the OpenAI client for embeddings and summaries.

    The rest of the codebase should call only these methods:
        * embed(text) -> List[float]
        * summarise(history_text) -> str

    This keeps the rest of the system decoupled from provider details,
    and makes it trivial to swap model names or providers later.
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        # Client is threadsafe and can be reused across requests.
        if OpenAI is None:
            raise ModuleNotFoundError("openai is required to initialize LLMClient")
        self._client = OpenAI(api_key=settings.openai_api_key)

    def embed(self, text: str) -> List[float]:
        """Return an embedding vector for the given text.

        Empty or whitespace-only input returns an empty list to avoid
        unnecessary API calls.
        """
        if not text or not text.strip():
            return []

        logger.debug(
            "llm_embed_start",
            extra={
                "stage": "llm_embed",
                "model": self._settings.embedding_model,
                "input_length": len(text),
            },
        )
        resp = self._client.embeddings.create(
            model=self._settings.embedding_model,
            input=text,
        )
        # We expect exactly one embedding back.
        vec = resp.data[0].embedding
        if len(vec) != self._settings.embedding_dim:
            # Fail loudly rather than silently propagating wrong dimensions.
            raise RuntimeError(
                f"Embedding dimension mismatch: expected "
                f"{self._settings.embedding_dim}, got {len(vec)}"
            )
        logger.debug(
            "llm_embed_complete",
            extra={
                "stage": "llm_embed",
                "model": self._settings.embedding_model,
                "output_dim": len(vec),
            },
        )
        return vec

    def extract_memories(self, prompt: str) -> List[dict]:
        """Run the graph extraction prompt and return candidate memories."""
        prompt = (prompt or "").strip()
        if not prompt:
            return []

        logger.info(
            "llm_extract_start",
            extra={
                "stage": "llm_extract",
                "model": self._settings.summary_model,
                "prompt_length": len(prompt),
            },
        )
        try:
            resp = self._client.chat.completions.create(
                model=self._settings.summary_model,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Extract concise, structured facts from the provided transcript context. "
                            "Return a JSON array of objects with fields: "
                            "`entity` (string key), `type` (string category such as config/preference), "
                            "`fact` (string), `confidence` (0-1), "
                            "`source_event_ids` (list of event_id strings).\n"
                            "Keep outputs minimal and avoid prose."
                        ),
                    },
                    {"role": "user", "content": prompt},
                ],
            )
            content = resp.choices[0].message.content or "[]"
        except Exception:
            logger.error(
                "llm_extract_error",
                extra={"stage": "llm_extract", "model": self._settings.summary_model},
                exc_info=True,
            )
            raise

        try:
            data = json.loads(content)
            if isinstance(data, dict) and "memories" in data:
                data = data.get("memories") or []
            if isinstance(data, list):
                return data
        except Exception:
            logger.warning(
                "llm_extract_parse_fallback",
                extra={"stage": "llm_extract", "status": "fallback"},
            )
        return []

    def summarise(self, history_text: str) -> str:
        """Summarise a conversation history into a compact memory summary.

        The summary should emphasise:
            * stable facts,
            * decisions,
            * configurations,
            * user preferences.

        Transient chit-chat and small-talk is intentionally downplayed.
        """
        text = (history_text or "").strip()
        if not text:
            return ""

        logger.debug(
            "llm_summarise_start",
            extra={
                "stage": "llm_summarise",
                "model": self._settings.summary_model,
                "input_length": len(text),
            },
        )
        system_prompt = (
            "You are a memory compression assistant. Given a conversation "
            "history, extract a concise summary that preserves stable facts, "
            "decisions, configurations, and user preferences. Ignore small "
            "talk and ephemeral details. Write in plain English."
        )

        resp = self._client.chat.completions.create(
            model=self._settings.summary_model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": text},
            ],
            max_completion_tokens=512,
        )
        summary = resp.choices[0].message.content.strip()
        logger.debug(
            "llm_summarise_complete",
            extra={
                "stage": "llm_summarise",
                "model": self._settings.summary_model,
                "output_length": len(summary),
            },
        )
        return summary
