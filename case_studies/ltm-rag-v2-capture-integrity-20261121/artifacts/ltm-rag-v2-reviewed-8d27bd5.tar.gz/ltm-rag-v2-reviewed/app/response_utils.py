from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

from .models import Event, PrePhaseResponse, SemanticHit, TurnResponse


@dataclass
class ResponseSizeReport:
    """Structured response size metrics for logging and budgeting."""

    total_bytes: int
    field_bytes: Dict[str, int]
    per_event_bytes: List[int]
    per_hit_bytes: List[int]


def _json_size(value: Any) -> int:
    """Return the UTF-8 byte length of a JSON-encoded value."""
    return len(json.dumps(value).encode("utf-8"))


def response_to_body(resp: PrePhaseResponse | TurnResponse) -> Dict[str, Any]:
    """Convert a response dataclass to the HTTP/JSON body shape."""
    _ensure_response_meta(resp)
    body: Dict[str, Any] = {
        "short_summary": resp.short_summary,
        "recent_events": [_event_to_dict(e) for e in resp.recent_events],
        "semantic_hits": [_hit_to_dict(h) for h in resp.semantic_hits],
        "response_truncated": bool(getattr(resp, "response_truncated", False)),
    }
    if getattr(resp, "rehydrated_s3_windows", None) is not None:
        body["rehydrated_s3_windows"] = [
            _rehydrated_window_to_dict(w) for w in (resp.rehydrated_s3_windows or [])
        ]
    if getattr(resp, "memory_telemetry", None) is not None:
        body["memory_telemetry"] = resp.memory_telemetry.to_dict()  # type: ignore[union-attr]
    if getattr(resp, "graph_memory_facts", None) is not None:
        body["graph_memory_facts"] = resp.graph_memory_facts  # type: ignore[attr-defined]
    if getattr(resp, "graph_memory_history", None) is not None:
        body["graph_memory_history"] = resp.graph_memory_history  # type: ignore[attr-defined]
    if isinstance(resp, TurnResponse):
        body["persisted_last_turn"] = resp.persisted_last_turn
    if getattr(resp, "bytes_total", None) is not None:
        body["bytes_total"] = resp.bytes_total
    return body


def measure_body_bytes(body: Dict[str, Any]) -> ResponseSizeReport:
    """Return total and per-field byte counts for a response body."""
    field_bytes: Dict[str, int] = {
        "short_summary": _json_size(body.get("short_summary")),
        "recent_events": _json_size(body.get("recent_events", [])),
        "semantic_hits": _json_size(body.get("semantic_hits", [])),
        "rehydrated_s3_windows": _json_size(body.get("rehydrated_s3_windows", [])),
        "graph_memory_facts": _json_size(body["graph_memory_facts"])
        if "graph_memory_facts" in body
        else 0,
        "graph_memory_history": _json_size(body["graph_memory_history"])
        if "graph_memory_history" in body
        else 0,
        "memory_telemetry": _json_size(body["memory_telemetry"])
        if "memory_telemetry" in body
        else 0,
        "response_truncated": _json_size(body["response_truncated"])
        if "response_truncated" in body
        else 0,
        "bytes_total": _json_size(body["bytes_total"])
        if "bytes_total" in body
        else 0,
    }
    if "persisted_last_turn" in body:
        field_bytes["persisted_last_turn"] = _json_size(body["persisted_last_turn"])
    per_event_bytes = [
        _json_size(evt) for evt in body.get("recent_events", []) if isinstance(evt, dict)
    ]
    per_hit_bytes = [
        _json_size(hit) for hit in body.get("semantic_hits", []) if isinstance(hit, dict)
    ]
    total_bytes = _json_size(body)
    return ResponseSizeReport(
        total_bytes=total_bytes,
        field_bytes=field_bytes,
        per_event_bytes=per_event_bytes,
        per_hit_bytes=per_hit_bytes,
    )


def build_body_and_measure(
    resp: PrePhaseResponse | TurnResponse,
    *,
    set_bytes_total: bool = False,
) -> Tuple[Dict[str, Any], ResponseSizeReport]:
    """Return the response body dict plus a ResponseSizeReport."""
    _ensure_response_meta(resp)
    body = response_to_body(resp)
    report = measure_body_bytes(body)
    if set_bytes_total:
        resp.bytes_total = report.total_bytes
        body = response_to_body(resp)
        report = measure_body_bytes(body)
        if resp.bytes_total != report.total_bytes:
            resp.bytes_total = report.total_bytes
            body = response_to_body(resp)
            report = measure_body_bytes(body)
    return body, report


def _event_to_dict(e: Event) -> Dict[str, Any]:
    """Serialize an Event, guarding against accidental None."""
    return e.to_dict() if isinstance(e, Event) else {}


def _hit_to_dict(hit: SemanticHit) -> Dict[str, Any]:
    """Serialize a SemanticHit to a plain dict."""
    if isinstance(hit, SemanticHit):
        return {"text": hit.text, "score": hit.score, "metadata": hit.metadata}
    return {}


def _rehydrated_window_to_dict(window: Any) -> Dict[str, Any]:
    """Serialize a rehydrated window with window_events normalized to dicts."""
    if not isinstance(window, dict):
        return {}
    window_events = window.get("window_events") or []
    normalized_events: List[Dict[str, Any]] = []
    for evt in window_events:
        if isinstance(evt, Event):
            normalized_events.append(evt.to_dict())
        elif isinstance(evt, dict):
            normalized_events.append(evt)
        else:
            normalized_events.append({})
    payload = dict(window)
    payload["window_events"] = normalized_events
    if "anchor" in payload and not isinstance(payload["anchor"], dict):
        payload["anchor"] = {}
    if "source" in payload and not isinstance(payload["source"], dict):
        payload["source"] = {}
    if "hit_ref" in payload and not isinstance(payload["hit_ref"], dict):
        payload["hit_ref"] = {}
    return payload


def _ensure_response_meta(resp: PrePhaseResponse | TurnResponse) -> None:
    """Guarantee response_truncated/bytes_total attrs exist on the response object."""
    if not hasattr(resp, "response_truncated"):
        setattr(resp, "response_truncated", False)
    if not hasattr(resp, "bytes_total"):
        setattr(resp, "bytes_total", None)
