from __future__ import annotations

from typing import Dict

from .aws_clients import get_dynamodb_table
from .config import Settings
from .models import utc_now


def _marker_sk(session_id: str, event_id: str) -> str:
    return f"semantic_marker#{session_id}#{event_id}"


def semantic_marker_exists(settings: Settings, root_session_id: str, session_id: str, event_id: str) -> bool:
    table = get_dynamodb_table(settings)
    resp = table.get_item(Key={"PK": root_session_id, "SK": _marker_sk(session_id, event_id)})
    return bool(resp.get("Item"))


def write_semantic_marker(settings: Settings, root_session_id: str, session_id: str, event_id: str) -> None:
    table = get_dynamodb_table(settings)
    item: Dict[str, str] = {
        "PK": root_session_id,
        "SK": _marker_sk(session_id, event_id),
        "event_id": event_id,
        "session_id": session_id,
        "semantic_indexed": "true",
        "created_at": utc_now().isoformat(),
    }
    table.put_item(Item=item)
