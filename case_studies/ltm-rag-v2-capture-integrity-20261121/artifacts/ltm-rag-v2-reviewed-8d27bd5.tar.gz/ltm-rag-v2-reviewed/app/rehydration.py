from __future__ import annotations

import json
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .config import Settings
from .logging_utils import get_logger
from .models import SemanticHit


logger = get_logger(__name__)


def _default_transcript_key(root_session_id: str, session_id: str) -> str:
    return f"sessions/{root_session_id}/{session_id}.log.jsonl"


def _coerce_int(value: Any) -> Optional[int]:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _load_transcript_events(
    settings: Settings,
    transcript_key: str,
    *,
    bucket: Optional[str] = None,
    s3_client: Any = None,
) -> List[Dict[str, Any]]:
    try:
        from botocore.exceptions import ClientError  # type: ignore
    except ModuleNotFoundError:  # pragma: no cover
        class ClientError(Exception):
            pass

    if s3_client is None:
        from .aws_clients import get_s3_client

        s3_client = get_s3_client(settings)
    bucket = bucket or settings.transcript_bucket
    try:
        resp = s3_client.get_object(Bucket=bucket, Key=transcript_key)
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code")
        if code in ("NoSuchKey", "404"):
            logger.info(
                "rehydration_transcript_missing",
                extra={"stage": "rehydration", "bucket": bucket, "key": transcript_key},
            )
            return []
        raise

    body = resp.get("Body")
    payload = body.read().decode("utf-8") if body else ""
    events: List[Dict[str, Any]] = []
    for raw in payload.splitlines():
        line = (raw or "").strip()
        if not line:
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict):
            events.append(data)
    return events


def select_window_events(
    events: Iterable[Dict[str, Any]],
    *,
    anchor_event_id: Optional[str],
    anchor_sequence: Optional[int],
    window_radius: int = 2,
) -> Tuple[List[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """Return a bounded window around the anchor, plus the anchor event."""
    events_list = list(events)
    anchor_idx: Optional[int] = None

    if anchor_event_id:
        for idx, evt in enumerate(events_list):
            if evt.get("event_id") == anchor_event_id:
                anchor_idx = idx
                break

    if anchor_idx is None and anchor_sequence is not None:
        for idx, evt in enumerate(events_list):
            if _coerce_int(evt.get("sequence")) == anchor_sequence:
                anchor_idx = idx
                break

    if anchor_idx is None:
        return [], None

    start = max(0, anchor_idx - max(window_radius, 0))
    end = min(len(events_list), anchor_idx + max(window_radius, 0) + 1)
    window = events_list[start:end]
    anchor_event = events_list[anchor_idx]
    return window, anchor_event


def rehydrate_semantic_hits(
    settings: Settings,
    hits: Iterable[SemanticHit],
    *,
    window_radius: Optional[int] = None,
    max_windows: Optional[int] = None,
    max_total_events: Optional[int] = None,
    s3_client: Any = None,
) -> List[Dict[str, Any]]:
    """Load S3 transcripts and return bounded windows around semantic hits."""
    radius = window_radius if window_radius is not None else getattr(
        settings, "s3_rehydration_window_events", 2
    )
    cap = (
        max_windows
        if max_windows is not None
        else getattr(settings, "max_rehydrated_windows", None)
    )
    if cap is not None and cap <= 0:
        return []

    windows: List[Dict[str, Any]] = []
    cache: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    total_events = 0
    total_cap = (
        max_total_events
        if max_total_events is not None
        else getattr(settings, "rehydration_max_total_events", None)
    )
    if total_cap is not None and total_cap <= 0:
        return []

    def _trim_window(window_events: List[Dict[str, Any]], anchor_event: Dict[str, Any], limit: int) -> List[Dict[str, Any]]:
        if limit <= 0 or not window_events:
            return []
        if len(window_events) <= limit:
            return window_events
        anchor_idx = None
        for idx, evt in enumerate(window_events):
            if evt is anchor_event:
                anchor_idx = idx
                break
            if anchor_event.get("event_id") and evt.get("event_id") == anchor_event.get("event_id"):
                anchor_idx = idx
                break
            if anchor_idx is None and anchor_event.get("sequence") is not None and evt.get("sequence") == anchor_event.get("sequence"):
                anchor_idx = idx
                break
        if anchor_idx is None:
            return window_events[:limit]

        keep: set[int] = {anchor_idx}
        offset = 1
        while len(keep) < limit and (anchor_idx - offset >= 0 or anchor_idx + offset < len(window_events)):
            before = anchor_idx - offset
            after = anchor_idx + offset
            if before >= 0 and len(keep) < limit:
                keep.add(before)
            if after < len(window_events) and len(keep) < limit:
                keep.add(after)
            offset += 1
        return [window_events[i] for i in sorted(keep)]

    for hit in hits or []:
        if cap is not None and len(windows) >= cap:
            break
        meta = getattr(hit, "metadata", {}) or {}
        root_session_id = meta.get("root_session_id")
        session_id = meta.get("session_id")
        if not root_session_id or not session_id:
            continue

        transcript_key = meta.get("transcript_key") or _default_transcript_key(
            str(root_session_id), str(session_id)
        )
        bucket = meta.get("transcript_bucket") or settings.transcript_bucket
        cache_key = (bucket, transcript_key)
        if cache_key not in cache:
            cache[cache_key] = _load_transcript_events(
                settings, transcript_key, bucket=bucket, s3_client=s3_client
            )
        events = cache[cache_key]

        event_id = meta.get("event_id") or meta.get("id")
        sequence = _coerce_int(meta.get("sequence"))
        window_events, anchor_event = select_window_events(
            events,
            anchor_event_id=event_id,
            anchor_sequence=sequence,
            window_radius=radius,
        )
        if not window_events or not anchor_event:
            continue
        if total_cap is not None:
            remaining = total_cap - total_events
            if remaining <= 0:
                break
            if len(window_events) > remaining:
                window_events = _trim_window(window_events, anchor_event, remaining)
                if not window_events:
                    break

        anchor = {
            "event_id": anchor_event.get("event_id"),
            "role": anchor_event.get("role"),
            "content": anchor_event.get("content"),
            "sequence": anchor_event.get("sequence"),
        }
        hit_ref: Dict[str, Any] = {}
        if event_id:
            hit_ref["event_id"] = event_id
        if sequence is not None:
            hit_ref["sequence"] = sequence
        if not hit_ref and anchor.get("event_id"):
            hit_ref["event_id"] = anchor.get("event_id")

        windows.append(
            {
                "anchor": anchor,
                "window_events": window_events,
                "source": {"transcript_key": transcript_key, "bucket": bucket},
                "hit_ref": hit_ref,
            }
        )
        total_events += len(window_events)

    return windows
