from __future__ import annotations

import io
from typing import Any

from openai import OpenAI

from .graph_models import MemoryNode
from .logging_utils import get_logger

logger = get_logger(__name__)


class GraphFactVectorStore:
    """Wrapper to upload consolidated graph facts to an OpenAI vector store."""

    def __init__(self, settings: Any):
        self._settings = settings
        self._client = OpenAI(api_key=settings.openai_api_key)
        self._vector_store_id = getattr(settings, "openai_vector_store_id", None)

    def upload(self, node: MemoryNode) -> None:
        if not self._vector_store_id:
            logger.warning(
                "graph_vector_store_missing_id",
                extra={"stage": "graph_vector_upload", "status": "skip"},
            )
            return

        text = f"{node.entity} {node.type} {node.fact}"
        payload = text.encode("utf-8")
        buf = io.BytesIO(payload)
        buf.name = f"{node.node_id}.txt"  # type: ignore[attr-defined]

        class FilePayload(tuple):
            def __new__(cls, filename: str, buffer: io.BytesIO):
                return super().__new__(cls, (filename, buffer))

            def read(self):
                return self[1].read()

        file_payload = FilePayload(f"{node.node_id}.txt", buf)

        logger.info(
            "graph_vector_upload_start",
            extra={
                "stage": "graph_vector_upload",
                "status": "start",
                "vector_store_id": self._vector_store_id,
                "node_id": node.node_id,
            },
        )
        file_obj = self._client.files.create(file=file_payload, purpose="assistants")
        attrs = {
            "node_id": node.node_id,
            "root_session_id": node.root_session_id,
            "entity": node.entity,
            "type": node.type,
            "state": node.state,
            "updated_at": node.updated_at.isoformat(),
            "kind": node.kind or "graph_fact",
        }
        # Avoid blocking Lambda on OpenAI ingestion; enqueue and return.
        self._client.vector_stores.files.create(
            vector_store_id=self._vector_store_id,
            file_id=file_obj.id,
            attributes=attrs,
        )
        logger.info(
            "graph_vector_upload_complete",
            extra={
                "stage": "graph_vector_upload",
                "status": "ok",
                "vector_store_id": self._vector_store_id,
                "node_id": node.node_id,
            },
        )
