from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Dict

from .coefficients.loader import CoefficientsPresetError, load_coefficients_preset


class ConfigError(RuntimeError):
    """Raised when required configuration is missing or inconsistent."""


def _require_env(name: str) -> str:
    """Return an environment variable or raise a descriptive error.

    This keeps configuration errors as deploy-time failures rather than
    mysterious runtime behaviour.
    """
    value = os.getenv(name)
    if not value:
        raise ConfigError(
            f"Required environment variable {name!r} is not set. "
            "Please configure it before starting the memory service."
        )
    return value


def _get_bool_env(name: str, default: bool = False) -> bool:
    """Parse a boolean from an environment variable with sane defaults."""
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _get_log_level(name: str, default: str = "INFO") -> str:
    """Return an uppercased log level from env or a safe default.

    Unknown values fall back to the default rather than raising to keep
    logging configuration resilient in Lambda and tests.
    """
    raw = os.getenv(name)
    if not raw:
        return default
    level = raw.strip().upper()
    allowed = {"CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"}
    if level in allowed:
        return level
    return default


# Known embedding model dimensions. Extend this map deliberately as you
# adopt new embedding models; unknown entries are rejected at startup.
EMBEDDING_DIMS: Dict[str, int] = {
    "text-embedding-3-small": 1536,
    "text-embedding-3-large": 3072,
}

SEMANTIC_BACKENDS = {"openai", "none"}
SEMANTIC_SEARCH_SCOPES = {"root", "session"}


@dataclass(frozen=True)
class Settings:
    """In-memory snapshot of configuration for the memory service.

    This keeps all config in one place and makes it easier to inspect and
    validate during health checks. Environment variables map directly to the
    fields below:

    * aws_region (`AWS_REGION`)
    * transcript_bucket (`TRANSCRIPT_BUCKET`)
    * state_table (`STATE_TABLE`)
    * openai_api_key (`OPENAI_API_KEY`)
    * summary_model (`SUMMARY_MODEL_NAME`) — canonical example `gpt-5.1`
    * embedding_model (`EMBEDDING_MODEL_NAME`) — canonical example
      `text-embedding-3-large`
    * openai_vector_store_id (`OPENAI_VECTOR_STORE_ID`) — required when
      `semantic_backend` is `openai`
    * coefficients_preset (`COEFFICIENTS_PRESET`) versioned baseline knobs
    * semantic_backend (`SEMANTIC_BACKEND`) in `{"openai", "none"}`
    * semantic_chunk_size_tokens (`SEMANTIC_CHUNK_SIZE_TOKENS`, optional)
    * semantic_chunk_overlap_tokens (`SEMANTIC_CHUNK_OVERLAP_TOKENS`, optional)
    * semantic_search_top_k (`SEMANTIC_SEARCH_TOP_K`, optional)
    * semantic_return_hits_cap (`SEMANTIC_RETURN_HITS_CAP`, optional)
    * semantic_index_roles (`SEMANTIC_INDEX_ROLES`, optional; JSON list or comma-separated)
    * semantic_search_scope (`SEMANTIC_SEARCH_SCOPE`) in {"root", "session"}
    * healthcheck_llm_calls (`HEALTHCHECK_LLM_CALLS`) toggles whether the
      healthcheck makes test LLM calls
    * healthcheck_write_probes (`HEALTHCHECK_WRITE_PROBES`) toggles optional
      write/read probes for S3 and DynamoDB
    * log_level (`LOG_LEVEL`) controls logging verbosity (default INFO)
    * response_budget_bytes (`RESPONSE_BUDGET_BYTES`) caps response size
    * s3_rehydration_window_events (`S3_REHYDRATION_WINDOW_EVENTS`) window radius around anchors
    * max_rehydrated_windows (`MAX_REHYDRATED_WINDOWS`) cap on returned S3 windows
    * rehydration_max_total_events (`REHYDRATION_MAX_TOTAL_EVENTS`) hard cap across windows
    * recent_events_return_cap (`RECENT_EVENTS_RETURN_CAP`) caps returned recent_events
    * summary_return_max_chars (`SUMMARY_RETURN_MAX_CHARS`) truncates returned short_summary
    """

    aws_region: str
    transcript_bucket: str
    state_table: str
    openai_api_key: str
    openai_vector_store_id: str | None
    coefficients_preset: str
    semantic_backend: str
    semantic_chunk_size_tokens: int
    semantic_chunk_overlap_tokens: int
    semantic_search_top_k: int
    semantic_return_hits_cap: int
    semantic_index_roles: list[str]
    semantic_search_scope: str
    healthcheck_llm_calls: bool
    healthcheck_write_probes: bool
    embedding_model: str
    summary_model: str
    log_level: str
    # V3 graph settings
    graph_enabled: bool
    graph_vector_index_enabled: bool
    memory_nodes_table: str | None
    graph_events_queue_url: str | None
    response_budget_bytes: int
    s3_rehydration_window_events: int
    max_rehydrated_windows: int | None
    rehydration_max_total_events: int
    recent_events_return_cap: int
    summary_return_max_chars: int

    @property
    def embedding_dim(self) -> int:
        """Return the expected dimensionality for the configured embedding model."""
        try:
            return EMBEDDING_DIMS[self.embedding_model]
        except KeyError as exc:
            raise ConfigError(
                f"Unknown embedding model {self.embedding_model!r}. "
                f"Known models: {sorted(EMBEDDING_DIMS)}"
            ) from exc


def load_settings() -> Settings:
    """Load and validate configuration from environment variables.

    In Lambda or container deployments, environment variables should be
    wired from infrastructure config.
    """
    aws_region = _require_env("AWS_REGION")
    transcript_bucket = _require_env("TRANSCRIPT_BUCKET")
    state_table = _require_env("STATE_TABLE")

    preset_name = os.getenv("COEFFICIENTS_PRESET", "v1")
    try:
        coefficients = load_coefficients_preset(preset_name)
    except CoefficientsPresetError as exc:
        raise ConfigError(f"Invalid COEFFICIENTS_PRESET={preset_name!r}: {exc}") from exc

    # Semantic backend selection
    semantic_backend = os.getenv("SEMANTIC_BACKEND", "openai").lower()
    if semantic_backend not in SEMANTIC_BACKENDS:
        raise ConfigError(
            f"SEMANTIC_BACKEND must be one of {sorted(SEMANTIC_BACKENDS)}, got {semantic_backend!r}"
        )

    openai_api_key = _require_env("OPENAI_API_KEY")  # required even when semantic backend is disabled (used for summaries)
    openai_vector_store_id = os.getenv("OPENAI_VECTOR_STORE_ID")
    if semantic_backend == "openai" and not openai_vector_store_id:
        raise ConfigError(
            "OPENAI_VECTOR_STORE_ID is required when SEMANTIC_BACKEND=openai"
        )

    embedding_model = _require_env("EMBEDDING_MODEL_NAME")
    summary_model = _require_env("SUMMARY_MODEL_NAME")

    semantic_chunk_size_tokens = int(
        os.getenv(
            "SEMANTIC_CHUNK_SIZE_TOKENS",
            str(coefficients.semantic.chunk_size_tokens),
        )
    )
    semantic_chunk_overlap_tokens = int(
        os.getenv(
            "SEMANTIC_CHUNK_OVERLAP_TOKENS",
            str(coefficients.semantic.chunk_overlap_tokens),
        )
    )
    semantic_search_top_k = int(
        os.getenv("SEMANTIC_SEARCH_TOP_K", str(coefficients.semantic.retrieve_top_k))
    )
    semantic_return_hits_cap = int(
        os.getenv(
            "SEMANTIC_RETURN_HITS_CAP",
            str(coefficients.semantic.return_hits_cap),
        )
    )

    def _parse_roles(raw: str) -> list[str]:
        text = (raw or "").strip()
        if not text:
            raise ValueError("SEMANTIC_INDEX_ROLES must be non-empty when set")
        if text.startswith("["):
            parsed = json.loads(text)
            if not isinstance(parsed, list) or not all(isinstance(v, str) for v in parsed):
                raise ValueError("SEMANTIC_INDEX_ROLES JSON must be a list of strings")
            roles = [v.strip() for v in parsed if v.strip()]
        else:
            roles = [v.strip() for v in text.split(",") if v.strip()]
        if not roles:
            raise ValueError("SEMANTIC_INDEX_ROLES must include at least one role")
        return roles

    raw_roles = os.getenv("SEMANTIC_INDEX_ROLES")
    if raw_roles is None:
        semantic_index_roles = list(coefficients.semantic.index_roles)
    else:
        semantic_index_roles = _parse_roles(raw_roles)

    semantic_search_scope = os.getenv("SEMANTIC_SEARCH_SCOPE", "root").lower()
    if semantic_search_scope not in SEMANTIC_SEARCH_SCOPES:
        raise ConfigError(
            f"SEMANTIC_SEARCH_SCOPE must be one of {sorted(SEMANTIC_SEARCH_SCOPES)}, got {semantic_search_scope!r}"
        )
    healthcheck_llm_calls = _get_bool_env("HEALTHCHECK_LLM_CALLS", default=False)
    healthcheck_write_probes = _get_bool_env(
        "HEALTHCHECK_WRITE_PROBES", default=False
    )
    log_level = _get_log_level("LOG_LEVEL", default="INFO")

    # V3 graph settings
    graph_enabled = _get_bool_env("GRAPH_ENABLED", default=False)
    graph_vector_index_enabled = _get_bool_env("GRAPH_VECTOR_INDEX_ENABLED", default=False)
    memory_nodes_table = os.getenv("MEMORY_NODES_TABLE")
    graph_events_queue_url = os.getenv("GRAPH_EVENTS_QUEUE_URL")
    if graph_enabled:
        if not memory_nodes_table:
            raise ConfigError("MEMORY_NODES_TABLE is required when GRAPH_ENABLED=true")
        if not graph_events_queue_url:
            raise ConfigError("GRAPH_EVENTS_QUEUE_URL is required when GRAPH_ENABLED=true")
    response_budget_bytes = int(
        os.getenv(
            "RESPONSE_BUDGET_BYTES",
            str(coefficients.response_budget.budget_bytes),
        )
    )
    s3_rehydration_window_events = int(
        os.getenv(
            "S3_REHYDRATION_WINDOW_EVENTS",
            str(coefficients.rehydration.window_radius_events),
        )
    )
    max_rehydrated_windows: int | None
    raw_max_windows = os.getenv("MAX_REHYDRATED_WINDOWS")
    if raw_max_windows is None:
        max_rehydrated_windows = coefficients.rehydration.max_windows
    else:
        max_rehydrated_windows = int(raw_max_windows)
        if max_rehydrated_windows < 0:
            raise ConfigError("MAX_REHYDRATED_WINDOWS must be >= 0 when set")

    rehydration_max_total_events = int(
        os.getenv(
            "REHYDRATION_MAX_TOTAL_EVENTS",
            str(coefficients.rehydration.max_total_events),
        )
    )
    if rehydration_max_total_events < 0:
        raise ConfigError("REHYDRATION_MAX_TOTAL_EVENTS must be >= 0")

    recent_events_return_cap = int(
        os.getenv(
            "RECENT_EVENTS_RETURN_CAP",
            str(coefficients.short_term.recent_events_return_cap),
        )
    )
    if recent_events_return_cap < 0:
        raise ConfigError("RECENT_EVENTS_RETURN_CAP must be >= 0")

    summary_return_max_chars = int(
        os.getenv(
            "SUMMARY_RETURN_MAX_CHARS",
            str(coefficients.short_term.summary_return_max_chars),
        )
    )
    if summary_return_max_chars < 0:
        raise ConfigError("SUMMARY_RETURN_MAX_CHARS must be >= 0")

    settings = Settings(
        aws_region=aws_region,
        transcript_bucket=transcript_bucket,
        state_table=state_table,
        openai_api_key=openai_api_key,
        openai_vector_store_id=openai_vector_store_id,
        coefficients_preset=preset_name,
        semantic_backend=semantic_backend,
        semantic_chunk_size_tokens=semantic_chunk_size_tokens,
        semantic_chunk_overlap_tokens=semantic_chunk_overlap_tokens,
        semantic_search_top_k=semantic_search_top_k,
        semantic_return_hits_cap=semantic_return_hits_cap,
        semantic_index_roles=semantic_index_roles,
        semantic_search_scope=semantic_search_scope,
        healthcheck_llm_calls=healthcheck_llm_calls,
        healthcheck_write_probes=healthcheck_write_probes,
        embedding_model=embedding_model,
        summary_model=summary_model,
        log_level=log_level,
        graph_enabled=graph_enabled,
        graph_vector_index_enabled=graph_vector_index_enabled,
        memory_nodes_table=memory_nodes_table,
        graph_events_queue_url=graph_events_queue_url,
        response_budget_bytes=response_budget_bytes,
        s3_rehydration_window_events=s3_rehydration_window_events,
        max_rehydrated_windows=max_rehydrated_windows,
        rehydration_max_total_events=rehydration_max_total_events,
        recent_events_return_cap=recent_events_return_cap,
        summary_return_max_chars=summary_return_max_chars,
    )
    # Force embedding model validation at load time.
    _ = settings.embedding_dim
    return settings
