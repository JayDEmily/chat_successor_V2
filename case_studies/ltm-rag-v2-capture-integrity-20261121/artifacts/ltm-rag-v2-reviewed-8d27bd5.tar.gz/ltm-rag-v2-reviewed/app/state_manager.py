from __future__ import annotations

from .aws_clients import get_dynamodb_table
from .config import Settings
from .logging_utils import get_logger
from .models import BranchState


logger = get_logger(__name__)


def load_branch_state(settings: Settings, root_session_id: str, session_id: str) -> BranchState:
    """Load the BranchState for (root_session_id, session_id).

    All branch state lives in the single table named by settings.state_table
    using a simple PK/SK schema:
        PK = root_session_id
        SK = session_id
    There are no secondary indexes; access is simple key-value get/put.
    If no state exists yet, return a default empty BranchState. This function
    is the only place that knows the DynamoDB schema for this single-tenant,
    single-user service.
    """
    table = get_dynamodb_table(settings)
    resp = table.get_item(Key={"PK": root_session_id, "SK": session_id})
    item = resp.get("Item")
    if not item:
        logger.debug(
            "branch_state_missing",
            extra={
                "stage": "branch_state_load",
                "status": "missing",
                "root_session_id": root_session_id,
                "session_id": session_id,
            },
        )
        return BranchState(root_session_id=root_session_id, session_id=session_id)

    state = BranchState.from_item(item)
    logger.debug(
        "branch_state_loaded",
        extra={
            "stage": "branch_state_load",
            "status": "ok",
            "root_session_id": root_session_id,
            "session_id": session_id,
            "recent_events_count": len(state.recent_events),
            "next_sequence": state.next_sequence,
        },
    )
    return state


def save_branch_state(settings: Settings, state: BranchState) -> None:
    """Persist the given BranchState to DynamoDB (simple upsert)."""
    table = get_dynamodb_table(settings)
    table.put_item(Item=state.to_item())
    logger.debug(
        "branch_state_saved",
        extra={
            "stage": "branch_state_save",
            "status": "ok",
            "root_session_id": state.root_session_id,
            "session_id": state.session_id,
            "recent_events_count": len(state.recent_events),
            "next_sequence": state.next_sequence,
        },
    )
