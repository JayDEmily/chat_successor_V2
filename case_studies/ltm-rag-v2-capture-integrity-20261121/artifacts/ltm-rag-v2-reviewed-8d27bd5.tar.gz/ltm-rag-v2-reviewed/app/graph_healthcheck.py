from __future__ import annotations

from types import SimpleNamespace

from openai import OpenAI
import io

from .aws_clients import get_memory_nodes_table
from .config import load_settings
from .logging_utils import get_logger

logger = get_logger(__name__)


def get_settings():
    return load_settings()


def run_graph_healthcheck() -> None:
    settings = get_settings()
    table = get_memory_nodes_table(settings)
    table.load()
    logger.info(
        "graph_healthcheck_table_ok",
        extra={"stage": "graph_healthcheck", "component": "memory_nodes", "status": "ok"},
    )

    check_vector = getattr(settings, "check_graph_vector", False)
    if check_vector:
        client = OpenAI(api_key=getattr(settings, "openai_api_key", None))
        vector_store_id = getattr(settings, "openai_vector_store_id", "")
        payload = io.BytesIO(b"graph healthcheck")
        payload.name = "graph_healthcheck.txt"  # type: ignore[attr-defined]

        class FilePayload(tuple):
            def __new__(cls, filename: str, buffer: io.BytesIO):
                return super().__new__(cls, (filename, buffer))

            def read(self):
                return self[1].read()

        file_payload = FilePayload("graph_healthcheck.txt", payload)
        file_obj = client.files.create(file=file_payload, purpose="assistants")
        client.vector_stores.files.create_and_poll(
            vector_store_id=vector_store_id,
            file_id=file_obj.id,
        )
        logger.info(
            "graph_healthcheck_vector_ok",
            extra={"stage": "graph_healthcheck", "component": "graph_fact_vector", "status": "ok"},
        )
