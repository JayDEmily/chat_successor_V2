from __future__ import annotations

from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Literal, Optional


Role = Literal["user", "assistant", "system", "tool"]


def utc_now() -> datetime:
    """Return a timezone-aware UTC timestamp.

    We keep timestamps explicit and serialisable. Anything written to
    DynamoDB / S3 should eventually be converted to ISO 8601 strings.
    """
    return datetime.now(timezone.utc)


@dataclass
class Event:
    """Single conversational event (turn) in a specific branch.

    This is the ground-truth representation of "what was actually said".
    Events are immutable once persisted; ordering is tracked via the
    monotonically increasing `sequence` within each
    (root_session_id, session_id) pair, and `created_at` is always stored
    as an ISO 8601 UTC string.

    Attributes
    ----------
    event_id:
        Globally-unique identifier for this event (e.g. UUID or ULID).
    root_session_id:
        Logical root of the conversation tree (topic root).
    session_id:
        Branch identifier within the root session.
    sequence:
        Monotonic index of the event within the (root_session_id, session_id)
        branch. Starts at 0 and increments by 1 for each new event.
    role:
        Role of the speaker: "user", "assistant", "system", or "tool".
    created_at:
        Time this event was created, in UTC. Serialized as ISO 8601.
    content:
        Raw textual content of the event.
    metadata:
        Optional arbitrary structured payload. For example, tool call
        arguments or extra diagnostic information.
    """

    event_id: str
    root_session_id: str
    session_id: str
    sequence: int
    role: Role
    created_at: datetime
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate role membership."""
        allowed_roles = {"user", "assistant", "system", "tool"}
        if self.role not in allowed_roles:
            raise ValueError(f"Invalid role {self.role!r}; expected one of {allowed_roles}")

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serialisable dict representation.

        We convert datetimes to ISO 8601 strings and leave metadata as-is.
        """
        d = asdict(self)
        d["created_at"] = self.created_at.isoformat()
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Event":
        """Reconstruct an Event from a JSON-like dict."""
        created_raw = data.get("created_at")
        if isinstance(created_raw, str):
            created_at = datetime.fromisoformat(created_raw)
        elif isinstance(created_raw, datetime):
            created_at = created_raw
        else:
            created_at = utc_now()

        return cls(
            event_id=data["event_id"],
            root_session_id=data["root_session_id"],
            session_id=data["session_id"],
            sequence=int(data["sequence"]),
            role=data["role"],
            created_at=created_at,
            content=data.get("content", ""),
            metadata=data.get("metadata", {}) or {},
        )


@dataclass
class SemanticHit:
    """Result of a semantic memory search.

    Attributes
    ----------
    text:
        The stored text associated with this memory.
    score:
        Similarity score from the vector search backend (higher is better).
    metadata:
        Identity fields (root_session_id, session_id, sequence, role,
        created_at) and any extra flags (e.g. kind) that help the caller
        interpret the hit. Mirrors the attributes stored at index time.
    """

    text: str
    score: float
    metadata: Dict[str, Any]


@dataclass
class MemoryTelemetry:
    policy_applied: str = "auto"
    memory_dependent: Optional[bool] = None
    semantic_search_ran: bool = False
    graph_read_ran: bool = False
    s3_rehydration_ran: bool = False
    s3_rehydration_windows_returned: int = 0
    s3_rehydration_truncated: bool = False
    salient_last_turn: Optional[bool] = None
    semantic_index_ran: bool = False
    graph_enqueue_ran: bool = False
    graph_structured_parse_used: Optional[bool] = None
    graph_llm_fallback_used: Optional[bool] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "policy_applied": self.policy_applied,
            "memory_dependent": self.memory_dependent,
            "semantic_search_ran": self.semantic_search_ran,
            "graph_read_ran": self.graph_read_ran,
            "s3_rehydration_ran": self.s3_rehydration_ran,
            "s3_rehydration_windows_returned": self.s3_rehydration_windows_returned,
            "s3_rehydration_truncated": self.s3_rehydration_truncated,
            "salient_last_turn": self.salient_last_turn,
            "semantic_index_ran": self.semantic_index_ran,
            "graph_enqueue_ran": self.graph_enqueue_ran,
            "graph_structured_parse_used": self.graph_structured_parse_used,
            "graph_llm_fallback_used": self.graph_llm_fallback_used,
        }


@dataclass
class PrePhaseRequest:
    """Request payload for the pre-phase (before the model call).

    Required fields (all strings): `root_session_id`, `session_id`,
    and `user_message`.

    The orchestrator calls this as the first step of each turn to obtain
    context for the model before generating a reply.
    """

    root_session_id: str
    session_id: str
    user_message: str


@dataclass
class PrePhaseResponse:
    """Response payload from the pre-phase.

    Attributes
    ----------
    short_summary:
        Optional rolling summary of the branch so far.
    recent_events:
        Recent events from this branch, in chronological order.
    semantic_hits:
        Optional semantic memories retrieved for this query. May be empty.
    graph_memory_facts / graph_memory_history:
        Optional V3 graph memory enrichments; present only when graph is enabled.
    memory_telemetry:
        Optional telemetry for memory policy execution.
    response_truncated:
        Flag indicating whether the response was trimmed to fit the byte budget.
    bytes_total:
        Total JSON response size in bytes (including metadata fields).

    The caller uses these fields directly when constructing the prompt
    for the model in the canonical turn loop.
    """

    short_summary: Optional[str]
    recent_events: List[Event]
    semantic_hits: List[SemanticHit]
    graph_memory_facts: Optional[List[Dict[str, Any]]] = None
    graph_memory_history: Optional[Dict[str, Any]] = None
    rehydrated_s3_windows: Optional[List[Dict[str, Any]]] = None
    memory_telemetry: Optional[MemoryTelemetry] = None
    response_truncated: bool = False
    bytes_total: Optional[int] = None


@dataclass
class PostPhaseRequest:
    """Request payload for the post-phase (after the model call).

    Required fields (all strings): `root_session_id`, `session_id`,
    `user_message`, and `assistant_message`.

    The orchestrator calls this after the model replies to persist the
    turn; this is the only API surface that writes or updates memory.
    """

    root_session_id: str
    session_id: str
    user_message: str
    assistant_message: str


@dataclass
class PostPhaseResponse:
    """Response payload from the post-phase.

    For Phase 1 this is intentionally minimal. It mainly signals success
    or failure, but can grow later to include light diagnostics.
    """

    ok: bool = True
    memory_telemetry: Optional[MemoryTelemetry] = None


@dataclass
class TurnRequest:
    """Composite request for persisting the previous turn and preparing the next.

    Attributes
    ----------
    root_session_id / session_id:
        Identity of the conversation branch.
    last_user_message / last_assistant_message:
        Optional completed turn to persist before preparing the next reply.
    current_user_message:
        The current user message to fetch context for (pre-phase).
    """

    root_session_id: str
    session_id: str
    last_user_message: Optional[str]
    last_assistant_message: Optional[str]
    current_user_message: str


@dataclass
class TurnResponse(PrePhaseResponse):
    """Response from the composite /turn endpoint.

    Mirrors PrePhaseResponse fields and adds a flag indicating whether the
    previous turn was persisted during this call.
    """

    persisted_last_turn: bool = False
    memory_telemetry: Optional[MemoryTelemetry] = None


@dataclass
class BranchState:
    """Mutable per-branch state stored in DynamoDB.

    Attributes
    ----------
    root_session_id / session_id:
        Identity of the branch.
    short_summary:
        Rolling summary text for this branch, or None if never summarised.
    recent_events:
        Recent events kept in-memory for cheap short-term context. Always
        chronological and trimmed to a bounded size.
    next_sequence:
        Next sequence number to assign to a new event for this branch.
    summary_turns_since_update:
        Count of turns since the last summary refresh, used for throttling.
    """

    root_session_id: str
    session_id: str
    short_summary: Optional[str] = None
    recent_events: List[Event] = field(default_factory=list)
    next_sequence: int = 0
    summary_turns_since_update: int = 0

    def to_item(self) -> Dict[str, Any]:
        """Serialise this state to a DynamoDB item dict."""
        return {
            "PK": self.root_session_id,
            "SK": self.session_id,
            "short_summary": self.short_summary,
            "recent_events": [e.to_dict() for e in self.recent_events],
            "next_sequence": self.next_sequence,
            "summary_turns_since_update": self.summary_turns_since_update,
        }

    @classmethod
    def from_item(cls, item: Dict[str, Any]) -> "BranchState":
        """Reconstruct a BranchState from a DynamoDB item."""
        events_data = item.get("recent_events") or []
        events = [Event.from_dict(d) for d in events_data]
        return cls(
            root_session_id=item["PK"],
            session_id=item["SK"],
            short_summary=item.get("short_summary"),
            recent_events=events,
            next_sequence=int(item.get("next_sequence", len(events))),
            summary_turns_since_update=int(
                item.get("summary_turns_since_update", 0)
            ),
        )
