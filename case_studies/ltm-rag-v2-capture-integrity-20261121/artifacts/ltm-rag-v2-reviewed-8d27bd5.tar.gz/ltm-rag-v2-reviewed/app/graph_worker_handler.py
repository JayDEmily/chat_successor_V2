"""SQS worker entrypoint for the graph pipeline.

This handler is intended for a dedicated Lambda subscribed to the graph
events FIFO queue. Each record carries the payload emitted by /post
(`graph_pipeline.build_graph_payload`). The worker performs extraction
followed by consolidation in-process.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List

from .config import load_settings
from .graph_consolidation_worker import handle_consolidation_message
from .graph_extraction_worker import handle_extraction_message
from .llm_client import LLMClient
from .logging_utils import get_logger, request_context, update_request_context
from .aws_clients import get_s3_client
from .state_manager import load_branch_state
from .graph_store import DynamoNodeStore
from .graph_vector_store import GraphFactVectorStore


logger = get_logger(__name__)


def _parse_record_body(record: Dict[str, Any]) -> Dict[str, Any]:
    body = record.get("body") or record.get("Body") or "{}"
    if isinstance(body, (bytes, bytearray)):
        body = body.decode("utf-8")
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        logger.warning("graph_worker_bad_message_body", extra={"body": body})
        return {}


def _process_message(
    payload: Dict[str, Any],
    *,
    settings: Any,
    llm_client: Any,
    node_store: Any,
    vector_store: Any,
) -> None:
    root_session_id = payload.get("root_session_id")
    session_id = payload.get("session_id")
    if not root_session_id or not session_id:
        logger.warning(
            "graph_worker_missing_ids",
            extra={"stage": "graph_worker", "status": "skip", "payload_keys": list(payload.keys())},
        )
        return

    # Minimal request context for structured logs.
    update_request_context(
        {"path": "graph_worker", "root_session_id": root_session_id, "session_id": session_id}
    )

    # Load branch state to supply recent events for extraction context.
    branch_state = load_branch_state(settings, root_session_id, session_id)

    s3_client = get_s3_client(settings)
    candidates = handle_extraction_message(
        message=payload,
        s3_client=s3_client,
        branch_state=branch_state,
        llm_client=llm_client,
        settings=settings,
    )

    consolidation_payload: Dict[str, Any] = dict(payload)
    consolidation_payload["candidates"] = candidates
    consolidation_payload.setdefault("transcript_events", branch_state.recent_events)

    handle_consolidation_message(
        message=consolidation_payload,
        node_store=node_store,
        vector_store=vector_store,
        settings=settings,
    )


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Lambda entrypoint for SQS-triggered graph work."""
    settings = load_settings()
    llm_client = LLMClient(settings)
    node_store = DynamoNodeStore(settings)
    vector_store = (
        GraphFactVectorStore(settings)
        if getattr(settings, "graph_vector_index_enabled", False)
        else None
    )
    records: List[Dict[str, Any]] = event.get("Records") or []

    with request_context(path="graph_worker"):
        for rec in records:
            payload = _parse_record_body(rec)
            _process_message(
                payload,
                settings=settings,
                llm_client=llm_client,
                node_store=node_store,
                vector_store=vector_store,
            )

    return {"ok": True, "processed": len(records)}
