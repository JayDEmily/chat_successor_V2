from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Dict, Iterable, List


ANCHORS_NVDA_DESK_V2 = [
    "PLAYBOOK_VERSION=NVDA_DESK_V2",
    "RISK_BUDGET_USD=7500",
    "REGIME_TAG=risk_off",
    "CATALYST=FOMC_2025_03",
    "RULE: if VWAP_reclaim then add",
    "LEVELS: buy=495.50 sell=510.25",
]


def _is_truthy(value: Any) -> bool:
    return value is True


def _telemetry(row: Dict[str, Any]) -> Dict[str, Any]:
    t = row.get("memory_telemetry")
    return t if isinstance(t, dict) else {}


def _contains_requote_cue(text: str) -> bool:
    lower = (text or "").lower()
    cues = ("quote", "verbatim", "exactly", "exact ", "what did you say")
    return any(cue in lower for cue in cues)


def _safe_mean(values: List[int]) -> float:
    if not values:
        return 0.0
    return sum(values) / len(values)


@dataclass(frozen=True)
class AnchorReport:
    seen: Dict[str, bool]
    requoted_later: Dict[str, bool]
    first_seen_turn: Dict[str, int]


def compute_anchor_report(rows: List[Dict[str, Any]]) -> AnchorReport:
    seen: Dict[str, bool] = {a: False for a in ANCHORS_NVDA_DESK_V2}
    first_seen_turn: Dict[str, int] = {}
    requoted_later: Dict[str, bool] = {a: False for a in ANCHORS_NVDA_DESK_V2}

    for row in rows:
        turn_index = int(row.get("turn_index") or 0)
        desk = str(row.get("desk_agent_text") or "")
        for anchor in ANCHORS_NVDA_DESK_V2:
            if anchor in desk:
                seen[anchor] = True
                first_seen_turn.setdefault(anchor, turn_index)

    for row in rows:
        turn_index = int(row.get("turn_index") or 0)
        user = str(row.get("user_agent_text") or "")
        desk = str(row.get("desk_agent_text") or "")
        if not _contains_requote_cue(user):
            continue
        for anchor in ANCHORS_NVDA_DESK_V2:
            first_turn = first_seen_turn.get(anchor)
            if first_turn is None or turn_index <= first_turn:
                continue
            if anchor in desk:
                requoted_later[anchor] = True

    return AnchorReport(seen=seen, requoted_later=requoted_later, first_seen_turn=first_seen_turn)


def compute_baseline_metrics(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    exchanges_total = len(rows)

    desk_texts = [str(r.get("desk_agent_text") or "") for r in rows]
    ack_count = sum(1 for t in desk_texts if t.strip().upper() == "ACK")
    empty_output_count = sum(1 for t in desk_texts if not t.strip())
    substantive_count = sum(1 for t in desk_texts if len(t.strip()) > 200)
    desk_outputs_substantive_ratio = (
        (substantive_count / exchanges_total) if exchanges_total else 0.0
    )

    semantic_search_ran_count = sum(1 for r in rows if _is_truthy(_telemetry(r).get("semantic_search_ran")))
    graph_read_ran_count = sum(1 for r in rows if _is_truthy(_telemetry(r).get("graph_read_ran")))
    graph_enqueue_ran_count = sum(1 for r in rows if _is_truthy(_telemetry(r).get("graph_enqueue_ran")))

    rehydrated_windows_nonzero_count = sum(
        1 for r in rows if int(r.get("rehydrated_windows_count") or 0) > 0
    )

    bytes_values = [int(r.get("bytes_total")) for r in rows if isinstance(r.get("bytes_total"), int)]
    bytes_total_max = max(bytes_values) if bytes_values else 0
    bytes_total_avg = _safe_mean(bytes_values)

    response_truncated_count = sum(1 for r in rows if _is_truthy(r.get("response_truncated")))

    anchor_report = compute_anchor_report(rows)

    return {
        "exchanges_total": exchanges_total,
        "desk_outputs_substantive_ratio": desk_outputs_substantive_ratio,
        "ack_count": ack_count,
        "empty_output_count": empty_output_count,
        "semantic_search_ran_count": semantic_search_ran_count,
        "graph_read_ran_count": graph_read_ran_count,
        "graph_enqueue_ran_count": graph_enqueue_ran_count,
        "rehydrated_windows_nonzero_count": rehydrated_windows_nonzero_count,
        "anchors_seen_in_desk_output": dict(anchor_report.seen),
        "anchors_requoted_later": dict(anchor_report.requoted_later),
        "bytes_total_max": bytes_total_max,
        "bytes_total_avg": bytes_total_avg,
        "response_truncated_count": response_truncated_count,
    }


def enforce_quality_gates(rows: List[Dict[str, Any]]) -> None:
    metrics = compute_baseline_metrics(rows)
    if metrics["ack_count"] != 0:
        raise ValueError(f"ACK outputs detected: {metrics['ack_count']}")
    if metrics["empty_output_count"] != 0:
        raise ValueError(f"Empty outputs detected: {metrics['empty_output_count']}")

    missing = [a for a, ok in metrics["anchors_seen_in_desk_output"].items() if not ok]
    if missing:
        raise ValueError(f"Missing anchors in desk output: {missing}")

    not_requoted = [a for a, ok in metrics["anchors_requoted_later"].items() if not ok]
    if not_requoted:
        raise ValueError(f"Anchors not re-quoted later: {not_requoted}")

    ratio = float(metrics["desk_outputs_substantive_ratio"] or 0.0)
    if math.isfinite(ratio) and ratio < 0.7:
        raise ValueError(f"Desk outputs not substantive enough (ratio={ratio:.2f})")

