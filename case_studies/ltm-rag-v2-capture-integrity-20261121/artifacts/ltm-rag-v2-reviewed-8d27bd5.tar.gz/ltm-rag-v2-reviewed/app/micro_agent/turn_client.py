from __future__ import annotations

import json
import os
from typing import Any, Dict

import requests
import boto3
from botocore.exceptions import BotoCoreError, ClientError


ENV_URL_KEYS = ("LIVE_LAMBDA_URL", "LIVE_FUNCTION_URL", "MEMORY_AGENT_URL")
CANONICAL_ENV_MATCH = {
    "STATE_TABLE": "memory-agent-branch-state",
    "TRANSCRIPT_BUCKET": "memory-agent-transcripts-000000000000-ap-southeast-2",
    "MEMORY_NODES_TABLE": "memory-nodes",
    "GRAPH_EVENTS_QUEUE_URL": "https://example.invalid/sqs-placeholder",
}
CANONICAL_REGION = "ap-southeast-2"


class TurnClientError(RuntimeError):
    """Raised when HTTP or response parsing fails for /turn."""


def _discover_function_url() -> str | None:
    """Attempt to find the Lambda Function URL by matching canonical env config."""
    client = boto3.client("lambda", region_name=CANONICAL_REGION)
    try:
        paginator = client.get_paginator("list_functions")
        for page in paginator.paginate():
            for fn in page.get("Functions") or []:
                env = (fn.get("Environment") or {}).get("Variables") or {}
                if all(env.get(k) == v for k, v in CANONICAL_ENV_MATCH.items()):
                    fn_name = fn.get("FunctionName")
                    if not fn_name:
                        continue
                    try:
                        url_cfg = client.get_function_url_config(FunctionName=fn_name)
                    except client.exceptions.ResourceNotFoundException:
                        # No Function URL configured for this function; keep searching.
                        continue
                    except (ClientError, BotoCoreError) as exc:  # pragma: no cover - passthrough
                        raise TurnClientError(
                            f"AWS Lambda get_function_url_config failed for {fn_name}: {exc}"
                        ) from exc
                    url = url_cfg.get("FunctionUrl")
                    if url:
                        return url.rstrip("/")
    except (ClientError, BotoCoreError) as exc:  # pragma: no cover - passthrough
        raise TurnClientError(f"AWS Lambda discovery failed in {CANONICAL_REGION}: {exc}") from exc
    return None


def resolve_function_url() -> str:
    """Resolve the Lambda Function URL from environment variables.

    Mirrors the resolution logic used in existing live tests and scripts.
    """
    for key in ENV_URL_KEYS:
        val = os.getenv(key)
        if val:
            return val.rstrip("/")

    discovered = _discover_function_url()
    if discovered:
        return discovered

    raise TurnClientError(
        "Function URL missing; set LIVE_LAMBDA_URL/LIVE_FUNCTION_URL/MEMORY_AGENT_URL "
        f"or ensure a Lambda in {CANONICAL_REGION} has env "
        f"{CANONICAL_ENV_MATCH} and a configured Function URL"
    )


def post_turn(function_url: str, payload: Dict[str, Any], timeout: int = 90) -> Dict[str, Any]:
    """POST a payload to /turn and return {'status': int, 'body': dict}."""
    url = function_url.rstrip("/") + "/turn"
    try:
        resp = requests.post(url, json=payload, timeout=timeout)
    except requests.RequestException as exc:
        raise TurnClientError(f"Request to {url} failed: {exc}") from exc

    status = resp.status_code
    try:
        body = resp.json()
    except ValueError as exc:
        raise TurnClientError(
            f"/turn returned non-JSON (status {status}): {resp.text}"
        ) from exc

    return {"status": status, "body": body}

