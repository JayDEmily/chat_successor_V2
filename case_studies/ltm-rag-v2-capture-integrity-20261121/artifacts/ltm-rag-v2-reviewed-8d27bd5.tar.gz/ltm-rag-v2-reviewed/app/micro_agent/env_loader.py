from __future__ import annotations

import os
from pathlib import Path


def load_env(path: str | None = None) -> None:
    """Load KEY=VALUE pairs from a .env file into os.environ.

    Lines starting with `#` or empty lines are ignored. Existing environment
    variables are not overwritten.
    """
    env_path = Path(path) if path is not None else Path(__file__).resolve().parents[2] / ".env"
    if not env_path.exists():
        return

    try:
        content = env_path.read_text(encoding="utf-8")
    except OSError:
        return

    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key or key in os.environ:
            continue
        os.environ[key] = value


