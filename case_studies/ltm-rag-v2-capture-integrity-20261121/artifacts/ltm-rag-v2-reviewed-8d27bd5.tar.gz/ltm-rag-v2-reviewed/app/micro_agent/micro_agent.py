from __future__ import annotations

from dataclasses import dataclass
import os
import time
from typing import Any, Dict, List, Optional

from openai import OpenAI

from .turn_client import TurnClientError, post_turn, resolve_function_url


MICRO_AGENT_MODEL_ENV = "MICRO_AGENT_MODEL"
DEFAULT_MODEL = "gpt-5-nano"
DEFAULT_INSTRUCTIONS = (
    "You are a concise assistant for a memory-enabled RAG prototype. "
    "Use the conversation summary, recent events, semantic hits, and "
    "graph memory facts (when present) to answer the latest user "
    "message. Reply in a short, factual paragraph."
)


@dataclass
class StepResult:
    """Result of a single micro-agent step."""

    turn_response: Dict[str, Any]
    assistant_text: str
    model_used: str
    http_status: int


class MicroAgent:
    """Minimal harness that calls /turn then GPT-5 nano via Responses API.

    The agent threads last_user_message/last_assistant_message through the
    /turn loop and uses the returned context to build a prompt for the model.
    """

    def __init__(
        self,
        root_session_id: str,
        session_id: str,
        scenario_name: str = "animals",
        *,
        function_url: Optional[str] = None,
        model: Optional[str] = None,
        instructions: Optional[str] = None,
        max_output_tokens: int = 800,
        timeout_seconds: int = 90,
    ):
        self.root_session_id = root_session_id
        self.session_id = session_id
        self.scenario_name = scenario_name
        self.last_user_message: Optional[str] = None
        self.last_assistant_message: Optional[str] = None

        self._function_url = (
            function_url.rstrip("/") if function_url is not None else resolve_function_url()
        )
        self._model = model or os.getenv(MICRO_AGENT_MODEL_ENV) or DEFAULT_MODEL
        self._client = OpenAI()
        self._instructions = (instructions or DEFAULT_INSTRUCTIONS).strip()
        self._max_output_tokens = max_output_tokens
        self._timeout_seconds = timeout_seconds

    @property
    def model_name(self) -> str:
        """Return the model id configured for this micro agent."""
        return self._model

    @property
    def instructions(self) -> str:
        """Return the system instructions used for Responses calls."""
        return self._instructions

    def step(self, user_message: str) -> StepResult:
        """Execute one turn: call /turn, then call the Responses API."""
        payload: Dict[str, Any] = {
            "root_session_id": self.root_session_id,
            "session_id": self.session_id,
            "last_user_message": self.last_user_message,
            "last_assistant_message": self.last_assistant_message,
            "current_user_message": user_message,
        }

        turn_http = post_turn(self._function_url, payload, timeout=self._timeout_seconds)
        status = int(turn_http.get("status", 0))
        body = turn_http.get("body") or {}
        if status != 200:
            raise TurnClientError(f"/turn returned HTTP {status}: {body}")

        prompt = self._build_prompt(body, user_message)

        request_data = dict(
            model=self._model,
            instructions=self._instructions,
            input=[
                {
                    "role": "user",
                    "content": [{"type": "input_text", "text": prompt}],
                }
            ],
            max_output_tokens=self._max_output_tokens,
        )
        if self._model.startswith("gpt-5-nano"):
            request_data["reasoning"] = {"effort": "low"}
        else:
            request_data["temperature"] = 0

        response = None
        last_exc: Exception | None = None
        for attempt in range(3):
            try:
                response = self._client.responses.create(**request_data)
                last_exc = None
                break
            except Exception as exc:  # pragma: no cover - best-effort live retry
                last_exc = exc
                if attempt == 2:
                    break
                time.sleep(1 + attempt)
        if response is None:
            assert last_exc is not None
            raise last_exc

        assistant_text = getattr(response, "output_text", "") or ""
        if not assistant_text:
            try:
                outputs = getattr(response, "output", None) or []
                for item in outputs:
                    content_list = getattr(item, "content", None) or []
                    for content in content_list:
                        candidate = getattr(content, "text", None) or getattr(
                            content, "output_text", None
                        )
                        if candidate:
                            assistant_text = str(candidate)
                            break
                    if assistant_text:
                        break
            except Exception:
                assistant_text = ""
        assistant_text = assistant_text.strip()
        if not assistant_text:
            assistant_text = "ACK"

        # Update last_* for the next step.
        self.last_user_message = user_message
        self.last_assistant_message = assistant_text

        model_used = getattr(response, "model", self._model)

        return StepResult(
            turn_response=body,
            assistant_text=assistant_text,
            model_used=model_used,
            http_status=status,
        )

    def _build_prompt(self, turn_body: Dict[str, Any], user_message: str) -> str:
        """Construct a prompt from the /turn context plus the current message."""
        lines: List[str] = []

        summary = turn_body.get("short_summary") or ""
        if isinstance(summary, str) and summary.strip():
            lines.append("Conversation summary:")
            lines.append(summary.strip())

        events = turn_body.get("recent_events") or []
        if isinstance(events, list) and events:
            lines.append("Recent events:")
            for evt in events[-6:]:
                if not isinstance(evt, dict):
                    continue
                role = str(evt.get("role") or "unknown")
                content = str(evt.get("content") or "").strip()
                if content:
                    lines.append(f"{role}: {content}")

        hits = turn_body.get("semantic_hits") or []
        if isinstance(hits, list) and hits:
            lines.append("Semantic memories:")
            for hit in hits[:3]:
                if not isinstance(hit, dict):
                    continue
                text = str(hit.get("text") or "").strip()
                if text:
                    lines.append(f"- {text}")

        windows = turn_body.get("rehydrated_s3_windows") or []
        if isinstance(windows, list) and windows:
            lines.append("Rehydrated transcript windows:")
            for window in windows[:2]:
                if not isinstance(window, dict):
                    continue
                source = window.get("source") or {}
                key = source.get("transcript_key")
                if key:
                    lines.append(f"Window from {key}:")
                events = window.get("window_events") or []
                for evt in events:
                    if not isinstance(evt, dict):
                        continue
                    seq = evt.get("sequence")
                    role = evt.get("role")
                    event_id = evt.get("event_id")
                    content = str(evt.get("content") or "").strip()
                    if content:
                        lines.append(f"[{seq}] {role} ({event_id}): {content}")

        graph_facts = turn_body.get("graph_memory_facts") or []
        if isinstance(graph_facts, list) and graph_facts:
            lines.append("Graph memory facts:")
            for fact in graph_facts[:3]:
                if not isinstance(fact, dict):
                    continue
                entity = fact.get("entity")
                fact_text = fact.get("fact")
                if entity and fact_text:
                    lines.append(f"- {entity}: {fact_text}")
                else:
                    lines.append(f"- {fact}")

        graph_history = turn_body.get("graph_memory_history") or {}
        if isinstance(graph_history, dict) and graph_history:
            keys = ", ".join(sorted(str(k) for k in graph_history.keys()))
            lines.append("Graph memory history keys:")
            lines.append(keys)

        lines.append("User message:")
        lines.append(user_message)

        return "\n".join(lines)
