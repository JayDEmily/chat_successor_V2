from __future__ import annotations

import json
from typing import Any, Dict, Iterable, List, Optional


def _as_dict(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    return {}


def _as_list(value: Any) -> List[Any]:
    if isinstance(value, list):
        return value
    return []


def _truncate(text: str, max_chars: int) -> str:
    s = (text or "").strip()
    if len(s) <= max_chars:
        return s
    return s[: max_chars - 1].rstrip() + "…"


def _format_event(evt: Dict[str, Any]) -> str:
    seq = evt.get("sequence")
    role = evt.get("role")
    event_id = evt.get("event_id")
    content = _truncate(str(evt.get("content") or ""), 400)
    return f"[{seq}] {role} ({event_id}): {content}"


def _format_semantic_hit(hit: Dict[str, Any]) -> str:
    score = hit.get("score")
    text = _truncate(str(hit.get("text") or ""), 300)
    metadata = _as_dict(hit.get("metadata"))
    meta_keys = sorted(str(k) for k in metadata.keys())
    return f"score={score} meta_keys={meta_keys} text={text}"


def _format_graph_fact(fact: Dict[str, Any]) -> str:
    entity = fact.get("entity")
    state = fact.get("state")
    fact_text = _truncate(str(fact.get("fact") or ""), 320)
    source_ids = fact.get("source_event_ids")
    updated_at = fact.get("updated_at")
    extra = []
    if source_ids:
        extra.append(f"source_event_ids={source_ids}")
    if updated_at:
        extra.append(f"updated_at={updated_at}")
    extra_s = (" " + " ".join(extra)) if extra else ""
    return f"entity={entity} state={state} fact={fact_text}{extra_s}"


def build_context_pack(
    turn_body: Optional[Dict[str, Any]],
    *,
    max_recent_events: int = 10,
    max_semantic_hits: int = 3,
    max_rehydrated_windows: int = 2,
    max_window_events: int = 8,
    max_graph_facts: int = 5,
) -> str:
    """Build a deterministic, bounded context pack string from a /turn response body."""
    body = turn_body or {}

    lines: List[str] = []

    short_summary = body.get("short_summary")
    lines.append("SHORT_SUMMARY:")
    if isinstance(short_summary, str) and short_summary.strip():
        lines.append(_truncate(short_summary, 1200))
    else:
        lines.append("<none>")

    lines.append("")
    lines.append("RECENT_EVENTS:")
    recent_events = _as_list(body.get("recent_events"))
    if recent_events:
        tail = recent_events[-max_recent_events:]
        for raw in tail:
            evt = _as_dict(raw)
            if not evt:
                continue
            lines.append(f"- {_format_event(evt)}")
    else:
        lines.append("- <none>")

    lines.append("")
    lines.append("SEMANTIC_HITS:")
    semantic_hits = _as_list(body.get("semantic_hits"))
    if semantic_hits:
        for raw in semantic_hits[:max_semantic_hits]:
            hit = _as_dict(raw)
            if not hit:
                continue
            lines.append(f"- {_format_semantic_hit(hit)}")
    else:
        lines.append("- <none>")

    lines.append("")
    lines.append("REHYDRATED_S3_WINDOWS:")
    windows = _as_list(body.get("rehydrated_s3_windows"))
    if windows:
        for raw_window in windows[:max_rehydrated_windows]:
            window = _as_dict(raw_window)
            if not window:
                continue
            source = _as_dict(window.get("source"))
            transcript_key = source.get("transcript_key")
            bucket = source.get("bucket")
            lines.append(f"- source transcript_key={transcript_key} bucket={bucket}")
            anchor = _as_dict(window.get("anchor"))
            if anchor:
                lines.append(
                    f"  anchor seq={anchor.get('sequence')} role={anchor.get('role')} event_id={anchor.get('event_id')}"
                )
            window_events = _as_list(window.get("window_events"))
            if window_events:
                lines.append("  window_events:")
                for raw_evt in window_events[:max_window_events]:
                    evt = _as_dict(raw_evt)
                    if not evt:
                        continue
                    lines.append(f"  - {_format_event(evt)}")
            else:
                lines.append("  window_events: <none>")
    else:
        lines.append("- <none>")

    lines.append("")
    lines.append("GRAPH_MEMORY_FACTS:")
    facts = _as_list(body.get("graph_memory_facts"))
    if facts:
        for raw_fact in facts[:max_graph_facts]:
            fact = _as_dict(raw_fact)
            if not fact:
                continue
            lines.append(f"- {_format_graph_fact(fact)}")
    else:
        lines.append("- <none>")

    lines.append("")
    lines.append("TELEMETRY:")
    persisted_last_turn = body.get("persisted_last_turn")
    bytes_total = body.get("bytes_total")
    response_truncated = body.get("response_truncated")
    memory_telemetry = body.get("memory_telemetry") or {}
    lines.append(f"- persisted_last_turn={persisted_last_turn}")
    lines.append(f"- bytes_total={bytes_total}")
    lines.append(f"- response_truncated={response_truncated}")
    try:
        lines.append("- memory_telemetry=" + json.dumps(memory_telemetry, sort_keys=True))
    except TypeError:
        lines.append("- memory_telemetry=<unserialisable>")

    return "\n".join(lines).strip() + "\n"

