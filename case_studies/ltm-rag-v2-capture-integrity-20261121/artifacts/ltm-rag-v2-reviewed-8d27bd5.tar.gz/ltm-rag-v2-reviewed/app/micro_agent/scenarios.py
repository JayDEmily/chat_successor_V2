from __future__ import annotations

from typing import Dict, List, TypedDict


class ScenarioTurn(TypedDict):
    user: str


Scenario = List[ScenarioTurn]


DEFAULT_SCENARIO_NAME = "animals"


SCENARIOS: Dict[str, Scenario] = {
    "animals": [
        {
            "user": (
                "You are a concise assistant. I enjoy learning about birds, "
                "dogs, and animal migrations. Please answer factually and briefly."
            )
        },
        {
            "user": "Name one migratory bird species and where it travels."
        },
        {
            "user": "Name one working dog breed and its typical job."
        },
        {
            "user": "In one sentence, summarise my interests from this chat."
        },
    ],
    "nvda_desk_v1": [
        {
            "user": (
                "We are creating a stable benchmark transcript with fictional scenario "
                "numbers (NOT live market data). You are a Tier-1 equities desk execution "
                "assistant. We are day-trading NVDA stock ONLY (no options). Confirm and "
                "restate the constraint in one line."
            )
        },
        {
            "user": (
                "Set the playbook context and print an 'Execution Card' using these exact "
                "lines verbatim (don't alter spacing/case):\n"
                "PLAYBOOK_VERSION=NVDA_DESK_V1\n"
                "RISK_BUDGET_USD=7500\n"
                "REGIME_TAG=risk_off\n"
                "CATALYST=FOMC_2025_03\n"
                "RULE: if VWAP_reclaim then add\n"
                "LEVELS: buy=495.50 sell=510.25\n\n"
                "Then add 4–6 bullets explaining how you will enforce this (rule-based, "
                "no vibes)."
            )
        },
        {
            "user": (
                "Assume a fictional spot reference of 503.00. Give a rule-based plan for "
                "three scenarios (breakdown, range, breakout) using the LEVELS above and "
                "explicit stop distances."
            )
        },
        {
            "user": (
                "Define position sizing rules in shares with examples so that a single "
                "stop-out never exceeds 2,500 USD and total day loss never exceeds "
                "RISK_BUDGET_USD=7500."
            )
        },
        {
            "user": (
                "Remind me of the exact risk budget line and the per-trade max loss rule "
                "you just set. Quote them verbatim and then restate in different words "
                "(risk discipline theme)."
            )
        },
        {
            "user": (
                "Add regime context: use fictional VIX=21.4 and VVIX=102. Explain what "
                "'risk_off' means operationally for sizing, adding, and holding time."
            )
        },
        {
            "user": (
                "Calendar: We have CATALYST=FOMC_2025_03 (2pm ET) and CPI tomorrow "
                "(8:30am ET). Give rules for exposure into/after these prints, including "
                "an explicit 'no overnight' constraint."
            )
        },
        {
            "user": (
                "Sector confirmation: reference SOX and NQ as context (fictional). Define "
                "a rule like 'only press longs if semis breadth confirms' and explain how "
                "that interacts with NVDA."
            )
        },
        {
            "user": (
                "Now design a concrete long setup and a concrete short setup for NVDA "
                "with triggers, entries, stops, targets, and what invalidates each. Use "
                "hard numbers tied to 495.50/510.25 and 503.00."
            )
        },
        {
            "user": (
                "Add a VWAP-based add rule: expand on RULE: if VWAP_reclaim then add. "
                "Specify what counts as a reclaim and when you refuse to add."
            )
        },
        {
            "user": (
                "Controlled distractor: AMD looks strong today and TSLA is squeezing. "
                "Briefly mention whether that changes anything, but keep the plan strictly "
                "NVDA-only."
            )
        },
        {
            "user": (
                "I'm tempted to 'go bigger' after a win. Push back: restate the risk "
                "budget discipline and how you prevent emotional sizing."
            )
        },
        {
            "user": (
                "Give a micro playbook for the first 15 minutes after the open vs. the "
                "last hour into FOMC. Include explicit 'stand down' conditions."
            )
        },
        {
            "user": (
                "Ask yourself: what are the top 3 failure modes in this plan (chop, "
                "headline risk, false VWAP reclaim)? Give mitigations."
            )
        },
        {
            "user": (
                "Memory check: What was our exact LEVELS line and the VWAP add rule line? "
                "Quote them verbatim."
            )
        },
        {
            "user": (
                "Now simulate a fictional tape: NVDA trades down to 496.20 then reclaims "
                "500.80 with semis firming. Walk through what you do step-by-step with "
                "sizing and stops."
            )
        },
        {
            "user": (
                "Now simulate the opposite: NVDA rejects 510.25, VIX pops, NQ rolls. Walk "
                "through the short-side play with risk controls."
            )
        },
        {
            "user": (
                "Overnight constraints (again, indirectly): It's 15:55 ET and liquidity "
                "is thinning. What do we do with any remaining position and why?"
            )
        },
        {
            "user": (
                "Create a final 'Desk Summary' with: regime, key levels, catalyst rules, "
                "risk limits, and 2–3 do/don't bullets. Keep it crisp but specific."
            )
        },
        {
            "user": (
                "Final recall: In one block, print the Execution Card again including "
                "the exact anchor lines verbatim, and add a one-sentence disclaimer that "
                "numbers are fictional scenario values."
            )
        },
    ],
}


def get_scenario(name: str = DEFAULT_SCENARIO_NAME) -> Scenario:
    """Return a predefined scenario script by name."""
    if name not in SCENARIOS:
        raise KeyError(f"Unknown scenario: {name!r}")
    return SCENARIOS[name]

