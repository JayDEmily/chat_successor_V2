from __future__ import annotations

from collections.abc import Iterable
from typing import Any, Optional


class ResponseTextError(ValueError):
    """Raised when the Responses API output text cannot be extracted."""


def _maybe_get(obj: Any, key: str) -> Any:
    if isinstance(obj, dict):
        return obj.get(key)
    return getattr(obj, key, None)


def _iter_output_items(response: Any) -> Iterable[Any]:
    output = _maybe_get(response, "output")
    if output is None:
        return []
    if isinstance(output, (list, tuple)):
        return output
    if isinstance(output, dict) or isinstance(output, str):
        return []
    if isinstance(output, Iterable):
        return output
    return []


def _iter_content_blocks(item: Any) -> Iterable[Any]:
    content = _maybe_get(item, "content")
    if content is None:
        return []
    if isinstance(content, (list, tuple)):
        return content
    if isinstance(content, dict) or isinstance(content, str):
        return []
    if isinstance(content, Iterable):
        return content
    return []


def extract_output_text(response: Any) -> Optional[str]:
    """Best-effort extraction of text from an OpenAI Responses object/dict."""
    direct = _maybe_get(response, "output_text")
    if isinstance(direct, str) and direct.strip():
        return direct

    for item in _iter_output_items(response):
        for block in _iter_content_blocks(item):
            candidate = _maybe_get(block, "text") or _maybe_get(block, "output_text")
            if isinstance(candidate, str) and candidate.strip():
                return candidate
    return None


def extract_output_text_strict(response: Any, *, label: str) -> str:
    """Extract text from a Responses payload or raise ResponseTextError."""
    text = extract_output_text(response)
    if text is None:
        raise ResponseTextError(f"{label}: could not extract output text from Responses payload")
    cleaned = text.strip()
    if not cleaned:
        raise ResponseTextError(f"{label}: extracted output text was empty")
    return cleaned
