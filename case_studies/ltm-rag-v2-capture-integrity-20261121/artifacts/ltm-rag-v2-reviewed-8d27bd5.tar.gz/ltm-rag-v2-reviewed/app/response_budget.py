from __future__ import annotations

from typing import List

from .models import Event, PrePhaseResponse, SemanticHit, TurnResponse
from .response_utils import ResponseSizeReport, build_body_and_measure

# Conservative caps to keep responses within the byte budget while retaining
# the most recent/high-signal content.
MAX_SEMANTIC_HIT_CHARS = 2000
MAX_RECENT_EVENT_CHARS = 4000
MAX_SUMMARY_CHARS = 2000


def enforce_response_budget(
    resp: PrePhaseResponse | TurnResponse, budget_bytes: int
) -> ResponseSizeReport:
    """Mutate resp in-place to ensure the JSON response stays within budget_bytes."""
    truncated = False
    rehydration_truncated = False

    def _update_rehydration_telemetry() -> None:
        windows = getattr(resp, "rehydrated_s3_windows", None)
        telemetry = getattr(resp, "memory_telemetry", None)
        if telemetry is None:
            return
        telemetry.s3_rehydration_windows_returned = len(windows or [])
        if rehydration_truncated:
            telemetry.s3_rehydration_truncated = True

    def _measure() -> ResponseSizeReport:
        resp.response_truncated = truncated
        _, report = build_body_and_measure(resp, set_bytes_total=True)
        return report

    if budget_bytes <= 0:
        report = _measure()
        resp.response_truncated = False
        _update_rehydration_telemetry()
        return report

    report = _measure()
    if report.total_bytes <= budget_bytes:
        resp.response_truncated = truncated
        _update_rehydration_telemetry()
        return report

    # (1) Remove graph_memory_history entirely.
    if getattr(resp, "graph_memory_history", None) is not None:
        resp.graph_memory_history = None  # type: ignore[attr-defined]
        truncated = True
        report = _measure()
        if report.total_bytes <= budget_bytes:
            resp.response_truncated = True
            return report

    # (2) Truncate semantic hit text, then drop tail hits until within budget.
    truncated = _truncate_semantic_hits(resp.semantic_hits, MAX_SEMANTIC_HIT_CHARS) or truncated
    report = _measure()
    while report.total_bytes > budget_bytes and resp.semantic_hits:
        resp.semantic_hits = resp.semantic_hits[:-1]
        truncated = True
        report = _measure()

    # (3) Truncate recent event content, then drop oldest events until within budget.
    truncated = _truncate_recent_events(resp.recent_events, MAX_RECENT_EVENT_CHARS) or truncated
    report = _measure()
    while report.total_bytes > budget_bytes and resp.recent_events:
        resp.recent_events.pop(0)
        truncated = True
        report = _measure()

    # (4) Truncate the short_summary progressively.
    truncated = _truncate_summary(resp, MAX_SUMMARY_CHARS) or truncated
    report = _measure()
    while report.total_bytes > budget_bytes and getattr(resp, "short_summary", None):
        current = resp.short_summary or ""
        new_len = max(0, len(current) - max(256, len(current) // 2))
        resp.short_summary = current[:new_len] or None
        truncated = True
        report = _measure()
        if not resp.short_summary:
            break

    if report.total_bytes > budget_bytes:
        # Last resort: strip remaining heavy fields but never omit telemetry.
        resp.semantic_hits = []
        resp.recent_events = []
        resp.short_summary = None
        if getattr(resp, "graph_memory_history", None) is not None:
            resp.graph_memory_history = None  # type: ignore[attr-defined]
        truncated = True
        _, report = build_body_and_measure(resp, set_bytes_total=True)

    if report.total_bytes > budget_bytes:
        windows = getattr(resp, "rehydrated_s3_windows", None) or []
        if windows:
            changed = _truncate_rehydrated_windows(windows)
            if changed:
                rehydration_truncated = True
                truncated = True
                report = _measure()
            while report.total_bytes > budget_bytes and len(windows) > 1:
                windows.pop()
                rehydration_truncated = True
                truncated = True
                report = _measure()

    resp.response_truncated = truncated or report.total_bytes > budget_bytes
    _, report = build_body_and_measure(resp, set_bytes_total=True)
    _update_rehydration_telemetry()
    return report


def _truncate_semantic_hits(hits: List[SemanticHit], max_chars: int) -> bool:
    changed = False
    for hit in hits or []:
        text = getattr(hit, "text", "") or ""
        if len(text) > max_chars:
            hit.text = text[:max_chars]
            changed = True
    return changed


def _truncate_recent_events(events: List[Event], max_chars: int) -> bool:
    changed = False
    for evt in events or []:
        content = getattr(evt, "content", "") or ""
        if len(content) > max_chars:
            evt.content = content[:max_chars]
            changed = True
    return changed


def _truncate_summary(resp: PrePhaseResponse | TurnResponse, max_chars: int) -> bool:
    if not getattr(resp, "short_summary", None):
        return False
    summary = resp.short_summary or ""
    if len(summary) <= max_chars:
        return False
    resp.short_summary = summary[:max_chars]
    return True


def _truncate_rehydrated_windows(windows: List[dict]) -> bool:
    """Shrink each window down to its anchor event only."""
    changed = False
    for window in windows or []:
        if not isinstance(window, dict):
            continue
        anchor = window.get("anchor") or {}
        anchor_id = anchor.get("event_id")
        anchor_seq = anchor.get("sequence")
        events = window.get("window_events") or []
        anchor_event = None
        for evt in events:
            if not isinstance(evt, dict):
                continue
            if anchor_id and evt.get("event_id") == anchor_id:
                anchor_event = evt
                break
            if anchor_event is None and anchor_seq is not None and evt.get("sequence") == anchor_seq:
                anchor_event = evt
                break
        if anchor_event is None:
            continue
        if len(events) != 1 or events[0] is not anchor_event:
            window["window_events"] = [anchor_event]
            changed = True
    return changed
