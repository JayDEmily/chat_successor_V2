from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from decimal import Decimal


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: Optional[datetime]) -> Optional[str]:
    if dt is None:
        return None
    return dt.astimezone(timezone.utc).isoformat()


def _from_iso(raw: Optional[str | datetime]) -> Optional[datetime]:
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw.astimezone(timezone.utc)
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00")).astimezone(timezone.utc)
    except Exception:
        return None


def make_node_id(root_session_id: str, entity: str, type: str, fact: str, source_event_ids: List[str] | None = None) -> str:
    """Deterministic node id based on immutable identity fields (excluding evidence)."""
    h = hashlib.sha256()
    h.update(root_session_id.encode("utf-8"))
    h.update(b"|")
    h.update(entity.encode("utf-8"))
    h.update(b"|")
    h.update(type.encode("utf-8"))
    h.update(b"|")
    h.update(fact.encode("utf-8"))
    return h.hexdigest()


@dataclass
class MemoryNode:
    node_id: str
    root_session_id: str
    entity: str
    type: str
    fact: str
    state: str = "active"
    confidence: float = 0.0
    valid_from: datetime = field(default_factory=_utc_now)
    valid_to: Optional[datetime] = None
    history_reason: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    source_event_ids: List[str] = field(default_factory=list)
    source_session_ids: List[str] = field(default_factory=list)
    supersedes: List[str] = field(default_factory=list)
    superseded_by: Optional[str] = None
    created_at: datetime = field(default_factory=_utc_now)
    updated_at: datetime = field(default_factory=_utc_now)
    kind: str = "graph_fact"

    @property
    def pk(self) -> str:
        return self.root_session_id

    @property
    def sk(self) -> str:
        return f"{self.entity}#{self.type}#{self.node_id}"

    def to_item(self) -> Dict[str, Any]:
        return {
            "PK": self.pk,
            "SK": self.sk,
            "node_id": self.node_id,
            "root_session_id": self.root_session_id,
            "entity": self.entity,
            "type": self.type,
            "fact": self.fact,
            "state": self.state,
            "confidence": Decimal(str(self.confidence)),
            "valid_from": _iso(self.valid_from),
            "valid_to": _iso(self.valid_to),
            "history_reason": self.history_reason,
            "tags": list(self.tags),
            "source_event_ids": list(self.source_event_ids),
            "source_session_ids": list(self.source_session_ids),
            "supersedes": list(self.supersedes),
            "superseded_by": self.superseded_by,
            "created_at": _iso(self.created_at),
            "updated_at": _iso(self.updated_at),
            "kind": self.kind,
        }

    @classmethod
    def from_item(cls, item: Dict[str, Any]) -> "MemoryNode":
        return cls(
            node_id=item.get("node_id") or item.get("SK", "").split("#")[-1],
            root_session_id=item.get("root_session_id") or item.get("PK"),
            entity=item.get("entity") or (item.get("SK", "").split("#")[:1] or [""])[0],
            type=item.get("type") or (item.get("SK", "").split("#")[1] if "SK" in item else ""),
            fact=item.get("fact", ""),
            state=item.get("state", "active"),
            confidence=float(item.get("confidence", 0.0)),
            valid_from=_from_iso(item.get("valid_from")) or _utc_now(),
            valid_to=_from_iso(item.get("valid_to")),
            history_reason=item.get("history_reason"),
            tags=item.get("tags") or [],
            source_event_ids=item.get("source_event_ids") or [],
            source_session_ids=item.get("source_session_ids") or [],
            supersedes=item.get("supersedes") or [],
            superseded_by=item.get("superseded_by"),
            created_at=_from_iso(item.get("created_at")) or _utc_now(),
            updated_at=_from_iso(item.get("updated_at")) or _utc_now(),
            kind=item.get("kind", "graph_fact"),
        )


@dataclass
class MemoryEdge:
    root_session_id: str
    from_node_id: str
    to_node_id: str
    relation: str
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=_utc_now)
    updated_at: datetime = field(default_factory=_utc_now)

    @property
    def pk(self) -> str:
        return self.root_session_id

    @property
    def sk(self) -> str:
        return f"{self.from_node_id}#{self.to_node_id}#{self.relation}"

    def to_item(self) -> Dict[str, Any]:
        return {
            "PK": self.pk,
            "SK": self.sk,
            "root_session_id": self.root_session_id,
            "from_node_id": self.from_node_id,
            "to_node_id": self.to_node_id,
            "relation": self.relation,
            "tags": list(self.tags),
            "created_at": _iso(self.created_at),
            "updated_at": _iso(self.updated_at),
        }

    @classmethod
    def from_item(cls, item: Dict[str, Any]) -> "MemoryEdge":
        return cls(
            root_session_id=item.get("root_session_id") or item.get("PK"),
            from_node_id=item.get("from_node_id") or (item.get("SK", "").split("#")[:1] or [""])[0],
            to_node_id=item.get("to_node_id") or (item.get("SK", "").split("#")[1] if "SK" in item else ""),
            relation=item.get("relation") or (item.get("SK", "").split("#")[2] if "SK" in item and len(item.get("SK", "").split("#")) > 2 else ""),
            tags=item.get("tags") or [],
            created_at=_from_iso(item.get("created_at")) or _utc_now(),
            updated_at=_from_iso(item.get("updated_at")) or _utc_now(),
        )
