from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional

from .logging_utils import get_logger

logger = get_logger(__name__)


_STRUCTURED_PATTERN = re.compile(
    r'entity\s*=\s*(?P<entity>\S+)\s+type\s*=\s*(?P<type>\S+)\s+fact\s*=\s*(?P<fact>"[^"]+"|\S+)',
    re.IGNORECASE,
)


def _structured_candidates_from_events(events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Deterministic extraction for structured 'entity= type= fact=' strings."""
    by_key: Dict[tuple, Dict[str, Any]] = {}
    for evt in events or []:
        if not isinstance(evt, dict):
            continue
        content = str(evt.get("content") or "")
        match = _STRUCTURED_PATTERN.search(content)
        if not match:
            continue
        entity = match.group("entity")
        type_ = match.group("type")
        raw_fact = match.group("fact") or ""
        # Strip surrounding quotes and trailing punctuation while retaining inner spaces/content.
        fact = raw_fact.strip().strip('"').rstrip(".,; ").strip()
        event_id = evt.get("event_id")
        key = (entity, type_, fact)
        cand = by_key.get(key)
        if not cand:
            cand = {
                "entity": entity,
                "type": type_,
                "fact": fact,
                "confidence": 1.0,
                "source_event_ids": [],
                "structured_parse_used": True,
                "llm_fallback_used": False,
                "tags": ["extraction:structured"],
            }
            by_key[key] = cand
        if event_id and event_id not in cand["source_event_ids"]:
            cand["source_event_ids"].append(event_id)
        # Ensure tags persist if multiple events map to the same candidate.
        tags = set(cand.get("tags") or [])
        tags.add("extraction:structured")
        cand["tags"] = sorted(tags)
    return list(by_key.values())


def build_context_window(
    *,
    transcript_body: str,
    recent_events: Optional[List[Dict[str, Any]]] = None,
    anchor_event_ids: Optional[List[str]] = None,
) -> str:
    """Build a simple context window anchored on specific event_ids."""
    lines = []
    if recent_events:
        for evt in recent_events:
            if isinstance(evt, dict):
                eid = evt.get("event_id")
                content = evt.get("content", "")
            else:
                eid = getattr(evt, "event_id", None)
                content = getattr(evt, "content", "")
            lines.append(f"[recent] {eid}: {content}")
    if transcript_body:
        for raw in transcript_body.splitlines():
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue
            eid = data.get("event_id")
            if anchor_event_ids and eid not in anchor_event_ids:
                continue
            lines.append(f"[transcript] {eid}: {data.get('content','')}")
    return "\n".join(lines)


def call_extraction_llm(prompt: str, llm_client: Any) -> List[Dict[str, Any]]:
    """Invoke the extraction model with the prompt."""
    if hasattr(llm_client, "extract_memories"):
        return llm_client.extract_memories(prompt)
    raise RuntimeError("LLM client does not implement extract_memories")


def handle_extraction_message(
    *,
    message: Dict[str, Any],
    s3_client: Any,
    branch_state: Any,
    llm_client: Any,
    settings: Any = None,
) -> List[Dict[str, Any]]:
    """Process an extraction work item and return candidate memories."""
    root_session_id = message.get("root_session_id")
    session_id = message.get("session_id")
    user_event_id = message.get("user_event_id")
    assistant_event_id = message.get("assistant_event_id")
    transcript_key = message.get("transcript_key")
    transcript_bucket = (
        message.get("transcript_bucket")
        or getattr(settings, "transcript_bucket", None)
        or getattr(settings, "TRANSCRIPT_BUCKET", None)
    )
    anchor_ids = [eid for eid in [user_event_id, assistant_event_id] if eid]

    raw_recent_events = getattr(branch_state, "recent_events", None) or []
    recent_events = []
    for evt in raw_recent_events:
        if hasattr(evt, "to_dict"):
            recent_events.append(evt.to_dict())
        elif isinstance(evt, dict):
            recent_events.append(evt)
        else:
            recent_events.append({})
    transcript_body = ""
    transcript_events: List[Dict[str, Any]] = []
    if s3_client and transcript_key and transcript_bucket:
        resp = s3_client.get_object(Bucket=transcript_bucket, Key=transcript_key)
        body = resp.get("Body")
        transcript_body = body.read().decode("utf-8") if body else ""
        if transcript_body:
            for raw in transcript_body.splitlines():
                if not raw:
                    continue
                try:
                    data = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                eid = data.get("event_id")
                if anchor_ids and eid not in anchor_ids:
                    continue
                transcript_events.append(data)

    prompt = build_context_window(
        transcript_body=transcript_body,
        recent_events=recent_events,
        anchor_event_ids=anchor_ids,
    )

    # Attach transcript events (anchored) for downstream consolidation validation.
    if transcript_events:
        events_by_id = {evt.get("event_id"): evt for evt in transcript_events if evt.get("event_id")}
        for evt in recent_events:
            eid = evt.get("event_id")
            if eid and eid not in events_by_id:
                transcript_events.append(evt)
        message["transcript_events"] = transcript_events
    elif recent_events:
        message["transcript_events"] = recent_events

    structured_source: List[Dict[str, Any]] = []
    if message.get("transcript_events"):
        structured_source.extend(message["transcript_events"])
    if recent_events:
        structured_source.extend(recent_events)
    if transcript_events:
        structured_source.extend(transcript_events)
    # Deduplicate by event_id if present.
    if structured_source:
        seen_ids = set()
        uniq_events = []
        for evt in structured_source:
            eid = evt.get("event_id") if isinstance(evt, dict) else None
            if eid and eid in seen_ids:
                continue
            if eid:
                seen_ids.add(eid)
            uniq_events.append(evt if isinstance(evt, dict) else {})
        structured = _structured_candidates_from_events(uniq_events)
    else:
        structured = []
    if structured:
        logger.info(
            "extraction_structured_candidates",
            extra={
                "stage": "extraction",
                "status": "structured",
                "candidate_count": len(structured),
                "root_session_id": root_session_id,
                "session_id": session_id,
            },
        )
        return structured

    logger.info(
        "extraction_start",
        extra={
            "stage": "extraction",
            "status": "start",
            "root_session_id": root_session_id,
            "session_id": session_id,
        },
    )
    try:
        candidates = call_extraction_llm(prompt=prompt, llm_client=llm_client)
    except Exception:
        logger.error(
            "extraction_error",
            extra={
                "stage": "extraction",
                "status": "error",
                "root_session_id": root_session_id,
                "session_id": session_id,
            },
            exc_info=True,
        )
        raise

    candidates = candidates or []
    for cand in candidates:
        # Mark fallback mode deterministically for telemetry/tagging.
        cand.setdefault("structured_parse_used", False)
        cand.setdefault("llm_fallback_used", True)
        tags = set(cand.get("tags") or [])
        tags.add("extraction:llm_fallback")
        cand["tags"] = sorted(tags)
    if not candidates:
        logger.info(
            "extraction_no_candidates",
            extra={
                "stage": "extraction",
                "status": "noop",
                "root_session_id": root_session_id,
                "session_id": session_id,
            },
        )
        return []

    logger.info(
        "extraction_complete",
        extra={
            "stage": "extraction",
            "status": "ok",
            "root_session_id": root_session_id,
            "session_id": session_id,
            "candidate_count": len(candidates),
        },
    )
    return candidates
