from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Dict

import boto3
from botocore.config import Config as BotoConfig

from .config import Settings


def compute_dedupe_key(root_session_id: str, session_id: str, assistant_event_id: str) -> str:
    h = hashlib.sha256()
    h.update(root_session_id.encode("utf-8"))
    h.update(b"|")
    h.update(session_id.encode("utf-8"))
    h.update(b"|")
    h.update(assistant_event_id.encode("utf-8"))
    return h.hexdigest()


def build_graph_payload(
    *,
    root_session_id: str,
    session_id: str,
    user_event_id: str,
    assistant_event_id: str,
    sequence_start: int,
    sequence_end: int,
    transcript_key: str,
) -> Dict[str, Any]:
    dedupe_key = compute_dedupe_key(root_session_id, session_id, assistant_event_id)
    return {
        "root_session_id": root_session_id,
        "session_id": session_id,
        "user_event_id": user_event_id,
        "assistant_event_id": assistant_event_id,
        "sequence_start": sequence_start,
        "sequence_end": sequence_end,
        "transcript_key": transcript_key,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "dedupe_key": dedupe_key,
    }


def enqueue_graph_job(settings: Settings, payload: Dict[str, Any]) -> None:
    """Send the graph pipeline payload to the configured SQS FIFO queue."""
    if not settings.graph_events_queue_url:
        raise ValueError("GRAPH_EVENTS_QUEUE_URL is not configured")
    client = boto3.client(
        "sqs",
        region_name=settings.aws_region,
        config=BotoConfig(retries={"max_attempts": 5, "mode": "standard"}),
    )
    body = json.dumps(payload)
    client.send_message(
        QueueUrl=settings.graph_events_queue_url,
        MessageBody=body,
        MessageGroupId=payload["root_session_id"],
        MessageDeduplicationId=payload["dedupe_key"],
    )
