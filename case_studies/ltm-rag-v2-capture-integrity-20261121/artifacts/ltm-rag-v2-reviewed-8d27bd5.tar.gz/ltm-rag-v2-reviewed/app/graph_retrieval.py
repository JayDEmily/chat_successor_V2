from __future__ import annotations

from typing import Any, Dict, List, Tuple

from .logging_utils import get_logger
from .graph_models import MemoryNode
from .graph_store import get_memory_nodes_table
from boto3.dynamodb.conditions import Key  # type: ignore[import]
from openai import OpenAI

logger = get_logger(__name__)


def load_graph_memory(
    settings: Any,
    root_session_id: str,
    session_id: str,
    entity_hint: str | None = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Fetch active facts and histories for a root/session."""
    table = get_memory_nodes_table(settings)
    resp = table.query(KeyConditionExpression=Key("PK").eq(root_session_id), ConsistentRead=True)
    items = resp.get("Items") or []
    # Exclude marker rows (e.g., SK starts with "_marker#") from retrieval.
    items = [i for i in items if not str(i.get("SK", "")).startswith("_marker#")]
    nodes: List[MemoryNode] = [MemoryNode.from_item(i) for i in items]

    if session_id:
        scoped: List[MemoryNode] = []
        for node in nodes:
            # Backward compatibility: nodes without source_session_ids are treated as applicable to all sessions.
            if node.source_session_ids and session_id not in node.source_session_ids:
                continue
            scoped.append(node)
        nodes = scoped

    if entity_hint:
        nodes = [n for n in nodes if n.entity == entity_hint]

    active_states = {"active", "reopened"}
    facts: Dict[tuple, MemoryNode] = {}
    history: Dict[str, List[Dict[str, Any]]] = {}

    for node in nodes:
        key = (node.entity, node.type)
        if node.entity not in history:
            history[node.entity] = []
        history[node.entity].append(
            {
                "fact": node.fact,
                "state": node.state,
                "valid_from": node.valid_from.isoformat(),
                "valid_to": node.valid_to.isoformat() if node.valid_to else None,
                "updated_at": node.updated_at.isoformat(),
                "source_event_ids": list(node.source_event_ids),
                "supersedes": list(node.supersedes),
                "superseded_by": node.superseded_by,
                "history_reason": node.history_reason,
            }
        )
        if node.state in active_states:
            # keep the most recently updated node per entity/type
            existing = facts.get(key)
            if not existing or node.updated_at > existing.updated_at:
                facts[key] = node

    # Sort history entries by updated_at
    for entries in history.values():
        entries.sort(key=lambda e: e.get("updated_at") or "")

    fact_list: List[Dict[str, Any]] = []
    for node in facts.values():
        fact_list.append(
            {
                "entity": node.entity,
                "type": node.type,
                "fact": node.fact,
                "state": node.state,
                "confidence": node.confidence,
                "updated_at": node.updated_at.isoformat(),
                "valid_from": node.valid_from.isoformat() if node.valid_from else None,
                "valid_to": node.valid_to.isoformat() if node.valid_to else None,
                "source_event_ids": list(node.source_event_ids),
                "supersedes": list(node.supersedes),
                "superseded_by": node.superseded_by,
                "tags": list(node.tags),
            }
        )

    return fact_list, history


def search_graph_memory_vector(
    settings: Any,
    root_session_id: str,
    session_id: str,
    query_text: str,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Optional semantic search over graph facts."""
    query_text = (query_text or "").strip()
    if not query_text:
        return [], {}

    client = OpenAI(api_key=settings.openai_api_key)
    clauses: List[Dict[str, Any]] = [
        {"type": "eq", "key": "root_session_id", "value": root_session_id},
        {"type": "eq", "key": "kind", "value": "graph_fact"},
    ]
    # Keep search scoped to root; session filter optional
    filters = {"type": "and", "filters": clauses}

    resp = client.vector_stores.search(
        vector_store_id=settings.openai_vector_store_id,
        query=query_text,
        filters=filters,
        max_num_results=6,
    )
    facts: List[Dict[str, Any]] = []
    history: Dict[str, List[Dict[str, Any]]] = {}
    for item in resp.data:
        text = " ".join(
            c.text for c in item.content if getattr(c, "type", "") == "text"
        )
        meta = item.attributes or {}
        entity = meta.get("entity")
        type_ = meta.get("type")
        updated_at = meta.get("updated_at")
        facts.append(
            {
                "entity": entity,
                "type": type_,
                "fact": text or meta.get("fact") or "",
                "state": meta.get("state", "active"),
                "confidence": float(item.score or 0.0),
                "updated_at": updated_at,
                "source_event_ids": meta.get("source_event_ids") or [],
            }
        )
        if entity:
            history.setdefault(entity, []).append(
                {
                    "fact": text or meta.get("fact") or "",
                    "state": meta.get("state", "active"),
                    "updated_at": updated_at,
                    "supersedes": meta.get("supersedes") or [],
                    "superseded_by": meta.get("superseded_by"),
                    "source_event_ids": meta.get("source_event_ids") or [],
                }
            )

    for entries in history.values():
        entries.sort(key=lambda e: e.get("updated_at") or "")
    return facts, history
