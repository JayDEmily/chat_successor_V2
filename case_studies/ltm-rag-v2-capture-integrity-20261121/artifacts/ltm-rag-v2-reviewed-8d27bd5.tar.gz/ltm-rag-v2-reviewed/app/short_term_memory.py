from __future__ import annotations

from typing import Iterable, List

from .llm_client import LLMClient
from .logging_utils import get_logger
from .models import BranchState, Event


# Conservative defaults; tune via config if needed.
RECENT_EVENTS_MAX = 40
SUMMARY_MIN_TURNS = 6
logger = get_logger(__name__)


def _should_refresh_summary(state: BranchState) -> bool:
    """Return True if the rolling summary for this branch should be updated.

    We use a simple heuristic based on the number of turns since the last
    summary update and the size of the recent_events buffer.
    """
    if len(state.recent_events) >= RECENT_EVENTS_MAX:
        return True
    if state.summary_turns_since_update >= SUMMARY_MIN_TURNS:
        return True
    return False


def _build_history_text(events: List[Event]) -> str:
    """Render recent events into a plain-text conversation transcript.

    This text is fed to the summariser; we keep it simple and robust.
    """
    lines: List[str] = []
    for e in events:
        prefix = f"{e.role.upper()}:"
        lines.append(f"{prefix} {e.content}")
    return "\n".join(lines)


def update_branch_state_with_events(
    llm: LLMClient,
    state: BranchState,
    new_events: Iterable[Event],
) -> None:
    """Update a BranchState in response to new events.

    This function is called from the post-phase. It:
        * appends new events to recent_events,
        * increments the summary_turns_since_update counter,
        * optionally refreshes the short_summary using the LLM when
          thresholds are crossed,
        * trims recent_events so it does not grow unbounded.
    """
    events_list = list(new_events)
    for e in events_list:
        state.recent_events.append(e)
        if e.role == "assistant":
            state.summary_turns_since_update += 1

    logger.debug(
        "short_term_memory_ingest",
        extra={
            "stage": "short_term_memory",
            "status": "ingest",
            "new_event_count": len(events_list),
            "recent_events_count": len(state.recent_events),
            "summary_turns_since_update": state.summary_turns_since_update,
        },
    )

    refresh = _should_refresh_summary(state)
    logger.debug(
        "short_term_summary_decision",
        extra={
            "stage": "short_term_memory",
            "status": "decision",
            "should_refresh": refresh,
            "recent_events_count": len(state.recent_events),
            "summary_turns_since_update": state.summary_turns_since_update,
        },
    )

    if refresh:
        history_text = _build_history_text(state.recent_events)
        summary = llm.summarise(history_text)
        if summary:
            state.short_summary = summary
            state.summary_turns_since_update = 0
            # After summarising, keep only the tail of the conversation.
            state.recent_events = state.recent_events[-RECENT_EVENTS_MAX :]
            logger.debug(
                "short_term_summary_refreshed",
                extra={
                    "stage": "short_term_memory",
                    "status": "summary_refreshed",
                    "summary_length": len(summary),
                    "recent_events_count": len(state.recent_events),
                },
            )
        else:
            # If the summariser returned an empty string, avoid resetting
            # the existing summary; just stop the counter from exploding.
            state.summary_turns_since_update = 0
            logger.debug(
                "short_term_summary_empty",
                extra={
                    "stage": "short_term_memory",
                    "status": "summary_empty",
                    "recent_events_count": len(state.recent_events),
                },
            )
    else:
        # Keep the buffer bounded even if we didn't summarise.
        if len(state.recent_events) > RECENT_EVENTS_MAX:
            state.recent_events = state.recent_events[-RECENT_EVENTS_MAX :]
            logger.debug(
                "short_term_memory_trimmed",
                extra={
                    "stage": "short_term_memory",
                    "status": "trimmed",
                    "recent_events_count": len(state.recent_events),
                },
            )
