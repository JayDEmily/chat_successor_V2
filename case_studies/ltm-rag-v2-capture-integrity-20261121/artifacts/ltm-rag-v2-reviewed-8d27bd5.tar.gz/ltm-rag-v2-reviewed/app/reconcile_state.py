from __future__ import annotations

import json
from typing import Iterable, List

from .llm_client import LLMClient
from .models import BranchState, Event
from .short_term_memory import RECENT_EVENTS_MAX, _build_history_text


def reconcile_branch_state_from_transcript(
    root_session_id: str,
    session_id: str,
    transcript_lines: Iterable[str],
    *,
    llm: LLMClient | None = None,
    summarise: bool = True,
) -> BranchState:
    """Rebuild a BranchState from a transcript JSONL stream.

    This is an operational helper for cases where DynamoDB state is missing
    or stale but S3 transcripts remain authoritative. It parses transcript
    lines into Events, filters to the requested branch, rebuilds the
    recent_events buffer, recomputes next_sequence, and optionally refreshes
    short_summary using the provided LLMClient. It does not perform any
    persistence; callers should write the returned BranchState to DynamoDB.
    """
    events: List[Event] = []
    for line in transcript_lines:
        line = (line or "").strip()
        if not line:
            continue
        data = json.loads(line)
        evt = Event.from_dict(data)
        if evt.root_session_id == root_session_id and evt.session_id == session_id:
            events.append(evt)

    events = sorted(events, key=lambda e: e.sequence)
    state = BranchState(root_session_id=root_session_id, session_id=session_id)
    state.recent_events = events[-RECENT_EVENTS_MAX :]
    state.next_sequence = (max((e.sequence for e in events), default=-1) + 1)
    state.summary_turns_since_update = 0

    if summarise and llm:
        history_text = _build_history_text(events)
        state.short_summary = llm.summarise(history_text) or None

    return state
