from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .graph_models import MemoryNode
from .graph_store import load_marker, save_marker
from .logging_utils import get_logger
from . import graph_consolidation

logger = get_logger(__name__)


def persist_node(node_store: Any, node: MemoryNode) -> None:
    """Persist node via provided store abstraction."""
    if node_store is None:
        return
    if hasattr(node_store, "put_node"):
        node_store.put_node(node)
    elif hasattr(node_store, "upsert"):
        node_store.upsert(node)
    elif hasattr(node_store, "nodes"):
        node_store.nodes[node.node_id] = node
    else:
        raise RuntimeError("No persistence path for node_store")


def upload_graph_fact(vector_store: Any, node: MemoryNode) -> None:
    if vector_store is None:
        return
    if hasattr(vector_store, "upload"):
        vector_store.upload(node)


def parse_consolidation_payload(message: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract candidate list from message; separated for test hooks."""
    candidates = message.get("candidates")
    if candidates is None:
        return []
    if not isinstance(candidates, list):
        raise ValueError("candidates payload malformed")
    return candidates


def handle_consolidation_message(
    *,
    message: Dict[str, Any],
    node_store: Any,
    vector_store: Any,
    logger: Any = logger,
    now: Optional[datetime] = None,
    settings: Any = None,
) -> None:
    """Process consolidation work item."""
    ts = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    root_session_id = message.get("root_session_id")
    session_id = message.get("session_id")
    sequence_end = int(message.get("sequence_end", -1))

    # Marker check
    if node_store and hasattr(node_store, "get_marker"):
        last_seq = node_store.get_marker(root_session_id, session_id) or -1
    elif settings:
        last_seq = load_marker(settings, root_session_id, session_id)
    else:
        last_seq = -1

    if last_seq >= 0 and sequence_end <= last_seq:
        logger.info(
            "consolidation_skip_already_processed",
            extra={
                "stage": "consolidation",
                "status": "skip",
                "root_session_id": root_session_id,
                "session_id": session_id,
                "last_processed_sequence": last_seq,
            },
        )
        return

    candidates = parse_consolidation_payload(message) or []
    if not candidates:
        logger.info(
            "consolidation_no_candidates",
            extra={
                "stage": "consolidation",
                "status": "noop",
                "root_session_id": root_session_id,
                "session_id": session_id,
            },
        )
        if node_store and hasattr(node_store, "update_marker"):
            node_store.update_marker(root_session_id, session_id, sequence_end)
        elif settings:
            save_marker(settings, root_session_id, session_id, sequence_end)
        return

    new_nodes, updated_nodes = graph_consolidation.consolidate_candidates(
        store=node_store,
        candidates=candidates,
        root_session_id=root_session_id,
        session_id=session_id,
        now=ts,
    )

    # Safety net: ensure superseded nodes are marked even if upstream mutation fails.
    supersede_map = {}
    for node in new_nodes:
        for sid in node.supersedes:
            supersede_map[sid] = node.node_id
    if supersede_map:
        for node in updated_nodes:
            superseded_by = supersede_map.get(node.node_id)
            if superseded_by:
                node.state = "superseded"
                node.superseded_by = superseded_by
                node.valid_to = ts
                node.updated_at = ts

    # Validate evidence linkage to transcript events if provided.
    transcript_events = message.get("transcript_events") or []
    transcript_ids = {evt.get("event_id") for evt in transcript_events}
    for node in new_nodes:
        if node.source_event_ids and transcript_ids:
            if not set(node.source_event_ids).issubset(transcript_ids):
                logger.warning(
                    "consolidation_source_event_mismatch",
                    extra={
                        "stage": "consolidation",
                        "status": "warning",
                        "root_session_id": root_session_id,
                        "session_id": session_id,
                        "node_id": node.node_id,
                    },
                )

    for node in updated_nodes:
        persist_node(node_store, node)
    # Write new nodes after superseded/reopened nodes are persisted to avoid
    # transient reads where a new fact is visible before the prior fact is
    # marked superseded.
    for node in new_nodes:
        persist_node(node_store, node)
        upload_graph_fact(vector_store, node)

    if node_store and hasattr(node_store, "update_marker"):
        node_store.update_marker(root_session_id, session_id, sequence_end)
    elif settings:
        save_marker(settings, root_session_id, session_id, sequence_end)

    logger.info(
        "consolidation_complete",
        extra={
            "stage": "consolidation",
            "status": "ok",
            "root_session_id": root_session_id,
            "session_id": session_id,
            "new_nodes": len(new_nodes),
        },
    )
