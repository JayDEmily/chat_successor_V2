from __future__ import annotations

import time
import uuid

from openai import OpenAI

from .aws_clients import get_dynamodb_table, get_s3_client
from .config import Settings, load_settings
from .graph_healthcheck import run_graph_healthcheck
from .llm_client import LLMClient
from .logging_utils import get_logger, update_request_context

logger = get_logger(__name__)


def run_healthcheck() -> None:
    """Run startup health checks.

    Called once per cold start (Lambda) or process start to fail-fast on
    misconfiguration or connectivity. Loads Settings (env presence, embedding
    dimension map, backend/vector store rules), checks DynamoDB + S3 reachability,
    validates the OpenAI vector store when enabled, and optionally exercises
    minimal embedding + summary calls when HEALTHCHECK_LLM_CALLS is true.
    """
    logger.info("healthcheck_start", extra={"stage": "healthcheck", "status": "start"})
    settings: Settings = load_settings()
    key_prefix = settings.openai_api_key[:7] if settings.openai_api_key else ""
    key_suffix = settings.openai_api_key[-4:] if settings.openai_api_key else ""
    logger.info(
        "healthcheck_openai_config",
        extra={
            "stage": "healthcheck",
            "component": "openai_config",
            "openai_key_present": bool(settings.openai_api_key),
            "openai_key_length": len(settings.openai_api_key or ""),
            "openai_key_prefix": key_prefix,
            "openai_key_suffix": key_suffix,
            "openai_vector_store_id": settings.openai_vector_store_id,
        },
    )
    update_request_context({"backend": settings.semantic_backend})

    # Validate AWS resources
    start = time.monotonic()
    table = get_dynamodb_table(settings)
    table.load()
    logger.info(
        "healthcheck_dynamo_ok",
        extra={
            "stage": "healthcheck",
            "component": "dynamodb",
            "status": "ok",
            "duration_ms": int((time.monotonic() - start) * 1000),
        },
    )

    start = time.monotonic()
    s3 = get_s3_client(settings)
    s3.list_objects_v2(Bucket=settings.transcript_bucket, MaxKeys=1)
    logger.info(
        "healthcheck_s3_ok",
        extra={
            "stage": "healthcheck",
            "component": "s3",
            "status": "ok",
            "duration_ms": int((time.monotonic() - start) * 1000),
        },
    )

    if settings.healthcheck_write_probes:
        probe_id = f"healthcheck-{uuid.uuid4()}"
        table.put_item(Item={"PK": "healthcheck", "SK": probe_id, "ttl": int(time.time())})
        table.delete_item(Key={"PK": "healthcheck", "SK": probe_id})
        key = f"healthcheck/{probe_id}.txt"
        s3.put_object(Bucket=settings.transcript_bucket, Key=key, Body=b"ok")
        s3.delete_object(Bucket=settings.transcript_bucket, Key=key)
        logger.info(
            "healthcheck_write_probe_ok",
            extra={
                "stage": "healthcheck",
                "component": "write_probe",
                "status": "ok",
            },
        )

    if settings.semantic_backend == "openai":
        start = time.monotonic()
        client = OpenAI(api_key=settings.openai_api_key)
        # Lightweight check to ensure vector store is reachable.
        if settings.openai_vector_store_id:
            store = client.vector_stores.retrieve(settings.openai_vector_store_id)
        else:
            store = None
        logger.info(
            "healthcheck_vector_store_ok",
            extra={
                "stage": "healthcheck",
                "component": "vector_store",
                "status": "ok",
                "duration_ms": int((time.monotonic() - start) * 1000),
            },
        )
        store_model = None
        if store is not None:
            store_model = getattr(store, "embedding_model", None)
            if store_model is None and hasattr(store, "embedding_configuration"):
                store_model = getattr(store.embedding_configuration, "model", None)
        if store_model and store_model != settings.embedding_model:
            logger.warning(
                "embedding_model_mismatch",
                extra={
                    "stage": "healthcheck",
                    "component": "vector_store",
                    "status": "warning",
                    "store_embedding_model": store_model,
                    "configured_embedding_model": settings.embedding_model,
                },
            )

    # Validate LLM configuration by making cheap dry-run calls.
    if settings.healthcheck_llm_calls:
        start = time.monotonic()
        llm = LLMClient(settings)
        _ = llm.embed("healthcheck")
        _ = llm.summarise("User: hello\nAssistant: hi")
        logger.info(
            "healthcheck_llm_ok",
            extra={
                "stage": "healthcheck",
                "component": "llm",
                "status": "ok",
                "duration_ms": int((time.monotonic() - start) * 1000),
            },
        )

    # Optional graph resources when enabled.
    if getattr(settings, "graph_enabled", False):
        start = time.monotonic()
        run_graph_healthcheck()
        logger.info(
            "healthcheck_graph_ok",
            extra={
                "stage": "healthcheck",
                "component": "graph",
                "status": "ok",
                "duration_ms": int((time.monotonic() - start) * 1000),
            },
        )

    logger.info("healthcheck_complete", extra={"stage": "healthcheck", "status": "ok"})
