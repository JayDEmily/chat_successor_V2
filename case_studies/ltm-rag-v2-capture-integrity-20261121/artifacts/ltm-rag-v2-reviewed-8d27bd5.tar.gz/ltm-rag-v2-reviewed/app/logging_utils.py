from __future__ import annotations

import json
import logging
import os
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any, Dict, Iterable

# Context shared across a single logical request (Lambda invocation or MCP call).
_request_context: ContextVar[Dict[str, Any]] = ContextVar("request_context", default={})
_LOGGING_CONFIGURED = False

# Keys that should always be redacted if encountered in a dict payload.
_SECRET_KEYS = {"api_key", "openai_api_key", "authorization", "password", "token", "secret"}


def _utc_now_iso() -> str:
    """Return an ISO-8601 UTC timestamp string."""
    return datetime.now(timezone.utc).isoformat()


def _redact_value(value: Any) -> Any:
    """Redact likely secret values.

    Strings containing common secret markers (e.g. 'sk-') are replaced with a
    placeholder. Dicts with secret-looking keys have their values redacted.
    """
    if isinstance(value, str):
        if "sk-" in value or "api_key" in value.lower():
            return "[REDACTED]"
        return value
    if isinstance(value, dict):
        return {k: ("[REDACTED]" if k.lower() in _SECRET_KEYS else _redact_value(v)) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return type(value)(_redact_value(v) for v in value)
    return value


def redact_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of the payload with common secret patterns removed."""
    return {k: (_redact_value(v) if k.lower() not in _SECRET_KEYS else "[REDACTED]") for k, v in payload.items()}


class JsonFormatter(logging.Formatter):
    """Structured JSON formatter suitable for CloudWatch single-line logs."""

    def format(self, record: logging.LogRecord) -> str:
        data: Dict[str, Any] = {
            "timestamp": _utc_now_iso(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Merge request-scoped context.
        data.update(_request_context.get())

        # Include extra fields from the record (stage/status/etc.).
        skip_keys = {
            "name",
            "msg",
            "args",
            "levelname",
            "levelno",
            "pathname",
            "filename",
            "module",
            "exc_info",
            "exc_text",
            "stack_info",
            "lineno",
            "funcName",
            "created",
            "msecs",
            "relativeCreated",
            "thread",
            "threadName",
            "processName",
            "process",
        }
        for key, value in record.__dict__.items():
            if key in skip_keys:
                continue
            if value is None:
                continue
            # Allow request-scoped context to take precedence.
            if key not in data:
                data[key] = value

        # Attach exception info in a safe, redacted form if present.
        if record.exc_info:
            data["exc_type"] = record.exc_info[0].__name__
            data["exc_message"] = str(record.exc_info[1])

        safe_data = redact_payload(data)
        try:
            return json.dumps(safe_data, ensure_ascii=False)
        except TypeError:
            # Fallback to a stringified version if some value is not JSON-serialisable.
            return json.dumps({k: str(v) for k, v in safe_data.items()}, ensure_ascii=False)


def init_logging(log_level: str | None = None) -> None:
    """Configure root logger with JSON formatting once per process.

    The log level may be provided directly or via LOG_LEVEL env var (default INFO).
    """
    global _LOGGING_CONFIGURED
    if _LOGGING_CONFIGURED:
        return

    level_name = (log_level or os.getenv("LOG_LEVEL") or "INFO").upper()
    level = getattr(logging, level_name, logging.INFO)

    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())

    root = logging.getLogger()
    root.setLevel(level)
    # Avoid duplicate handlers if init_logging is called repeatedly.
    root.handlers = [handler]

    _LOGGING_CONFIGURED = True


def get_logger(name: str = "memory_agent") -> logging.Logger:
    """Return a logger configured with the JSON formatter."""
    if not _LOGGING_CONFIGURED:
        init_logging()
    return logging.getLogger(name)


@contextmanager
def request_context(**fields: Any):
    """Context manager to seed or extend request-scoped logging fields."""
    ctx = _request_context.get().copy()
    ctx.update({k: v for k, v in fields.items() if v is not None})
    token = _request_context.set(ctx)
    try:
        yield
    finally:
        _request_context.reset(token)


def update_request_context(updates: Dict[str, Any]) -> None:
    """Merge additional fields into the current request context."""
    ctx = _request_context.get().copy()
    ctx.update({k: v for k, v in updates.items() if v is not None})
    _request_context.set(ctx)


def current_request_context() -> Dict[str, Any]:
    """Return a shallow copy of the current request context."""
    return _request_context.get().copy()
